/**
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  WEEKLY-EDITABLE REPORT DATA — this is the ONLY file you edit each week.  │
 * │  It contains NO logic. Editing it cannot break windowing or metrics.      │
 * │  Everything else in the report (Salesforce, Campaign Monitor, ClickUp)    │
 * │  is fully automatic — do not touch report.ts to update weekly numbers.    │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * Two things to update each Friday:
 *   1. MANUAL_GA4   — the numbers you read off the GA4 screenshots
 *   2. AUTOMATION_LOG — the free-text Automation & Project Work list
 *
 * See the `/update-weekly-report` skill for the guided procedure.
 */

import type { GA4Metrics } from './integrations/ga4';

// ---------------------------------------------------------------------------
// Types (kept here so this file is self-contained)
// ---------------------------------------------------------------------------

export interface AutomationEntry {
  text: string;
  tag: string;
  status?: 'LIVE' | 'DONE' | 'IN PROGRESS' | 'NEW' | 'NEEDS';
}

export interface AutomationSection {
  periodLabel: string;
  entries: AutomationEntry[];
}

export interface ManualGa4 {
  current: GA4Metrics;
  prior: GA4Metrics;
}

// ===========================================================================
// 1) MANUAL GA4  ── edit these numbers each week ───────────────────────────
// ===========================================================================
//
// Read from GA4 (property 433530724) for the two windows the report shows:
//   • current = Saturday–Friday (7 days, incl. weekend)
//   • prior   = the previous Monday–Friday (5 days)
//
// Each week: move last week's `current` block down into `prior`, then type the
// new screenshot numbers into `current`. (The `/update-weekly-report` skill
// does this roll-forward for you.)
//
// Field guide (all numbers, no commas):
//   activeUsers            — "Active users"
//   newUsers               — "New users"
//   sessions               — "Sessions"
//   screenPageViews        — "Views" / "Page views"
//   keyEvents              — "Key events" (conversions)
//   avgEngagementPerUserSec— "Average engagement time per active user", IN SECONDS
//                            (e.g. 2m 22s → 142). userEngagementDuration is then
//                            auto-derived as activeUsers × that value.
//
// Set MANUAL_GA4 to `null` to hide the traffic section entirely.
// The moment GA4_SA_JSON is set in the environment, live data overrides all of
// this automatically — no code change needed.
// ---------------------------------------------------------------------------

const CURRENT_ACTIVE_USERS = 217;
const CURRENT_ENGAGEMENT_SEC = 142; // 2m 22s

export const MANUAL_GA4: ManualGa4 | null = {
  current: {
    activeUsers: CURRENT_ACTIVE_USERS,
    newUsers: 169,
    sessions: 345,
    screenPageViews: 1000,
    keyEvents: 81,
    avgEngagementPerUserSec: CURRENT_ENGAGEMENT_SEC,
    userEngagementDuration: CURRENT_ACTIVE_USERS * CURRENT_ENGAGEMENT_SEC,
  },
  prior: {
    activeUsers: 228,
    newUsers: 132,
    sessions: 293,
    screenPageViews: 801,
    keyEvents: 50,
    avgEngagementPerUserSec: 0, // was "—" in the source report
    userEngagementDuration: 0,
  },
};

// ===========================================================================
// 2) AUTOMATION & PROJECT WORK  ── current week only ───────────────────────
// ===========================================================================
//
// Rules:
//   • ONE entry per real item — never cluster several items into one bullet.
//   • `status` is optional: LIVE | DONE | IN PROGRESS | NEW | NEEDS.
//   • Do NOT include work done by Cristi (attribute clearly if it must appear).
//   • Update `periodLabel` to the current work week (e.g. "Jun 29 – Jul 3, 2026").
// ---------------------------------------------------------------------------

export const AUTOMATION_LOG: AutomationSection = {
  periodLabel: 'Jun 28 – Jul 3, 2026',
  entries: [
    { text: 'Automated the weekly marketing report — website traffic, email, and new-listing numbers now update live in one dashboard (7/2)', tag: 'Automation & Systems', status: 'DONE' },
    { text: 'Weekly report — made it a one-step update: drop in the analytics screenshot and it refreshes itself (7/2)', tag: 'Automation & Systems', status: 'DONE' },
    { text: 'Built the leadership transition & knowledge-handoff plan — SOPs, systems/access map, and a 30/60/90 onboarding roadmap (7/2)', tag: 'Transition & Handoff', status: 'DONE' },
    { text: 'Analytics brought in-house — set up Google Analytics 4 and Search Console under a Fausto-owned account so all website data is centralized and company-owned (7/2)', tag: 'Website · Analytics', status: 'DONE' },
    { text: 'Onboarded the new web contractor — provisioned Cloudways and WordPress admin access to begin website support (7/2)', tag: 'Website · Vendor', status: 'DONE' },
    { text: 'Website listing audit — ran automated audits and delivered two cleanup lists (with photo links) to speed up publishing listings to the site (6/29–6/30)', tag: 'Website · Listings', status: 'DONE' },
    { text: 'Website drafts cleanup — flagged previously-closed listings among the draft pages and aligned a keep-as-history strategy to reduce reliance on LoopNet (6/30)', tag: 'Website · Listings', status: 'IN PROGRESS' },
    { text: 'EAM | Foundation Impact 1-pager — revised and re-sent the updated version for leadership review (6/29)', tag: 'PR & Brand Assets', status: 'DONE' },
    { text: 'EAM | Wellness for a Cause — began preparing the July 6 raffle-prize and sponsor-announcement e-blast (6/30)', tag: 'Email Marketing', status: 'IN PROGRESS' },
    { text: 'Reviewed and provided design corrections on the "Donate for Venezuela" e-blast (6/29)', tag: 'Design Reviews', status: 'DONE' },
  ],
};
