/**
 * Bulk-revert the May 2026 auto-publish fallout back to draft.
 *
 * Background
 *   Between ~May 5-11, the SF→WP sync handler had a bug where ANY SF field
 *   update on a Property__c record (including agent-review submissions
 *   appending to Notes_for_Marketing__c) caused the handler to push
 *   `status='publish'` to WP, force-promoting drafts the team hadn't yet
 *   finished curating. ~119 posts went live without their featured image
 *   and without final marketing copy.
 *
 *   The bug is fixed (sf-property-changed.ts now refuses to auto-promote
 *   drafts), so this is a one-time cleanup to restore draft state on the
 *   affected posts.
 *
 * Filter (all must hold):
 *   - status == 'publish'
 *   - featured_media == 0   (no featured image)
 *   - date starts with '2026-05'
 *   - title does NOT start with '[DUPLICATE'  (those were handled separately)
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/wp-revert-may-publishes.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/wp-revert-may-publishes.ts
 *
 * Non-destructive: only changes `status` from 'publish' to 'draft'.
 * Title, body, address, price, agent, and all other fields are untouched.
 */

import { updatePropertyPost } from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 150;

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  modified: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function fetchPublishedPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (let page = 1; page <= 20; page++) {
    const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=publish&context=edit&_fields=id,date,modified,status,title,fave_property_address,featured_media`;
    const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
    if (!res.ok) {
      throw new Error(`WP fetch failed: ${res.status} ${await res.text()}`);
    }
    const batch = (await res.json()) as any[];
    if (!Array.isArray(batch) || batch.length === 0) break;
    for (const p of batch) {
      out.push({
        id: p.id,
        date: p.date || '',
        modified: p.modified || '',
        status: p.status || '',
        title: (p.title?.rendered || p.title || '').toString(),
        fave_property_address: p.fave_property_address || '',
        featured_media: p.featured_media || 0,
      });
    }
    if (batch.length < 100) break;
  }
  return out;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP_USER or WP_APP_PASSWORD env vars.');
    process.exit(1);
  }

  console.log(`\n🔙 Revert May 2026 auto-published posts to draft ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  // ---------------------------------------------------------------------------
  // 1. Pull all published posts, filter for the May-bug pattern
  // ---------------------------------------------------------------------------
  console.log('→ Fetching all published property posts...');
  const all = await fetchPublishedPosts();
  console.log(`   ${all.length} published posts total`);

  const targets = all.filter(
    (p) =>
      p.featured_media === 0 &&
      p.date.startsWith('2026-05') &&
      !p.title.startsWith('[DUPLICATE')
  );
  console.log(
    `   ${targets.length} match revert criteria (publish + no_photo + May 2026 + not [DUPLICATE])`
  );

  if (targets.length === 0) {
    console.log('\nNothing to do. Exiting.');
    process.exit(0);
  }

  // Sort by date asc for chronology
  targets.sort((a, b) => a.date.localeCompare(b.date));

  // Show what we'd change
  console.log('\n── Posts to revert ──');
  for (const p of targets) {
    const modifiedNote =
      p.date.slice(0, 10) !== p.modified.slice(0, 10) ? ' [edited after publish]' : '';
    console.log(
      `   wp:${p.id}  ${p.date.slice(0, 10)}${modifiedNote}  "${p.title.slice(0, 70)}"`
    );
  }

  if (DRY_RUN) {
    console.log(`\n[DRY RUN] Would revert ${targets.length} posts to draft. No changes made.\n`);
    process.exit(0);
  }

  // ---------------------------------------------------------------------------
  // 2. Revert each to draft
  // ---------------------------------------------------------------------------
  console.log(`\n→ Reverting ${targets.length} posts to draft...`);
  let ok = 0;
  let err = 0;
  for (const p of targets) {
    const result = await updatePropertyPost(p.id, { status: 'draft' });
    if (result.ok) {
      ok++;
      if (ok % 25 === 0) {
        console.log(`   ...${ok}/${targets.length} reverted`);
      }
    } else {
      err++;
      console.warn(`   ❌ wp:${p.id}: ${result.error}`);
    }
    await sleep(REQUEST_DELAY_MS);
  }

  // ---------------------------------------------------------------------------
  // 3. Summary
  // ---------------------------------------------------------------------------
  console.log('\n=== Summary ===');
  console.log(`Reverted to draft:   ${ok}`);
  console.log(`Failures:            ${err}`);
  console.log('');

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Revert crashed:', err);
  process.exit(1);
});
