/**
 * Reconcile Fausto's authoritative agent->group list (Excel, 2026-05-20)
 * against the live Salesforce `Group__c` table.
 *
 * Source: data/agent-groups-fausto-2026-05-20.json (snapshot of Fausto's Excel)
 *
 * Surfaces:
 *   1. Exact matches             (Excel name == SF Group__c.Name verbatim)
 *   2. Fuzzy matches             (case/whitespace/punctuation variant in SF)
 *   3. Orphans                   (Excel group has NO SF match at all)
 *   4. SF-side duplicate clusters (multiple SF rows that normalize to same key)
 *   5. SF-only groups             (group exists in SF but no agent claims it
 *                                  in Fausto's Excel)
 *
 * Writes:
 *   data/agent-group-reconcile-2026-05-20.txt  (human-readable report)
 *   data/agent-group-reconcile-2026-05-20.json (structured for downstream use)
 *
 * Read-only against Salesforce. Standing approval per memory.
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-reconcile.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-reconcile.ts --target dev
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const SNAPSHOT_PATH = path.join(
  REPO_ROOT,
  'data',
  'agent-groups-fausto-2026-05-20.json'
);
const REPORT_TXT = path.join(
  REPO_ROOT,
  'data',
  'agent-group-reconcile-2026-05-20.txt'
);
const REPORT_JSON = path.join(
  REPO_ROOT,
  'data',
  'agent-group-reconcile-2026-05-20.json'
);

interface SnapshotAssignment {
  agent: string;
  group: string;
}

interface Snapshot {
  source: string;
  file: string;
  received_date: string;
  assignments: SnapshotAssignment[];
  agents_without_groups: string[];
}

interface SfGroup {
  Id: string;
  Name: string;
}

interface SfLeadGroupCount {
  Group__c: string;
  cnt: number;
}

/** lowercase + strip everything that isn't a letter or digit */
function normalize(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, '');
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';

async function main() {
  console.log(`\n🔍 Agent-group reconciliation  (target=${TARGET})\n`);

  // ---- Load snapshot ------------------------------------------------------
  if (!fs.existsSync(SNAPSHOT_PATH)) {
    console.error(`❌ Snapshot not found: ${SNAPSHOT_PATH}`);
    process.exit(1);
  }
  const snapshot: Snapshot = JSON.parse(fs.readFileSync(SNAPSHOT_PATH, 'utf8'));
  console.log(`Loaded snapshot: ${snapshot.assignments.length} (agent,group) pairs`);

  // Excel-side group name → set of agents claiming it (preserve first-seen casing)
  const excelGroupsByName = new Map<string, Set<string>>();
  for (const a of snapshot.assignments) {
    const existing = excelGroupsByName.get(a.group);
    if (existing) existing.add(a.agent);
    else excelGroupsByName.set(a.group, new Set([a.agent]));
  }
  console.log(`  ${excelGroupsByName.size} distinct group names from Excel\n`);

  // ---- Pull SF ------------------------------------------------------------
  const sf = await sfClient(TARGET);
  console.log(`Connected to ${sf.instance}`);

  console.log('Pulling Group__c records...');
  const sfGroups = await sf.soql<SfGroup>(`SELECT Id, Name FROM Group__c`);
  console.log(`  ${sfGroups.length} Group__c records in SF`);

  console.log('Pulling Lead group counts...');
  const leadCounts = await sf.soql<SfLeadGroupCount>(
    `SELECT Group__c, COUNT(Id) cnt FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const leadCountById = new Map<string, number>(
    leadCounts.map((r) => [r.Group__c, r.cnt])
  );
  const totalLeadsInGroups = leadCounts.reduce((s, r) => s + r.cnt, 0);
  console.log(`  ${leadCounts.length} groups have at least one Lead (${totalLeadsInGroups} leads total)\n`);

  // ---- Index SF by exact name and normalized key --------------------------
  const sfByExactName = new Map<string, SfGroup[]>();
  const sfByNormKey = new Map<string, SfGroup[]>();
  for (const g of sfGroups) {
    const name = (g.Name || '').trim();
    const norm = normalize(name);
    if (!sfByExactName.has(name)) sfByExactName.set(name, []);
    sfByExactName.get(name)!.push(g);
    if (!sfByNormKey.has(norm)) sfByNormKey.set(norm, []);
    sfByNormKey.get(norm)!.push(g);
  }

  // ---- Categorize Excel groups --------------------------------------------
  interface ExcelGroupResult {
    excelName: string;
    agents: string[];
    matchType: 'exact' | 'fuzzy' | 'orphan';
    sfMatches: Array<{ id: string; name: string; leads: number }>;
  }
  const results: ExcelGroupResult[] = [];
  const matchedSfIds = new Set<string>();

  for (const [excelName, agentSet] of excelGroupsByName) {
    const agents = [...agentSet].sort();
    const exact = sfByExactName.get(excelName) || [];
    if (exact.length > 0) {
      const sfMatches = exact.map((g) => ({
        id: g.Id,
        name: g.Name,
        leads: leadCountById.get(g.Id) || 0,
      }));
      for (const g of exact) matchedSfIds.add(g.Id);
      results.push({ excelName, agents, matchType: 'exact', sfMatches });
      continue;
    }
    const norm = normalize(excelName);
    const fuzzy = sfByNormKey.get(norm) || [];
    if (fuzzy.length > 0) {
      const sfMatches = fuzzy.map((g) => ({
        id: g.Id,
        name: g.Name,
        leads: leadCountById.get(g.Id) || 0,
      }));
      for (const g of fuzzy) matchedSfIds.add(g.Id);
      results.push({ excelName, agents, matchType: 'fuzzy', sfMatches });
      continue;
    }
    results.push({ excelName, agents, matchType: 'orphan', sfMatches: [] });
  }

  // ---- SF-side duplicate clusters (>1 SF row sharing normalized key) ------
  interface SfDupCluster {
    normKey: string;
    rows: Array<{ id: string; name: string; leads: number }>;
    inExcel: boolean;
  }
  const sfDupClusters: SfDupCluster[] = [];
  for (const [normKey, rows] of sfByNormKey) {
    if (rows.length < 2) continue;
    const inExcel = rows.some((r) => excelGroupsByName.has(r.Name));
    sfDupClusters.push({
      normKey,
      rows: rows.map((g) => ({
        id: g.Id,
        name: g.Name,
        leads: leadCountById.get(g.Id) || 0,
      })),
      inExcel,
    });
  }
  // Sort: clusters that intersect Excel first, then by total leads desc
  sfDupClusters.sort((a, b) => {
    if (a.inExcel !== b.inExcel) return a.inExcel ? -1 : 1;
    const al = a.rows.reduce((s, r) => s + r.leads, 0);
    const bl = b.rows.reduce((s, r) => s + r.leads, 0);
    return bl - al;
  });

  // ---- SF-only groups (in SF, not claimed by anyone in Excel) -------------
  // Use normalized matching so we don't double-report fuzzy hits.
  const excelNormKeys = new Set(
    [...excelGroupsByName.keys()].map((n) => normalize(n))
  );
  const sfOnly: Array<{ id: string; name: string; leads: number }> = [];
  for (const g of sfGroups) {
    if (excelNormKeys.has(normalize(g.Name || ''))) continue;
    sfOnly.push({
      id: g.Id,
      name: g.Name,
      leads: leadCountById.get(g.Id) || 0,
    });
  }
  sfOnly.sort((a, b) => b.leads - a.leads || a.name.localeCompare(b.name));

  // ---- Render text report -------------------------------------------------
  const lines: string[] = [];
  const exactCount = results.filter((r) => r.matchType === 'exact').length;
  const fuzzyCount = results.filter((r) => r.matchType === 'fuzzy').length;
  const orphanCount = results.filter((r) => r.matchType === 'orphan').length;

  lines.push('AGENT-GROUP RECONCILIATION');
  lines.push(`Source: ${snapshot.file} (received ${snapshot.received_date})`);
  lines.push(`Target: Salesforce ${TARGET}`);
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push('');
  lines.push('─── SUMMARY ───');
  lines.push(`Excel distinct groups:    ${excelGroupsByName.size}`);
  lines.push(`  ✅ Exact in SF:         ${exactCount}`);
  lines.push(`  ⚠️  Fuzzy match in SF:   ${fuzzyCount}`);
  lines.push(`  ❌ Orphans (no match):  ${orphanCount}`);
  lines.push(`SF Group__c records:      ${sfGroups.length}`);
  lines.push(`  🔁 Duplicate clusters:  ${sfDupClusters.length}`);
  lines.push(`  👻 Not in Excel:        ${sfOnly.length}`);
  lines.push(`Agents w/ empty groups:   ${snapshot.agents_without_groups.length} (${snapshot.agents_without_groups.join(', ')})`);
  lines.push('');

  // 1. Exact matches — just list them compactly
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`✅ EXACT MATCHES (${exactCount})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  for (const r of results.filter((r) => r.matchType === 'exact')) {
    const sfLeads = r.sfMatches.reduce((s, m) => s + m.leads, 0);
    lines.push(
      `  ${r.excelName.padEnd(30)}  agents=[${r.agents.join(', ')}]  leads=${sfLeads}`
    );
  }
  lines.push('');

  // 2. Fuzzy matches — Excel name + the SF row it landed on
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`⚠️  FUZZY MATCHES — confirm canonical name (${fuzzyCount})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('Excel name → SF Name(s) [leads]   |   agents');
  lines.push('-------------------------------------------------------------------');
  for (const r of results.filter((r) => r.matchType === 'fuzzy')) {
    const sfDesc = r.sfMatches
      .map((m) => `"${m.name}" [${m.leads}]`)
      .join('  ·  ');
    lines.push(`  "${r.excelName}"`);
    lines.push(`     → ${sfDesc}`);
    lines.push(`     agents: ${r.agents.join(', ')}`);
  }
  lines.push('');

  // 3. Orphans — Excel name + agents who claim it
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`❌ ORPHANS — no SF Group__c match (${orphanCount})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('Excel group name   |   agents');
  lines.push('-------------------------------------------------------------------');
  for (const r of results.filter((r) => r.matchType === 'orphan')) {
    lines.push(`  "${r.excelName}"  ←  ${r.agents.join(', ')}`);
  }
  lines.push('');

  // 4. SF duplicate clusters
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`🔁 SF DUPLICATE CLUSTERS (${sfDupClusters.length})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('Multiple Group__c records that normalize to the same key.');
  lines.push('Pick a canonical name and merge or delete the others.');
  lines.push('Clusters that intersect Fausto\'s Excel are shown first.');
  lines.push('-------------------------------------------------------------------');
  for (const c of sfDupClusters) {
    const tag = c.inExcel ? '[claimed in Excel]' : '[SF-only]';
    lines.push(`  cluster key="${c.normKey}"  ${tag}`);
    for (const r of c.rows) {
      lines.push(`     • ${r.id}  "${r.name}"  leads=${r.leads}`);
    }
    lines.push('');
  }
  if (sfDupClusters.length === 0) lines.push('  (none)\n');

  // 5. SF-only — group exists in SF but no agent claims it
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`👻 SF-ONLY GROUPS — exist in SF, nobody in Excel claims them (${sfOnly.length})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('Candidates for archive, or agents missing from Fausto\'s list.');
  lines.push('Sorted by lead count desc (most-used first).');
  lines.push('-------------------------------------------------------------------');
  for (const g of sfOnly) {
    lines.push(`  ${g.id}  "${g.name}"  leads=${g.leads}`);
  }
  lines.push('');

  fs.writeFileSync(REPORT_TXT, lines.join('\n'));
  fs.writeFileSync(
    REPORT_JSON,
    JSON.stringify(
      {
        generated_at: new Date().toISOString(),
        target: TARGET,
        snapshot_file: path.basename(SNAPSHOT_PATH),
        summary: {
          excel_distinct_groups: excelGroupsByName.size,
          exact_matches: exactCount,
          fuzzy_matches: fuzzyCount,
          orphans: orphanCount,
          sf_group_records: sfGroups.length,
          sf_duplicate_clusters: sfDupClusters.length,
          sf_only_groups: sfOnly.length,
          agents_without_groups: snapshot.agents_without_groups,
        },
        results,
        sf_duplicate_clusters: sfDupClusters,
        sf_only_groups: sfOnly,
      },
      null,
      2
    )
  );

  console.log(`\n📄 Wrote ${path.relative(REPO_ROOT, REPORT_TXT)}`);
  console.log(`📄 Wrote ${path.relative(REPO_ROOT, REPORT_JSON)}\n`);
  console.log(
    `Exact=${exactCount}  Fuzzy=${fuzzyCount}  Orphans=${orphanCount}  SF-dups=${sfDupClusters.length}  SF-only=${sfOnly.length}\n`
  );
}

function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        out[key] = next;
        i++;
      } else {
        out[key] = true;
      }
    }
  }
  return out;
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
