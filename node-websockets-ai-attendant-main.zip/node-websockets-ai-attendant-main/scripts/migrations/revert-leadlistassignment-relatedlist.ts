/**
 * Revert the Lead_List_Assignment__c.Lead__c related list addition to the
 * commercial Lead Layouts. Turns out the Lightning Record Page "Leads"
 * already has this related list (added by Jesus yesterday with custom
 * columns), so the Page Layout add was creating a duplicate in admin's view.
 *
 * Idempotent.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const TARGET_RELATIONSHIP = 'Lead_List_Assignment__c.Lead__c';
const TARGET_LAYOUTS = ['Lead Layout'];

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  const layouts: any[] = await (sf as any).toolingQuery(
    `SELECT Id, Name FROM Layout WHERE EntityDefinition.QualifiedApiName = 'Lead'`
  );
  for (const l of layouts) {
    if (!TARGET_LAYOUTS.includes(l.Name)) { console.log(`SKIP: ${l.Name}`); continue; }
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);
    const full: any = await toolingGet(sf, 'Layout', l.Id);
    const meta = full.Metadata || {};
    const rls = (meta.relatedLists || []) as any[];
    const filtered = rls.filter((rl: any) => rl.relatedList !== TARGET_RELATIONSHIP);
    if (filtered.length === rls.length) { console.log(`  Already absent — skip`); continue; }
    console.log(`  Plan: REMOVE Lead_List_Assignment related list (${rls.length} → ${filtered.length})`);
    if (DRY) continue;
    await toolingPatch(sf, 'Layout', l.Id, {
      Metadata: { layoutSections: meta.layoutSections, relatedLists: filtered },
    });
    console.log(`  ✓ Reverted`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
