/**
 * Flyer route handler.
 *
 * Endpoints:
 *   GET /api/flyer/:sfPropertyId          — returns HTML preview (default)
 *   GET /api/flyer/:sfPropertyId?pdf=1    — returns PDF download (requires PDF backend)
 *
 * Auth: same shared secret as the SF webhook in `X-Auth` header, OR a signed
 * link from SF (we'll add that when we wire the SF formula button — for now
 * any non-public hosting + the secret is fine).
 *
 * SF integration: agents click a Hyperlink formula field on Property__c
 * that points at /api/flyer/:Id — the link includes the auth secret as a
 * query param (acceptable for short-lived links served behind HTTPS).
 */

import type { FastifyInstance } from 'fastify';
import { renderFlyerForProperty } from '../integrations/flyer';

export async function registerFlyerRoutes(app: FastifyInstance): Promise<void> {
  app.get<{
    Params: { sfPropertyId: string };
    Querystring: { pdf?: string; secret?: string };
  }>('/api/flyer/:sfPropertyId', async (req, reply) => {
    const { sfPropertyId } = req.params;
    const wantPdf = req.query.pdf === '1' || req.query.pdf === 'true';

    // Auth: header OR query param (so SF formula buttons can pass it via URL)
    const expected = process.env.FLYER_SHARED_SECRET || '';
    if (!expected) {
      app.log.error('FLYER_SHARED_SECRET not configured');
      return reply.code(503).send({ error: 'flyer_not_configured' });
    }
    const provided = req.headers['x-auth'] || req.query.secret;
    if (provided !== expected) {
      return reply.code(401).send({ error: 'unauthorized' });
    }

    if (!sfPropertyId || !sfPropertyId.startsWith('a0R')) {
      return reply.code(400).send({ error: 'invalid_sf_property_id' });
    }

    const result = await renderFlyerForProperty(
      sfPropertyId,
      wantPdf ? 'pdf' : 'html'
    );

    if (!result.ok) {
      return reply.code(500).send({ error: result.error });
    }

    if (wantPdf && result.pdfBuffer) {
      reply.header('Content-Type', 'application/pdf');
      reply.header(
        'Content-Disposition',
        `inline; filename="flyer-${sfPropertyId}.pdf"`
      );
      return reply.send(result.pdfBuffer);
    }

    reply.header('Content-Type', 'text/html; charset=utf-8');
    return reply.send(result.html);
  });
}
