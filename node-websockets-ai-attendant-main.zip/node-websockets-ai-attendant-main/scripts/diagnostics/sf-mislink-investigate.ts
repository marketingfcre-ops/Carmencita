/**
 * Investigate the 3 confirmed SF→WP mislinks.
 * For each SF record, search ALL WP posts for one whose address actually
 * matches SF.Address__c. Reports candidates so a human can confirm.
 *
 * Read-only. Doesn't change anything.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';
const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const TARGETS = [
  'a0RJw000008GimsMAC', // "700 SW 16th Ave"
  'a0RJw000008KCQDMA4', // "1395 NW 22 ST"
  'a0RJw000008c9AXMAY', // "2811 SW 3rd Ave"
];

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  City__c: string | null;
  WP_Post_ID__c: number | null;
  Status__c: string | null;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  fave_property_size: string;
  fave_property_price: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address,fave_property_size,fave_property_price`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
          fave_property_size: p.fave_property_size || '',
          fave_property_price: p.fave_property_price || '',
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/**
 * Stronger normalizer:
 *   - Skip non-numeric prefix tokens (building names like "Castle Beach Club")
 *   - If first comma-part is digits/range, consume next part as street name
 *   - Normalize all directions (north→n, northwest→nw, etc.)
 *   - Normalize street types (avenue→ave, etc.)
 *   - Strip ordinal suffixes (23rd → 23)
 *   - Strip city/state/zip tail
 *   - Fix known typos
 */
function strongNormalize(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().trim();

  // Skip a leading building-name segment if present: take from first digit onward
  const firstDigit = a.search(/\d/);
  if (firstDigit > 0) a = a.substring(firstDigit);

  // Split by comma
  const parts = a
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (parts.length === 0) return '';

  // Build street portion. If first chunk is digits/range, keep adding parts
  // until we have something containing letters (the street name).
  let streetPart = parts[0];
  let i = 1;
  while (i < parts.length && /^[\d\s\-#/]+$/.test(streetPart)) {
    streetPart = streetPart + ' ' + parts[i];
    i++;
  }

  let s = streetPart;
  s = s.replace(/[#.,/]/g, ' ');

  // For ranges like "504/520" or "2120-2130-2140", take just the FIRST number
  s = s.replace(/(\d+)[\s\-]+\d+([\s\-]+\d+)*/g, '$1');

  // Direction normalization — order matters (longer first)
  s = s.replace(/\bnorthwest\b/g, 'nw');
  s = s.replace(/\bnortheast\b/g, 'ne');
  s = s.replace(/\bsouthwest\b/g, 'sw');
  s = s.replace(/\bsoutheast\b/g, 'se');
  s = s.replace(/\bnorthwesr\b/g, 'nw'); // known typo
  s = s.replace(/\bnorth\b/g, 'n');
  s = s.replace(/\bsouth\b/g, 's');
  s = s.replace(/\beast\b/g, 'e');
  s = s.replace(/\bwest\b/g, 'w');

  // Street types
  s = s.replace(/\b(street|str)\b/g, 'st');
  s = s.replace(/\b(avenue|av)\b/g, 'ave');
  s = s.replace(/\b(boulevard|boul)\b/g, 'blvd');
  s = s.replace(/\broad\b/g, 'rd');
  s = s.replace(/\bdrive\b/g, 'dr');
  s = s.replace(/\bterrace\b/g, 'ter');
  s = s.replace(/\bcourt\b/g, 'ct');
  s = s.replace(/\bplace\b/g, 'pl');
  s = s.replace(/\bhighway\b/g, 'hwy');

  // Ordinal suffixes — including the "151th" typo case
  s = s.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');

  // Strip common geographic tail tokens
  s = s.replace(
    /\b(miami|miami-dade county|miami dade county|miami-dade|broward county|duval county|florida|fl|united states|hialeah|opa-locka|opalocka|jacksonville|dania beach|hollywood|north miami beach|miami beach|coral gables|miramar|fort lauderdale|lauderdale lakes|pompano beach|pompano|davie|deerfield beach|lake worth beach|west park|pembroke park|pembroke pines|hallandale beach|hallandale|medley|homestead|allapattah|wynwood|little havana|silver court trailer park|strawberry village trailer park|bay heights)\b/g,
    ''
  );
  s = s.replace(/\b\d{5}(-\d{4})?\b/g, ''); // zip codes

  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function snippet(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔎 Investigate 3 SF mislinks — find correct WP target for each\n');

  const { token, instance } = await sfAuth();
  const sfRecords = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, City__c, WP_Post_ID__c, Status__c
       FROM Property__c
      WHERE Id IN ('${TARGETS.join("','")}')`
  );

  const wp = await fetchAllWpPosts();
  console.log(`Loaded ${sfRecords.length} SF records, ${wp.length} WP posts.\n`);

  for (const sf of sfRecords) {
    console.log('═'.repeat(70));
    console.log(`SF ${sf.Id}`);
    console.log(`   Name:        ${sf.Name}`);
    console.log(`   Address__c:  "${sf.Address__c}"`);
    console.log(`   City__c:     ${sf.City__c}`);
    console.log(`   Status__c:   ${sf.Status__c}`);
    console.log(`   currently linked: wp:${sf.WP_Post_ID__c}`);
    console.log('═'.repeat(70));

    const sfNorm = strongNormalize(sf.Address__c);
    console.log(`SF address (normalized): "${sfNorm}"\n`);

    // Find candidate WP posts
    const exact: WpPost[] = [];
    const partial: WpPost[] = [];

    for (const p of wp) {
      const wpNorm = strongNormalize(p.fave_property_address);
      if (!wpNorm) continue;
      if (wpNorm === sfNorm) {
        exact.push(p);
      } else {
        // Partial: share house number AND at least one other token (street name)
        const sfTokens = new Set(sfNorm.split(' ').filter((t) => t.length > 1));
        const wpTokens = new Set(wpNorm.split(' ').filter((t) => t.length > 1));
        const shared = [...sfTokens].filter((t) => wpTokens.has(t));
        if (shared.length >= 2) partial.push(p);
      }
    }

    console.log(`Exact-match candidates: ${exact.length}`);
    for (const p of exact) {
      const flag = p.id === sf.WP_Post_ID__c ? ' ← currently linked' : '';
      console.log(`   wp:${p.id} ${p.status.padEnd(8)} ${p.date.slice(0, 10)}  "${snippet(p.title.replace(/&#8211;/g, '–'), 60)}"${flag}`);
      console.log(`     addr: "${p.fave_property_address}"`);
      console.log(`     size: ${p.fave_property_size}    price: ${p.fave_property_price}`);
    }

    console.log(`\nPartial-match candidates (share house # + street tokens): ${partial.length}`);
    for (const p of partial.slice(0, 8)) {
      console.log(`   wp:${p.id} ${p.status.padEnd(8)} ${p.date.slice(0, 10)}  "${snippet(p.title.replace(/&#8211;/g, '–'), 60)}"`);
      console.log(`     addr: "${snippet(p.fave_property_address, 70)}"`);
    }

    console.log('');
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
