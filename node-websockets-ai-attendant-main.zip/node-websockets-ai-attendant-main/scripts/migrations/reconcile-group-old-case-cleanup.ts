/**
 * Cleanup pass — fix case-variant misses from reconcile-group-old-to-group.ts.
 *
 * Salesforce SOQL GROUP BY is case-insensitive at the comparison level but
 * returns one specific case per group, so 'SURDEVRET' and 'SURDevRet' show up
 * as one row in the distinct query. The main reconcile then only links leads
 * whose Group_old2__c EXACTLY matches the returned case. This script catches
 * the leftovers by case-insensitive lookup:
 *
 *   1. Build a map { lowercase(name) → Group__c.Id } from all Group__c records
 *   2. Pull leads where Group__c=null AND Group_old2__c != null
 *   3. For each, lookup by lowercase(Group_old2__c). Update if matched.
 *
 * Idempotent. Dry-run by default.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/reconcile-group-old-case-cleanup.ts
 *   tsx --env-file .env.local scripts/migrations/reconcile-group-old-case-cleanup.ts --commit
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const OVERRIDES_PATH = path.join(REPO_ROOT, 'data', 'group-old-overrides.json');
const API_VERSION = '59.0';
const BATCH_SIZE = 200;

function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) { out[key] = next; i++; }
      else out[key] = true;
    }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';
const COMMIT = args.commit === true;

// Load overrides so we can build the same MERGE / NEW-name mapping as the
// main reconcile — text "SURDevRet" overrides to NEW:SURDEVRET, etc.
function loadOverrides(): { mergeTo: Map<string, string>; newName: Map<string, string>; skip: Set<string> } {
  const out = { mergeTo: new Map<string, string>(), newName: new Map<string, string>(), skip: new Set<string>() };
  if (!fs.existsSync(OVERRIDES_PATH)) return out;
  const raw = JSON.parse(fs.readFileSync(OVERRIDES_PATH, 'utf8')) as Record<string, string>;
  for (const [k, v] of Object.entries(raw)) {
    if (k.startsWith('_')) continue;
    if (v === 'SKIP') out.skip.add(k);
    else if (v.startsWith('MERGE:')) out.mergeTo.set(k, v.slice(6));
    else if (v.startsWith('NEW:')) out.newName.set(k, v.slice(4));
  }
  return out;
}

async function main() {
  console.log(`\n🧹 Case-variant cleanup for Group_old2 → Group__c reconciliation`);
  console.log(`   target: ${TARGET}`);
  console.log(`   mode:   ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  const overrides = loadOverrides();

  // Build lowercase → Group__c.Id and normalized-key → Group__c.Id maps from
  // every Group__c canonical. Normalized = lowercase + strip non-alphanumeric.
  // That catches whitespace variants like "Hialeah Com" → "HialeahCom".
  const normalize = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  console.log('Building Group__c name → Id maps...');
  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const groupByLowerName = new Map<string, string>();
  const groupByNormName = new Map<string, string>();
  for (const g of groups) {
    groupByLowerName.set(g.Name.toLowerCase(), g.Id);
    groupByNormName.set(normalize(g.Name), g.Id);
  }
  console.log(`  ${groups.length} canonicals (${groupByLowerName.size} case-insensitive, ${groupByNormName.size} normalized)`);

  // For each override, also add the override target's lowercase key → Id mapping
  // for case-variant text values. e.g. "SURDevRet" → NEW:SURDEVRET means a lead
  // with Group_old2 = "SURDevRet" should link to the Group__c whose Name is
  // "SURDEVRET". We do that lookup case-insensitively in groupByLowerName.
  // Map each override key (case-sensitive) → target canonical's Id via
  // lowercase name lookup.
  const overrideTargetId = new Map<string, string>(); // exact text → Group__c.Id
  for (const [text, canonicalName] of overrides.mergeTo) {
    const id = groupByLowerName.get(canonicalName.toLowerCase());
    if (id) overrideTargetId.set(text, id);
  }
  for (const [text, canonicalName] of overrides.newName) {
    const id = groupByLowerName.get(canonicalName.toLowerCase());
    if (id) overrideTargetId.set(text, id);
  }

  // Lowercase-keyed overrides too (so case variants of override keys work)
  const overrideTargetIdCi = new Map<string, string>();
  for (const [k, v] of overrideTargetId) overrideTargetIdCi.set(k.toLowerCase(), v);

  // Pull leads with Group__c=null AND Group_old2__c != null
  console.log('\nPulling leads with Group__c=null and Group_old2__c set...');
  const leads: any[] = await sf.soql(
    `SELECT Id, Group_old2__c FROM Lead WHERE Group__c = null AND Group_old2__c != null`
  );
  console.log(`  ${leads.length} candidate leads`);

  // Resolve each lead's Group_old2 to a Group__c.Id
  const batches: any[] = [];
  const unresolved = new Map<string, number>();
  let resolvedViaDirect = 0;
  let resolvedViaNorm = 0;
  let resolvedViaOverride = 0;
  let skipped = 0;

  for (const lead of leads) {
    const text = lead.Group_old2__c as string;
    const lower = text.toLowerCase();

    // SKIP'd by override (case-sensitive match only since SKIPs are exact)
    if (overrides.skip.has(text)) { skipped++; continue; }

    // 1. Direct canonical name match (case-insensitive)
    let cid = groupByLowerName.get(lower);
    if (cid) { resolvedViaDirect++; }
    else {
      // 2. Override-mapped target (case-insensitive on the override key)
      cid = overrideTargetIdCi.get(lower);
      if (cid) resolvedViaOverride++;
      else {
        // 3. Normalized match (strips whitespace + punctuation)
        cid = groupByNormName.get(normalize(text));
        if (cid) resolvedViaNorm++;
      }
    }

    if (cid) {
      batches.push({ attributes: { type: 'Lead' }, Id: lead.Id, Group__c: cid });
    } else {
      unresolved.set(text, (unresolved.get(text) || 0) + 1);
    }
  }

  console.log(`\n=== Resolution stats ===`);
  console.log(`  Direct canonical match: ${resolvedViaDirect}`);
  console.log(`  Via override map:       ${resolvedViaOverride}`);
  console.log(`  Via normalized match:   ${resolvedViaNorm}`);
  console.log(`  SKIP'd by override:     ${skipped}`);
  console.log(`  Still unresolved:       ${[...unresolved.values()].reduce((s, n) => s + n, 0)} leads across ${unresolved.size} distinct values`);

  if (unresolved.size > 0) {
    console.log(`\n=== Top 20 still-unresolved values ===`);
    const sorted = [...unresolved.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20);
    for (const [k, n] of sorted) console.log(`  "${k}"  →  ${n}`);
  }

  if (!COMMIT) {
    console.log(`\n🧪 Dry-run only. Would PATCH ${batches.length} leads. Re-run with --commit when ready.`);
    return;
  }

  console.log(`\nPhase 2: PATCHing ${batches.length} leads...`);
  let failed = 0;
  for (let off = 0; off < batches.length; off += BATCH_SIZE) {
    const chunk = batches.slice(off, off + BATCH_SIZE);
    const url = `${sf.instanceUrl}/services/data/v${API_VERSION}/composite/sobjects`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ allOrNone: false, records: chunk }),
    });
    if (!res.ok) {
      console.error(`Batch ${off}: ${res.status} ${await res.text()}`);
      failed += chunk.length;
      continue;
    }
    const results: any[] = await res.json();
    const f = results.filter((r) => !r.success).length;
    failed += f;
    console.log(`  [${Math.min(off + BATCH_SIZE, batches.length)}/${batches.length}] ${f > 0 ? `(${f} failed)` : 'ok'}`);
  }

  console.log(`\n✅ Cleanup complete. ${batches.length - failed} updated, ${failed} failed.`);
}

main().catch((e) => { console.error('💀 Crashed:', e); process.exit(1); });
