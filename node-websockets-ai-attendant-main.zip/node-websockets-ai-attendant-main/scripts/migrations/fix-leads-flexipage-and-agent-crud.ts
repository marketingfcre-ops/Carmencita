/**
 * Two fixes for the agent-vs-admin Lightning rendering problem:
 *
 * (a) Patch the "Leads" Lightning Record Page (FlexiPage 0M0Jw00000015aLKAQ)
 *     to replace `Record.Group_old2__c` with `Record.Group__c` everywhere it
 *     appears as a fieldInstance. The Page Layout edit from earlier was the
 *     right intent at the wrong layer — Lightning renders from this FlexiPage,
 *     which hardcodes field references.
 *
 * (b) Grant Account for Agents profile Read access to Lead_List_Assignment__c
 *     so when the related list shows, agents see the records rather than
 *     "Insufficient Privileges". Done via adding an ObjectPermissions row to
 *     the profile's underlying PermissionSet (PPS).
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const FLEXIPAGE_ID = '0M0Jw00000015aLKAQ';
const ACCOUNT_FOR_AGENTS_PPS = '0PSJw000000502bOAA';

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // ---------- (a) Patch FlexiPage "Leads" ----------
  console.log(`=== (a) FlexiPage ${FLEXIPAGE_ID} — replace Record.Group_old2__c with Record.Group__c ===`);
  const fp: any = await toolingGet(sf, 'FlexiPage', FLEXIPAGE_ID);
  const meta = fp.Metadata || {};

  // Deep-clone via JSON round-trip so we can mutate freely
  const newMeta = JSON.parse(JSON.stringify(meta));
  let swaps = 0;

  function walk(node: any) {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const x of node) walk(x); return; }
    if (typeof node.fieldItem === 'string' && node.fieldItem === 'Record.Group_old2__c') {
      node.fieldItem = 'Record.Group__c';
      swaps++;
    }
    for (const k of Object.keys(node)) {
      if (typeof node[k] === 'object') walk(node[k]);
    }
  }
  walk(newMeta);
  console.log(`  Field swaps planned: ${swaps}`);
  if (swaps === 0) console.log(`  (FlexiPage already clean — Group_old2 not referenced as a fieldItem)`);

  if (swaps > 0 && !DRY) {
    await toolingPatch(sf, 'FlexiPage', FLEXIPAGE_ID, { Metadata: newMeta });
    console.log(`  ✓ FlexiPage PATCHed.`);
  }

  // ---------- (b) Grant Account for Agents Read on Lead_List_Assignment__c ----------
  console.log(`\n=== (b) Grant Account for Agents Read on Lead_List_Assignment__c ===`);
  const existing: any[] = await (sf as any).soql(
    `SELECT Id, PermissionsRead FROM ObjectPermissions
     WHERE ParentId = '${ACCOUNT_FOR_AGENTS_PPS}' AND SobjectType = 'Lead_List_Assignment__c'`
  );
  if (existing.length) {
    console.log(`  Already has ObjectPermissions: Read=${existing[0].PermissionsRead}`);
    if (existing[0].PermissionsRead) { console.log(`  ✓ Already Read=true, skip`); }
    // Could PATCH to enable Read if false — skip for v1
  } else {
    console.log(`  Plan: CREATE ObjectPermissions on Account for Agents PPS (Read=true)`);
    if (!DRY) {
      const url = `${sf.instance}/services/data/v59.0/sobjects/ObjectPermissions/`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ParentId: ACCOUNT_FOR_AGENTS_PPS,
          SobjectType: 'Lead_List_Assignment__c',
          PermissionsRead: true,
          PermissionsCreate: false,
          PermissionsEdit: false,
          PermissionsDelete: false,
          PermissionsViewAllRecords: false,
          PermissionsModifyAllRecords: false,
        }),
      });
      const text = await res.text();
      if (!res.ok) { console.log(`  ✗ Failed: ${res.status} ${text.slice(0, 400)}`); }
      else console.log(`  ✓ Created: ${text}`);
    }
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
