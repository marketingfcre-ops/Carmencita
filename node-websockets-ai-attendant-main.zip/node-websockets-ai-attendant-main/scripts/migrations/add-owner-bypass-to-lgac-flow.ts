/**
 * Add owner-bypass to the Lead_Group_Access_Check Flow.
 *
 * Modifies the "Is Admin" decision's "Yes" rule to add a third condition:
 *   $Record.OwnerId == $User.Id
 *
 * And updates conditionLogic from "1 OR 2" to "1 OR 2 OR 3".
 *
 * Effect: the lead owner can always edit their own lead, regardless of group
 * access. This is in addition to existing bypasses (System Admin profile +
 * wildcard User_Group_Access row).
 *
 * Strategy:
 *   1. Snapshot current active Flow via Tooling API → save to sf-deploy/flows/
 *   2. Read its Metadata, modify the Is_Admin decision
 *   3. POST as a new Flow version (creates v4)
 *   4. Activate v4 via FlowDefinition PATCH
 *   5. Verify
 *
 * Dry-run by default.
 */
import fs from 'node:fs';
import path from 'node:path';
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const REPO_ROOT = path.resolve(__dirname, '..', '..');

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPost<T = any>(sf: SfClient, sobject: string, body: any): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`POST ${sobject} → ${res.status}: ${text.slice(0, 800)}`);
  return JSON.parse(text);
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // 1. Find the current Active version of Lead_Group_Access_Check
  const versions: any[] = await (sf as any).toolingQuery(
    `SELECT Id, VersionNumber, Status FROM Flow
     WHERE Definition.DeveloperName = 'Lead_Group_Access_Check'
     ORDER BY VersionNumber DESC`
  );
  console.log(`Found ${versions.length} Flow version(s):`);
  for (const v of versions) console.log(`  v${v.VersionNumber}  ${v.Status}  ${v.Id}`);

  const active = versions.find((v: any) => v.Status === 'Active');
  if (!active) { console.error('No active version found'); process.exit(1); }
  console.log(`\nActive: v${active.VersionNumber} (${active.Id})`);

  // 2. Pull full Metadata
  const full: any = await toolingGet(sf, 'Flow', active.Id);
  const meta = full.Metadata;
  console.log(`Snapshot — saving to sf-deploy/flows/...`);
  const snapshotPath = path.join(REPO_ROOT, 'sf-deploy', 'flows', `Lead_Group_Access_Check-PRE-OWNER-BYPASS.json`);
  fs.writeFileSync(snapshotPath, JSON.stringify({
    snapshotted_at: new Date().toISOString(),
    flow_version_id: active.Id,
    flow_version_number: active.VersionNumber,
    Metadata: meta,
  }, null, 2));
  console.log(`  ${path.relative(REPO_ROOT, snapshotPath)}`);

  // 3. Modify the Is_Admin decision
  const newMeta = JSON.parse(JSON.stringify(meta)); // deep clone
  const isAdmin = (newMeta.decisions || []).find((d: any) => d.name === 'Is_Admin');
  if (!isAdmin) { console.error('Is_Admin decision not found in Flow metadata'); process.exit(1); }
  const yesRule = (isAdmin.rules || []).find((r: any) => r.name === 'Yes');
  if (!yesRule) { console.error('Is_Admin / Yes rule not found'); process.exit(1); }

  console.log(`\nCurrent Is_Admin/Yes conditionLogic: "${yesRule.conditionLogic}"`);
  console.log(`Current conditions count: ${(yesRule.conditions || []).length}`);

  // Already has owner-bypass?
  const alreadyHas = (yesRule.conditions || []).some((c: any) =>
    c.leftValueReference === '$Record.OwnerId' && c.rightValue?.elementReference === '$User.Id'
  );
  if (alreadyHas) {
    console.log('  ✓ Owner bypass already present — nothing to do');
    return;
  }

  const ownerCondition = {
    conditionType: null,
    leftValueReference: '$Record.OwnerId',
    operator: 'EqualTo',
    processMetadataValues: [],
    rightValue: {
      apexValue: null,
      booleanValue: null,
      dateTimeValue: null,
      dateValue: null,
      elementReference: '$User.Id',
      formulaDataType: null,
      formulaExpression: null,
      numberValue: null,
      setupReference: null,
      setupReferenceType: null,
      sobjectValue: null,
      stringValue: null,
    },
  };

  yesRule.conditions = [...(yesRule.conditions || []), ownerCondition];
  const n = yesRule.conditions.length;
  yesRule.conditionLogic = Array.from({ length: n }, (_, i) => `${i + 1}`).join(' OR ');
  console.log(`New conditionLogic: "${yesRule.conditionLogic}"`);
  console.log(`New conditions count: ${n}`);

  // Update description to note the change
  newMeta.description = (newMeta.description || '') + ' [v4: owner-bypass added 2026-06-10]';

  if (DRY) {
    console.log('\nDry-run complete. Re-run with --apply.');
    return;
  }

  // 4. POST as new Flow version — Tooling auto-versions if we pass FullName
  // matching the existing definition with no version suffix. But duplicate
  // errors fire because Salesforce wants a versioned suffix. Try a few formats.
  console.log('\nCreating new Flow version via Tooling API...');
  let created: any = null;
  const newVersionNum = (active.VersionNumber || 3) + 1;
  const attempts = [
    // Most common pattern: just Metadata, no FullName at all
    { body: { Metadata: newMeta }, label: 'Metadata only' },
    // With versioned FullName
    { body: { Metadata: newMeta, FullName: `Lead_Group_Access_Check-${newVersionNum}` }, label: `FullName=Lead_Group_Access_Check-${newVersionNum}` },
  ];
  let lastErr = '';
  for (const attempt of attempts) {
    try {
      console.log(`  Attempt: ${attempt.label}`);
      created = await toolingPost(sf, 'Flow', attempt.body);
      console.log(`  ✓ Created: ${JSON.stringify(created)}`);
      break;
    } catch (e: any) {
      lastErr = e.message;
      console.log(`    failed: ${e.message?.slice(0, 200)}`);
    }
  }
  if (!created) { console.error(`All attempts failed. Last error: ${lastErr}`); process.exit(1); }

  // 5. Activate the new version via FlowDefinition update
  // Find the FlowDefinition (DurableId / Id)
  const defs: any[] = await (sf as any).toolingQuery(
    `SELECT Id, DeveloperName FROM FlowDefinition WHERE DeveloperName = 'Lead_Group_Access_Check'`
  );
  if (!defs.length) { console.error('FlowDefinition not found'); process.exit(1); }
  const fdId = defs[0].Id;

  // Get the new version number (the one we just created)
  const newVersions: any[] = await (sf as any).toolingQuery(
    `SELECT Id, VersionNumber FROM Flow
     WHERE Definition.DeveloperName = 'Lead_Group_Access_Check'
     ORDER BY VersionNumber DESC LIMIT 3`
  );
  const newestVersion = newVersions[0]?.VersionNumber;
  console.log(`\nNewest Flow version is now: v${newestVersion}`);

  console.log('Activating new version via FlowDefinition PATCH...');
  await toolingPatch(sf, 'FlowDefinition', fdId, {
    Metadata: { activeVersionNumber: newestVersion },
  });
  console.log(`  ✓ Activated v${newestVersion}`);

  // 6. Verify
  console.log('\nVerifying...');
  const after: any[] = await (sf as any).toolingQuery(
    `SELECT VersionNumber, Status FROM Flow
     WHERE Definition.DeveloperName = 'Lead_Group_Access_Check' ORDER BY VersionNumber DESC`
  );
  for (const v of after) console.log(`  v${v.VersionNumber}  ${v.Status}`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
