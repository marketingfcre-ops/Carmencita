/**
 * Read-only feasibility check for the "hidden / restricted-view list" work.
 *
 * The validation Flow we built restricts EDITS. Truly hiding records (view
 * restriction) needs OWD=Private + sharing rules — and whether that's even
 * available depends on the org's edition. This checks the load-bearing facts
 * before we promise Fausto anything.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/sharing-feasibility-check.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Edition — decides which sharing features are even available.
  console.log('=== Org edition ===');
  const org: any[] = await sf.soql(`SELECT Name, OrganizationType, IsSandbox FROM Organization`);
  for (const o of org) console.log(`  ${o.Name}  ·  ${o.OrganizationType}  ·  sandbox=${o.IsSandbox}`);

  // 2. Lead OWD (the thing that would have to flip to Private to hide anything).
  console.log('\n=== Lead Org-Wide Default (sharing model) ===');
  const ent: any[] = await sf.toolingQuery(
    `SELECT QualifiedApiName, InternalSharingModel, ExternalSharingModel FROM EntityDefinition WHERE QualifiedApiName = 'Lead'`
  ).catch((e: any) => { console.log('  (tooling query failed: ' + e.message + ')'); return []; });
  for (const e of ent) console.log(`  Lead  internal=${e.InternalSharingModel}  external=${e.ExternalSharingModel}`);

  // 3. Existing public groups (the buckets we'd add agents to for sharing rules).
  console.log('\n=== Existing public groups (Type=Regular) ===');
  const groups: any[] = await sf.soql(
    `SELECT Id, Name, DeveloperName FROM Group WHERE Type = 'Regular' ORDER BY Name`
  );
  if (!groups.length) console.log('  (none — would all be created from scratch)');
  for (const g of groups.slice(0, 30)) console.log(`  ${g.DeveloperName}  "${g.Name}"`);
  if (groups.length > 30) console.log(`  ...and ${groups.length - 30} more`);

  // 4. Any existing Lead sharing rules already in place?
  console.log('\n=== Existing Lead sharing rules ===');
  const crit: any[] = await sf.toolingQuery(
    `SELECT DeveloperName, Label FROM LeadCriteriaBasedSharingRule`
  ).catch((e: any) => { console.log('  criteria-based: query failed → ' + e.message); return []; });
  console.log(`  criteria-based rules: ${crit.length}`);
  for (const r of crit) console.log(`    ${r.DeveloperName}  "${r.Label}"`);
  const owned: any[] = await sf.toolingQuery(
    `SELECT DeveloperName, Label FROM LeadOwnerSharingRule`
  ).catch((e: any) => { console.log('  ownership-based: query failed → ' + e.message); return []; });
  console.log(`  ownership-based rules: ${owned.length}`);

  // 5. The validation Flow's current state (edit-restriction we already built).
  console.log('\n=== Lead_Group_Access_Check flow state ===');
  const flows: any[] = await sf.toolingQuery(
    `SELECT ActiveVersionId, DeveloperName, Description FROM FlowDefinition WHERE DeveloperName = 'Lead_Group_Access_Check'`
  ).catch((e: any) => { console.log('  (query failed: ' + e.message + ')'); return []; });
  for (const f of flows) console.log(`  ${f.DeveloperName}  active=${f.ActiveVersionId ? 'YES' : 'NO (inactive)'}`);
  if (!flows.length) console.log('  (flow not found by that name)');
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
