/**
 * Deepgram Flux — Conversational Speech Recognition via raw WebSocket.
 *
 * Uses the /v2/listen API with native turn detection:
 *   - EagerEndOfTurn → fast-trigger (replaces isThoughtComplete heuristics)
 *   - EndOfTurn      → definitive respond (replaces UtteranceEnd)
 *   - StartOfTurn    → barge-in signal (replaces word-count logic)
 *   - TurnResumed    → cancel speculative response (new!)
 *   - Update         → partial transcript for language detection
 *
 * No SDK upgrade needed — this speaks the WebSocket protocol directly.
 */

import WebSocket from 'ws';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface FluxWord {
  word: string;
  confidence: number;
}

export type FluxEventType =
  | 'Update'
  | 'StartOfTurn'
  | 'EagerEndOfTurn'
  | 'TurnResumed'
  | 'EndOfTurn';

export interface FluxTurnEvent {
  event: FluxEventType;
  turnIndex: number;
  transcript: string;
  words: FluxWord[];
  confidence: number; // end_of_turn_confidence
}

export interface FluxConfig {
  encoding?: string;
  sampleRate?: number;
  eotThreshold?: number;       // 0.5–0.9, default 0.7
  eagerEotThreshold?: number;  // 0.3–0.9, default disabled
  eotTimeoutMs?: number;       // 500–10000, default 5000
  keyterms?: string[];         // "warehouse:2", "Miami:2", etc.
  model?: string;              // default "flux-general-multi" (EN+ES+8 others)
  languageHints?: string[];    // BCP-47 codes for multilingual; only valid for flux-general-multi
}

export interface FluxCallbacks {
  onUpdate?: (transcript: string, words: FluxWord[]) => void;
  onStartOfTurn?: () => void;
  onEagerEndOfTurn?: (
    transcript: string,
    words: FluxWord[],
    confidence: number,
    languages?: string[],
  ) => void;
  onTurnResumed?: () => void;
  onEndOfTurn?: (
    transcript: string,
    words: FluxWord[],
    confidence: number,
    languages?: string[],
  ) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (err: Error) => void;
}

// ---------------------------------------------------------------------------
// App-level STT replacements (Flux doesn't support Deepgram `replace` param)
// ---------------------------------------------------------------------------

const REPLACEMENTS: [RegExp, string][] = [
  [/\bdubai\b/gi, 'to buy'],
  [/\bdo buy\b/gi, 'to buy'],
  [/\bthe buy\b/gi, 'to buy'],
  [/\bdo by\b/gi, 'to buy'],
  [/\bjust one\b/gi, 'US-1'],
  [/\bjust won\b/gi, 'US-1'],
  [/\bhughes one\b/gi, 'US-1'],
  [/\bus one\b/gi, 'US-1'],
  [/\byou us one\b/gi, 'US-1'],
  [/\balla parra\b/gi, 'Allapattah'],
  [/\balapara\b/gi, 'Allapattah'],
  [/\bcoral cable\b/gi, 'Coral Gables'],
  [/\bcoral cables\b/gi, 'Coral Gables'],
];

export function applyReplacements(text: string): string {
  let result = text;
  for (const [pattern, replacement] of REPLACEMENTS) {
    result = result.replace(pattern, replacement);
  }
  return result;
}

// ---------------------------------------------------------------------------
// FluxConnection
// ---------------------------------------------------------------------------

export class FluxConnection {
  private ws: WebSocket | null = null;
  private callbacks: FluxCallbacks;
  private closed = false;

  constructor(
    apiKey: string,
    config: FluxConfig,
    callbacks: FluxCallbacks,
  ) {
    this.callbacks = callbacks;

    // Build query string
    const params = new URLSearchParams();
    const model = config.model || 'flux-general-multi';
    params.set('model', model);
    params.set('encoding', config.encoding || 'mulaw');
    params.set('sample_rate', String(config.sampleRate || 8000));

    if (config.eotThreshold != null) {
      params.set('eot_threshold', String(config.eotThreshold));
    }
    if (config.eagerEotThreshold != null) {
      params.set('eager_eot_threshold', String(config.eagerEotThreshold));
    }
    if (config.eotTimeoutMs != null) {
      params.set('eot_timeout_ms', String(config.eotTimeoutMs));
    }

    // Keyterms: each as a separate param (Flux uses repeated `keyterm=` params)
    const url = `wss://api.deepgram.com/v2/listen?${params.toString()}`;
    const keytermSuffix = (config.keyterms || [])
      .map((k) => `&keyterm=${encodeURIComponent(k)}`)
      .join('');
    // Language hints: only valid for multi model. Repeated `language_hint=` params.
    const isMulti = model.endsWith('-multi');
    const langSuffix =
      isMulti && config.languageHints
        ? config.languageHints
            .map((l) => `&language_hint=${encodeURIComponent(l)}`)
            .join('')
        : '';

    this.ws = new WebSocket(url + keytermSuffix + langSuffix, {
      headers: { Authorization: `Token ${apiKey}` },
    });

    this.ws.on('open', () => {
      this.callbacks.onOpen?.();
    });

    this.ws.on('message', (data: Buffer) => {
      try {
        const msg = JSON.parse(data.toString());
        this.handleMessage(msg);
      } catch {
        // Binary or unparseable — ignore
      }
    });

    this.ws.on('close', () => {
      this.closed = true;
      this.callbacks.onClose?.();
    });

    this.ws.on('error', (err: Error) => {
      this.callbacks.onError?.(err);
    });
  }

  /** Send raw audio bytes to Deepgram. */
  send(buffer: Buffer): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(buffer);
    }
  }

  /** Update thresholds or keyterms mid-stream. */
  configure(options: {
    eotThreshold?: number;
    eagerEotThreshold?: number;
    eotTimeoutMs?: number;
    keyterms?: string[];
  }): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const msg: Record<string, any> = { type: 'Configure' };
    const thresholds: Record<string, any> = {};

    if (options.eotThreshold != null) thresholds.eot_threshold = options.eotThreshold;
    if (options.eagerEotThreshold != null) thresholds.eager_eot_threshold = options.eagerEotThreshold;
    if (options.eotTimeoutMs != null) thresholds.eot_timeout_ms = options.eotTimeoutMs;

    if (Object.keys(thresholds).length > 0) msg.thresholds = thresholds;
    if (options.keyterms) msg.keyterms = options.keyterms;

    this.ws.send(JSON.stringify(msg));
  }

  /** Gracefully close the connection. */
  close(): void {
    if (this.closed) return;
    this.closed = true;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({ type: 'CloseStream' }));
      } catch {}
      this.ws.close();
    }
    this.ws = null;
  }

  get isOpen(): boolean {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN && !this.closed;
  }

  // ---------------------------------------------------------------------------
  // Event parsing
  // ---------------------------------------------------------------------------

  private handleMessage(msg: any): void {
    switch (msg.type) {
      case 'Connected':
        // Already handled via ws 'open' event
        break;

      case 'TurnInfo': {
        const event = msg.event as FluxEventType;
        const transcript = applyReplacements(msg.transcript || '');
        const words: FluxWord[] = (msg.words || []).map((w: any) => ({
          word: w.word,
          confidence: w.confidence,
        }));
        const confidence = msg.end_of_turn_confidence || 0;
        const languages: string[] | undefined = Array.isArray(msg.languages)
          ? msg.languages
          : undefined;

        switch (event) {
          case 'Update':
            this.callbacks.onUpdate?.(transcript, words);
            break;

          case 'StartOfTurn':
            this.callbacks.onStartOfTurn?.();
            break;

          case 'EagerEndOfTurn':
            this.callbacks.onEagerEndOfTurn?.(transcript, words, confidence, languages);
            break;

          case 'TurnResumed':
            this.callbacks.onTurnResumed?.();
            break;

          case 'EndOfTurn':
            this.callbacks.onEndOfTurn?.(transcript, words, confidence, languages);
            break;
        }
        break;
      }

      case 'ConfigureSuccess':
        console.log('🔧 Flux: Configure success');
        break;

      case 'ConfigureFailure':
        console.warn('⚠️ Flux: Configure failed');
        break;

      case 'Error':
        this.callbacks.onError?.(
          new Error(`Flux error: ${msg.code} — ${msg.description}`)
        );
        break;
    }
  }
}
