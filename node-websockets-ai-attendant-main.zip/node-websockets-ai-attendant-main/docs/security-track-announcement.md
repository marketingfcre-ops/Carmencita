# Security Track — Done

> Draft. Edit voice / opening / sign-off before sending. Targets: Fausto + Nathalie + agent team.

**Subject:** Security/groups work is done — what changed, what to expect

---

The multi-list and group-access work is finished. Sharing what changed under the hood so when the new behavior kicks in (when Nathalie re-activates the validation rule) nobody is surprised.

## What we built

**Two new objects** to track group access properly:

1. **Lead Group Assignments** (`Lead_List_Assignment__c`) — every Lead can now belong to multiple Groups. Previously a Lead had one Group on the Group lookup; now there's a junction record per (Lead, Group) pair. Existing single-Group memberships were grandfathered as `Status = Approved`. New memberships start `Pending` and need approval.

2. **User Group Access** (`User_Group_Access__c`) — who is allowed to work with which Group. Same pattern: one row per (User, Group). Status `Approved` means the agent can see/edit leads in that group; `Pending` means waiting on admin sign-off.

Plus a **before-save validation Flow** on Lead that blocks updates to a Lead's Group field if the user lacks `User_Group_Access` to that group. The Flow is currently **deactivated** — Nathalie will re-activate it once she's done verifying.

## What we fixed in the data to get here

Most of the work was cleaning up the legacy group data so the new model would actually work:

- **Two group fields existed:** `Group` (lookup to the Group object) and `Group_old2` (free-form text). The Group lookup table had 236 records, but day-to-day workflow had drifted into the free-form field — ~14,500 Leads had a value in `Group_old2` but a null `Group`. The earlier list of "missing" groups Nathalie flagged was actually all sitting in `Group_old2`.

- **Reconciled `Group_old2` → `Group`:** matched the free-form values against the canonical Group table. After deduping spelling variants (e.g. "DORALINDUSTRIAL", "Doral Indust", "DoralInustrial" all roll up to the existing "Doral Industrial" Group), splitting by property type (so `HialeahCom`, `HialeahApt`, `HialeahRetail`, `HialeahApts`, `HialeahInd` stay distinct rather than getting lumped together), and creating 222 new Group records for lists that didn't have a canonical yet (SURDEVRET, FlagamiApts, FTL NE Ind, BrowardShopping, etc. — full list available on request).

- **Multi-group entries:** when agents had typed two groups separated by a comma or semicolon (`"HiaApts, LitHavApt"`, `"JRLitHaitiWyn;WWNAPT"`, etc.), those leads now have a Lead Group Assignment to each component group instead of being stuck in a weirdly-named single group.

- **BVM tag:** the `"; BVM"` suffix that appears on 245 leads is treated as group membership in a `BVM` Group, in addition to the lead's primary group. The Bertolotti / Miranda / Villasuso pod now sees those leads in their BVM list.

- **Agent-specific lists preserved:** Carlos's `CFM Big MF`, Tony's `TS Buyers`, Ben's, Joshua's, Bobby's, Robin's — kept as separate Groups (not folded into generic lists) so each agent's curated set stays theirs.

## Where things stand now

| | Before | After |
|---|---|---|
| Group records | 236 | **458** |
| Leads with a Group set | ~85,000 | **100,273** |
| Lead Group Assignment records | ~85,400 | **100,599** |
| User Group Access records | 127 | **1,031** |
| Users with explicit Group access | ~30 | **90** |

**Multi-group memberships:** 288 leads now belong to more than one group via Lead Group Assignments — these are the leads where the original agent typed multi-group values.

**Access guarantee:** every agent who owns active leads has `User_Group_Access` to every Group those leads belong to. We "grandfathered" 866 (User, Group) access rows based on who currently owns what — that way nobody gets blocked when the validation rule turns on. New access grants going forward will come from the standard approval flow.

## What this enables (the point of all this)

- **An agent only sees / edits leads in groups they're approved for.** No more accidental cross-pollination of one team's pipeline with another's.
- **Leads can belong to multiple lists** — the same property-owner lead can be in both `HialeahCom` and `LittleHavanaApt` if that's what the agent wants, and shows up correctly on both teams' related lists.
- **The Group lookup field on Property keeps working as before** — agents pick a Group when creating a Property and it's all there in the dropdown (including the new ones we created, like SURDEVRET — that's why the property-creation issue Fausto hit earlier today is now resolved).

## What we did NOT touch

- **`Group_old2` is preserved on every lead** — we did not clear the legacy field. That's the audit trail. If anything looks wrong, we can compare against `Group_old2` to see what the lead used to have.
- **Property page layout** — not changed by any of this work. (Last touched 2026-03-09 by Nathalie.) The "owner entity LLC" issue Fausto mentioned earlier is unrelated — it's a missing Account record, not a layout issue.
- **Existing Group records that nobody flagged** — left alone. We did not consolidate `Doral HG&M&MS Retail`, `GroveRIN`, `Project 130`, etc. — those are real lists for someone.

## Known small loose ends (none blocking)

1. **53 leads have `Group_old2` set but `Group` null** — 39 are converted leads (Salesforce makes them read-only by design; can't update), 14 are niche text variants of canonicals that didn't normalize cleanly. We can hand-clean if anyone notices.
2. **5 ugly Group names** preserved per "don't lose data" directive (`Hialeah comm, allapa`, `Lucerne Apartments,`, `Pgim, Inc.`, `casinos, strip malls`, `n/a`) — agents can rename or delete as they bump into them.
3. **Some asset-type-only and area-only Groups** (e.g. `MULTIFAMILY` 18 leads, `Hialeah` 11 leads, `LITTLEHAVANA` 90 leads) exist as their own Group records waiting for an agent to claim them. Per the discussion with Fausto, leaving them as-is so nothing is lost.

## What needs to happen for the rollout

1. **Nathalie re-activates the validation Flow** (`Lead Group Access Check` — Setup → Process Automation → Flows → Activate). Recommend doing this during business hours so we can spot-check that agents aren't getting blocked unexpectedly.
2. **Brief the agents** that the new behavior is live: if they try to assign a Lead to a Group they're not approved for, they'll see the validation error. They can request access via Nathalie / Fausto, who creates a `User_Group_Access` row.
3. **Optional cleanup pass** in the next couple weeks — agents will start noticing the niche entries (`n/a`, `Pgim Inc.`, address-shaped Groups) and can consolidate them as they go. We have all the scripts ready to do another reconcile pass if patterns emerge.

## How to roll back any of this if something looks wrong

Everything we changed today is reversible:

- Lead Group Assignments / User Group Access: soft-deletable from the SF UI; new rows have today's `CreatedDate` so they're easy to find.
- The grandfather access pass: one command rolls back all 866 rows by timestamp (rows go to Recycle Bin for 15 days, restorable). Audit log: `data/archive/grandfather-access-2026-05-29T22-17-17.json`.
- The reconcile commit: documented in `data/archive/group-old-reconcile-2026-05-28.txt` (every text → canonical mapping).

I'd be surprised if we need any of that, but it's there.

That's it. Let me know if anything looks off as it rolls out.

Thanks,
Jesús

---

## Internal-only checklist (don't include in the announce)

- [ ] Re-activate `Lead Group Access Check` Flow
- [ ] Update CLAUDE.md / project notes with the new junction objects + access model
- [ ] Reply to Fausto's "Owner Entity LLC" question — confirm it's unrelated to our work, suggest the Account-doesn't-exist hypothesis
- [ ] Send Nathalie the list of agent-specific groups so she knows what to approve when those agents request access
- [ ] Stash all scripts under `scripts/migrations/` in a git commit titled "security track final"
