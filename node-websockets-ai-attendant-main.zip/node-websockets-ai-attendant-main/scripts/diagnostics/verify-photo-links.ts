/**
 * Verify stored Photo_URL__c image-source links — read-only external GETs.
 *
 * For listings that are NOT live on WP and have a Dropbox / Google Drive / other
 * URL in Photo_URL__c, actually fetch each link and classify it:
 *   live    — resolves to real content (folder/file exists, publicly viewable)
 *   auth    — exists but redirects to a sign-in wall (Drive private share)
 *   dead    — 404 / expired / "link doesn't work"
 *   error   — network/timeout
 *
 * Tells marketing which links are worth chasing. Writes
 * data/photo-links-verified-2026-06-22.csv. Read-only; safe to run.
 *   npx tsx --env-file .env.local scripts/diagnostics/verify-photo-links.ts
 */

import { sfClient } from '../../src/integrations/sf-client';
import { writeFile } from 'fs/promises';

const API_BASE = `${(process.env.WP_SITE_URL || 'https://faustocommercial.com').replace(/\/$/, '')}/wp-json`;
const wpAuth = () => `Basic ${Buffer.from(`${process.env.WP_USER || ''}:${process.env.WP_APP_PASSWORD || ''}`).toString('base64')}`;
const postIdFromUrl = (u: string | null) => { const m = u?.match(/[?&]p=(\d+)/); return m ? Number(m[1]) : null; };
const chunk = <T,>(a: T[], n: number) => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36';

const photoSource = (u: string): 'dropbox' | 'gdrive' | 'other-url' | 'junk' => {
  if (/dropbox\.com\/(scl|sh|s|home)\//i.test(u)) return 'dropbox';
  if (/drive\.google|docs\.google/i.test(u)) return 'gdrive';
  if (/^https?:\/\/[^\/\s]+\/\S+/i.test(u)) return 'other-url';
  return 'junk';
};

type Verdict = 'live' | 'auth' | 'dead' | 'error';

async function verify(url: string, src: string): Promise<{ verdict: Verdict; http: number; note: string }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow', signal: ctrl.signal });
    const finalUrl = res.url || url;
    const http = res.status;
    let body = '';
    try { body = (await res.text()).slice(0, 20000).toLowerCase(); } catch { /* ignore */ }

    if (/accounts\.google\.com|servicelogin|signin/i.test(finalUrl)) return { verdict: 'auth', http, note: 'redirected to sign-in' };
    if (http === 404 || http === 410) return { verdict: 'dead', http, note: 'not found' };
    if (http >= 400) return { verdict: 'dead', http, note: `http ${http}` };

    const deadMarkers = [
      "link doesn't work", 'link_not_found', 'no longer exists', 'has been deleted',
      'sorry, the file you have requested does not exist', 'this link is disabled',
      'error (404)', "couldn't find", 'page not found',
    ];
    if (deadMarkers.some((m) => body.includes(m))) return { verdict: 'dead', http, note: 'error page' };

    if (src === 'gdrive' && /you need access|request access/i.test(body)) return { verdict: 'auth', http, note: 'needs access' };
    return { verdict: 'live', http, note: 'resolves' };
  } catch (e: any) {
    return { verdict: 'error', http: 0, note: (e?.name === 'AbortError' ? 'timeout' : (e?.message || 'fetch error')).slice(0, 60) };
  } finally {
    clearTimeout(timer);
  }
}

// tiny concurrency pool
async function pool<T, R>(items: T[], n: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: n }, async () => {
    while (i < items.length) { const idx = i++; out[idx] = await fn(items[idx]); }
  }));
  return out;
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  const props: any[] = await sf.soql(`SELECT Id, Name, Public_URL__c, WP_Post_ID__c, Photo_URL__c FROM Property__c`);

  // WP featured_media to find the no-photo set
  const wpIdByProp = new Map<string, number>();
  for (const p of props) { const id = p.WP_Post_ID__c ? Number(p.WP_Post_ID__c) : postIdFromUrl(p.Public_URL__c); if (id) wpIdByProp.set(p.Id, id); }
  const featuredById = new Map<number, number>();
  const liveStatus = new Map<number, string>();
  for (const ids of chunk([...new Set(wpIdByProp.values())], 100)) {
    const url = `${API_BASE}/wp/v2/properties?include=${ids.join(',')}&per_page=100&status=publish,draft,private,pending,future&context=edit&_fields=id,status,featured_media`;
    const res = await fetch(url, { headers: { Authorization: wpAuth() } });
    if (res.ok) for (const r of (await res.json()) as any[]) { featuredById.set(r.id, r.featured_media || 0); liveStatus.set(r.id, r.status); }
  }

  // candidates: not live on WP + Photo_URL__c is a real link
  const candidates = props.map((p) => {
    const id = wpIdByProp.get(p.Id);
    const onWp = id && liveStatus.get(id) === 'publish' && (featuredById.get(id) || 0) > 0;
    const u = (p.Photo_URL__c || '').trim();
    const src = u ? photoSource(u) : 'junk';
    return { name: p.Name, id: p.Id, url: u, src, onWp };
  }).filter((c) => !c.onWp && ['dropbox', 'gdrive', 'other-url'].includes(c.src));

  console.log(`\n🔎 Verifying ${candidates.length} image-source links (read-only GETs)...\n`);
  const results = await pool(candidates, 6, async (c) => ({ ...c, ...(await verify(c.url, c.src)) }));

  const tally = (src: string, v: Verdict) => results.filter((r) => r.src === src && r.verdict === v).length;
  for (const src of ['dropbox', 'gdrive', 'other-url']) {
    const n = results.filter((r) => r.src === src).length;
    if (!n) continue;
    console.log(`${src} (${n}): live=${tally(src, 'live')}  auth=${tally(src, 'auth')}  dead=${tally(src, 'dead')}  error=${tally(src, 'error')}`);
  }
  const liveAll = results.filter((r) => r.verdict === 'live').length;
  console.log(`\n   ✅ ${liveAll} links resolve to real content → images likely there, ready to migrate to WP.`);

  const csv = ['Name,SF_Id,Source,Verdict,HTTP,Note,Photo_URL']
    .concat(results.map((r) => [r.name, r.id, r.src, r.verdict, r.http, r.note, r.url].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')));
  const path = 'data/photo-links-verified-2026-06-22.csv';
  await writeFile(path, csv.join('\n'));
  console.log(`   📄 wrote ${results.length} rows → ${path}\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
