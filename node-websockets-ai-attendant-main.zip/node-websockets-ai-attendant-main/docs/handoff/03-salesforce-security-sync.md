# 03 — Salesforce: Data Model, Lead-Access Security & App Sync

This section covers three tightly related things:

1. **The lead-access security model** — who can *see* vs. *edit* which leads, and how that
   rule is enforced inside Salesforce.
2. **How the Node app talks to Salesforce** — the OAuth client, the data it reads/writes,
   and the agent review dashboard.
3. **The Salesforce → WordPress listing sync** — the trigger and handler on the
   Salesforce side (WordPress itself is covered in its own handoff doc).

It is written for two readers. **If you are the owner**, read the "In plain language"
boxes and skip the file/line citations. **If you are the technical successor**, the
file/line references and the `sf-deploy/` notes are the operational contract.

---

## Part A — The Lead-Access Security Model

### In plain language

Fausto's agents share one Salesforce org. Leads are organized into **lists** (called
"Groups" in Salesforce). The business rule the owner asked for is:

> *Every agent can **see** every lead, but an agent may only **edit** a lead that belongs
> to a list they've been granted access to. Admins (and a few designated managers) can
> edit everything. An agent who needs access to a new list can **request** it; an admin
> **approves** it.*

"See everything, edit only yours" is deliberate. Agents need full visibility for
coverage and referrals, but they must not be able to alter (or quietly poach) leads that
belong to another agent's list. This is the core of the security work in this project: a
brokerage's lead data is its most valuable asset, and this model is what keeps one
agent's pipeline from being editable by another.

### The data model

Four objects work together. Three are custom (`__c`); `Lead` is standard.

| Object | Role | Key fields |
|---|---|---|
| `Lead` | Standard Salesforce lead. Has one **primary** list. | `Group__c` (lookup to the lead's primary list), `OwnerId` |
| `Group__c` | A **list** (a.k.a. group). The unit of access. | `Name` |
| `Lead_List_Assignment__c` | **Lead ↔ Group junction.** Lets one lead belong to *multiple* lists beyond its primary. | `Lead__c`, `Group__c`, `Status__c` (`Pending` / `Approved`) |
| `User_Group_Access__c` | **User ↔ Group grant.** Says "this user may edit leads in this list." | `User__c`, `Group__c`, `Status__c` (`Pending` / `Approved`), `All_Groups__c` (wildcard flag) |

The shape of the rule:

- A lead is "on" a list if **either** `Lead.Group__c` points at that list (its primary)
  **or** there is an **Approved** `Lead_List_Assignment__c` joining the lead to that list
  (its additional lists). This is the **multi-list** capability — one lead can legitimately
  live on several lists.
- A user "has" a list if they hold an **Approved** `User_Group_Access__c` for it.
- **Edit is allowed** when the set of lists the lead is on **intersects** the set of lists
  the user has. If the intersection is empty, the edit is blocked.
- **Pending** records grant nothing — they are *requests*, not grants. Status must be
  `Approved` to count, on both the junction and the access object.

Edge cases (intentional):
- A lead with **no** `Group__c` and **no** approved assignments is **unscoped** → anyone
  can edit it. (Fail-open only for genuinely unowned leads.)
- A user with **no** access records can edit unscoped leads but **no** scoped lead.

### How edit access is enforced — the "Lead Group Access Check" Flow

Enforcement happens **inside Salesforce**, not in this app, so it applies no matter how
the lead is edited (UI, API, data loader, this app's `createLead`/`updatePropertyField`,
anything). It is a **record-triggered Flow** named **`Lead_Group_Access_Check`** that runs
**before save** on `Lead` **update**.

> **The prod Flow is built and maintained in the Salesforce Flow Builder UI. Its
> authoritative backup is the JSON in `sf-deploy/flows/`.** Treat
> `sf-deploy/flows/Lead_Group_Access_Check-BACKUP.json` as the source of truth for what
> the live Flow does. If you change the Flow in the UI, re-snapshot it to that file.

The Flow logic (current version is **v4**, "owner-bypass"; the backup JSON captures
**v3**, "all groups for admin users" — see *Versions* below). Reading
`Lead_Group_Access_Check-BACKUP.json`:

1. **`Get_My_Profile`** — look up the running user's Profile (`recordLookups`, queries
   `Profile` by `$User.ProfileId`). *(JSON ~line 478)*
2. **`Get_My_Wildcard_Access`** — look up any `User_Group_Access__c` for the user that is
   `Approved` **and** has `All_Groups__c = true` (the wildcard / "edit all lists" grant).
   *(JSON ~line 524)*
3. **`Is_Admin`** decision — the bypass. Its "Yes" rule (`conditionLogic: "1 OR 2"`):
   - `Get_My_Profile.Name == "System Administrator"`, **OR**
   - the user has a wildcard access row (`Get_My_Wildcard_Access` is not empty).

   If **Yes** → the Flow ends and the edit is allowed. *(JSON ~line 143)*
   In **v4**, a third OR-condition was added — `$Record.OwnerId == $User.Id` — so the
   **lead's owner can always edit their own lead** regardless of group access. (See the
   migration script `scripts/migrations/add-owner-bypass-to-lgac-flow.ts` for exactly how
   that condition was injected and a new active version published.)
4. If not an admin/wildcard/owner, the Flow builds the set of the user's approved lists:
   **`Get_My_Group_Access`** queries `User_Group_Access__c` where `User__c == $User.Id`
   and `Status__c == "Approved"`, then **`Loop_My_Accesses`** → **`Append_GroupId`**
   collects each `Group__c` into the `userGroupIds` text collection. *(JSON ~lines 226,
   12, 394)*
5. **`Get_Matching_Assignments`** — query `Lead_List_Assignment__c` where
   `Lead__c == $Record.Id` **and** `Status__c == "Approved"` **and** `Group__c IN
   userGroupIds`. This is the intersection test, done as a single SOQL filter. *(JSON
   ~line 309)*
6. **`Has_Matching_Assignment`** decision — if `Get_Matching_Assignments` returned
   anything (not null / not empty) → **allow**. Otherwise fall through to
   **`Block_Cross_Group_Edit`**, a **custom error** that aborts the save with:
   *"You can only edit leads assigned to a group you have approved access to..."* *(JSON
   ~lines 72, 52)*

Note one subtlety: the Flow's intersection is checked **only against the junction**
(`Lead_List_Assignment__c`). That is why the app and the schedulers work so hard to keep a
junction row in existence for every `Lead.Group__c` (see the reconcile job below) — a lead
whose primary `Group__c` is set but which has *no* approved junction row would be treated
as unscoped by the Flow. The `reconcile` job closes that gap by materializing an
`Approved` junction for every `Lead.Group__c`.

### The agent request → approval workflow (Pending → Approved)

Agents don't get access by emailing an admin. They **self-serve a request**, and an admin
approves:

- To request access to a list, an agent creates a `User_Group_Access__c` (or, per-lead, a
  `Lead_List_Assignment__c`) with `Status__c = 'Pending'`. Pending grants nothing.
- An admin flips `Status__c` to `Approved`, at which point the Flow above starts counting
  it.
- So the admin isn't blind to the queue, the app runs a **notifier**:
  `notifyPendingAssignments()` in `src/integrations/lla-reconcile.ts:225` emails a digest
  of *new* `Pending` `Lead_List_Assignment__c` requests to the approving admin (default
  `na@faustocommercial.com`, override `LLA_NOTIFY_EMAIL`). It uses a **watermark file** on
  the Railway volume so the same request isn't re-sent every tick, and on first run it
  seeds the watermark and sends nothing (so enabling it never blasts the entire historical
  backlog). It also **suppresses** pendings that are already covered by an `Approved`
  junction (`lla-reconcile.ts:248`).
- `tidyRedundantPendings()` (`lla-reconcile.ts:325`) deletes `Pending` requests that are
  already `Approved` for the same lead+group — e.g. when an agent creates a lead in their
  own list (auto-approved by reconcile) and *also* files a request. Provably safe: it only
  deletes a Pending when an Approved row already exists.

### Versions & owner-bypass

There are three layered bypasses, added over time:
1. **System Administrator profile** — original.
2. **Wildcard access** — an `Approved` `User_Group_Access__c` with `All_Groups__c = true`
   grants edit-all without the System Admin profile. Used for managers (e.g. Erick
   Moretti, Pedro Galindo, Nathalie Aguirre — see project memory "Lead-access bypass
   cohort"). This is v3, the state captured in `Lead_Group_Access_Check-BACKUP.json`.
3. **Owner-bypass** — v4, `$Record.OwnerId == $User.Id`. Snapshot of the pre-change state
   is `sf-deploy/flows/Lead_Group_Access_Check-PRE-OWNER-BYPASS.json` (its `Metadata` is
   identical to the v3 backup); the change is described by
   `scripts/migrations/add-owner-bypass-to-lgac-flow.ts`.

---

## Part B — Why it was built this way

This design is shaped by hard platform constraints, and the constraints are worth keeping
in mind before "improving" it.

- **Salesforce production is Professional Edition, which cannot run Apex.** PE has no Apex
  triggers, no Apex classes, no Apex tests in production. Therefore enforcement *cannot* be
  a trigger in prod — it **must** be a Flow. The Flow is the production security control.
- **`sf-deploy/triggers/LeadGroupAccessRestriction.trigger` and
  `sf-deploy/classes/LeadGroupAccessRestrictionTest.cls` are DEV-ORG ONLY.** They are an
  Apex re-implementation of the exact same rule (admin bypass; primary `Group__c` +
  approved `Lead_List_Assignment__c` intersected with approved `User_Group_Access__c`;
  Pending doesn't count; unscoped lead is editable). They exist for two reasons: (1) to
  prototype/verify the logic in a Developer Edition org where Apex *is* available, and (2)
  as executable documentation of the rule, with a full behavior matrix in the test class
  (`LeadGroupAccessRestrictionTest.cls` covers admin bypass, matching access, blocked,
  multi-list additional-list path, unscoped, and Pending-doesn't-grant). **They must never
  be deployed to prod** — `sf-deploy/package.xml` lists them only for the dev org. (See
  CLAUDE.md and project memory "Prod Salesforce is Professional Edition — no custom Apex".)
- **Multi-list per lead** is a real requirement (a lead can belong to more than one list),
  which is why there's a junction object (`Lead_List_Assignment__c`) rather than just the
  single `Lead.Group__c` lookup. The junction is also what the Flow keys off, because a
  Flow can filter a related-object query by an `IN` collection cleanly.
- **PE caps autolaunched Flows at 5.** The org is at that cap. That's why the "create a
  junction whenever an admin sets `Lead.Group__c`" step is **not** a Flow — it would burn a
  scarce slot. Instead it runs server-side as the **reconcile job** (Part D). The whole
  reason `lla-reconcile.ts` exists is to do, from the always-on Node server, what would
  normally be a record-triggered Flow. (See project memory "Auto-create LLA + pending-notify
  via scheduled job (not Flow)".)
- **Capability-based access** is the preferred direction: grants live in data
  (`User_Group_Access__c` rows, wildcard flag) rather than in cloned profiles or
  per-record sharing rules, so access is portable and auditable. (See project memory
  "Prefer capability-based SF access".)

---

## Part C — How the app reads & writes Salesforce

### Two Salesforce clients, one auth model

Both use **OAuth 2.0 Client Credentials flow** (server-to-server, no user login). The
Connected App in Salesforce is configured to **run as** a specific integration user; every
read and write the app makes is done **as that user**. That run-as identity matters for
security — see Gotchas.

1. **`src/salesforce.ts`** — the long-lived, prod-bound runtime client. This is what the
   live phone attendant uses.
   - `authenticate()` (`salesforce.ts:104`) POSTs `grant_type=client_credentials` to
     `${SF_LOGIN_URL}/services/oauth2/token` and caches `access_token` + `instance_url` in
     module state.
   - `soqlQuery()` (`salesforce.ts:143`) runs SOQL and **fully paginates** via
     `nextRecordsUrl`; re-auths once on 401. *(There is a prominent bug-history comment
     here: it previously fetched only the first page, silently dropping ~20% of active
     properties from the in-memory cache — which shrank both the agent dashboard and the
     voice search. Don't regress this.)*
   - `sfApiRequest()` (`salesforce.ts:185`) does POST/PATCH with one 401 re-auth retry.
   - `initSalesforce()` (`salesforce.ts:314`) authenticates, loads data, and sets a
     **4-hour auto-refresh** timer. Called from `src/server.ts:198`.

2. **`src/integrations/sf-client.ts`** — a generic, reusable `SfClient` class + `sfClient()`
   factory. This is for **scripts and handlers** that may need to target **prod *or* the
   Dev org**:
   - `sfClient('prod')` reads `SF_*`; `sfClient('dev')` reads `SF_DEV_*`; or pass explicit
     creds. *(`sf-client.ts:198`)*
   - Methods: `soql`, `toolingQuery`, `retrieve`, `describe`, `create`, `update`, `delete`,
     `toolingCreate`, plus `instance`/`token` getters. All go through `req()`
     (`sf-client.ts:173`) which does one 401 re-auth retry and throws descriptive errors.
   - Used by the WP sync handler (Part E), `sf-files.ts`, and the LLA jobs (Part D).

### What the runtime reads (cached in memory)

`refreshData()` (`salesforce.ts:341`) loads two collections every 4 hours and pushes
properties into the `listings` search module:

- **`fetchProperties()`** (`salesforce.ts:226`) — all `Property__c WHERE Status__c =
  'Active'`, ~30 fields mapped into the `SFProperty` interface (`salesforce.ts:21`). Lot
  acres are derived from sqft (`÷ 43,560`).
- **`fetchAgents()`** (`salesforce.ts:291`) — active `User` records (excluding Chatter Free),
  mapped to `SFAgent` (`salesforce.ts:56`).
- Getters: `getProperties()`, `getAgents()`, `getLastRefresh()` (`salesforce.ts:500–509`).

### What the runtime writes

- **`createLead()`** (`salesforce.ts:523`) — **fire-and-forget** lead creation from the
  phone call. Maps caller intent (`Lead_Intent__c`), city (`Interested_City__c`: MIA/JAX),
  and asset type. Crucially it **never blocks or crashes the call** — errors are logged,
  and if SF is unreachable it falls back to a **Make.com webhook** (`MAKE_WEBHOOK_URL`,
  legacy) or local logging.
- **`updatePropertyField()`** (`salesforce.ts:473`) — PATCH arbitrary fields on a
  `Property__c`. Used by the agent review dashboard (Part D) and elsewhere.
- **`fetchPropertyForSync()`** (`salesforce.ts:418`) — single `Property__c` by ID with the
  WP link-back fields (`WP_Post_ID__c`, `Public_URL__c`) and the listing agent's email;
  used by the email-flyer handler. **SOQL-injection-safe** (escapes quotes in the ID).

### Salesforce Files (flyers) — `src/integrations/sf-files.ts`

Flyers are stored as modern Salesforce **Files** (`ContentDocumentLink` → `ContentVersion`)
on the `Property__c`. `getFlyerForProperty()` (`sf-files.ts:80`) finds the best flyer PDF
and downloads its bytes for email attachment; `propertyHasFlyer()` (`sf-files.ts:71`) is a
cheap existence check. Selection order (`findFlyerVersion`, `sf-files.ts:51`): a PDF whose
title/filename contains "flyer"; else the only PDF; else **null** (ambiguous → caller
attaches nothing rather than guessing). It caches one authed `SfClient`.

---

## Part D — Property data & the Agent Review Dashboard

`src/agent-review.ts` is a lightweight, self-contained web tool (registered at
`src/server.ts:55`) that lets each agent confirm the status of their own listings.

**What it does:**
- `GET /review?agent={SF_USER_ID}` renders an HTML page of the listings where
  `Property__c.Listing_Agent__c` matches that user ID (`loadAgentListings`,
  `agent-review.ts:63`), with links out to Salesforce and the public website, the prior
  review (if any), and a status dropdown: **Still Active / Sold / Lost / Needs Update**.
- `POST /review/submit?agent=...` (`agent-review.ts:454`) writes each response into the
  property's `Notes_for_Marketing__c` field, **appending** a tagged line like
  `[Agent Review 2026-04-09] Yuniel De Varona: ACTIVE — note` rather than overwriting
  (`parsePriorReview`, `agent-review.ts:45`, parses the latest such line back out). Saves
  via `updatePropertyField()` and also drops a JSON backup to `REVIEW_DIR`.
- `GET /review/results?key=...` (`agent-review.ts:602`) is an admin view of the local
  backups, gated by `ADMIN_KEY`.

**Two important caveats for the successor:**
- **No real auth.** The SF user ID in the URL *is* the token (`agent-review.ts:10`). This
  is explicitly "temporary tooling." If it outlives its purpose, it needs real auth.
- **The placeholder-fields hack** (`agent-review.ts:483–542`): Salesforce rejects a PATCH
  on a record that has empty *required* fields, even when you're only touching
  `Notes_for_Marketing__c`. So the submit handler fills placeholder values
  (`Photo_URL__c='pending'`, `Zoning__c='TBD'`, zeros for numeric sizes, etc.) **only for
  fields detected as empty**, and retries once adding `Listing_Date__c` if SF complains.
  This is a workaround for PE/validation constraints; if listing data gets cleaner, it can
  be trimmed.

### The LLA scheduler (server-side jobs) — `src/integrations/lla-reconcile.ts`

Started from `src/server.ts:204` via `startLlaReconcileScheduler()`
(`lla-reconcile.ts:371`). It runs one pass ~30s after boot, then every
`LLA_RECONCILE_INTERVAL_MIN` minutes (default 10). It stays **dark unless explicitly
enabled** by env flags. Two independent jobs share the tick:

- **Reconcile** (`reconcileLeadGroupAssignments`, `lla-reconcile.ts:70`, gated by
  `LLA_RECONCILE_ENABLED`): finds `Lead`s with `Group__c` set but **no** matching
  `Lead_List_Assignment__c`, and creates the junction with `Status__c='Approved'`. This is
  the server-side substitute for the record-triggered Flow PE can't afford (the 5-flow
  cap). **Create-only, idempotent, fails closed** (a missing junction means *no* access,
  never accidental access). Capped at 500/run as a safety valve. It also runs
  `tidyRedundantPendings()` each tick.
- **Notify** (`notifyPendingAssignments`, `lla-reconcile.ts:225`, gated by
  `LLA_NOTIFY_ENABLED`): the Pending-request digest email described in Part A. Uses a
  watermark file (`LLA_NOTIFY_STORE_DIR` / Railway volume) and Resend
  (`src/integrations/resend.ts`). Lightning record links are built against the
  `*.lightning.force.com` host, **not** the API `*.my.salesforce.com` host
  (`lightningBaseUrl`, `lla-reconcile.ts:191`) — the API host 404s the UI path.

The same reconcile logic backs the manual CLI `scripts/migrations/reconcile-lla.ts`, so a
`--dry-run` there exercises exactly what the scheduler runs.

---

## Part E — Salesforce → WordPress listing sync (SF side)

> WordPress internals (Houzez meta, taxonomies, post creation) are covered in the
> WordPress handoff doc. Here we cover only the **trigger and handler on the Salesforce
> side**.

**Trigger:** a Salesforce **record-triggered Flow** on `Property__c` fires an **HTTP
Callout** to this app whenever a property is created/updated. It POSTs to:

```
POST /webhooks/salesforce/event
```

handled by `src/webhooks/salesforce.ts` (registered at `src/server.ts:58`).

**Auth & org selection** (`salesforce.ts` webhook, `webhooks/salesforce.ts:46`): a shared
secret in the `X-SF-Webhook-Secret` header (or `?secret=` query, allowed because SF's
External Services wizard makes header config painful). The secret *also selects the org*:
matching `SF_WEBHOOK_SECRET` → `prod`, `SF_DEV_WEBHOOK_SECRET` → `dev`. Unknown secret →
401. Headers are redacted in logs (`redactHeaders`, `webhooks/salesforce.ts:138`).

**Payload:** `{ objectType, eventType: created|updated, recordId, changedFields?, reason? }`.
Only `objectType === 'Property__c'` is handled; anything else returns 202 "ignored". On
handler failure the route returns **500 on purpose** so SF's HTTP Callout retry policy
re-fires (`webhooks/salesforce.ts:96`).

**Handler:** `handlePropertyChanged()` in `src/handlers/sf-property-changed.ts:56`. It uses
`sfClient(target)` to read the property (`fetchPropertyForSyncVia`, `:92`) and then:

- **No `WP_Post_ID__c` yet** → first try to **backfill** the WP post id by matching an
  existing WP post (`tryBackfillWpPostId`, `:175`): by URL slug, then by normalized street
  address, then by WP native title search. This avoids creating duplicate WP posts for the
  ~150 April drafts whose `Public_URL__c` never landed back in SF. If found, write
  `WP_Post_ID__c` back and treat as an update; otherwise **create a new WP draft**
  (`createNewListing`, `:223`) and write `WP_Post_ID__c` + `Public_URL__c` back to SF.
- **Has `WP_Post_ID__c`** → **update** the existing post (`updateExistingListing`, `:273`).

**Two hard-won safety rules in the update path — do not regress these:**
1. **SF owns structured data; WP owns marketing copy.** The handler **never** pushes
   `title`/`content` to WP on update (`:306`) — only post *status* and the listing-status
   taxonomy. Marketers curate titles/descriptions in WP and must not be clobbered on every
   SF field change.
2. **Never auto-publish a draft** (`:319`). If the current WP post is a `draft`, SF can
   only move it to draft (no-op) or private — **publishing is a deliberate human action**.
   And it **fails safe**: if the current WP status can't be determined, it does *not*
   publish. (Both of these are fixes for real incidents — ~120 photo-less drafts were once
   accidentally published when any SF field change flipped draft→publish.)

It also keeps `Public_URL__c` in sync with the canonical WP permalink (`:416`) and degrades
gracefully on WP 404s (returns a 200 noop to stop SF retry loops, and points you at
`scripts/diagnostics/sf-wp-link-audit.ts` to clean up orphaned links). The handler is
**idempotent** — the same event twice yields the same result.

---

## Part F — Key files & functions (quick reference)

| File | Key symbols (file:line) | Purpose |
|---|---|---|
| `src/salesforce.ts` | `authenticate` :104 · `soqlQuery` :143 (paginates) · `sfApiRequest` :185 · `fetchProperties` :226 · `fetchAgents` :291 · `initSalesforce` :314 · `refreshData` :341 · `fetchPropertyForSync` :418 · `updatePropertyField` :473 · `createLead` :523 | Prod runtime SF client: cache + leads + property writes |
| `src/integrations/sf-client.ts` | `SfClient` :36 · `soql` :67 · `toolingQuery` :81 · `create`/`update`/`delete` :109–138 · `req` :173 · `sfClient()` factory :198 | Generic prod/dev SF client for scripts & handlers |
| `src/integrations/sf-files.ts` | `findFlyerVersion` :51 · `propertyHasFlyer` :71 · `getFlyerForProperty` :80 | Flyer PDF lookup/download from SF Files |
| `src/webhooks/salesforce.ts` | route :46 · `handlePropertyEvent` :110 · `redactHeaders` :138 | Inbound SF Flow HTTP-callout endpoint + auth/org select |
| `src/handlers/sf-property-changed.ts` | `handlePropertyChanged` :56 · `tryBackfillWpPostId` :175 · `createNewListing` :223 · `updateExistingListing` :273 | SF→WP property sync handler (idempotent, fail-safe) |
| `src/agent-review.ts` | `loadAgentListings` :63 · `parsePriorReview` :45 · `registerReviewRoutes` :430 · submit :454 | Agent listing-review dashboard (`/review`) |
| `src/integrations/lla-reconcile.ts` | `reconcileLeadGroupAssignments` :70 · `notifyPendingAssignments` :225 · `tidyRedundantPendings` :325 · `startLlaReconcileScheduler` :371 | Server-side reconcile + pending-request notifier |
| `sf-deploy/flows/Lead_Group_Access_Check-BACKUP.json` | `Is_Admin` decision ~:143 · `Get_Matching_Assignments` ~:309 · `Block_Cross_Group_Edit` ~:52 | **Source of truth** for the prod enforcement Flow (v3) |
| `sf-deploy/flows/Lead_Group_Access_Check-PRE-OWNER-BYPASS.json` | — | Snapshot before v4 owner-bypass |
| `sf-deploy/triggers/LeadGroupAccessRestriction.trigger` | — | **DEV-ORG ONLY** Apex mirror of the rule |
| `sf-deploy/classes/LeadGroupAccessRestrictionTest.cls` | 6-case matrix | **DEV-ORG ONLY** test + behavior spec |
| `scripts/migrations/add-owner-bypass-to-lgac-flow.ts` | — | How v4 (owner-bypass) was published |
| `scripts/migrations/reconcile-lla.ts` | — | Manual CLI for the reconcile job (supports dry-run) |

---

## Part G — Configuration / environment variables

| Var | Used by | Notes |
|---|---|---|
| `SF_LOGIN_URL` | `salesforce.ts`, `sf-client.ts` | The **My Domain** host, e.g. `https://<org>.my.salesforce.com` — **not** `login.salesforce.com`. |
| `SF_CLIENT_ID` | both clients | Connected App consumer key (prod). |
| `SF_CLIENT_SECRET` | both clients | Connected App consumer secret (prod). |
| `SF_DEV_LOGIN_URL` / `SF_DEV_CLIENT_ID` / `SF_DEV_CLIENT_SECRET` | `sf-client.ts` (`sfClient('dev')`) | Dev Edition org creds (for scripts/testing). |
| `SF_WEBHOOK_SECRET` | `webhooks/salesforce.ts` | Shared secret for inbound SF Flow callouts → selects **prod**. |
| `SF_DEV_WEBHOOK_SECRET` | `webhooks/salesforce.ts` | Same, selects **dev**. |
| `SF_LIGHTNING_BASE_URL` | `lla-reconcile.ts` | Optional override for the Lightning UI host in notification links (derived from instance URL by default). |
| `MAKE_WEBHOOK_URL` | `salesforce.ts` | Optional legacy Make.com fallback for lead creation. |
| `LLA_RECONCILE_ENABLED` | `lla-reconcile.ts` | `'true'` to run the junction-reconcile job. Off by default. |
| `LLA_NOTIFY_ENABLED` | `lla-reconcile.ts` | `'true'` to run the pending-request digest email. Off by default. |
| `LLA_NOTIFY_EMAIL` | `lla-reconcile.ts` | Approver recipient. Default `na@faustocommercial.com`. |
| `LLA_NOTIFY_STORE_DIR` | `lla-reconcile.ts` | Watermark file dir; defaults to `RAILWAY_VOLUME_MOUNT_PATH` then `./data`. Must be **persistent** (Railway volume). |
| `LLA_RECONCILE_INTERVAL_MIN` | `lla-reconcile.ts` | Scheduler interval, default 10 min. |
| `REVIEW_DIR` | `agent-review.ts` | Local backup dir for review submissions (default `/tmp/agent-reviews`). |
| `ADMIN_KEY` | `agent-review.ts` | Gate for `/review/results` (default `fausto2026` — change it). |

Connected-App / OAuth note: client-credentials grant requires a Connected App with a
designated **"Run As" user** and the right OAuth scopes. The integration user's
profile/permissions determine what the app can read and write.

---

## Part H — Gotchas & maintenance notes

- **Professional Edition = no Apex in prod.** The Flow is the only enforcement that runs in
  production. The `sf-deploy/` Apex is dev-org only — **never deploy it to prod**
  (`package.xml` targets the dev org). Don't propose moving enforcement to a trigger.
- **PE caps autolaunched Flows at 5, and the org is at the cap.** This is why the
  junction-create runs as a server-side job, not a Flow. Don't try to add another
  record-triggered Flow without retiring one.
- **The Flow keys off the junction, not `Lead.Group__c` directly.** A lead whose primary
  `Group__c` is set but which has no `Approved` `Lead_List_Assignment__c` will be treated
  as **unscoped** (editable by anyone). The reconcile job is what guarantees a junction row
  exists for every `Lead.Group__c`. If reconcile is disabled, scoped-but-junction-less
  leads silently lose protection.
- **Pending grants nothing — on both objects.** Status must be `Approved`. This is enforced
  in the Flow and mirrored in the dev trigger/tests.
- **Three bypasses exist**: System Administrator profile, wildcard `User_Group_Access__c`
  (`All_Groups__c = true`), and lead owner (v4). The wildcard permset/rows are
  **load-bearing** — don't unassign them (see project memory on the bypass cohort and the
  export-lockdown permset).
- **`sf-deploy/flows/*.json` is the source of truth for the prod Flow.** The Flow is edited
  in the Flow Builder UI (per project memory: keep Flow edits in the UI, do everything else
  via scripts). After any UI change, **re-snapshot** to the JSON backup. If the live Flow
  and the backup drift, the backup is wrong — fix it.
- **Connected-App run-as user.** All app reads/writes happen as the integration user. If
  that user is deactivated, has its profile changed, or loses field-level security on a
  field the app touches, things break with permission errors — not code bugs. Note the
  integration user is *also* subject to the access Flow on `Lead` edits unless it's an admin
  or has wildcard access; today lead writes are `createLead` (insert, not update, so the
  before-update Flow doesn't apply) — keep that in mind if you ever add lead *updates* from
  the app.
- **`soqlQuery` must paginate.** The big bug-history comment in `salesforce.ts:143` is
  there for a reason: a non-paginating query silently truncated ~20% of active properties.
  Any new SF read should follow `nextRecordsUrl`.
- **SOQL injection.** IDs interpolated into SOQL are quote-escaped
  (`salesforce.ts:427`, `sf-files.ts:52`, `sf-property-changed.ts:96`). Keep that up for any
  new query that interpolates external input.
- **WP sync never overwrites marketing copy and never auto-publishes drafts.** Both are
  fixes for real production incidents. If you touch `updateExistingListing`, preserve both
  invariants and the fail-safe behavior on indeterminate WP status.
- **Watermark persistence.** The notify watermark must live on a persistent Railway volume;
  if it resets, the first run after reset re-seeds and sends nothing (safe), but a wrong
  `LLA_NOTIFY_STORE_DIR` pointing at ephemeral storage means notifications effectively never
  fire steadily.
- **Agent review dashboard has no real auth** and uses a placeholder-fields hack to satisfy
  PE required-field validation on PATCH. Treat it as temporary tooling.
