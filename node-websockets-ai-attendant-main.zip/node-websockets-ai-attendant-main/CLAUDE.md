# Fausto — Commercial AI Phone Attendant

Low-latency real-time AI phone attendant. Callers talk to an AI receptionist that
answers questions about commercial real-estate listings, captures leads, and
syncs with Salesforce / Campaign Monitor / WordPress.

## Stack & runtime

- **Node + TypeScript** (build with `tsc`, dev with `tsx watch`).
- **Call path:** Twilio `<Connect><Stream>` → WebSocket (`/stream`) → Deepgram STT
  (streaming) → Claude API (streaming) → sentence splitter → **ElevenLabs TTS**
  (Flash v2.5, mulaw) → back to Twilio. Text is streamed to TTS sentence-by-sentence
  so the caller hears the first words in ~1–1.5s.
  - ⚠️ **STT is Deepgram; TTS is ElevenLabs** (`src/tts.ts`), not Deepgram. The
    Deepgram SDK is still a dependency for STT.
- **Server:** Fastify + `@fastify/websocket` (not raw `ws`/Express).
- **Hosting:** Railway. `railway.json` defines the service.

## Documentation

The full technical handover lives in **`docs/handoff/`** (tracked in git; start at
`00-overview.md`) and is also served in-app at **`/admin/docs`** behind `ADMIN_KEY`.
The in-app viewer renders `src/docs-bundle.ts`, a generated bundle of sections
00–07 — after editing the handoff markdown, regenerate it with
`npx tsx scripts/setup/build-docs-bundle.ts` (add `--check` to verify sync).
Ops runbooks and design notes are in `docs/` (`morning-runbook.md`,
`nathalie-sf-runbook.md`, etc.). New-developer entry point: `README.md`.

## Local development

```bash
npm run dev      # tsx watch, loads .env.local, port 3000
npm run ngrok    # exposes :3000 on the fixed domain below
npm run build    # tsc → dist/
npm start        # node dist/server.js (prod-style)
```

- Fixed ngrok domain: `https://thymy-unjarring-brande.ngrok-free.dev`
- Health check: `GET /health`. Debug view: `GET /debug`.
- Secrets live in `.env.local` (gitignored). Never print or commit them.

## Directory map

| Path | What's there |
|---|---|
| `src/server.ts` | Entry point — HTTP + WebSocket server |
| `src/call-handler.ts`, `call-logger.ts` | Live call orchestration + logging |
| `src/claude.ts` | Claude API streaming wrapper |
| `src/stt-flux.ts` | Deepgram STT (streaming) |
| `src/tts.ts` | **ElevenLabs** TTS (streaming, mulaw) |
| `src/admin.ts`, `docs-bundle.ts` | Admin dashboard + in-app `/admin/docs` viewer |
| `src/salesforce.ts` | Salesforce read/write (leads, listings, groups) |
| `src/campaign-monitor.ts` | Campaign Monitor list sync |
| `src/sms.ts`, `sms-consent.ts`, `sms-keywords.ts` | SMS + A2P consent flow |
| `src/listings.ts`, `search.ts`, `geography.ts` | Listing search / geo |
| `src/handlers/`, `integrations/`, `webhooks/` | Route + integration glue |
| `scripts/` | Ops tooling — see below |
| `sf-deploy/` | Salesforce metadata (Apex classes, triggers, flows) |
| `docs/handoff/` | **Technical handover** (00–07) — start here for onboarding |
| `docs/` | Ops runbooks, design notes, client deliverables |

### `scripts/` layout
- `diagnostics/` — read-only investigation (SOQL audits, WP auth health, etc.)
- `migrations/` — one-off data migrations (often have `--dry-run`)
- `audit/`, `setup/`, `tests/` — as named
- `twilio-restore-prod.sh` — restores Twilio webhook config to prod

Run TS scripts with `npx tsx scripts/<dir>/<file>.ts`. Most migrations support
`--dry-run`; always dry-run first.

## External integrations

| System | Where | Notes |
|---|---|---|
| Twilio | webhooks → `/voice/answer`, `/voice/status`, `/stream` | Media Streams |
| Deepgram | `src/stt-flux.ts`, `src/tts.ts` | STT + TTS |
| Claude API | `src/claude.ts` | streaming completions |
| Salesforce | `src/salesforce.ts`, `sf-deploy/` | data (prod) + Apex metadata (dev org only) |
| Campaign Monitor | `src/campaign-monitor.ts` | email list sync |
| WordPress | `faustocommercial.com/wp-json/...` | listing data via REST |

## Deploy

- **Prod:** merge to `main` → Railway auto-deploys. No manual step.
- **Preview:** open a PR → Railway spins up a PR preview environment.
- **Salesforce:** prod is **Professional Edition — no custom Apex.** The Apex
  trigger + test class in `sf-deploy/` are **dev-org only** and must **never** be
  deployed to prod. Prod lead-group access is enforced by **Flow**
  (`Lead_Group_Access_Check`), built manually in the SF UI; its config is backed
  up as JSON in `sf-deploy/flows/` — treat those backups as the source of truth.
  (See memory: "Prod Salesforce is Professional Edition — no custom Apex".)

## Workflow & approval gates

This project follows a tight-approval workflow:

1. **Every file write** is reviewed before it lands.
2. **PR open** is a gate — summarize the change, wait for approval.
3. **Any deploy** (Railway prod via merge, or `sf-deploy` push) is a gate.

**Read-only ops need no confirmation** (standing approval): SOQL `SELECT`,
Salesforce describe/Tooling reads, read-only HTTP GETs (WP, Campaign Monitor),
script `--dry-run`, local reads/greps, `git log/diff/blame`. Announce briefly,
then run. **Any write — even a single field update — requires confirmation.**

## Gotchas

- `.env.local` holds live API keys + a webhook secret. Keep them out of diffs,
  logs, and `settings.local.json`.
- Migrations can touch prod Salesforce data — dry-run, then gate the real run.
- The ngrok domain is fixed; Twilio webhooks may point at it during local dev.
  Run `twilio-restore-prod.sh` to put webhooks back to prod when done.
