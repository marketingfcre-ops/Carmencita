/**
 * Fix the 18 [DUPLICATE]-titled posts that are still in publish status.
 * The dedupe migration prefixed their titles but the simultaneous status='draft'
 * PATCH didn't take (likely a Houzez/plugin hook). This re-PATCHes status only.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/wp-finish-duplicate-drafts.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/wp-finish-duplicate-drafts.ts
 */

import { updatePropertyPost } from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 150;

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
}

async function fetchPublished(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (let page = 1; page <= 20; page++) {
    const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=publish&context=edit&_fields=id,date,status,title`;
    const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
    if (!res.ok) break;
    const batch = (await res.json()) as any[];
    if (!Array.isArray(batch) || batch.length === 0) break;
    for (const p of batch) {
      out.push({
        id: p.id,
        date: p.date || '',
        status: p.status || '',
        title: (p.title?.rendered || p.title || '').toString(),
      });
    }
    if (batch.length < 100) break;
  }
  return out;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP_USER or WP_APP_PASSWORD env vars.');
    process.exit(1);
  }

  console.log(`\n🔧 Finish moving [DUPLICATE] posts to draft ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const all = await fetchPublished();
  // Match both the en-dash and the HTML entity form (&#8211;) the WP response uses
  const targets = all.filter((p) => /\[DUPLICATE/.test(p.title));

  console.log(`Found ${targets.length} published posts with [DUPLICATE in title.`);
  if (targets.length === 0) {
    console.log('Nothing to do.');
    process.exit(0);
  }

  for (const p of targets) {
    console.log(`   wp:${p.id}  "${p.title.slice(0, 70)}"`);
  }

  if (DRY_RUN) {
    console.log('\n[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('\n→ PATCHing each to status=draft (status only, no other fields)...');
  let ok = 0;
  let err = 0;
  for (const p of targets) {
    const result = await updatePropertyPost(p.id, { status: 'draft' });
    if (result.ok) {
      ok++;
    } else {
      err++;
      console.warn(`   ❌ wp:${p.id}: ${result.error}`);
    }
    await sleep(REQUEST_DELAY_MS);
  }

  // Verify by re-fetching
  console.log('\n→ Verifying...');
  const after = await fetchPublished();
  const stillStuck = after.filter((p) => /\[DUPLICATE/.test(p.title));

  console.log('\n=== Summary ===');
  console.log(`PATCH succeeded:   ${ok}`);
  console.log(`PATCH failed:      ${err}`);
  console.log(`Still published:   ${stillStuck.length}  ${stillStuck.length === 0 ? '✅' : '⚠️'}`);
  if (stillStuck.length > 0) {
    console.log('\nStill stuck — these will need manual intervention in WP admin:');
    for (const p of stillStuck) {
      console.log(`   wp:${p.id}  "${p.title.slice(0, 70)}"`);
    }
  }
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
