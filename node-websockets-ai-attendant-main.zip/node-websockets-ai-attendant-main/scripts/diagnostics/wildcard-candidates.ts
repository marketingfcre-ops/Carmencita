/**
 * Identify who currently has — or might need — wildcard all-leads access.
 * Read-only. Surfaces:
 *   - Users already bypassed via System Administrator profile (no wildcard row needed).
 *   - Users on the "Lead Data Export" permset (export power; common admin-assistant set).
 *   - Users with broad existing group coverage (top by approved-group count).
 *   - Users already holding an All_Groups__c=true row (current wildcard set).
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/wildcard-candidates.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. System Administrators (already bypass via Is_Admin Yes rule 1).
  const sysadmins: any[] = await sf.soql(
    `SELECT Id, Name, Username, IsActive FROM User WHERE Profile.Name = 'System Administrator' AND IsActive = true ORDER BY Name`
  );
  console.log(`=== System Administrators (${sysadmins.length}) — already bypass via profile ===`);
  for (const u of sysadmins) console.log(`  ${u.Id}  ${u.Name.padEnd(28)} ${u.Username}`);

  // 2. Existing wildcard holders.
  const wildcards: any[] = await sf.soql(
    `SELECT Id, User__r.Name, User__r.IsActive, User__r.Profile.Name, Status__c, Group__c
     FROM User_Group_Access__c
     WHERE All_Groups__c = true
     ORDER BY User__r.Name`
  );
  console.log(`\n=== Existing wildcard rows (${wildcards.length}) ===`);
  for (const r of wildcards) {
    console.log(`  ${r.Id}  ${r.User__r?.Name.padEnd(28)} Status=${r.Status__c.padEnd(10)} profile=${r.User__r?.Profile?.Name}  active=${r.User__r?.IsActive}`);
  }

  // 3. "Lead Data Export" permset assignments (admin-assistant cohort).
  const exportPermSet: any[] = await sf.soql(
    `SELECT Assignee.Id, Assignee.Name, Assignee.IsActive, Assignee.Profile.Name
     FROM PermissionSetAssignment
     WHERE PermissionSet.Name = 'Lead_Data_Export' AND Assignee.IsActive = true
     ORDER BY Assignee.Name`
  ).catch((e: any) => {
    console.log(`\n(Lead Data Export query err: ${(e.message || '').slice(0, 200)})`);
    return [];
  });
  console.log(`\n=== Lead Data Export permset holders (${exportPermSet.length}) ===`);
  for (const r of exportPermSet) {
    console.log(`  ${r.Assignee?.Id}  ${r.Assignee?.Name.padEnd(28)} profile=${r.Assignee?.Profile?.Name}`);
  }

  // 4. Top users by approved-group count (broad existing coverage — proxy for "kinda admin").
  const allAssigns: any[] = await sf.soql(
    `SELECT User__c, User__r.Name, User__r.IsActive, User__r.Profile.Name
     FROM User_Group_Access__c
     WHERE Status__c = 'Approved' AND Group__c != null`
  );
  const counts = new Map<string, { name: string; profile: string; active: boolean; n: number }>();
  for (const r of allAssigns) {
    if (!r.User__c) continue;
    if (!counts.has(r.User__c)) {
      counts.set(r.User__c, {
        name: r.User__r?.Name || '?',
        profile: r.User__r?.Profile?.Name || '?',
        active: !!r.User__r?.IsActive,
        n: 0,
      });
    }
    counts.get(r.User__c)!.n++;
  }
  const ranked = [...counts.entries()]
    .filter(([, v]) => v.active)
    .sort((a, b) => b[1].n - a[1].n)
    .slice(0, 15);
  console.log(`\n=== Top 15 active users by approved-group count (proxy for broad-access roles) ===`);
  for (const [uid, v] of ranked) {
    console.log(`  ${uid}  ${v.name.padEnd(28)} groups=${String(v.n).padStart(3)}  profile=${v.profile}`);
  }

  // 5. Specific named candidates: Pedro Galindo + Erick Moretti.
  const named: any[] = await sf.soql(
    `SELECT Id, Name, IsActive, Profile.Name, Username
     FROM User
     WHERE Name IN ('Pedro Galindo', 'Erick Moretti')
     ORDER BY Name`
  );
  console.log(`\n=== Named candidates from prior planning (Fausto's "edit everything, no exports") ===`);
  for (const u of named) {
    console.log(`  ${u.Id}  ${u.Name.padEnd(28)} active=${u.IsActive}  profile=${u.Profile?.Name}`);
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
