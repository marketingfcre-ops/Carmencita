/**
 * Fix the 6 leads whose Group_old2__c is a comma-separated list of multiple
 * group names (the agent meant "this lead is in both X and Y", not "this lead
 * is in one group named 'X, Y'").
 *
 * Per the user (2026-05-28), the reconcile committed earlier today preserved
 * the literal comma-names by creating bogus single Group__c records like
 * "HiaApts, LitHavApt". We now:
 *   1. Look up the real canonical Group__c.Id for each component group
 *   2. Update Lead.Group__c to the FIRST component (preserves legacy lookup)
 *   3. Create Lead_List_Assignment__c for EACH component (Status='Approved')
 *   4. Delete the 2 bogus single-name groups ("HiaApts, LitHavApt",
 *      "LitHat,  LitHavCom") that the reconcile created
 *
 * Idempotent. Dry-run by default.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/fix-comma-multi-group-leads.ts
 *   tsx --env-file .env.local scripts/migrations/fix-comma-multi-group-leads.ts --commit
 */

import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const TARGET: SfTarget = 'prod';
const COMMIT = process.argv.includes('--commit');

// Each entry maps a literal Group_old2__c value to the canonical Group__c
// names it actually represents (in order — the FIRST is what Lead.Group__c
// gets set to). Use exact Group__c.Name strings — looked up case-insensitively
// at runtime against the live schema.
const MULTI_GROUP_MAP: Record<string, string[]> = {
  'HiaApts, LitHavApt':     ['HialeahApts', 'LittleHavanaApt'],
  'LitHat,  LitHavCom':     ['LittleHaiti', 'LittleHavanaCom'],
  'CID, BVM':               ['CID', 'BVM'],
  'LibCityCom, Cindi':      ['LibCityCom', 'Cindi'],
  'CID, LIBCITYCOM':        ['CID', 'LibCityCom'],
  'Hialeah comm, allapa':   ['HialeahCom', 'Allapattah'],
};

// Bogus single-name groups the reconcile created today that we need to drop
// after re-routing the leads above. Looked up by exact Name.
const BOGUS_GROUPS_TO_DELETE = ['HiaApts, LitHavApt', 'LitHat,  LitHavCom'];

async function main() {
  console.log(`\n🧹 Fix comma-separated multi-group Group_old2__c values`);
  console.log(`   target: ${TARGET}`);
  console.log(`   mode:   ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Build lowercase Name → Group__c.Id map
  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const groupByLowerName = new Map<string, string>();
  for (const g of groups) groupByLowerName.set(g.Name.toLowerCase(), g.Id);

  // 2. For each comma-multi-value, find the lead(s) and figure out the
  //    component canonical Ids.
  const planUpdates: Array<{ leadId: string; firstCanonicalId: string; allCanonicalIds: string[]; originalText: string; firstName: string; allNames: string[] }> = [];
  for (const [text, componentNames] of Object.entries(MULTI_GROUP_MAP)) {
    // Look up each component
    const ids: string[] = [];
    const missing: string[] = [];
    for (const n of componentNames) {
      const id = groupByLowerName.get(n.toLowerCase());
      if (id) ids.push(id);
      else missing.push(n);
    }
    if (missing.length) {
      console.warn(`  ⚠ "${text}": missing canonical(s) [${missing.join(', ')}] — skipping`);
      continue;
    }
    const leads: any[] = await sf.soql(
      `SELECT Id, Name, Group__c FROM Lead WHERE Group_old2__c = '${text.replace(/'/g, "\\'")}'`
    );
    for (const lead of leads) {
      planUpdates.push({
        leadId: lead.Id,
        firstCanonicalId: ids[0],
        allCanonicalIds: ids,
        originalText: text,
        firstName: componentNames[0],
        allNames: componentNames,
      });
    }
  }

  console.log(`\nPlan: ${planUpdates.length} lead(s) to re-route, each into ${
    Math.max(...planUpdates.map((p) => p.allCanonicalIds.length))
  } groups`);
  for (const p of planUpdates) {
    console.log(`  ${p.leadId}  "${p.originalText}"  →  Lead.Group__c=${p.firstName}  + junctions to [${p.allNames.join(', ')}]`);
  }

  // 3. Look up the bogus Group__c Ids to delete
  console.log(`\nBogus groups to delete:`);
  const bogusIds: Array<{ id: string; name: string }> = [];
  for (const name of BOGUS_GROUPS_TO_DELETE) {
    const id = groupByLowerName.get(name.toLowerCase());
    if (id) {
      bogusIds.push({ id, name });
      console.log(`  ${id}  "${name}"`);
    } else {
      console.log(`  ⊘ "${name}" — not found (already deleted?)`);
    }
  }

  // 4. Existing Lead_List_Assignment__c for these leads (so we don't dupe)
  if (planUpdates.length > 0) {
    const leadIds = planUpdates.map((p) => `'${p.leadId}'`).join(',');
    const existing: any[] = await sf.soql(
      `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c WHERE Lead__c IN (${leadIds})`
    );
    const existingKey = new Set(existing.map((e) => `${e.Lead__c}|${e.Group__c}`));
    let toCreate = 0;
    for (const p of planUpdates) {
      for (const gid of p.allCanonicalIds) {
        if (!existingKey.has(`${p.leadId}|${gid}`)) toCreate++;
      }
    }
    console.log(`\nLead_List_Assignment__c to create: ${toCreate} (skip ${existing.length} existing)`);

    if (!COMMIT) {
      console.log(`\n🧪 Dry-run only. Re-run with --commit to actually write.`);
      return;
    }

    // ----- COMMIT path -----
    // (a) PATCH Lead.Group__c to the first component
    console.log(`\nPhase 1: PATCH Lead.Group__c → first component`);
    for (const p of planUpdates) {
      const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/Lead/${p.leadId}`;
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ Group__c: p.firstCanonicalId }),
      });
      if (!res.ok) console.error(`  ✗ ${p.leadId}: ${res.status} ${await res.text()}`);
      else console.log(`  ✓ ${p.leadId} → ${p.firstName}`);
    }

    // (b) Create Lead_List_Assignment__c for each component (skip existing)
    console.log(`\nPhase 2: create Lead_List_Assignment__c rows`);
    const newAssignments: any[] = [];
    for (const p of planUpdates) {
      for (const gid of p.allCanonicalIds) {
        if (existingKey.has(`${p.leadId}|${gid}`)) continue;
        newAssignments.push({
          attributes: { type: 'Lead_List_Assignment__c' },
          Lead__c: p.leadId,
          Group__c: gid,
          Status__c: 'Approved',
        });
      }
    }
    if (newAssignments.length > 0) {
      const url = `${sf.instanceUrl}/services/data/v59.0/composite/sobjects`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ allOrNone: false, records: newAssignments }),
      });
      const results: any[] = await res.json();
      const failed = results.filter((r) => !r.success);
      console.log(`  Created ${results.length - failed.length}/${results.length}${failed.length ? ` (${failed.length} failed)` : ''}`);
      for (const f of failed.slice(0, 3)) console.log(`    failed: ${JSON.stringify(f.errors).slice(0, 200)}`);
    }
  }

  // (c) Delete the bogus single-name groups
  if (!COMMIT) return;
  if (bogusIds.length > 0) {
    console.log(`\nPhase 3: delete bogus single-name groups`);
    for (const b of bogusIds) {
      const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/Group__c/${b.id}`;
      const res = await fetch(url, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${sf.accessToken}` },
      });
      if (!res.ok) console.error(`  ✗ ${b.name}: ${res.status} ${await res.text()}`);
      else console.log(`  ✓ deleted ${b.name}`);
    }
  }

  console.log(`\n✅ Done.`);
}

main().catch((e) => { console.error('💀 Crashed:', e); process.exit(1); });
