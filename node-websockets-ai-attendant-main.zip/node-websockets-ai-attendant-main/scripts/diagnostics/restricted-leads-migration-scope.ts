/**
 * Restricted-leads MIGRATION scope — read-only.
 *
 * For each of the 11 restricted "lists", find the matching/duplicate/close-spelled
 * Group__c records and count how many Leads currently point at each. This scopes
 * the migration (how many leads move, which dup groups to merge) and the cleanup.
 *
 * Also resolves the 3 admin User Ids (cfm@, ct@, Jesus) for the permission set.
 *
 * Read-only. Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/restricted-leads-migration-scope.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

// Canonical list name (tidied) ← raw name(s) as given by Fausto.
const LISTS: { tidy: string; raw: string }[] = [
  { tidy: 'ALFs Broward & Palm Beach', raw: 'ALFs broward Palm' },
  { tidy: 'Dania Multifamily', raw: 'DaniaMulti' },
  { tidy: 'South Broward Apartments', raw: 'SouthBrowardApts' },
  { tidy: 'Hollywood Apts 33023/33024', raw: 'hollywoodapt33023_4' },
  { tidy: 'South Broward Apts 33020', raw: 'southbrowardapt33020' },
  { tidy: 'Hallandale Multifamily', raw: 'Hallandale MF' },
  { tidy: 'North Miami Apartments', raw: 'NorthMiaApts' },
  { tidy: 'Pompano Multifamily', raw: 'PompanoMultiFam' },
  { tidy: 'Broward Multifamily', raw: 'browardmulti' },
  { tidy: 'West Fort Lauderdale Multifamily', raw: 'w fort laderdale mf' },
  { tidy: 'Fort Lauderdale Apartments', raw: 'FTLApts' },
];

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
// keyword sets for fuzzy candidate detection
const KEYWORDS: Record<string, string[]> = {
  'ALFs broward Palm': ['alf'],
  DaniaMulti: ['dania'],
  SouthBrowardApts: ['southbroward', 'sbroward'],
  hollywoodapt33023_4: ['hollywood', '33023', '33024'],
  southbrowardapt33020: ['33020'],
  'Hallandale MF': ['hallandale'],
  NorthMiaApts: ['northmia', 'northmiami', 'nmiami'],
  PompanoMultiFam: ['pompano'],
  browardmulti: ['browardmulti', 'browardmf'],
  'w fort laderdale mf': ['fortlaud', 'ftlaud', 'wftl', 'wfortlaud', 'laderdale'],
  FTLApts: ['ftlapts', 'fortlauderdaleapt', 'ftlauderdale'],
};

async function main() {
  const sf = (await sfClient('prod')) as any;

  // All groups (only ~464) + lead counts by group.
  const groups: { Id: string; Name: string }[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const counts: { Group__c: string; cnt: number }[] = await sf.soql(
    `SELECT Group__c gid, COUNT(Id) cnt FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const countById = new Map<string, number>();
  for (const c of counts as any[]) countById.set(c.gid, c.cnt);

  console.log(`\n📊 ${groups.length} Group__c records total. Leads attached to a group: ${
    [...countById.values()].reduce((a, b) => a + b, 0)
  }\n`);

  let migrateTotal = 0;
  for (const { tidy, raw } of LISTS) {
    const nraw = norm(raw);
    const kws = KEYWORDS[raw] || [];
    const candidates = groups.filter((g) => {
      const ng = norm(g.Name);
      return ng === nraw || ng.includes(nraw) || nraw.includes(ng) || kws.some((k) => ng.includes(k));
    });
    const listLeads = candidates.reduce((a, g) => a + (countById.get(g.Id) || 0), 0);
    migrateTotal += listLeads;
    console.log(`▶ ${tidy}`);
    console.log(`    raw="${raw}"  candidate groups: ${candidates.length}  leads to migrate: ${listLeads}`);
    for (const g of candidates) {
      console.log(`      - ${g.Name.padEnd(34)} ${g.Id}  (${countById.get(g.Id) || 0} leads)`);
    }
    if (candidates.length === 0) console.log(`      (no matching Group__c — list may be new/empty)`);
    if (candidates.length > 1) console.log(`      ⚠️ ${candidates.length} candidates → likely duplicates to merge`);
  }
  console.log(`\n── total leads across all 11 lists (pre-dedup): ${migrateTotal} ──`);

  // Admin users for the View-All permission set.
  const admins = await sf.soql(
    `SELECT Id, Name, Username, Profile.Name FROM User
     WHERE Username IN ('cfm@faustocommercial.com','ct@faustocommercial.com')
        OR (Profile.Name = 'System Administrator' AND IsActive = true)
     ORDER BY Profile.Name`
  );
  console.log(`\n🔑 Candidate admins for the Restricted-Leads View-All permset:`);
  for (const u of admins as any[]) {
    console.log(`   ${u.Name.padEnd(26)} ${(u.Profile?.Name || '').padEnd(22)} ${u.Username}  ${u.Id}`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
