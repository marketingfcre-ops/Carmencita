/**
 * Audit Giovanni Bertolotti's group access against:
 *   - The 3 groups Nathalie's email mentions: LibCityCom, LittleHaitiCorridor, FlagamiCom
 *   - Where Ashleen Cruz works (to identify partnership overlap)
 *   - Leads Giovanni actively owns or worked on recently (to ground "missed by script" vs "new partnership")
 *
 * Read-only.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/giovanni-access-audit.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Confirm canonical groups exist
  console.log('=== Canonical groups Nathalie mentioned ===');
  const groupNames = ['LibCityCom', 'LittleHaitiCorridor', 'FlagamiCom'];
  for (const name of groupNames) {
    const g: any[] = await sf.soql(
      `SELECT Id, Name FROM Group__c WHERE Name = '${name}' LIMIT 5`
    );
    if (!g.length) console.log(`  ✗ "${name}" not found`);
    else for (const x of g) console.log(`  ✓ ${x.Id}  "${x.Name}"`);
  }

  // 2. Giovanni's current User_Group_Access — focus on the 3 groups
  console.log('\n=== Giovanni Bertolotti — access to the 3 groups ===');
  for (const name of groupNames) {
    const a: any[] = await sf.soql(
      `SELECT Status__c FROM User_Group_Access__c
       WHERE User__r.Name = 'Giovanni Bertolotti' AND Group__r.Name = '${name}'`
    );
    if (!a.length) console.log(`  ✗ NO access to "${name}"`);
    else console.log(`  ${a[0].Status__c.padEnd(10)} "${name}"`);
  }

  // 3. Giovanni's owned leads — count by Group
  console.log('\n=== Giovanni\'s owned leads — group distribution (top 15) ===');
  const ownedByGroup: any[] = await sf.soql(
    `SELECT Group__r.Name g, COUNT(Id) cnt
     FROM Lead WHERE Owner.Name = 'Giovanni Bertolotti' AND Group__c != null
     GROUP BY Group__r.Name ORDER BY COUNT(Id) DESC LIMIT 15`
  );
  console.log(`  ${ownedByGroup.length} groups; total owned leads with Group__c set: ${ownedByGroup.reduce((s: number, r: any) => s + r.cnt, 0)}`);
  for (const r of ownedByGroup) console.log(`    ${String(r.cnt).padStart(4)}  ${r.g}`);
  // Group_old2 distribution (where Group__c is null)
  const ownedOrphans: any[] = await sf.soql(
    `SELECT Group_old2__c v, COUNT(Id) cnt FROM Lead
     WHERE Owner.Name = 'Giovanni Bertolotti' AND Group__c = null AND Group_old2__c != null
     GROUP BY Group_old2__c ORDER BY COUNT(Id) DESC LIMIT 10`
  );
  if (ownedOrphans.length) {
    console.log(`\n  Giovanni-owned leads still orphaned (Group__c=null, Group_old2 set):`);
    for (const r of ownedOrphans) console.log(`    ${String(r.cnt).padStart(4)}  "${r.v}"`);
  } else {
    console.log(`\n  Giovanni-owned leads still orphaned: 0`);
  }

  // 4. Ashleen Cruz's owned leads — group distribution (where Gio partners)
  console.log('\n=== Ashleen Cruz — owned leads, group distribution (top 15) ===');
  const ashleenByGroup: any[] = await sf.soql(
    `SELECT Group__r.Name g, COUNT(Id) cnt
     FROM Lead WHERE Owner.Name = 'Ashleen Cruz' AND Group__c != null
     GROUP BY Group__r.Name ORDER BY COUNT(Id) DESC LIMIT 15`
  );
  for (const r of ashleenByGroup) console.log(`    ${String(r.cnt).padStart(4)}  ${r.g}`);

  // 5. Did Gio EVER have a lead in FlagamiCom? (rule out grandfathering bug)
  console.log('\n=== Has Giovanni ever owned a FlagamiCom lead? ===');
  const gioFlagami: any[] = await sf.soql(
    `SELECT COUNT(Id) cnt FROM Lead
     WHERE Owner.Name = 'Giovanni Bertolotti' AND Group__r.Name = 'FlagamiCom'`
  );
  console.log(`  Currently owns: ${gioFlagami[0]?.cnt}`);
  // History (any lead where Group_old2 hints FlagamiCom)
  const gioFlagamiOld: any[] = await sf.soql(
    `SELECT COUNT(Id) cnt FROM Lead
     WHERE Owner.Name = 'Giovanni Bertolotti' AND Group_old2__c LIKE '%FlagamiCom%'`
  );
  console.log(`  Owns + Group_old2 contains FlagamiCom: ${gioFlagamiOld[0]?.cnt}`);

  // 6. Was the grandfathering script's logic "owns a lead in this group at run time"?
  //    If yes, Gio not owning FlagamiCom leads at run time → correctly not granted.
  //    This is then a NEW partnership request, not a script bug.
  console.log('\n=== Grandfathering rule was: User has Approved access to G if they own ≥1 lead currently in G ===');
  console.log(`  → If Gio owns 0 FlagamiCom leads, he correctly was NOT granted access.`);
  console.log(`  → His partnership work on Ashleen's leads is genuinely new — no script bug.`);
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
