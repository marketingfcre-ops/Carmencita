# Email to Nathalie / Fausto — Group reconciliation update

> Draft. Edit subject/greeting/sign-off to taste before sending.

**Subject:** Group cleanup — what I sent earlier was incomplete, redoing it properly

---

Hi Nathalie,

Quick update on the group cleanup work.

The list I sent earlier was incomplete. I had only looked at the **Group** lookup field, but most of your day-to-day groups actually live in **Group_old2** (the free-form text field) — which is what your Excel was populated from. That's why so many of the groups you flagged as missing were "missing": they were sitting in Group_old2 and I hadn't reconciled them yet.

I went back and matched the Group_old2 values against the Group lookup table. After deduping spelling variants and splitting by property type (so Hialeah Commercial doesn't get lumped with Hialeah Apartments, for example), here's where things stand:

- **~13,000 leads** will get linked to a proper Group record automatically
- **161 groups** in the Group table absorb their text-field spelling variants (e.g. "DORALINDUSTRIAL", "DORAL INDUSTRIAL", "Doral Indust" all roll into the existing "Doral Industrial" canonical)
- **69 new Group records** would need to be created for lists that don't have a canonical yet — things like "FTL NE Ind" (2,898 leads), "BrowardShopping" (2,740), "Design North" (1,479), "BobbyRetail" (1,229), etc.
- **~360 leads** are stuck on Group_old2 values that don't look like real groups — placeholders, addresses, company names, asset types without an area, etc.

Before I commit any of this I need your input on a few things:

---

### 1. BVM

The tag `BVM` appears 235 times, almost always as a suffix on existing groups (e.g. `"CID; BVM"`, `"Allapattah; BVM"`, `"LibCityCom; BVM"`). The owners are mostly Carlos Miranda-Brassac, Markos Bertolotti, Giovanni Bertolotti, Ernesto Diaz, plus a few others.

**What is BVM?** Is it a team / agent group like CFM and TS? If yes, should the BVM-tagged leads be added to a "BVM" Group in addition to their main group?

---

### 2. "New Flagami" / "NEW FLAGAMI" / "NEW FAGAMI" — ~262 leads

These three variants show up alongside the regular "Flagami Com" list. The word "NEW" looks deliberate. Is this a separate sub-area, a "newly listed" flag, or just a typo I should fold into Flagami Com?

---

### 3. "203202" — 33 leads

There's a Group called `203202`. Just a number. What's it for? Should it stay?

---

### 4. Area-only values — what to do?

A bunch of Group_old2 values are just an area name with no property type. The Group table almost always has type-specific canonicals (Hialeah Com, HialeahApt, HialeahRetail) but no generic "Hialeah" group, so I don't have an obvious home for these:

| Group_old2 value | Lead count |
|---|---|
| EHIA / EHIALEAH (East Hialeah) | 343 |
| LITTLEHAVANA / LIttle Havana / LittleHav / LitHav / Lilhavana / others | 90 |
| OpaLocka | 17 |
| Surfside | 15 |
| Hialeah (alone) | 11 |
| Coral Gables / Coralgables | 8 |
| Miami Gardens | 6 |
| GABLES | 2 |
| Broward | 4 |
| Aventura, Florida City, Magic City, Miami Springs, Clewiston, Grapeland, southpark, El Dorado | 1 each |

**Options:**
- (a) Create a generic-area Group for each (e.g. a `LittleHavana` Group, separate from `LittleHavanaApt`). Agents can later split by type as needed.
- (b) Have someone go through them and tag the property type, then assign to the right type-specific canonical.
- (c) Leave them on Group_old2 only, no Group assignment, and the agents reclassify case-by-case.

What's your preference?

---

### 5. Asset-type-only values — same question

A handful of Group_old2 values are just a property type with no area:

| Value | Lead count |
|---|---|
| MULTIFAMILY | 18 |
| Retail / retailers | 8 |
| Duplex | 5 |
| Tenant Broker / Broker Tenant | 4 |
| INDUSTRIAL / Industrial group / Industrial condo | 4 |
| Fourplex | 2 |
| Motels | 1 |
| Single Family | 1 |
| Triplex | 1 |
| LOT | 1 |
| Restaurant | 1 |
| parking lot | 1 |

Same options as area-only. Probably easiest is someone glances at each lead and tags the right group manually — handful of records, not a lot of work.

---

### 6. Cleanup candidates — clear placeholders / not real groups

These look like workflow notes, status flags, or stuff that accidentally got typed into the Group field. Total ~115 records:

| Value | Lead count | Probably is |
|---|---|---|
| n/a / na | 45 | placeholder |
| Urgent | 27 | status flag |
| preforeclosure | 14 | status flag |
| None | 10 | placeholder |
| 71st Ind | 11 | partial / ambiguous |
| DELETE | 3 | marked for deletion |
| misc | 3 | placeholder |
| UPDATE ME*** | 1 | reminder |
| LEAD | 1 | not a group |
| Disc., Vacant, Has #s, Extra, LEASING, listing tasks, Group, In, FL, etc. | 1 each | not groups |

Plus ~50 single-lead entries that look like addresses (`1058 SW 1 ST`, `504 foster rd`, `2421 nw 27 ave`, etc.) or LLC / company names (`OcaAquatics`, `three dores llc`, `PROLOGIS`, `BORA APARTMENTS`, `HURWIT INVESTMENTS`, etc.) — these belong in Account Name, not Group.

**Proposal:** I won't assign any Group to these leads (Group stays null). They keep their Group_old2 text so you can pull them up and reclassify case-by-case. If you want, I can also clear the Group_old2 field on the clearly-garbage ones so they stop appearing in future reports.

Sound reasonable?

---

That's it for now. Once I have answers I'll commit the changes and the multi-list / approval workflow stays on track.

Thanks,
Jesús
