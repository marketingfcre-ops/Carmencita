/**
 * Salesforce Files access — fetch a property's flyer PDF for email delivery.
 *
 * Flyers attach to Property__c as modern Files (ContentDocumentLink →
 * ContentVersion). The marketing convention is "<ADDRESS>-<AGENT>-FLYER.pdf" in
 * the original filename (PathOnClient). This module finds the best flyer for a
 * property and downloads its bytes so the email transport can attach it.
 *
 * Selection order (best-effort until the rename cleanup standardizes names):
 *   1. A PDF whose Title or filename contains "flyer"
 *   2. Otherwise, if there's exactly ONE PDF on the record, use it
 *   3. Otherwise null — ambiguous; caller should not attach a guess
 *
 * Returns null when no confident flyer exists → caller offers no email (matches
 * the product rule: don't offer a flyer that isn't reliably there).
 */

import { sfClient, type SfClient } from './sf-client';

export interface FlyerFile {
  filename: string;
  content: Buffer;
  contentType: string;
  contentVersionId: string;
}

// Cache the authed client so runtime sends don't re-auth on every call.
let cached: SfClient | null = null;
async function client(): Promise<SfClient> {
  if (!cached) cached = await sfClient('prod');
  return cached;
}

const FLYER_RE = /flyer/i;

interface VersionRow {
  Id: string;
  ContentDocumentId: string;
  Title: string;
  PathOnClient: string;
  FileExtension: string;
  ContentSize: number;
}

/**
 * Pick the best flyer ContentVersion for a property (no download).
 *   1) a PDF whose Title/filename contains "flyer"
 *   2) else the only PDF
 *   3) else null (ambiguous)
 */
async function findFlyerVersion(sf: SfClient, sfPropertyId: string): Promise<VersionRow | null> {
  const safeId = sfPropertyId.replace(/'/g, "\\'");
  const links = await sf.soql<{ ContentDocumentId: string }>(
    `SELECT ContentDocumentId FROM ContentDocumentLink WHERE LinkedEntityId = '${safeId}'`
  );
  if (links.length === 0) return null;
  const docIds = [...new Set(links.map((l) => l.ContentDocumentId))];

  const versions = await sf.soql<VersionRow>(
    `SELECT Id, ContentDocumentId, Title, PathOnClient, FileExtension, ContentSize
     FROM ContentVersion
     WHERE ContentDocumentId IN (${docIds.map((d) => `'${d}'`).join(',')}) AND IsLatest = true`
  );
  const pdfs = versions.filter((v) => (v.FileExtension || '').toLowerCase() === 'pdf');
  if (pdfs.length === 0) return null;
  const named = pdfs.find((v) => FLYER_RE.test(v.Title || '') || FLYER_RE.test(v.PathOnClient || ''));
  return named || (pdfs.length === 1 ? pdfs[0] : null);
}

/** Cheap existence check — does this property have a confident flyer? (no download) */
export async function propertyHasFlyer(sfPropertyId: string): Promise<boolean> {
  const sf = await client();
  return (await findFlyerVersion(sf, sfPropertyId)) !== null;
}

/**
 * Find and download the flyer PDF for a Property__c. Returns null if there's no
 * confident flyer (no PDF, or multiple PDFs and none named "flyer").
 */
export async function getFlyerForProperty(sfPropertyId: string): Promise<FlyerFile | null> {
  const sf = await client();
  const chosen = await findFlyerVersion(sf, sfPropertyId);
  if (!chosen) return null;

  const bytes = await downloadVersion(sf, chosen.Id);
  if (!bytes) return null;

  const filename = (chosen.PathOnClient || chosen.Title || 'flyer').replace(/[^\w.\- ]+/g, '_');
  return {
    filename: filename.toLowerCase().endsWith('.pdf') ? filename : `${filename}.pdf`,
    content: bytes,
    contentType: 'application/pdf',
    contentVersionId: chosen.Id,
  };
}

/** Download ContentVersion binary (VersionData) as a Buffer. */
async function downloadVersion(sf: SfClient, contentVersionId: string): Promise<Buffer | null> {
  const url = `${sf.instance}/services/data/v59.0/sobjects/ContentVersion/${contentVersionId}/VersionData`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) {
    console.warn(`[sf-files] VersionData ${contentVersionId} failed: ${res.status}`);
    return null;
  }
  return Buffer.from(await res.arrayBuffer());
}
