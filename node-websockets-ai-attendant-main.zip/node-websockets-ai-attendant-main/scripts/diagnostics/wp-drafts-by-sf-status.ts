/**
 * Read-only: for every WP draft post, look up its linked SF record and
 * report the SF Status__c distribution.
 *
 * Goal: figure out what percentage of WP drafts represent CLOSED deals
 * (Closed Won, Closed Lost, Off Market, etc.) — those probably want
 * Sold/Off-Market property_status taxonomy in WP instead of being left
 * as untagged drafts.
 *
 * Also surfaces drafts with NO SF backing — those are orphans (WP-only
 * content with no SF source of truth).
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-drafts-by-sf-status.ts
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Address__c: string | null;
  Status__c: string | null;
  Listing_Type__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  date: string;
  modified: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllDrafts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (let page = 1; page <= 20; page++) {
    const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=draft&context=edit&_fields=id,date,modified,status,title,fave_property_address,featured_media`;
    const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
    if (!res.ok) break;
    const batch = (await res.json()) as any[];
    if (!Array.isArray(batch) || batch.length === 0) break;
    for (const p of batch) {
      out.push({
        id: p.id,
        date: p.date || '',
        modified: p.modified || '',
        status: p.status || '',
        title: (p.title?.rendered || '').toString(),
        fave_property_address: p.fave_property_address || '',
        featured_media: p.featured_media || 0,
      });
    }
    if (batch.length < 100) break;
  }
  return out;
}

function bucketForStatus(s: string | null): 'active' | 'closed' | 'midDeal' | 'other' {
  if (!s) return 'other';
  const v = s.toLowerCase();
  if (v === 'active' || v === 'draft/pre-market') return 'active';
  if (
    v === 'closed lost' ||
    v === 'closed won' ||
    v === 'off market' ||
    v === 'sold' ||
    v === 'lost'
  )
    return 'closed';
  if (v === 'pending' || v === 'contract signed' || v === 'loi signed') return 'midDeal';
  return 'other';
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔬 WP drafts × SF Status__c audit (read-only)\n');

  const { token, instance } = await sfAuth();
  const [sfAll, drafts] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Address__c, Status__c, Listing_Type__c, Listing_Agent__r.Name, WP_Post_ID__c
         FROM Property__c
        WHERE WP_Post_ID__c != NULL`
    ),
    fetchAllDrafts(),
  ]);

  // Index SF by WP id
  const sfByWpId = new Map<number, SfProperty>();
  for (const r of sfAll) if (r.WP_Post_ID__c) sfByWpId.set(r.WP_Post_ID__c, r);

  console.log(`WP drafts:                    ${drafts.length}`);
  console.log(`SF records with WP link:      ${sfAll.length}\n`);

  // Bucket drafts by their SF status (or "no SF link" if not in SF)
  type Row = { wp: WpPost; sf: SfProperty | null };
  const byStatus = new Map<string, Row[]>();
  let noSfBacking = 0;
  let withPhoto = 0;
  let noPhoto = 0;

  for (const wp of drafts) {
    if (wp.featured_media > 0) withPhoto++;
    else noPhoto++;
    const sf = sfByWpId.get(wp.id) || null;
    const statusKey = sf ? sf.Status__c || '(SF status empty)' : '(no SF backing)';
    if (!sf) noSfBacking++;
    const arr = byStatus.get(statusKey) || [];
    arr.push({ wp, sf });
    byStatus.set(statusKey, arr);
  }

  console.log(`Drafts with featured image:   ${withPhoto}`);
  console.log(`Drafts without featured img:  ${noPhoto}`);
  console.log(`Drafts with NO SF backing:    ${noSfBacking}\n`);

  // ─── Distribution table ─────────────────────────────────────────────
  console.log('── Drafts by SF Status__c ──\n');
  console.log(`${'SF Status'.padEnd(30)} ${'Count'.padStart(6)}  ${'%'.padStart(5)}  Bucket`);
  console.log('─'.repeat(60));
  const sorted = [...byStatus.entries()].sort((a, b) => b[1].length - a[1].length);
  let totalActive = 0,
    totalClosed = 0,
    totalMidDeal = 0,
    totalOther = 0,
    totalUnlinked = 0;
  for (const [status, rows] of sorted) {
    const pct = ((rows.length / drafts.length) * 100).toFixed(1);
    const bucket =
      status === '(no SF backing)'
        ? 'unlinked'
        : bucketForStatus(status === '(SF status empty)' ? null : status);
    console.log(`${status.padEnd(30)} ${String(rows.length).padStart(6)}  ${pct.padStart(5)}%  ${bucket}`);
    if (status === '(no SF backing)') totalUnlinked += rows.length;
    else if (bucket === 'active') totalActive += rows.length;
    else if (bucket === 'closed') totalClosed += rows.length;
    else if (bucket === 'midDeal') totalMidDeal += rows.length;
    else totalOther += rows.length;
  }
  console.log('─'.repeat(60));
  const pct = (n: number) => ((n / drafts.length) * 100).toFixed(1) + '%';
  console.log(`${'TOTAL ACTIVE (need curation)'.padEnd(30)} ${String(totalActive).padStart(6)}  ${pct(totalActive).padStart(6)}`);
  console.log(`${'TOTAL CLOSED (sold/lost/off)'.padEnd(30)} ${String(totalClosed).padStart(6)}  ${pct(totalClosed).padStart(6)}`);
  console.log(`${'TOTAL MID-DEAL (LOI/contract)'.padEnd(30)} ${String(totalMidDeal).padStart(6)}  ${pct(totalMidDeal).padStart(6)}`);
  console.log(`${'TOTAL OTHER'.padEnd(30)} ${String(totalOther).padStart(6)}  ${pct(totalOther).padStart(6)}`);
  console.log(`${'TOTAL UNLINKED'.padEnd(30)} ${String(totalUnlinked).padStart(6)}  ${pct(totalUnlinked).padStart(6)}`);

  // ─── Detail per bucket ───────────────────────────────────────────────
  for (const [status, rows] of sorted) {
    if (rows.length === 0) continue;
    console.log('\n' + '═'.repeat(78));
    console.log(`${status} — ${rows.length} draft${rows.length === 1 ? '' : 's'}`);
    console.log('═'.repeat(78));
    // Sort by date desc (newest first)
    rows.sort((a, b) => b.wp.date.localeCompare(a.wp.date));
    for (const r of rows.slice(0, 50)) {
      const photo = r.wp.featured_media > 0 ? '📷' : '🚫';
      const sfBit = r.sf
        ? `${r.sf.Address__c || ''} / ${r.sf.Listing_Type__c || ''} / ${r.sf.Listing_Agent__r?.Name || '—'}`
        : '(no SF — WP-only post)';
      console.log(`   wp:${String(r.wp.id).padEnd(6)} ${r.wp.date.slice(0, 10)} ${photo}  "${r.wp.title.replace(/&#8211;/g, '–').slice(0, 55)}"`);
      console.log(`     ${sfBit}`);
    }
    if (rows.length > 50) console.log(`   ... and ${rows.length - 50} more`);
  }

  console.log('\n');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
