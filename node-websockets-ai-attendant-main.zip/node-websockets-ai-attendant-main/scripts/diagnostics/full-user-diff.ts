import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  const names = ['Martina Smoláková', 'Ernesto Diaz', 'Mauricio Villasuso', 'Markos Bertolotti', 'Classic Test Agent', 'Carlos Fausto Miranda'];

  // Get ALL queryable User fields
  const desc: any = await sf.describe('User');
  const allFields = (desc.fields || []).filter((f: any) => f.type !== 'address' && !f.calculated).map((f: any) => f.name);
  // Salesforce limits SOQL to ~10k chars — split into chunks if needed
  // For now, just use all fields, may need batching
  const fieldList = allFields.join(',');
  let users: any[];
  try {
    users = await sf.soql(`SELECT ${fieldList} FROM User WHERE Name IN (${names.map(n=>`'${n}'`).join(',')})`);
  } catch (e: any) {
    // If too long, query in 2 batches
    console.log('SOQL too long, splitting...');
    const half = Math.ceil(allFields.length / 2);
    const a = allFields.slice(0, half).join(',');
    const b = ['Id', ...allFields.slice(half)].join(',');
    const r1 = await sf.soql(`SELECT ${a} FROM User WHERE Name IN (${names.map(n=>`'${n}'`).join(',')})`);
    const r2 = await sf.soql(`SELECT ${b} FROM User WHERE Name IN (${names.map(n=>`'${n}'`).join(',')})`);
    const byId = new Map(r1.map((u:any) => [u.Id, u]));
    for (const u of r2) {
      const ex = byId.get(u.Id);
      if (ex) Object.assign(ex, u);
    }
    users = Array.from(byId.values());
  }

  console.log(`Total User fields: ${allFields.length}\n`);

  const byName = new Map<string, any>();
  for (const u of users) byName.set(u.Name, u);

  // Find fields where test agent differs from real users
  // We want to find: fields where Classic Test Agent has value X, but ALL the real "can't switch" users have value Y
  const test = byName.get('Classic Test Agent');
  const martina = byName.get('Martina Smoláková');
  const ernesto = byName.get('Ernesto Diaz');
  const mauricio = byName.get('Mauricio Villasuso');
  const markos = byName.get('Markos Bertolotti');
  const carlos = byName.get('Carlos Fausto Miranda');

  const realAgents = [martina, ernesto, mauricio, markos].filter(Boolean);

  const interestingDiffs: string[] = [];
  for (const f of allFields) {
    const testVal = test?.[f];
    const realVals = new Set(realAgents.map(r => r?.[f]));
    // If test differs from ALL real agents AND all real agents have the same value
    if (realVals.size === 1 && !realVals.has(testVal)) {
      const realVal = [...realVals][0];
      interestingDiffs.push(`${f.padEnd(50)} test="${testVal}"  realAgents="${realVal}"  carlos="${carlos?.[f]}"`);
    }
  }
  console.log(`=== Fields where test agent differs from ALL 4 real agents (and they all agree) ===`);
  console.log(`Count: ${interestingDiffs.length}\n`);
  for (const d of interestingDiffs) console.log(`  ${d}`);
}
main().catch(e=>{console.error(e);process.exit(1);});
