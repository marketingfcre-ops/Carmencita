/**
 * Per-agent review-status counts, pulled live from Salesforce.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/agent-review-counts.ts
 *
 * Output: a table of agent / total / reviewed / pending, sorted by pending desc
 * (so the most-behind agents are at the top of the list).
 *
 * "Reviewed" = the property's Notes_for_Marketing__c contains at least one
 * "[Agent Review YYYY-MM-DD]" entry — same parse logic the /review page uses.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  Listing_Agent__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  Notes_for_Marketing__c: string | null;
  Status__c: string | null;
}

async function sfAuth(): Promise<{ token: string; instance: string }> {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  return { token: access_token, instance: instance_url };
}

async function sfQuery<T>(
  token: string,
  instance: string,
  soql: string
): Promise<T[]> {
  let url:
    | string
    | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

function hasReview(notes: string | null): boolean {
  if (!notes) return false;
  return /\[Agent Review \d{4}-\d{2}-\d{2}\]/.test(notes);
}

async function main() {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET) {
    console.error('❌ Missing SF_* env vars.');
    process.exit(1);
  }

  console.log('\n📋 Agent review-status counts (live from Salesforce)\n');

  const { token, instance } = await sfAuth();

  // Match the /review page's filter exactly — it only loads Status__c = 'Active'
  // listings (see salesforce.ts:225). Counting anything else would inflate the
  // pending number with listings agents can't even see on their review page.
  const records = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, Listing_Agent__c, Listing_Agent__r.Name,
            Notes_for_Marketing__c, Status__c
       FROM Property__c
      WHERE Listing_Agent__c != NULL AND Status__c = 'Active'`
  );

  console.log(
    `${records.length} ACTIVE properties with an assigned listing agent (matches /review page).\n`
  );

  interface Tally {
    name: string;
    id: string;
    total: number;
    reviewed: number;
  }
  const byAgent = new Map<string, Tally>();
  for (const r of records) {
    const agentId = r.Listing_Agent__c!;
    const agentName = r.Listing_Agent__r?.Name || agentId;
    const t = byAgent.get(agentId) || {
      name: agentName,
      id: agentId,
      total: 0,
      reviewed: 0,
    };
    t.total++;
    if (hasReview(r.Notes_for_Marketing__c)) t.reviewed++;
    byAgent.set(agentId, t);
  }

  const rows = [...byAgent.values()]
    .map((t) => ({ ...t, pending: t.total - t.reviewed }))
    .sort((a, b) => b.pending - a.pending || b.total - a.total);

  // Pretty table
  const nameW = Math.max(5, ...rows.map((r) => r.name.length));
  const pad = (s: string, w: number) => s + ' '.repeat(Math.max(0, w - s.length));
  console.log(
    `${pad('AGENT', nameW)}   TOTAL  REVIEWED  PENDING`
  );
  console.log('─'.repeat(nameW + 30));
  for (const r of rows) {
    const flag = r.pending === 0 ? ' ✅' : '';
    console.log(
      `${pad(r.name, nameW)}   ${String(r.total).padStart(5)}  ${String(r.reviewed).padStart(8)}  ${String(r.pending).padStart(7)}${flag}`
    );
  }

  // Totals row
  const totT = rows.reduce((n, r) => n + r.total, 0);
  const totR = rows.reduce((n, r) => n + r.reviewed, 0);
  const totP = rows.reduce((n, r) => n + r.pending, 0);
  console.log('─'.repeat(nameW + 30));
  console.log(
    `${pad('TOTAL', nameW)}   ${String(totT).padStart(5)}  ${String(totR).padStart(8)}  ${String(totP).padStart(7)}`
  );

  // Markdown variant for pasting into the message to Nathalie
  console.log('\n── Markdown table (for pasting) ──\n');
  console.log('| Agent | Total | Reviewed | Pending |');
  console.log('|---|---:|---:|---:|');
  for (const r of rows) {
    console.log(`| ${r.name} | ${r.total} | ${r.reviewed} | ${r.pending} |`);
  }
  console.log(`| **Total** | **${totT}** | **${totR}** | **${totP}** |`);
  console.log('');

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
