# 05 — WordPress Sync & Marketing Integrations

This subsystem keeps the public website (faustocommercial.com) and the email
marketing platform in step with Salesforce. It is the "publishing arm" of
Fausto: when an agent changes a listing in Salesforce, this code pushes that
change to the website; when leads are captured, this code feeds them into the
right email lists.

There are three external systems involved:

1. **WordPress** (the public website, running the *Houzez* real-estate theme) —
   where listings appear to the public.
2. **Campaign Monitor** — the email marketing platform that holds the contact
   lists and sends the newsletters.
3. **make.com** — a no-code automation platform. This is **external**, managed
   in the client's own make.com account, not in this repo (see section 3).

---

## For the non-technical owner — what this does in plain terms

- Every property your team manages in Salesforce automatically appears on the
  website. When you change a price, an address, or the listing's stage,
  the website updates itself — no one has to retype anything into WordPress.
- When a deal closes, the listing does **not** vanish. A property marked
  **Closed Won** stays on the site with a green **SOLD** badge (like the
  "sold" trophies on Zillow); a property marked **Closed Lost** stays up with
  an **OFF MARKET** badge. This was a deliberate marketing decision — it keeps
  the site full of credible inventory, helps Google rankings (SEO), and builds
  toward the "our own LoopNet" goal.
- New listings are created as **drafts** (invisible to the public). Your
  marketing person adds photos and polished copy and then clicks Publish. The
  system is specifically built **not** to publish a half-finished listing by
  accident.
- People who call the attendant or come in as leads get sorted into email
  lists by what they want (buying vs. leasing) and the type of property
  (industrial, retail, office, etc.), so the right newsletters reach the right
  people.

The clever, hard-won safety mechanisms behind all this are described below for
the technical successor.

---

## 1. Salesforce → WordPress sync

### 1.1 The big picture

Salesforce is the **source of truth for structured data** (price, address,
sizes, status, listing type). WordPress is the **source of truth for marketing
copy** (the headline/title, the description body, hand-curated SEO, photos).
The sync respects that split rigorously — it pushes structured data *to* WP but
never overwrites marketing copy.

Flow of a change:

```
Agent edits Property__c in Salesforce
        │
        ▼
SF Flow fires an HTTP Callout  ──►  /webhooks/salesforce/event  (this app)
        │
        ▼
src/handlers/sf-property-changed.ts  →  handlePropertyChanged()
        │
        ├─ resolve the WP post for this SF record (WP_Post_ID__c, or backfill it)
        ├─ create a draft  (new listing)        → src/integrations/wordpress.ts
        └─ update post status + taxonomy + meta  → src/integrations/wordpress.ts
```

> The Salesforce side of this (the Flow, the HTTP Callout, the
> `/webhooks/salesforce/event` router) is covered in another handoff doc. This
> doc covers the WordPress side: what happens once `handlePropertyChanged()` is
> called.

The entry point is `handlePropertyChanged()` at
`src/handlers/sf-property-changed.ts:56`. It is **idempotent** — firing the same
event twice yields the same result.

### 1.2 The `WP_Post_ID__c` linkage (how SF knows which web page to update)

Each `Property__c` in Salesforce carries two link fields:

- `WP_Post_ID__c` — the **stable** numeric WordPress post ID. This is the
  durable join key.
- `Public_URL__c` — the public permalink (e.g.
  `https://faustocommercial.com/property/prime-value-add-opportunity/`). This
  can change when the slug changes, so it is treated as secondary.

Also, every WP post stores the SF record ID back in a Houzez meta field
`_sf_property_id` (`src/integrations/wordpress.ts:175`) — a reverse pointer that
makes audits and re-linking possible.

**When `WP_Post_ID__c` is missing**, `handlePropertyChanged()` does not blindly
create a new post (that would spawn duplicates). It first tries to *backfill*
the ID via `tryBackfillWpPostId()`
(`src/handlers/sf-property-changed.ts:175`), matching in this order:

1. **Slug** parsed from `Public_URL__c` → `findPropertyIdBySlug()`
   (`wordpress.ts:397`). Fast, single REST call.
2. **Normalized street address** against an in-memory WP address index →
   `findPropertyIdByAddress()` (`wordpress.ts:523`). Catches the ~150 April
   drafts whose URL never made it back to SF.
3. **WP native full-text search** → `findPropertyIdByTitleSearch()`
   (`wordpress.ts:334`). Last resort — catches posts where the address is only
   in the marketing-curated *title* (e.g. "Approved 36-Unit Development at 2306
   Van Buren"), not in the address meta.

Only if all three fail does it create a brand-new draft.

### 1.3 Creating a listing (draft-first)

`createNewListing()` (`sf-property-changed.ts:223`) → `createPropertyDraft()`
(`wordpress.ts:191`):

- Posts a new WP `properties` post with `status: 'draft'` (hard-coded in
  `buildWpPostBody()`, `wordpress.ts:142`). **New listings are always invisible
  to the public until a human publishes them.**
- If the SF status is `Draft/Pre-Market`, creation is skipped entirely
  (`sf-property-changed.ts:228`).
- After the post is created, Houzez `fave_*` meta is written via a second call
  (`writeHouzezMeta`, see 1.5).
- The new `WP_Post_ID__c` and `Public_URL__c` are written **back** to
  Salesforce (`sf-property-changed.ts:247`).

### 1.4 Updating a listing (price and everything else)

`updateExistingListing()` (`sf-property-changed.ts:273`) is where ongoing
propagation happens.

**What gets pushed from SF:**

- **Post status** (publish/draft/private) — subject to the auto-publish guard
  (1.7).
- **Listing-status taxonomy** (For Sale / For Lease / Sold / Off Market).
- **Houzez meta** — price, building size, lot size, year built, zip, full
  address (1.5). **This is where price propagates.**

**What is deliberately NOT pushed:** `title` and `content`. See the comment at
`sf-property-changed.ts:308`. Marketers edit headlines and descriptions on WP;
the sync must never clobber them on a routine SF status change.

So a price change in Salesforce flows: SF Flow → `handlePropertyChanged` →
`updateExistingListing` → `buildHouzezMeta` (cleans the price) →
`writeHouzezMeta` → `fave_property_price` on the WP post. The price-cleaning
logic (`cleanPrice`, `wordpress.ts:94`) strips `$` and commas and truncates to
an integer so Houzez gets a bare number.

### 1.5 Houzez `fave_*` meta — the custom WordPress endpoints

Houzez stores listing facts in post-meta fields prefixed `fave_`. Stock WP REST
cannot write arbitrary meta, so **two custom endpoints** were installed on the
WordPress side as *Code Snippets* (documented in `scripts/README.md`):

- `POST /wp-json/fausto/v1/property-meta/{id}` — writes the `fave_*` meta.
  Used by `writeHouzezMeta()` (`wordpress.ts:259`).
- `GET  /wp-json/fausto/v1/push/{id}` — was intended to read a post + meta back
  cleanly. **This endpoint was never actually registered on the WP side** — see
  the gotcha in 1.7 and section 7.

The meta payload is assembled in `buildHouzezMeta()` (`wordpress.ts:160`):
address, map-address, price, size (+ `ft²` prefix), land size, year, zip, agent
display option, and the `_sf_property_id` reverse pointer.

> **Handover item:** those two PHP Code Snippets live inside WordPress (Code
> Snippets plugin), not in this repo. The successor must know they exist and not
> delete them, or all meta writes (prices, sizes) will 404.

### 1.6 Status mapping — publish, unpublish, Sold/Off-Market

The SF `Status__c` picklist is translated to a WP action by
`mapSfStatusToWpAction()` (`wordpress-mappings.ts:149`):

| SF `Status__c`     | WP post status | Listing-status badge        |
|--------------------|----------------|-----------------------------|
| Active             | publish        | inherit from Listing_Type__c|
| Pending            | publish        | inherit                     |
| LOI Signed         | publish        | inherit                     |
| Contract Signed    | publish        | inherit                     |
| **Closed Won**     | publish        | **sold** (SOLD badge)       |
| **Closed Lost**    | publish        | **off-market** (OFF MARKET) |
| Draft/Pre-Market   | draft          | —                           |
| (anything unknown) | (leave alone)  | (leave alone)               |

Key point on **"auto-unpublish when Closed Won/Lost"**: the marketing decision
is **not** to take the page down. Closed deals stay *published* but get a
status badge (SOLD / OFF MARKET) instead of disappearing
(`wordpress-mappings.ts:157-165`). The taxonomy term IDs live in
`WP_PROPERTY_STATUS_BY_KEY` (`wordpress-mappings.ts:41`): for-sale=29,
for-lease=28, sold=175, off-market=176. "inherit from listing type" is resolved
via `WP_PROPERTY_STATUS_BY_LISTING_TYPE` (`wordpress-mappings.ts:48`).

The only path that actually hides a post is `Draft/Pre-Market` → `status:
draft`, honored explicitly at `sf-property-changed.ts:347`. The handler reports
this as `action: 'unpublished'`.

### 1.7 Draft-vs-published handling and the auto-publish fail-safe

This is the most important safety mechanism in the subsystem, and it exists
because of a real production incident.

**The rule:** a WordPress *draft* may never be promoted to *publish* by a sync.
Publishing is a deliberate human act (the marketer has added photos and copy).
SF may push a draft → draft (no-op) or → private, but never draft → publish.

The guard lives at `sf-property-changed.ts:335`. Before pushing a publish, it
calls `getProperty(wpId)` (`wordpress.ts:294`) to read the post's current
status:

- If the post is currently a **draft** → skip the status change.
- If the current status **cannot be determined** (network error / 404 → returns
  `null`) → **fail safe and skip** (do not publish). Callers must never read
  `null` as "it's published".

**Why this is hard-won:** originally `getProperty()` pointed at the
`/fausto/v1/push/{id}` custom endpoint, which was never registered in WP — so
every call returned 404 → `null`. The old code treated that as "not a draft" and
went ahead. Result: in May 2026, ~120 photoless drafts were auto-published the
moment any field changed (e.g. an agent adding a review note flips status to
"Active", which maps to publish). The fix was to (a) repoint `getProperty()` at
the **standard** WP REST endpoint that actually works, and (b) make `null`
fail-safe. See the long comments at `wordpress.ts:281` and
`sf-property-changed.ts:316`.

### 1.8 Public_URL__c drift correction

On every successful update, if WP's canonical permalink differs from SF's
`Public_URL__c`, the handler writes WP's permalink back to SF
(`sf-property-changed.ts:416`). This is because WP owns the slug: when a draft
is published or a slug changes, the URL drifts and nothing pushes it back —
leaving stale or 404-ing URLs in SF. This keeps them in sync. Non-fatal if it
fails.

### 1.9 Broken-link graceful degradation

If a WP post was deleted in the WP admin but SF still points at it, a sync would
hit a 404. Returning HTTP 500 would make **make.com** retry with exponential
backoff and eventually freeze the whole scenario (this actually happened with
`wp:23555`). Instead, `isWpNotFound()` (`sf-property-changed.ts:153`) detects
the WP "invalid post ID" 404 and the handler returns a `200 / noop` so make.com
moves on, logging a `BROKEN LINK` warning and deferring cleanup to the audit
script (`scripts/diagnostics/sf-wp-link-audit.ts`). See
`sf-property-changed.ts:361`.

---

## 2. Campaign Monitor — contact sync & list building

`src/campaign-monitor.ts` is a thin, dependency-free client for the Campaign
Monitor (CM) v3.3 REST API. Auth is HTTP Basic with the API key as the username
and `x` as a throwaway password (`authHeader`, `campaign-monitor.ts:90`).

### 2.1 What the client can do

- **Discovery (read):** `listClients`, `listLists`, `getListStats`,
  `getListCustomFields`, `listSegments` (`campaign-monitor.ts:131-364`).
- **Read subscribers:** `getSubscribersPage` / `getAllSubscribers` (paginates
  through CM's state buckets: active / unconfirmed / unsubscribed / bounced /
  deleted) (`campaign-monitor.ts:155-181`).
- **Write subscribers:** `importSubscribers` (bulk, ≤1000/call),
  `importSubscribersBatched` (chunks of 1000 with aggregated results),
  `addOrUpdateSubscriber` (single, idempotent), `deleteSubscriber`
  (`campaign-monitor.ts:194-294`).
- **Transactional email:** `sendSmartEmail` — triggers a CM "Smart Email"
  (templated transactional, e.g. price-drop / new-listing alerts) with
  per-recipient merge data (`campaign-monitor.ts:326`).

> Note: `addOrUpdateSubscriber` and `sendSmartEmail` are written and ready
> ("new buyer captured from a phone call → added to a list immediately") but
> are **not yet wired into the live call flow** — no caller in `src/` invokes
> them today. They are library scaffolding for the next phase. The only live
> consumers of this module are the ops scripts below (`getAllSubscribers` reads,
> `importSubscribersBatched` writes).

### 2.2 How email lists are built by lead intent

List-building logic lives in the migration `scripts/migrations/cm-import.ts`
(the orchestrator), which uses `src/campaign-monitor.ts` for the API calls.

The model is **(asset type) × (intent)**:

- **Intent** is derived from the listing's `Listing_Type__c`: `parseIntent()`
  (`cm-import.ts:191`) maps any "sale" → `sale`, any "lease" → `lease`. This is
  the "buying vs. renting/leasing" axis.
- **Asset type** comes from `Property_Type__c`. `resolveCmKeys()`
  (`cm-import.ts:207`) maps SF types to CM buckets with business rules, e.g.:
  - `healthcare` → `medical office`
  - `office` → `office` (but suppressed if the record is also healthcare, to
    avoid double-listing)
  - `multi-family` → only a `sale` list (no lease list exists)
  - `land` → `land development` for sale, `land` for lease
  - `commercial` / `other` / `special purpose` → the fallback list

Each `asset|intent` key maps to an exact CM list name in `BUCKET_LIST_NAMES`
(`cm-import.ts:35`) — 11 lists like `Loopnet Industrial For Sale`,
`Loopnet Retail for Lease`, `Loopnet Multi-Family for Sale`, etc. Anything that
doesn't route lands in the fallback `General FCom List`
(`FALLBACK_LIST_NAME`, `cm-import.ts:31`).

**List IDs are resolved by name at runtime** (not hard-coded): the script fetches
the client's lists and builds a `name → ListID` map (`cm-import.ts:392`), then
imports each bucket via `importSubscribersBatched` (`cm-import.ts:428`).
Subscribers carry custom fields like `LastLoopNetID` and `LastListingType`
(`cm-import.ts:323`) so segments can target "buyers interested in [asset
type]". The script is **dry-run by default** and only pushes with `--live`
(`cm-import.ts:417`).

Audit/discovery tooling: `scripts/audit/cm-audit.ts` and
`scripts/audit/cm-discover.ts` (read-only).

---

## 3. make.com — external marketing automation (HANDOVER ITEM)

**make.com is a no-code automation platform that lives entirely in the
client's own make.com account. It is NOT in this repository and cannot be
operated, edited, or version-controlled from here.** It is included in this doc
only because this codebase references it and is designed to interoperate with
it.

What the codebase knows about make.com:

1. **Legacy lead-capture webhook.** `src/salesforce.ts` can fall back to posting
   captured leads to a make.com webhook (`MAKE_WEBHOOK_URL`) when Salesforce
   credentials are missing or a direct SF write fails
   (`createLeadViaMakeWebhook`, `salesforce.ts:608`; fallback decisions at
   `salesforce.ts:520-598`). This is explicitly labelled **legacy** — the
   primary path is now a direct Salesforce write; make.com is the safety net.
   The payload it sends: firstName, lastName, phone, propertyId, propertyName,
   interest, notes, leadSource, timestamp (`salesforce.ts:610`).

2. **The SF→WP webhook consumer.** The Salesforce Flow HTTP Callout that drives
   the WordPress sync is understood to be brokered through make.com (the SF→WP
   handler is written defensively around make.com's retry behavior). The
   broken-link and 404 handling in `sf-property-changed.ts` (lines 151, 363,
   366, 372) exists specifically to avoid make.com's exponential-backoff retry
   loop that "eventually freezes the whole scenario."

**Handover actions for the successor:**

- Obtain credentials/ownership of the client's **make.com account**.
- Inventory the active **scenarios** there — at minimum the lead-capture
  webhook target (`MAKE_WEBHOOK_URL`) and any SF→WP plumbing.
- Treat make.com scenarios as **undocumented external state**: there is no
  backup of them in this repo. Export/screenshot them as part of handover.
- If the SF Flow now calls this app's `/webhooks/salesforce/event` directly,
  confirm whether make.com is still in the path or has been retired.

---

## 4. Non-obvious / clever engineering worth calling out

- **Three-tier post matching to prevent duplicates** (slug → address index →
  title search). Stock WP REST can't query by arbitrary meta, so an **in-memory
  address index** is built from a full property crawl and cached for 5 minutes
  (`ADDRESS_INDEX_TTL_MS`, `wordpress.ts:448`), with aggressive address
  normalization (`normalizeAddress`, `wordpress.ts:450`: strips unit numbers,
  abbreviates NW/Ave/Blvd, collapses ordinals like "4th"→"4"). When duplicates
  exist, it deterministically picks the **oldest** post as canonical.
- **Fail-safe-by-design status guard.** The auto-publish guard treats "unknown
  WP state" as "do nothing," after a real incident where the opposite
  assumption force-published 120 drafts (1.7).
- **Owner-split data model.** SF owns structured facts; WP owns marketing copy.
  The update path surgically pushes only status/taxonomy/meta and never
  title/content (`sf-property-changed.ts:308`).
- **make.com-aware error handling.** Returning `200/noop` on a genuine 404
  instead of 500 is a deliberate accommodation of make.com's retry semantics
  (1.9).
- **Closed deals as marketing assets.** SOLD/OFF-MARKET badges instead of
  deletion — SEO + credibility + future "own LoopNet" (`wordpress-mappings.ts:157`).
- **CM partial-success handling.** CM returns HTTP 400 / Code 210 when *some*
  rows in a bulk import fail; the client detects this and returns the embedded
  `ResultData` as success rather than throwing (`campaign-monitor.ts:222`).
- **Runtime list-ID resolution.** CM lists are referenced by human-readable name
  and resolved to IDs at runtime, so the code survives list re-creation
  (`cm-import.ts:392`).

---

## 5. Key files & functions (with line references)

**WordPress integration — `src/integrations/wordpress.ts`**
- `createPropertyDraft()` — `:191` — create a draft + write meta.
- `updatePropertyPost()` — `:230` — patch title/content/status/taxonomy.
- `writeHouzezMeta()` — `:259` — write `fave_*` meta via custom endpoint.
- `getProperty()` — `:294` — read current post status (fail-safe; returns null on failure).
- `findPropertyIdByTitleSearch()` — `:334` — last-resort match by WP search.
- `findPropertyIdBySlug()` — `:397` / `extractSlugFromPublicUrl()` — `:419`.
- `findPropertyIdByAddress()` — `:523` / `buildAddressIndex()` — `:476` / `normalizeAddress()` — `:450`.
- `setPropertyListingStatus()` — `:546` — convenience badge setter.
- `buildWpPostBody()` — `:132` / `buildHouzezMeta()` — `:160` / `cleanPrice()` — `:94`.

**WordPress mappings — `src/integrations/wordpress-mappings.ts`**
- `mapSfStatusToWpAction()` — `:149` — SF status → publish/badge action (incl. Closed Won/Lost).
- `WP_PROPERTY_STATUS_BY_KEY` — `:41` (sold=175, off-market=176, for-sale=29, for-lease=28).
- `resolvePropertyTypes/City/State` — `:24 / :89 / :109`.

**SF→WP handler — `src/handlers/sf-property-changed.ts`**
- `handlePropertyChanged()` — `:56` — entry point.
- `tryBackfillWpPostId()` — `:175` — 3-tier post matching.
- `createNewListing()` — `:223` / `updateExistingListing()` — `:273`.
- `isWpNotFound()` — `:153` — make.com-safe 404 detection.

**Campaign Monitor — `src/campaign-monitor.ts`**
- `importSubscribersBatched()` — `:237` / `importSubscribers()` — `:194`.
- `addOrUpdateSubscriber()` — `:281` / `sendSmartEmail()` — `:326` (not yet wired live).
- `getAllSubscribers()` — `:167`.

**CM list-building orchestrator — `scripts/migrations/cm-import.ts`**
- `BUCKET_LIST_NAMES` — `:35` / `parseIntent()` — `:191` / `resolveCmKeys()` — `:207`.

**make.com fallback — `src/salesforce.ts`**
- `createLeadViaMakeWebhook()` — `:608`.

---

## 6. Configuration / environment variables

All loaded from `.env.local` locally and from Railway env in production. (Keys
are listed by name only — never print or commit the values.)

| Var | Used by | Purpose |
|---|---|---|
| `WP_SITE_URL` | `wordpress.ts:28` | WP base URL (defaults to `https://faustocommercial.com`). |
| `WP_USER` | `wordpress.ts:29` | WordPress username for REST Basic auth. |
| `WP_APP_PASSWORD` | `wordpress.ts:30` | WP **Application Password** (not the login password). |
| `CM_API_KEY` | `campaign-monitor.ts` (passed in) | Campaign Monitor account API key. |
| `MAKE_WEBHOOK_URL` | `salesforce.ts` | Legacy make.com lead-capture webhook (fallback only). |

Notes:
- **CM list IDs are NOT env vars** — they are resolved at runtime by list name
  (`cm-import.ts:392`). The CM **client ID** is taken as the first client on the
  account (`cm-import.ts:391`).
- **Smart Email template IDs** are created in the CM UI and passed at call time
  (no env var today).
- WP REST auth uses an **Application Password**, generated per-user in WP admin.
  If listing sync suddenly 401s, the App Password was likely revoked/rotated.
- The two custom WP endpoints (`/fausto/v1/property-meta`, `/fausto/v1/push`)
  live as **Code Snippets inside WordPress**, not as env config — see 1.5.

---

## 7. Gotchas & maintenance notes

- **Draft URLs 404 for the public.** New listings are drafts; their permalinks
  are only visible to logged-in WP editors. A `Public_URL__c` in SF that points
  at an unpublished draft will 404 for anyone not logged in. This is expected
  until a human publishes the post.
- **The `/fausto/v1/push/{id}` endpoint was never registered in WP.** It always
  404s. `getProperty()` was repointed to the standard WP REST endpoint;
  anything new must not depend on `push`. (This omission caused the May 2026
  120-draft mass-publish incident — see 1.7.)
- **Never let the sync push `title`/`content`.** Marketers curate those on WP.
  Re-enabling title/content sync would silently overwrite hand-written
  marketing copy on every SF edit.
- **Address-as-free-text fragility.** SF addresses are free text and rarely
  match WP's `fave_property_address` formatting. The whole `normalizeAddress`
  apparatus exists to bridge this; expect occasional mismatches and use the
  title-search fallback / `sf-wp-link-audit.ts` to reconcile.
- **Don't return 500 to make.com on a missing WP post.** It causes a retry
  storm that freezes the scenario. Genuine "post deleted" 404s must return
  `200/noop` (`isWpNotFound`, `sf-property-changed.ts:153`).
- **Duplicate WP posts.** Earlier batch scripts created drafts with
  auto-generated slugs that don't match SF's URL. The matching logic picks the
  **oldest** post as canonical; periodically run
  `scripts/diagnostics/sf-wp-link-audit.ts` to find orphans/duplicates, and use
  the `scripts/migrations/sf-wp-*` / `wp-finish-duplicate-drafts.ts` migrations
  (dry-run first) to clean up.
- **The "sold" WP term once didn't exist.** `WP_PROPERTY_STATUS_BY_KEY` now has
  sold=175 and off-market=176; if a new badge/term is created in WP, add its
  term ID here or the Closed-Won/Lost handler silently no-ops the taxonomy push.
- **CM `addOrUpdateSubscriber`/`sendSmartEmail` are live-ready but unused.**
  Wiring them into the call flow is a known next step; don't assume real-time
  CM sync happens today (it's batch via `cm-import.ts`).
- **make.com is undocumented external state.** Back it up out of band — there is
  no copy of its scenarios in this repo (section 3).
