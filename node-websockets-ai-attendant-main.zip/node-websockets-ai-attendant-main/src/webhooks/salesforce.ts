/**
 * Webhook router — Salesforce Flow HTTP Callouts land here.
 *
 * Single endpoint:
 *   POST /webhooks/salesforce/event
 *
 * Expected payload (sent by SF Record-Triggered Flow → HTTP Callout action):
 *   {
 *     "objectType": "Property__c",          // SF object API name
 *     "eventType": "created" | "updated",   // CRUD trigger
 *     "recordId": "a0R...",                 // SF record ID
 *     "changedFields": ["Status__c", ...],  // optional: only changed fields
 *     "reason": "status-changed" | ...      // optional: app-level reason
 *   }
 *
 * Auth: shared secret in `X-SF-Webhook-Secret` header. Set SF_WEBHOOK_SECRET
 * in env. SF Flow sends it via a Custom Header on the HTTP Callout action.
 */

import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import {
  handlePropertyChanged,
  type PropertyChangedEvent,
} from '../handlers/sf-property-changed';
import type { SfTarget } from '../integrations/sf-client';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface SfWebhookPayload {
  objectType: string;
  eventType: 'created' | 'updated';
  recordId: string;
  changedFields?: string[];
  reason?: PropertyChangedEvent['reason'];
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

export async function registerSalesforceWebhookRoutes(
  app: FastifyInstance
): Promise<void> {
  app.post<{ Querystring: { secret?: string } }>(
    '/webhooks/salesforce/event',
    async (req, reply) => {
      // ---- Auth + target detection ----
      // Two secrets supported: prod and dev. The matching one selects which SF
      // org we'll fetch the record from.
      // Auth source preference: header > query param. Query is allowed because
      // SF's legacy External Services wizard makes header config painful.
      const prodSecret = process.env.SF_WEBHOOK_SECRET || '';
      const devSecret = process.env.SF_DEV_WEBHOOK_SECRET || '';
      if (!prodSecret && !devSecret) {
        app.log.error('No SF_WEBHOOK_SECRET or SF_DEV_WEBHOOK_SECRET set');
        return reply.code(503).send({ error: 'webhook_not_configured' });
      }
      const provided =
        (req.headers['x-sf-webhook-secret'] as string | undefined) ||
        req.query.secret;
      let target: SfTarget;
      if (prodSecret && provided === prodSecret) {
        target = 'prod';
      } else if (devSecret && provided === devSecret) {
        target = 'dev';
      } else {
        app.log.warn(
          { headers: redactHeaders(req.headers) },
          'Webhook auth failed'
        );
        return reply.code(401).send({ error: 'unauthorized' });
      }

    // ---- Parse payload ----
    const body = req.body as SfWebhookPayload | undefined;
    if (!body || typeof body !== 'object') {
      return reply.code(400).send({ error: 'invalid_payload' });
    }
    const { objectType, eventType, recordId } = body;
    if (!objectType || !eventType || !recordId) {
      return reply
        .code(400)
        .send({ error: 'missing_required_fields', got: body });
    }

    // ---- Route by object type ----
    try {
      if (objectType === 'Property__c') {
        return await handlePropertyEvent(body, target, reply, app);
      }

      app.log.warn({ objectType, target }, 'Unhandled SF object type');
      return reply.code(202).send({ status: 'ignored', objectType, target });
    } catch (err) {
      app.log.error(
        { err, body },
        'Webhook handler threw — returning 500 so SF retries'
      );
      return reply.code(500).send({ error: 'handler_failed' });
    }
  });
}

// ---------------------------------------------------------------------------
// Per-object dispatchers
// ---------------------------------------------------------------------------

async function handlePropertyEvent(
  body: SfWebhookPayload,
  target: SfTarget,
  reply: FastifyReply,
  app: FastifyInstance
): Promise<FastifyReply> {
  const event: PropertyChangedEvent = {
    recordId: body.recordId,
    changedFields: body.changedFields,
    reason: body.reason || (body.eventType === 'created' ? 'created' : 'updated'),
  };

  const result = await handlePropertyChanged(event, target);

  if (!result.ok) {
    app.log.error({ event, target, result }, 'Property change handler failed');
    // 500 so SF retries via Flow's HTTP Callout retry policy
    return reply.code(500).send(result);
  }

  app.log.info({ event, target, result }, 'Property change handled');
  return reply.code(200).send(result);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function redactHeaders(
  headers: FastifyRequest['headers']
): Record<string, string | string[] | undefined> {
  const out: Record<string, string | string[] | undefined> = { ...headers };
  if (out['x-sf-webhook-secret']) out['x-sf-webhook-secret'] = '[REDACTED]';
  if (out.authorization) out.authorization = '[REDACTED]';
  return out;
}
