# DRAFT — Project update email (for Jesus to review + send)

**To:** Carlos (cfm@), Nathalie (na@)
**Suggested subject:** Project update — what's done, what's next, and two things we need from you

> Draft only. Not sent. Tone: brief, factual, forward-looking (per strategy notes).
> Fill in greeting/sign-off. Estimates are ranges with dependencies — keep them as
> estimates, not commitments.

---

Hi Carlos and Nathalie,

A quick status so we're all on the same page.

**Done and running**

- The AI phone assistant is live — answering calls, texting callers, and logging leads into Salesforce.
- Lead-access security is live — agents only see the lead lists they're assigned to. We're putting the final touches on the request-and-approve notifications (a small setup task on our side) so access requests reach you automatically.

**Two things we need from you (time-sensitive)**

1. **Salesforce is requiring multi-factor login.** Two deadlines:
   - **July 1** — the 5 admins need a secure passkey login. (Quick one-page guide attached.)
   - **July 20** — all agents need MFA, easiest via the Salesforce Authenticator app. (One-page guide attached.)
   We can run a short walkthrough for each group.
2. **Confirm agents' cell numbers.** To text an agent when someone calls about their listing, we need their mobile numbers correct in Salesforce — a number are missing. List attached; please have agents confirm/correct.

**Also helpful when you have it**

- For routing callers to the right specialist, a simple list of who handles what (property type + area) would let us build that feature.

**On our side — in progress / estimated next**

- **Automated weekly Salesforce backups** — in progress (~2 days).
- **Private/hidden lead lists** (e.g., the Broward lists) — the setup is underway. Moving the existing leads into them will take a little time, because the underlying group records have duplicates we need to clean up first. **One question for you:** when a lead moves into a private list, should it be **fully moved** (removed from the normal Leads) or **also kept** in the normal list? Your answer changes the migration, so we'll wait on it before moving any leads.
- **Texting agents when a caller asks about their listing** — ~3 days, starts once the cell numbers are confirmed.
- **Call-review dashboard** (listen to calls + read summaries for quality control) — the largest item; I'm scoping it now and will come back with a plan.
- **Routing callers to the right specialist** — ~3–5 days once we have the specialist list.

Happy to walk through any of this on a quick call.

Best,
Jesus

---

### Attachments to include
- `docs/mfa-admins-passkey.md` (admin passkey guide)
- `docs/mfa-agents-authenticator.md` (agent authenticator guide)
- `data/agent-contacts-2026-06-21.csv` (agent number list — **PII, send securely**)
