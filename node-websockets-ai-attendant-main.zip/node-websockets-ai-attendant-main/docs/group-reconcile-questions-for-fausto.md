# Questions for Fausto / Nathalie — Group Reconciliation

Items where I made a best-guess decision but want human confirmation before committing. Each item shows: what I did, what other interpretations exist, and what would need to change.

## 1. BVM — what does it stand for?

`BVM` appears 235 times across leads, almost always as a suffix tag like `"CID; BVM"`, `"Allapattah; BVM"`, `"LibCityCom; BVM"`. Only 3 leads have plain `"BVM"`.

**Owners of BVM-tagged leads (top):**
- Carlos Miranda-Brassac (62), Ernesto Diaz (47), Giovanni Bertolotti (47), Markos Bertolotti (46), Carlos Fausto Miranda (13 owned / 140 created), Frank Campos (11), Yuniel De Varona (8), Mauricio Villasuso (6).

No SF user has "BVM" in their name/alias/email. The Bertolotti family + Carlos Miranda-Brassac dominate — best guess is BVM = a team-initial tag (Bertolotti / Villasuso / Miranda?).

**What I did:** Treated `; BVM` as a tag — stripped it and merged into the parent group (e.g., `"CID; BVM"` → CID, `"Allapattah; BVM"` → Allapattah). Plain `"BVM"` (3 leads) → SKIP.

**Confirm:** Is BVM a team tag? Should we keep it as metadata somewhere when we strip it from the group? Or convert to a Lead tag field?

## 2. "NewFlagami" / "NEW FLAGAMI" / "NEW FAGAMI" (~262 leads)

Currently stay in the **Flagami Com** canonical alongside FLAGAMICOM (1591), Flagami Com (50), Flagami Commercial (17). The word "NEW" appearing in three different spellings looks deliberate.

**Hypotheses:**
- "New" expansion area within Flagami?
- "Newly listed" Flagami leads (timestamp flag)?
- A specific agent's prospecting list?

**What I did:** Left in Flagami Com (the algorithm clustered them there).

**Confirm:** Should "New Flagami" be its own canonical? If so, what type?

## 3. "EastSide" canonical (1036 leads)

Existing canonical, absorbed "EASTSIDE" (1435 text leads). What area is this? East Hialeah? East Miami? East Coral Gables? With 2,471 total leads it's a significant list.

**What I did:** Kept as-is (didn't change).

**Confirm:** What area? Should I rename for clarity?

## 4. "203202" canonical (33 leads)

Just a number. Looks like an internal code or ZIP fragment.

**Confirm:** What is this and should it stay as a group?

## 5. Area-only values — created general buckets

For values like `"LITTLEHAVANA"`, `"Hialeah"`, `"Coral Gables"`, `"Opa Locka"` that have no property type suffix, I pulled them out of the type-specific canonicals (LittleHavanaApt, HialeahCom, etc.) and created new generic-area canonicals:

- `LittleHavana` (90 leads) — from LITTLEHAVANA, LIttle Havana, LittleHav, LitHav, Lilhavana, LittHav, Litt, Little Habana
- `EastHialeah` (343 leads) — from EHIA (341), EHIALEAH (2)
- `Hialeah` (11 leads)
- `CoralGables` (8 leads), `CoralGablesOffice` (2), `CoralGablesRetail` (1)
- `OpaLocka` (17 leads)
- `MiamiGardens` (6 leads), `MiamiGardensMF` (14), `MiamiGardensLand` (7), `MiamiGardensInd` (2)

**Confirm:** Are these legitimate buckets, or should the area-only leads be inspected one-by-one and re-tagged with a specific type?

The alternative would be: don't create the generic buckets — leave those leads with `Group__c=null` and let Nathalie / the agents inspect each one and reassign.

## 6. "CFM Big MF" — kept separate from "Bigmf"

`CFM Big MF` (17 leads) — pulled out of the Bigmf cluster. CFM = Carlos Fausto Miranda's specific list.

**Confirm:** Should this be its own canonical, or merged into Bigmf?

## 7. "71st Ind" (11 leads)

71st Street is in the Hialeah Gardens area, but "Ind" is industrial. SKIP'd because ambiguous (could be Doral, Hialeah, or elsewhere).

**Confirm:** Which area? Most likely HialeahInd?

## 8. "TS Buyers" (5 leads), "BEN'S BUYERS" (1 lead)

Looks like agent-specific buyer lists (TS = Tony Saladrigas?). SKIP'd.

**Confirm:** Are these agent-specific groups Fausto wants to preserve?

## 9. "QUAILROOST" (2 leads), "K2 Goulds" (5 leads), "Surfside" (15), "Magic City" (1), "Aventura" (1), "Florida City" (1), "Miami Springs" (1)

All real Miami-area neighborhoods. SKIP'd the small ones (1-2 leads), kept K2 Goulds (5) and Surfside (15) as new canonicals.

**Confirm:** Want any of these as canonicals?

## 10. The 360 SKIP'd leads

Total 153 distinct Group_old2__c values mapping to **360 leads** that get NO Group__c assignment under the current overrides. Top:

| Value | Leads |
|---|---|
| JJ | 49 |
| n/a | 30 |
| Urgent | 27 |
| MULTIFAMILY | 18 |
| na | 15 |
| preforeclosure | 14 |
| 71st Ind | 11 |
| None | 10 |
| Retail | 6 |
| Duplex | 5 |
| TS Buyers | 5 |
| tax delinquent | 4 |
| Broward | 4 |
| DELETE | 3 |
| BVM | 3 |
| misc | 3 |
| GABLES | 2 |
| ...117 more single-lead garbage entries... |  |

**Suggestion for Nathalie:** This is the cleanup candidate list. The top entries (JJ, n/a, Urgent, MULTIFAMILY, preforeclosure, None, DELETE, misc) are clearly placeholders / workflow notes / generic types — not real groups. We can either:
- Leave them as-is (`Group__c=null`, `Group_old2__c=<value>`) so the agent can manually re-classify
- Clear `Group_old2__c` on these too (so they don't pollute future reports)
- Delete the leads (if confirmed they're dead records — need to check last activity / opportunity)

The full list with lead counts is in `data/archive/group-old-reconcile-2026-05-28.txt`.

## 11. Existing canonicals NOT touched but possibly worth reviewing

- **Doral HG&M&MS Retail** (1335 leads) — odd name, "HG&M&MS" looks like a multi-tenant code. Real?
- **GroveRIN** (327 leads) — what does RIN mean?
- **UniPrkSwtwtrSoDoral** (1031 leads) — Universal Park / Sweetwater / South Doral combined? Real area or sub-list?
- **Hollywood33020Resi** (1543), **HollywoodApt33023_4** (896) — ZIP-coded residential lists. Real?
- **Project 130** (8 leads), **CP 1872** (15 leads being created), **NNN Kodiak** (19) — internal project codes?

These all stayed as-is in this reconciliation. If they're stale internal codes, Nathalie may want to deactivate them.

---

## Default outcome if no answers come back

The current overrides file (`data/group-old-overrides.json`) reflects my best guesses. Running `--commit` as-is would:
- Create **67 new Group__c records** (including the area-only buckets)
- Link **13,046 leads** to canonical groups
- Leave **1,492 leads** with `Group__c=null` (the 360 SKIP'd + the rest already null)

If any of the above answers come back differently, edit `data/group-old-overrides.json` and re-run the dry-run before committing.
