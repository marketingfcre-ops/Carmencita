/**
 * Inbound SMS keyword classification — A2P/10DLC compliance.
 *
 * Twilio requires us to honor STOP, START/UNSTOP, and HELP as standard
 * commands. The double-opt-in flow also needs to recognize YES so we can
 * promote a pending consent record to confirmed.
 */

export type InboundKeyword =
  | 'STOP'
  | 'START'
  | 'HELP'
  | 'YES'
  | 'EMAIL'
  | 'OTHER';

const STOP_WORDS = new Set([
  'stop',
  'stopall',
  'unsubscribe',
  'end',
  'quit',
  'cancel',
  'opt-out',
  'optout',
  'revoke',
]);

const START_WORDS = new Set(['start', 'unstop', 'yes-resubscribe']);

const HELP_WORDS = new Set(['help', 'info']);

const YES_WORDS = new Set(['yes', 'y', 'ok', 'okay', 'sure', 'confirm', 'sí', 'si']);

// Very simple email detector — full RFC 5322 is overkill for SMS replies.
const EMAIL_RE = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/;

export function classifyInboundSms(body: string): InboundKeyword {
  const trimmed = body.trim();
  if (!trimmed) return 'OTHER';

  // Use just the first token for keyword matching — carriers strip multi-word
  // confirmations to the first word, and that's what Twilio does too.
  const firstWord = trimmed.split(/\s+/)[0].toLowerCase().replace(/[.,!?]/g, '');

  if (STOP_WORDS.has(firstWord)) return 'STOP';
  if (START_WORDS.has(firstWord)) return 'START';
  if (HELP_WORDS.has(firstWord)) return 'HELP';
  if (YES_WORDS.has(firstWord)) return 'YES';
  if (EMAIL_RE.test(trimmed)) return 'EMAIL';
  return 'OTHER';
}

export function extractEmail(body: string): string | null {
  const m = body.match(EMAIL_RE);
  return m ? m[0] : null;
}
