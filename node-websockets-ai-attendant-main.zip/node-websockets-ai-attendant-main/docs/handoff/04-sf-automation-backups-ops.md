# 04 — Salesforce Automation, Backups & the Ops Script Library

*Subsystem owner area: server-side Salesforce automation, automated backups, and the operations/script toolkit.*

This document covers three things that run *around* the live phone attendant rather than during a call:

1. A small in-process **scheduler** that keeps Salesforce lead-access records correct and emails the admin about access requests.
2. An **automated Salesforce backup** system (our own, because the Salesforce edition we use can't do it for us).
3. A large **library of operational scripts** — effectively a mini-toolkit for safely changing and inspecting Salesforce and WordPress data.

---

## For the non-technical owner (read this first)

Three pieces of "invisible plumbing" were built so the system keeps running correctly without anyone babysitting it:

- **Auto-grant lead access.** When an admin assigns a lead to a sales group in Salesforce, the agents in that group need to actually *see* the lead. Salesforce's built-in automation has a hard limit (we'd already hit the cap of 5 automations it allows on this plan), so instead a small program on our own server quietly checks every 10 minutes and creates the missing access record. It only ever *grants* access that an admin already authorized — it never removes access, and it can't accidentally over-grant.
- **Access-request email digest.** When an agent requests access to a lead, the admin (Nathalie) gets an email listing the new requests with one-click "Review" links. It de-duplicates and never re-nags about the same request twice, and it stays quiet when a request was already handled automatically.
- **Nightly backups.** Salesforce on our plan only offers a *monthly* native backup, which isn't good enough. So we built our own: every night it exports the entire Salesforce database, compresses it, and stores it in cheap cloud storage (Cloudflare), keeping the last 30 nightly copies plus 12 monthly copies (a full year of recovery points). There's also a tested "restore" procedure so the backups are real, not theoretical.

On top of that there is a **library of ~140 small scripts** — built up over the project — for doing data clean-ups, audits, and migrations safely. This is the "mini-framework" part: most data problems that come up can be solved by a short script that follows the same safe patterns (preview first, then apply), instead of risky manual clicking in Salesforce.

---

## 1. The LLA reconcile + admin-notify scheduler

**File:** `src/integrations/lla-reconcile.ts` (the whole subsystem lives here)
**Wired up at:** `src/server.ts:204` — `startLlaReconcileScheduler()` is called at boot (non-blocking).

### What "LLA" means

`Lead_List_Assignment__c` (LLA) is a custom **junction object** that records *"this Lead is assigned to this Group."* Lead-level access in the org is enforced by a Salesforce **Flow** (`Lead_Group_Access_Check`) that keys off these LLA junction rows. Until a matching LLA exists, the assigned agents cannot work the lead (`lla-reconcile.ts:1-16`).

### Why it runs on our server instead of as a Flow

Creating the LLA automatically when `Lead.Group__c` is set would normally be a record-triggered Flow. But **production is Salesforce Professional Edition, which is at the hard cap of 5 autolaunched flows.** Rather than burn a scarce flow slot (or bolt the logic onto an unrelated Lead flow whose entry conditions would never fire on a Group change), the work runs as a scheduled job inside the always-on Node server (`lla-reconcile.ts:8-16`). This is a recurring theme in this codebase: *PE limits push automation server-side.*

### The scheduler (one tick, three jobs)

`startLlaReconcileScheduler()` (`lla-reconcile.ts:371-442`) sets up a single timer. On each tick it runs up to three jobs depending on env flags:

- **First pass 30s after boot** (so it doesn't compete with startup), then every `LLA_RECONCILE_INTERVAL_MIN` minutes (default **10**) — `lla-reconcile.ts:431-433`.
- It is a **no-op unless at least one flag is set**, so it stays dark in any environment until explicitly switched on (`lla-reconcile.ts:375-380`).

#### Job A — Reconcile (`reconcileLeadGroupAssignments`, `lla-reconcile.ts:70-140`)
Gated by `LLA_RECONCILE_ENABLED=true`.

1. Load all existing LLAs and build a dedup key set of `Lead__c|Group__c` (`:77-82`).
2. Load all Leads with `Group__c != null` (`:85-87`).
3. Diff: any `(Lead, Group)` pair without an LLA is a create candidate (`:90-98`).
4. Create each missing LLA with **`Status__c = 'Approved'`** — an admin set the Group, so the access is sanctioned (same grandfathering rule the original `migrate-group-to-list-assignments.ts` migration used) (`:121-137`, `:23-25`).

**Safety guarantees** (`lla-reconcile.ts:17-28`):
- **Create-only** — never updates or deletes. Fails *closed*: a missing assignment means no access, never accidental access.
- **Idempotent** — skips any pair that already has an LLA.
- **`MAX_PER_RUN = 500`** safety valve (`:63`, `:100-101`) so a first run against an unexpected backlog can't hammer the API; if it caps, it logs `capped` rather than silently truncating. Steady-state backlog is ~0 (existing leads were grandfathered by the original migration).
- Re-authenticates a fresh prod client per call (`:74`) so the long-lived scheduler never trips on an expired token.

#### Job B — Tidy redundant pendings (`tidyRedundantPendings`, `lla-reconcile.ts:325-359`)
Also gated by `LLA_RECONCILE_ENABLED` (runs alongside reconcile, `:404-410`).

Agents can create an LLA with `Status='Pending'` to *request* access. If an agent created a lead in their own group (auto-approved by Job A) and *also* filed a request, the Pending is harmless but redundant. This job deletes a Pending **only when an Approved LLA already exists for the same `Lead__c|Group__c`** (`:343-345`) — provably safe, since access is already granted. Lead IDs are chunked in batches of 200 for the `IN (...)` query (`:334-341`).

#### Job C — Notify (`notifyPendingAssignments`, `lla-reconcile.ts:225-311`)
Gated by `LLA_NOTIFY_ENABLED=true`. Emails the admin a digest of **new** Pending requests via Resend (`src/integrations/resend.ts`).

The **watermark** is the heart of this job (so the admin isn't re-nagged every 10 minutes about the same unapproved requests):

- The "last notified" timestamp is persisted to a JSON file on the Railway volume: `lla-notify-watermark.json` under `LLA_NOTIFY_STORE_DIR` → `RAILWAY_VOLUME_MOUNT_PATH` → `./data` (`:152-156`). Same persistence pattern as the SMS consent store.
- **First run seeds the watermark to "now" and sends nothing** (`:230-234`), so enabling the feature never blasts a digest of the entire historical backlog. Pre-existing pendings must be cleared manually once.
- Each tick queries Pending LLAs with `CreatedDate > watermark`, oldest first, `LIMIT 200` (`:237-242`). Note `toSoqlDateTime()` strips milliseconds because SF datetime literals don't accept them (`:158-161`).
- **Redundant-pending suppression** (`:248-261`): before emailing, it loads Approved LLAs for the same leads and filters out any Pending whose `Lead__c|Group__c` is already Approved. Those are reported as `suppressed` and never emailed (the agent already has access — nothing for the admin to do).
- The watermark advances to the newest row *examined* (including suppressed ones), so they're never re-checked (`:262-263`).
- **Email send failure does NOT advance the watermark** (`:296-306`) — the same requests retry on the next tick. The watermark only advances after a confirmed send (`:308-310`) or when everything was suppressed (`:265-268`).

**Review links use the Lightning host, not the API host** (`lightningBaseUrl`, `:184-195`): the OAuth instance host (`*.my.salesforce.com`) is for API calls and 404s the UI path, so the link host is derived as `*.lightning.force.com` (overridable via `SF_LIGHTNING_BASE_URL`). This was a real bug fixed on this branch (`git log`: *"Fix LLA notify Review link: use Lightning host, not API host"*).

Default recipient is `na@faustocommercial.com`, overridable via `LLA_NOTIFY_EMAIL` (`:226`).

### Manual CLI counterpart

`scripts/migrations/reconcile-lla.ts` calls the **same** `reconcileLeadGroupAssignments()` function, so a `--dry-run` there is an exact preview of what the scheduler does (`reconcile-lla.ts:1-18`). Dry-run is the default; `--apply` is required to write to prod.

---

## 2. Automated Salesforce backups

**Files:** `scripts/backup/sf-backup.ts` (the job), `scripts/backup/sf-restore.ts` (download/decompress), `scripts/backup/sf-export.ts` (the original local-only spike), `scripts/backup/README.md`, and `.github/workflows/sf-backup.yml` (the schedule).

### Why a custom backup

Professional Edition's **native** scheduled Data Export is capped at **monthly**, and the export ZIPs aren't cleanly API-fetchable. **SOQL reads have no PE export limit**, so we built our own export out of plain SOQL queries — letting us back up on any cadence and own the output format (`sf-backup.ts:1-12`, `sf-export.ts:1-36`).

### How the backup job works (`sf-backup.ts`)

1. **Global describe** the org via a raw REST GET to `/services/data/v59.0/sobjects/` (`listBackupTargets`, `:100-113`).
2. Select targets: every **queryable** object that is **custom (`__c`)** *or* in the `STANDARD_KEEP` set (Account, Contact, Lead, Opportunity, Task, Event, Campaign, CampaignMember, User, ContentVersion, ContentDocument) (`:63-66`). Skip `__Share / __History / __Feed / __ChangeEvent / __Tag / __mdt` suffixes (`:67`).
3. For each object: `describe` → build a `SELECT` of all scalar fields, skipping `address / location / base64` field types (`:68`, `dumpObject` `:116-127`) → query all rows → **gzip the JSON** per object.
4. Upload each object to `s3://<bucket>/<tier>/<ISO-stamp>/<Object>.json.gz` (`:180-190`).
5. Upload `manifest.json` **last**, so its presence marks a complete backup (`:219-227`).
6. **Prune** old dated prefixes, keeping only the newest `KEEP` (`prune`, `:129-157`).
7. Exit non-zero if any object failed, so CI surfaces a partial backup (`:233-234`).

### Storage & retention

- **Cloudflare R2** (S3-compatible; Backblaze B2 works identically with no code change). Uses `@aws-sdk/client-s3` with `forcePathStyle: true` (R2/B2 require path-style addressing) (`:82-98`).
- Two tiers, two prefixes, script-managed retention (bucket lifecycle rules are age-only and can't express "keep N", so the script prunes itself — `:24-25`, `:129-140`):
  - **`daily/`** — keep newest **30** (`BACKUP_KEEP_DAILY`, default 30) — a rolling month.
  - **`monthly/`** — keep newest **12** (`BACKUP_KEEP_MONTHLY`, default 12) — a year.
- Measured volume: ~462K records, ~691 MB raw JSON, ~100–130 MB gzipped per backup. Total stays ~2 GB — within R2's 10 GB free tier (`README.md:14-16`). (The README's per-backup figure of ~51 MB and the source comment differ slightly from the measured 100–130 MB gz; treat the README's "~100–130 MB gz" as current.)

### Schedule (`.github/workflows/sf-backup.yml`)

Runs in **GitHub Actions**, *not* on the live call server (so backups never compete with calls):

- **Daily** cron `0 8 * * *` (08:00 UTC) → `--tier daily`.
- **Monthly** cron `0 9 1 * *` (1st, 09:00 UTC) → `--tier monthly`.
- **Manual** `workflow_dispatch` with a `tier` choice input (daily/monthly).
- A "Resolve tier" step maps the triggering cron (or manual input) to the tier passed to `npx tsx scripts/backup/sf-backup.ts --tier <tier>`.
- 30-minute job timeout; `concurrency` group prevents overlapping runs.
- Credentials come from GitHub Actions repo **secrets** (`SF_*` + `BACKUP_S3_*`).

### Restore drill (`sf-restore.ts`)

A backup nobody has restored is theoretical, so there's tooling and a documented drill (run once, then quarterly — `README.md:62-75`):

- `--list` enumerates available backups under `daily/` and `monthly/` (`:50-60`).
- `--get <tier>/<stamp>` downloads + **gunzips** every object's JSON into `./restore/<stamp>/` (`:62-85`).
- **It only retrieves + decompresses — it never writes back to Salesforce.** Re-import is a deliberate, manual step (jsforce / Data Loader / a targeted script), because a blind bulk re-insert would create duplicates and is never what you want in a real incident (`:1-7`).

### Backup scope caveats

- **Salesforce only.** WordPress is covered by Cloudways; Campaign Monitor backup is TBD (`README.md:79`).
- **No file/attachment binaries** — `ContentVersion`/`ContentDocument` *metadata* is included, but flyer PDF bytes are not (`base64` fields are skipped). Add separately if wanted (`README.md:80-81`).
- Big objects (Lead ~104K, Task ~254K) currently go through the paginated REST query path; switch to Bulk API v2 if runtime becomes a problem (`README.md:86-87`).

---

## 3. The ops / script library

**Root:** `scripts/` (run with `npx tsx --env-file .env.local scripts/<dir>/<file>.ts`). Most migrations support `--dry-run` — **always dry-run first** (the `fausto-migration` skill enforces this).

This is the "mini-framework" the owner refers to: a reusable toolkit for SF/WP data operations that grew alongside the project. **Production SF→WP sync runs *in the server*** (`src/webhooks/salesforce.ts` → `src/handlers/sf-property-changed.ts`); these scripts are for setup, migration, testing, audit, and backup only (`scripts/README.md:63-67`).

Approximate inventory: **~58 migrations, ~69 diagnostics, 7 setup, 4 audit, 6 tests, plus the backup tooling.**

### `migrations/` (~58) — one-time data moves (historical record once executed)
Touch prod data; most have a `--dry-run`/`--apply` gate. Representative examples:
- `migrate-group-to-list-assignments.ts` — `Lead.Group__c` → LLA junction rows (Status='Approved'); the original grandfathering migration the reconcile job mirrors.
- `reconcile-lla.ts` — manual runner for the live reconcile function (see §1).
- `backfill-wp-post-ids.ts`, `backfill-published-urls.ts` — populate `Property__c` fields from WordPress slugs/URLs.
- `grant-*` / `grandfather-user-group-access.ts` / `grant-wildcard-access.ts` — lead/group access grants (the access-bypass-cohort work).
- `cm-import.ts`, `sf-import-leads.ts` — bulk imports into Campaign Monitor / Salesforce.
- `sf-wp-cleanup-auto.ts`, `relink-and-cleanup-dupes.ts`, `wp-reconcile-cycles.ts` — SF↔WP relink / dedupe cleanups.
- Several dated point fixes (`fix-orphan-leads-2026-06-05.ts`, `fix-comma-multi-group-leads.ts`, `remap-mislabeled-group-leads.ts`) and rollbacks (`rollback-grandfather-access.ts`, `wp-revert-may-publishes.ts`).

### `diagnostics/` (~69) — read-only investigation (no approval needed; the `fausto-diagnose` skill runs these)
The largest folder — pure SELECT/GET inspection. Representative examples:
- **SF↔WP link integrity:** `sf-wp-link-audit.ts`, `full-sf-wp-cross-reference.ts`, `orphan-matcher.ts`, `sf-mislink-investigate.ts`.
- **Agent / group access:** `agent-group-reconcile.ts`, `erick-group-access-delta.ts`, `giovanni-access-audit.ts`, `verify-agent-lla-read.ts`, `lla-sharing.ts`.
- **Permissions / edition probes:** `full-permission-diff.ts`, `custom-permission-probe.ts`, `license-check.ts`, `hidden-list-prep-and-edition.ts`, `flow-lgac-snapshot.ts`.
- **WordPress health / listings:** `wp-auth-health-check.ts`, `wp-state-report.ts`, `wp-duplicate-pairs-audit.ts`, `property-flyer-audit.ts`, `property-url-audit.ts`, `draft-listings-report.ts`.

### `setup/` (7) — idempotent, re-runnable initialization (dev org / sandbox)
- `seed-dev-org.ts`, `copy-prod-sample-to-dev.ts` — stand up a realistic dev org.
- `seed-dev-validation-rule.ts`, `setup-test-agent.ts`, `set-test-agent-password.ts`.
- `deploy-apex-trigger.ts` — **dev-org only** (prod is PE, no Apex).

### `audit/` (4) — read-only reports / analytics
- `cm-discover.ts`, `cm-audit.ts` — Campaign Monitor list inspection vs SF leads.
- `marketing-90-day-review.ts` — 90-day listing & marketing-material analytics.
- `generate_audit_reports.py` — legacy Python property data-gap analysis.

### `tests/` (6) — smoke + regression
- `smoke-sf-to-wp.ts` — end-to-end SF→WP against one Property.
- `test-flow-trigger.ts`, `test-validation-rule.ts` / `-positive.ts`, `test-closed-won-lost.ts`, `debug-validation-rule.ts` (the latter are Apex `@isTest` / anonymous-eval, **dev-org only**).

### `backup/` — see §2.

### Top-level
- `scripts/twilio-restore-prod.sh` — restores Twilio webhook config to prod after local-dev points it at the ngrok domain.

---

## 4. Configuration / environment variables

All optional flags default to **off/safe**. Secrets live in `.env.local` locally and in Railway / GitHub Actions secrets in CI/prod.

### LLA scheduler (`src/integrations/lla-reconcile.ts`, read in `src/server.ts`)
| Var | Default | Purpose |
|---|---|---|
| `LLA_RECONCILE_ENABLED` | `false` | Enable Job A (auto-create Approved LLAs) + Job B (tidy redundant pendings). |
| `LLA_NOTIFY_ENABLED` | `false` | Enable Job C (email admin digest of new Pending requests). |
| `LLA_RECONCILE_INTERVAL_MIN` | `10` | Tick interval in minutes (min 1). Shared by all jobs. |
| `LLA_NOTIFY_EMAIL` | `na@faustocommercial.com` | Digest recipient. |
| `LLA_NOTIFY_STORE_DIR` | `RAILWAY_VOLUME_MOUNT_PATH` → `./data` | Where the notify watermark JSON is persisted. |
| `SF_LIGHTNING_BASE_URL` | derived from instance host | Override for Lightning record-link host in emails. |
| (Resend) | — | `src/integrations/resend.ts` config (API key) backs `sendEmail`. |

### Backups (`scripts/backup/*`, `.github/workflows/sf-backup.yml`)
| Var | Default | Purpose |
|---|---|---|
| `SF_LOGIN_URL`, `SF_CLIENT_ID`, `SF_CLIENT_SECRET` | — | Salesforce OAuth (read) — already set for the app. |
| `BACKUP_S3_ENDPOINT` | — | e.g. `https://<acct>.r2.cloudflarestorage.com`. |
| `BACKUP_S3_REGION` | — | `auto` for R2; the bucket region for B2. |
| `BACKUP_S3_BUCKET` | — | Bucket name (e.g. `fausto-sf-backups`). |
| `BACKUP_S3_ACCESS_KEY_ID`, `BACKUP_S3_SECRET_ACCESS_KEY` | — | Object Read & Write key. |
| `BACKUP_KEEP_DAILY` | `30` | Daily copies to retain. |
| `BACKUP_KEEP_MONTHLY` | `12` | Monthly copies to retain. |

### Scripts generally
- Run via `npx tsx --env-file .env.local scripts/<dir>/<file>.ts`. Target switching (prod vs dev) is by argument/secret depending on the script; `sfClient('prod')` vs `sfClient('dev')` (`src/integrations/sf-client.ts`).

---

## 5. Key files & functions (quick reference)

| Location | What |
|---|---|
| `src/integrations/lla-reconcile.ts:70-140` | `reconcileLeadGroupAssignments()` — create-only LLA reconcile |
| `src/integrations/lla-reconcile.ts:225-311` | `notifyPendingAssignments()` — watermarked admin digest |
| `src/integrations/lla-reconcile.ts:325-359` | `tidyRedundantPendings()` — delete already-approved Pendings |
| `src/integrations/lla-reconcile.ts:371-442` | `startLlaReconcileScheduler()` — the timer + job dispatch |
| `src/integrations/lla-reconcile.ts:163-182` | watermark read/write helpers |
| `src/integrations/lla-reconcile.ts:184-195` | `lightningBaseUrl()` — Lightning vs API host fix |
| `src/server.ts:204` | scheduler started at boot |
| `scripts/migrations/reconcile-lla.ts` | manual dry-run/apply CLI for the reconcile |
| `scripts/backup/sf-backup.ts:100-157` | target selection + `prune()` retention |
| `scripts/backup/sf-backup.ts:116-127` | `dumpObject()` — per-object gzip export |
| `scripts/backup/sf-restore.ts:50-85` | `--list` / `--get` download + gunzip |
| `scripts/backup/sf-export.ts` | original local-only export spike |
| `.github/workflows/sf-backup.yml` | daily + monthly + manual schedule |
| `src/integrations/sf-client.ts` | `SfClient` — auth, SOQL, describe, CRUD, 401 re-auth |
| `src/integrations/resend.ts` | `sendEmail()` used by the notify job |

---

## 6. Gotchas & maintenance notes

- **PE 5-flow cap is the design driver.** Both the LLA reconcile and the notify job exist *because* we can't add more record-triggered Flows in Professional Edition. If the org is ever upgraded to a higher edition, these could (optionally) move back into native Flows — but the server-side versions are robust and there's no urgency.
- **Fail-closed on access.** The reconcile is create-only and never deletes/updates LLAs. The only deletion anywhere is `tidyRedundantPendings`, and it deletes a Pending *only when an Approved LLA already covers the same lead+group* — it can never remove real access.
- **The notify watermark lives on the Railway volume.** If that volume is wiped/recreated, the first run after will re-seed to "now" and send nothing — correct behavior (no backlog blast), but be aware a wipe means any genuinely-new-but-pre-wipe pendings won't be emailed. Clear pendings manually once after enabling, as documented in the function header.
- **Email failures are safe.** A failed Resend send does not advance the watermark, so the digest retries next tick. Don't "fix" this by advancing unconditionally.
- **Lightning vs API host.** Email record links must use `*.lightning.force.com`. If My Domain is ever renamed and links 404, set `SF_LIGHTNING_BASE_URL`.
- **Backups run in GitHub Actions, not on Railway** — intentional, so they never compete with live calls. If you move them, give them their own process/host.
- **`manifest.json` is the completion marker.** It's uploaded last; a backup folder without a manifest is incomplete/partial. The job also exits non-zero on any per-object failure so CI flags it.
- **Retention is script-managed, not bucket-lifecycle.** Don't add an age-based R2 lifecycle rule expecting it to replace `prune()` — they'd fight. Adjust `BACKUP_KEEP_DAILY/MONTHLY` instead.
- **Backups exclude file binaries.** Flyer PDFs (`ContentVersion` body) are not backed up — only metadata. If those matter for recovery, add a binary-export path.
- **Do the restore drill.** Quarterly, run `sf-restore.ts --list` then `--get` on a recent stamp and spot-check counts vs. the manifest. Re-import to SF is always manual and deliberate.
- **Dry-run migrations first.** `scripts/migrations/` touch prod; the `fausto-migration` skill exists specifically because dry-run defaults are inconsistent across these one-off scripts.
- **Dev-org-only scripts.** Anything Apex (`deploy-apex-trigger.ts`, the `test-validation-rule*` Apex tests) must never run against prod — prod is PE and cannot run Apex.
- **Doc figure mismatch.** `scripts/backup/README.md:14` cites ~100–130 MB gz/backup while the `sf-backup.ts:25` header comment says ~51 MB; trust the measured README figure and update the comment if you touch it.
