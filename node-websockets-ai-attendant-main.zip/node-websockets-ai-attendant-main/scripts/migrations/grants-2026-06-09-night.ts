/**
 * Two grants for tonight's batch (2026-06-09):
 *
 *   1. Ernesto Diaz → group-level Westchester Retail access.
 *      He has more than one Westchester lead coming his way; group access
 *      is right per the §1 rule.
 *
 *   2. Lucia Villa → access to a single lead (EDMUND SANTIAGO / 2850 Douglas Rd,
 *      Bobby Berrido owner). Done via the personal-group pattern (§3) — create
 *      "Personal — Lucia Villa" group if not exists, grant her access, and
 *      add a Lead_List_Assignment from that lead to her personal group. This
 *      is the FIRST live use of the personal-group pattern.
 *
 * Idempotent. Dry-run by default. Pass --apply to commit.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const GRANTS = [
  { user: 'Ernesto Diaz', group: 'WestchesterRetail' },
];

const PERSONAL = {
  user: 'Lucia Villa',
  groupName: 'Personal — Lucia Villa',
  // Bobby Berrido's lead at 2850 Douglas Rd, from Nathalie's screenshot.
  leadId: '00QJw000004GCirMAG',
};

async function main() {
  const sf = await sfClient('prod') as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // ------------------- 1. Group-level grants -------------------
  for (const g of GRANTS) {
    console.log(`\n=== Grant: ${g.user} → "${g.group}" ===`);
    const u: any[] = await sf.soql(
      `SELECT Id, Name, IsActive FROM User WHERE Name = '${g.user}' AND IsActive = true LIMIT 5`
    );
    if (u.length !== 1) { console.log(`  ✗ User: ${u.length} matches — skip`); continue; }
    const grp: any[] = await sf.soql(
      `SELECT Id FROM Group__c WHERE Name = '${g.group}' LIMIT 5`
    );
    if (grp.length !== 1) { console.log(`  ✗ Group "${g.group}": ${grp.length} matches — skip`); continue; }
    const existing: any[] = await sf.soql(
      `SELECT Status__c FROM User_Group_Access__c WHERE User__c = '${u[0].Id}' AND Group__c = '${grp[0].Id}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) {
      console.log(`  ✓ Already Approved`);
      continue;
    }
    if (DRY) { console.log(`  Plan: CREATE User_Group_Access (Approved)`); continue; }
    const id = await sf.create('User_Group_Access__c', {
      User__c: u[0].Id, Group__c: grp[0].Id, Status__c: 'Approved',
    });
    console.log(`  ✓ Created User_Group_Access ${id}`);
  }

  // ------------------- 2. Personal-group pattern for Lucia -------------------
  console.log(`\n=== Personal-group: ${PERSONAL.user} → EDMUND SANTIAGO (${PERSONAL.leadId}) ===`);

  // 2a. User
  const lu: any[] = await sf.soql(
    `SELECT Id, Name FROM User WHERE Name = '${PERSONAL.user}' AND IsActive = true LIMIT 5`
  );
  if (lu.length !== 1) { console.log(`  ✗ ${PERSONAL.user}: ${lu.length} matches`); return; }
  const userId = lu[0].Id;
  console.log(`  User: ${userId}  ${lu[0].Name}`);

  // 2b. Personal group (create if missing)
  const existingGrp: any[] = await sf.soql(
    `SELECT Id, Name FROM Group__c WHERE Name = '${PERSONAL.groupName}' LIMIT 5`
  );
  let personalGroupId: string;
  if (existingGrp.length) {
    personalGroupId = existingGrp[0].Id;
    console.log(`  Personal group exists: ${personalGroupId}`);
  } else {
    if (DRY) {
      console.log(`  Plan: CREATE Group "${PERSONAL.groupName}"`);
      personalGroupId = '(would-create)';
    } else {
      personalGroupId = await sf.create('Group__c', { Name: PERSONAL.groupName });
      console.log(`  ✓ Created Group ${personalGroupId}`);
    }
  }

  // 2c. Lucia's User_Group_Access to her personal group
  if (personalGroupId !== '(would-create)') {
    const acc: any[] = await sf.soql(
      `SELECT Status__c FROM User_Group_Access__c WHERE User__c = '${userId}' AND Group__c = '${personalGroupId}'`
    );
    if (acc.find((r) => r.Status__c === 'Approved')) {
      console.log(`  ✓ Lucia already has Approved access to her personal group`);
    } else {
      if (DRY) { console.log(`  Plan: CREATE User_Group_Access (Lucia → personal)`); }
      else {
        const id = await sf.create('User_Group_Access__c', {
          User__c: userId, Group__c: personalGroupId, Status__c: 'Approved',
        });
        console.log(`  ✓ Created User_Group_Access ${id}`);
      }
    }
  }

  // 2d. EDMUND SANTIAGO lead (hardcoded ID from Nathalie's screenshot)
  const leads: any[] = await sf.soql(
    `SELECT Id, Name, Owner.Name, Group__r.Name FROM Lead WHERE Id = '${PERSONAL.leadId}'`
  );
  if (!leads.length) {
    console.log(`  ✗ Lead ${PERSONAL.leadId} not found`);
    return;
  }
  console.log(`  Lead: ${leads[0].Id}  ${leads[0].Name}  owner=${leads[0].Owner?.Name}  group=${leads[0].Group__r?.Name}`);
  const leadId = leads[0].Id;

  // 2e. Lead_List_Assignment EDMUND → Personal Lucia
  if (personalGroupId !== '(would-create)') {
    const existing: any[] = await sf.soql(
      `SELECT Id, Status__c FROM Lead_List_Assignment__c WHERE Lead__c = '${leadId}' AND Group__c = '${personalGroupId}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) {
      console.log(`  ✓ Assignment already exists`);
    } else {
      if (DRY) { console.log(`  Plan: CREATE Lead_List_Assignment (EDMUND → Personal Lucia, Approved)`); }
      else {
        const id = await sf.create('Lead_List_Assignment__c', {
          Lead__c: leadId, Group__c: personalGroupId, Status__c: 'Approved',
        });
        console.log(`  ✓ Created Lead_List_Assignment ${id}`);
      }
    }
  } else {
    console.log(`  Plan: CREATE Lead_List_Assignment after personal group is created`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
