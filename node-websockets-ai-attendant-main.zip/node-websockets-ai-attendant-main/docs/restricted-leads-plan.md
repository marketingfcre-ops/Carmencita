# Restricted (hidden) Leads — build + migration plan

_Draft 2026-06-21. Scoped read-only against prod. No prod writes made yet._

## Goal

11 lead "lists" (Broward/Dade multifamily) visible + editable ONLY by their
assigned agents + 3 people (Carlos **Fausto** Miranda, Carlos **Temperan**, Jesus).
Hidden from all other agents.

## Architecture (decided)

- **One** custom object `Restricted_Lead__c`, OWD = **Private**.
- Assigned agents get access via a **Flow that writes `Restricted_Lead__Share`
  records** (no Apex — PE-safe; same pattern the org already uses for leads).
- The 3 admins get **View All / Modify All** on the object via a permission set.
  (cfm gets it free as sysadmin; **ct/Temperan is on the agent profile so he needs
  the permset explicitly**; Jesus = TBD account.)
- "List" = a field on the record (`Restricted_List__c`), NOT reused `Group__c`.

## 🚨 Open issues that change scope / need Jesus's call

1. **Admins bypass OWD.** All 5 System Admins have "View All Data" → they will see
   restricted leads regardless of OWD. So "no one else can view" really means
   "hidden from the ~50 agents"; Nathalie/Elizabeth/Eleni/Tony will still see them.
   Removing View-All from those profiles is drastic and not recommended.
   **Confirm: hiding from agents is the real requirement?**
2. **Jesus's SF user** isn't a named System Administrator. Which login is yours?
3. **Duplicate / ambiguous source groups.** The migration is not 1 group → 1 list.
   Each list has a clear primary group plus near-dupes and same-geography-different-
   type groups that must be sorted by hand. Proposed primary mapping below — confirm
   each, and say which extras merge in.

## Proposed primary-group → list mapping (CONFIRM each)

| Tidied list name | Primary Group__c | Leads | Likely-merge candidates to review |
|---|---|--:|---|
| ALFs Broward & Palm Beach | `ALFs Broward Palm` | 0 | (empty — new/forward-only?) |
| Dania Multifamily | `DaniaMulti` | _see scope_ | dupe `DaniaMulti` rows |
| South Broward Apartments | `SouthBrowardApt` | 685 | `SouthBroward` (2), NOT `…Ind`/`…Comm`/`…Land`/`…Retail` |
| Hollywood Apts 33023/33024 | `HollywoodApt33023_4` | 896 | NOT `HollywoodRetail`/`Hollywood33020Resi` |
| South Broward Apts 33020 | `SouthBrowardApt33020` | 580 | — |
| Hallandale Multifamily | `Hallandale MultiFam` | 995 | NOT `HallandaleRetail` |
| North Miami Apartments | `NorthMiaApts` | 631 | NOT `NorthMiaLand`/`NorthMiaWrhse` |
| Pompano Multifamily | `PompanoMultiFam` | 2,177 | `Pompano Beach` (1) |
| Broward Multifamily | `BrowardMulti` | 3,607 | `Broward MF 33021` (523)? |
| West Fort Lauderdale Multifamily | `W Fort Lauderdale MF` | 1,049 | — |
| Fort Lauderdale Apartments | `FTLApts` | 1,179 | — |

~12K leads clean; more if dupes fold in. (Junk groups `a`, `SOU`, `Multi`, `Land`,
`Broward` are noise to ignore.) Full candidate dump: run
`scripts/diagnostics/restricted-leads-migration-scope.ts`.

## Field spec for `Restricted_Lead__c` (mirror the relevant Lead fields)

| API name | Type | Notes |
|---|---|---|
| Name | Auto-Number `RL-{00000}` | |
| First_Name__c | Text(40) | |
| Last_Name__c | Text(80) | required |
| Company__c | Text(255) | |
| Phone__c / Mobile__c | Phone | |
| Email__c | Email | |
| Property__c | Text(255) | |
| Status__c | Picklist | Open/Contacted/On Hold/Unqualified/Closed |
| Prospecting_Notes__c | Long Text | |
| Owning_Entity_LLC_Name__c | Text(255) | |
| Restricted_List__c | Picklist | the 11 tidied names — drives sharing (add after taxonomy confirmed) |
| Source_Lead_Id__c | Text(18) | provenance back to the original Lead (for migration audit) |

## Build sequence (each gated)

1. Create object + fields via Tooling API (script: `create-restricted-lead-object.ts`, staged, dry-run-guarded).
2. Permission set "Restricted Leads Admin" (View/Modify All) → assign cfm, ct, Jesus.
3. **Verify Flow → `Restricted_Lead__Share` DML works in this PE org** on one test record.
4. Build sharing Flow (UI) keyed on `Restricted_List__c`.
5. Lightning Record Page (UI, ~10 min).
6. **Migration** (dry-run first): per confirmed mapping, copy Leads → Restricted_Lead__c,
   set Restricted_List__c, stamp Source_Lead_Id__c. Then decide what happens to the
   originals (delete? flag? keep as archive?).

## Decisions still needed before any prod write
- Open issues 1–3 above.
- Migration: copy-and-keep, or copy-and-delete originals? (affects the 50 agents who
  currently *can* see these leads — deleting removes them from everyone.)
