/**
 * Link 9 SF records to existing WP posts (no new drafts needed).
 *
 * These are SF records the April import created but never wrote back
 * WP_Post_ID__c on — the WP post exists, address matches, just no link.
 *
 * NOTE on the Mendoza case (SF a0RJw000008bvHFMAY): the SF record contains
 * THREE addresses (320 Mendoza + 324 Mendoza + 1610 Salzedo). We link to
 * wp:49087 "Mendoza Twins" (which covers 320-324 Mendoza). The 1610 Salzedo
 * building (wp:32358 "Coral Gables Portfolio 28 Units") is a SEPARATE
 * building and likely needs its own SF record — flagged at end for human.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-link-9-existing-wp.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-link-9-existing-wp.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface LinkPair {
  sfId: string;
  sfAddress: string;
  wpId: number;
  rationale: string;
}

const PAIRS: LinkPair[] = [
  { sfId: 'a0RJw000008HYDbMAO', sfAddress: '943 SW 9 ave / Miami', wpId: 49056, rationale: 'Exact address match' },
  { sfId: 'a0RJw000008bvHFMAY', sfAddress: '320/324 Mendoza Ave + 1610 Salzedo (Coral Gables)', wpId: 49087, rationale: 'Linking to "Mendoza Twins" (covers 320-324). 1610 Salzedo separate — see flag.' },
  { sfId: 'a0RJw000008ygivMAA', sfAddress: '1420 SE 4th Ave / Pompano Beach', wpId: 56005, rationale: 'Exact address match' },
  { sfId: 'a0RJw0000092C9ZMAU', sfAddress: '8230-8330 Biscayne Blvd / Miami', wpId: 56037, rationale: 'Same building — SF has range, WP has 8330 anchor' },
  { sfId: 'a0RJw0000092D2PMAU', sfAddress: '1133 Cassat Avenue / Jacksonville', wpId: 62819, rationale: 'Exact address match' },
  { sfId: 'a0RJw0000092sQXMAY', sfAddress: '960 Jefferson Ave / Miami Beach', wpId: 62137, rationale: 'Exact address match' },
  { sfId: 'a0RJw0000094Dr7MAE', sfAddress: '420 78th St / Miami Beach', wpId: 62377, rationale: 'Exact address match' },
  { sfId: 'a0RJw0000094Fw9MAE', sfAddress: '1241-1251 W River Dr / Margate (SF city says Coral Springs — wrong)', wpId: 63114, rationale: 'Exact address match; SF.City__c is wrong' },
  { sfId: 'a0RJw0000097BETMA2', sfAddress: '1800 NW 19 Terr / Miami', wpId: 63204, rationale: 'Same building as wp:63204 that Cristina manually fixed earlier' },
];

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true } as const;
  return { ok: false as const, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true } as const;
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false as const, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false as const, error: lastError };
  }
  return { ok: false as const, error: lastError };
}

async function getWpLink(wpId: number): Promise<string | null> {
  const res = await fetch(
    `${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}?context=edit&_fields=link`,
    { headers: { Authorization: WP_AUTH } }
  );
  if (!res.ok) return null;
  const data = (await res.json()) as { link?: string };
  return data.link || null;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log(`\n🔗 Link ${PAIRS.length} SF records to existing WP posts ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();

  const sfRecords = await sfQuery<{ Id: string; WP_Post_ID__c: number | null; Address__c: string | null }>(
    token,
    instance,
    `SELECT Id, WP_Post_ID__c, Address__c
       FROM Property__c
      WHERE Id IN ('${PAIRS.map((p) => p.sfId).join("','")}')`
  );
  const sfById = new Map<string, typeof sfRecords[0]>();
  for (const r of sfRecords) sfById.set(r.Id, r);

  let safe = true;
  for (const p of PAIRS) {
    const sf = sfById.get(p.sfId);
    if (!sf) {
      console.error(`❌ ${p.sfId} not found in SF`);
      safe = false;
      continue;
    }
    if (sf.WP_Post_ID__c !== null) {
      console.error(`❌ ${p.sfId} already has WP_Post_ID__c=${sf.WP_Post_ID__c} (expected null) — aborting`);
      safe = false;
    }
  }
  if (!safe) {
    console.error('\nAborting due to safety check failures.');
    process.exit(1);
  }
  console.log(`✓ All ${PAIRS.length} SF records confirmed null. Safe to proceed.\n`);

  // Pre-fetch WP permalinks
  console.log('Fetching WP permalinks...\n');
  const wpLinks = new Map<number, string>();
  for (const p of PAIRS) {
    const link = await getWpLink(p.wpId);
    if (!link) {
      console.error(`❌ wp:${p.wpId} could not be fetched`);
      process.exit(1);
    }
    wpLinks.set(p.wpId, link);
  }

  console.log('── Plan ──\n');
  for (const p of PAIRS) {
    console.log(`SF ${p.sfId}`);
    console.log(`   ${p.sfAddress}`);
    console.log(`   → wp:${p.wpId}`);
    console.log(`     ${wpLinks.get(p.wpId)}`);
    console.log(`   ${p.rationale}`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('→ Executing...\n');
  let ok = 0;
  let err = 0;
  for (const p of PAIRS) {
    const result = await sfUpdateWithRetry(token, instance, p.sfId, {
      WP_Post_ID__c: p.wpId,
      Public_URL__c: wpLinks.get(p.wpId),
    });
    if (result.ok) {
      console.log(`   ✓ ${p.sfId} → wp:${p.wpId}`);
      ok++;
    } else {
      console.warn(`   ❌ ${p.sfId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Linked:    ${ok}`);
  console.log(`Failures:  ${err}`);
  console.log('');

  console.log('⚠️  FOLLOW-UP (human decision):');
  console.log('   wp:32358 "Coral Gables Portfolio 28 Units" at 1610 Salzedo Street is');
  console.log('   currently unlinked from SF. SF a0RJw000008bvHFMAY combines 320-324');
  console.log('   Mendoza + 1610 Salzedo into one record. If 1610 Salzedo is a separate');
  console.log('   building, create a new SF record for it.\n');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
