/**
 * Build the three client-facing action lists for the listing/photo/flyer cleanup.
 * Read-only (SF reads + WP GETs + verifying image-source links). Writes 3 CSVs:
 *
 *   data/list-1-publish-lowhanging.csv  — ready to publish or upload-then-publish
 *   data/list-2-request-from-agents.csv — need photos / Drive access sourced
 *   data/list-3-confirm-flyers.csv      — PDFs with unclear names to confirm as flyers
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/listing-action-lists.ts
 */

import { sfClient } from '../../src/integrations/sf-client';
import { writeFile } from 'fs/promises';

const API_BASE = `${(process.env.WP_SITE_URL || 'https://faustocommercial.com').replace(/\/$/, '')}/wp-json`;
const wpAuth = () => `Basic ${Buffer.from(`${process.env.WP_USER || ''}:${process.env.WP_APP_PASSWORD || ''}`).toString('base64')}`;
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36';
const postIdFromUrl = (u: string | null) => { const m = u?.match(/[?&]p=(\d+)/); return m ? Number(m[1]) : null; };
const chunk = <T,>(a: T[], n: number) => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const FLYER_RE = /flyer/i;
const csvRow = (a: any[]) => a.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',');

const photoSource = (u: string): 'dropbox' | 'gdrive' | 'other-url' | 'junk' => {
  if (/dropbox\.com\/(scl|sh|s|home)\//i.test(u)) return 'dropbox';
  if (/drive\.google|docs\.google/i.test(u)) return 'gdrive';
  if (/^https?:\/\/[^\/\s]+\/\S+/i.test(u)) return 'other-url';
  return 'junk';
};

async function verify(url: string, src: string): Promise<'live' | 'auth' | 'dead' | 'error'> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow', signal: ctrl.signal });
    const finalUrl = res.url || url;
    if (/accounts\.google\.com|servicelogin|signin/i.test(finalUrl)) return 'auth';
    if (res.status >= 400) return 'dead';
    const body = (await res.text().catch(() => '')).slice(0, 20000).toLowerCase();
    const dead = ["link doesn't work", 'link_not_found', 'no longer exists', 'has been deleted',
      'sorry, the file you have requested does not exist', 'error (404)', "couldn't find", 'page not found'];
    if (dead.some((m) => body.includes(m))) return 'dead';
    if (src === 'gdrive' && /you need access|request access/i.test(body)) return 'auth';
    return 'live';
  } catch { return 'error'; } finally { clearTimeout(timer); }
}
async function pool<T, R>(items: T[], n: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length); let i = 0;
  await Promise.all(Array.from({ length: n }, async () => { while (i < items.length) { const idx = i++; out[idx] = await fn(items[idx]); } }));
  return out;
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  const props: any[] = await sf.soql(`SELECT Id, Name, Status__c, Public_URL__c, WP_Post_ID__c, Photo_URL__c FROM Property__c`);

  // WP status + featured photo
  const wpIdByProp = new Map<string, number>();
  for (const p of props) { const id = p.WP_Post_ID__c ? Number(p.WP_Post_ID__c) : postIdFromUrl(p.Public_URL__c); if (id) wpIdByProp.set(p.Id, id); }
  const wp = new Map<number, { status: string; featured: number }>();
  for (const ids of chunk([...new Set(wpIdByProp.values())], 100)) {
    const url = `${API_BASE}/wp/v2/properties?include=${ids.join(',')}&per_page=100&status=publish,draft,private,pending,future&context=edit&_fields=id,status,featured_media`;
    const res = await fetch(url, { headers: { Authorization: wpAuth() } });
    if (res.ok) for (const r of (await res.json()) as any[]) wp.set(r.id, { status: r.status, featured: r.featured_media || 0 });
  }

  // Flyer presence (all properties)
  const docByProp = new Map<string, string[]>(); const allDocs = new Set<string>();
  for (const ids of chunk(props.map((p) => p.Id), 150)) {
    const links: any[] = await sf.soql(`SELECT LinkedEntityId, ContentDocumentId FROM ContentDocumentLink WHERE LinkedEntityId IN (${ids.map((i) => `'${i}'`).join(',')})`);
    for (const l of links) if (l.LinkedEntityId?.startsWith('a')) { const a = docByProp.get(l.LinkedEntityId) || []; a.push(l.ContentDocumentId); docByProp.set(l.LinkedEntityId, a); allDocs.add(l.ContentDocumentId); }
  }
  const flyerDocs = new Set<string>(); const docNames = new Map<string, string[]>();
  for (const ids of chunk([...allDocs], 150)) {
    const vers: any[] = await sf.soql(`SELECT ContentDocumentId, Title, PathOnClient, FileExtension FROM ContentVersion WHERE ContentDocumentId IN (${ids.map((i) => `'${i}'`).join(',')}) AND IsLatest = true`);
    for (const v of vers) {
      if (FLYER_RE.test(v.Title || '') || FLYER_RE.test(v.PathOnClient || '')) flyerDocs.add(v.ContentDocumentId);
    }
  }
  const hasFlyer = (pid: string) => (docByProp.get(pid) || []).some((d) => flyerDocs.has(d));

  // Verify image-source links for the not-live set
  const notLive = props.filter((p) => { const id = wpIdByProp.get(p.Id); const w = id ? wp.get(id) : undefined; return !(w && w.status === 'publish'); });
  const toVerify = notLive.map((p) => ({ p, u: (p.Photo_URL__c || '').trim() })).filter((x) => x.u && ['dropbox', 'gdrive', 'other-url'].includes(photoSource(x.u)));
  const verdicts = new Map<string, string>();
  const vres = await pool(toVerify, 6, async (x) => ({ id: x.p.Id, v: await verify(x.u, photoSource(x.u)) }));
  for (const r of vres) verdicts.set(r.id, r.v);

  // Build lists
  const list1: any[] = []; // publish low-hanging
  const list2: any[] = []; // request from agents
  for (const p of notLive) {
    const id = wpIdByProp.get(p.Id); const featured = id ? (wp.get(id)?.featured || 0) : 0;
    const src = (p.Photo_URL__c || '').trim() ? photoSource((p.Photo_URL__c || '').trim()) : 'junk';
    const flyer = hasFlyer(p.Id) ? 'YES' : 'no';
    const link = (p.Photo_URL__c || '').trim();
    if (featured > 0) { list1.push([p.Name, p.Id, 'Ready — just publish', '', flyer]); continue; }
    const v = verdicts.get(p.Id);
    if (v === 'live') list1.push([p.Name, p.Id, `Upload photos to WP then publish (${src})`, link, flyer]);
    else if (v === 'auth') list2.push([p.Name, p.Id, 'Photos in PRIVATE Google Drive — grant access', link, flyer]);
    else if (v === 'dead') list2.push([p.Name, p.Id, 'Saved photo link is broken — request new photos', link, flyer]);
    else list2.push([p.Name, p.Id, 'No photos on file — request from agent', '', flyer]);
  }

  // List 3 — flyers to confirm (files but no "flyer" in any name)
  const list3: any[] = [];
  for (const p of props) {
    const docs = docByProp.get(p.Id) || [];
    if (docs.length === 0) continue;
    if (hasFlyer(p.Id)) continue;
    // names of this property's files
    list3.push([p.Name, p.Id]); // names filled below
  }
  // get filenames for list3 properties
  const l3ids = new Set(list3.map((r) => r[1]));
  const filesByProp = new Map<string, string[]>();
  for (const [pid, docs] of docByProp) {
    if (!l3ids.has(pid)) continue;
    filesByProp.set(pid, []);
  }
  for (const ids of chunk([...new Set([...l3ids].flatMap((pid) => docByProp.get(pid) || []))], 150)) {
    if (!ids.length) continue;
    const vers: any[] = await sf.soql(`SELECT ContentDocumentId, Title, PathOnClient, FileExtension FROM ContentVersion WHERE ContentDocumentId IN (${ids.map((i) => `'${i}'`).join(',')}) AND IsLatest = true`);
    const nm = new Map(vers.map((v: any) => [v.ContentDocumentId, v.PathOnClient || ((v.Title || '') + (v.FileExtension ? '.' + v.FileExtension : ''))]));
    for (const [pid, docs] of docByProp) {
      if (!l3ids.has(pid)) continue;
      for (const d of docs) if (nm.has(d)) filesByProp.get(pid)!.push(nm.get(d)!);
    }
  }
  const list3full = list3.map((r) => {
    const files = [...new Set(filesByProp.get(r[1]) || [])];
    const pdfs = files.filter((f) => /\.pdf$/i.test(f));
    return [r[0], r[1], files.join(' | '), pdfs.length === 1 ? pdfs[0] : '(multiple/none — please pick)'];
  });

  await writeFile('data/list-1-publish-lowhanging.csv', ['Property,SF_Id,Action,Photo_Link,Has_Flyer', ...list1.map(csvRow)].join('\n'));
  await writeFile('data/list-2-request-from-agents.csv', ['Property,SF_Id,What_Is_Needed,Saved_Link,Has_Flyer', ...list2.map(csvRow)].join('\n'));
  await writeFile('data/list-3-confirm-flyers.csv', ['Property,SF_Id,Attached_Files,Likely_Flyer_(confirm),', ...list3full.map(csvRow)].join('\n'));

  console.log(`\n📋 Action lists written:`);
  console.log(`   list-1-publish-lowhanging.csv   ${list1.length}  (ready/just-upload → publish)`);
  console.log(`   list-2-request-from-agents.csv  ${list2.length}  (need photos/access sourced)`);
  console.log(`   list-3-confirm-flyers.csv       ${list3full.length}  (PDFs to confirm as flyers)`);
  console.log(`\n   List 1 breakdown: ready-to-publish=${list1.filter((r) => r[2].startsWith('Ready')).length}  upload-then-publish=${list1.filter((r) => r[2].startsWith('Upload')).length}`);
  console.log(`   List 2 breakdown: private-Drive=${list2.filter((r) => r[2].includes('PRIVATE')).length}  broken-link=${list2.filter((r) => r[2].includes('broken')).length}  no-photos=${list2.filter((r) => r[2].includes('No photos')).length}`);
  console.log(`   (of List 2, ${list2.filter((r) => r[4] === 'YES').length} already have a flyer → email-covered)\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
