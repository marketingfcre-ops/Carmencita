/**
 * Match Excel orphans against SF-only groups using fuzzy techniques.
 *
 * Input:  data/archive/agent-group-reconcile-2026-05-20.json
 *         (output from scripts/diagnostics/agent-group-reconcile.ts)
 *
 * For each ORPHAN (Excel group with no SF match), score every SF-only group
 * as a potential match. Bucket results by confidence:
 *
 *   🟢 HIGH    (≥0.85)  — likely the same group, abbreviation/typo variant.
 *                         Recommended for automatic rename in the write script.
 *   🟡 MEDIUM  (0.60–0.85) — plausible match, needs human review.
 *   🔴 LOW     (<0.60)   — no good candidate; treat as a real new group.
 *
 * Also re-analyzes the 95 SF duplicate clusters and picks a recommended
 * canonical (highest lead count by default; falls back to longest name when
 * there's a tie, since longer names are usually the intentional ones).
 *
 * Read-only. Standing approval per memory.
 *
 * Output:
 *   data/archive/orphan-matches-2026-05-24.txt   (human-readable)
 *   data/archive/orphan-matches-2026-05-24.json  (for Phase 2 write script)
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/diagnostics/orphan-matcher.ts
 */

import fs from 'node:fs';
import path from 'node:path';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const INPUT = path.join(REPO_ROOT, 'data', 'archive', 'agent-group-reconcile-2026-05-20.json');
const OUTPUT_TXT = path.join(REPO_ROOT, 'data', 'archive', 'orphan-matches-2026-05-24.txt');
const OUTPUT_JSON = path.join(REPO_ROOT, 'data', 'archive', 'orphan-matches-2026-05-24.json');

// ---------------------------------------------------------------------------
// Domain-specific abbreviation expansion.
// Fausto's Excel uses a consistent set of shorthand. Expand both sides of any
// comparison so "LitHavApt" tokens become [little, havana, apartments] and can
// match "LittleHavanaApt" tokens.
// ---------------------------------------------------------------------------

const ABBREV: Record<string, string> = {
  // Neighborhoods
  lit: 'little',
  hav: 'havana',
  lithav: 'littlehavana',
  hia: 'hialeah',
  mia: 'miami',
  bch: 'beach',
  ftl: 'fortlauderdale',
  jax: 'jacksonville',
  dwn: 'down',
  dwntwn: 'downtown',
  dwtwn: 'downtown',
  twn: 'town',
  swtwtr: 'sweetwater',
  // Directions
  no: 'north',
  so: 'south',
  n: 'north',
  s: 'south',
  e: 'east',
  w: 'west',
  ne: 'northeast',
  nw: 'northwest',
  se: 'southeast',
  sw: 'southwest',
  // Property types
  com: 'commercial',
  comm: 'commercial',
  apt: 'apartments',
  apts: 'apartments',
  ind: 'industrial',
  ret: 'retail',
  mf: 'multifamily',
  resi: 'residential',
  warehouse: 'warehouse',
  alf: 'assistedliving',
  alfs: 'assistedliving',
  // Other
  ts: 'tonysaladrigas',
  aac: 'ashleencruz',
  spring: 'spring',
};

// ---------------------------------------------------------------------------
// Tokenization + normalization
// ---------------------------------------------------------------------------

/** Split on CamelCase boundaries, whitespace, and punctuation. Lowercase. */
function tokenize(s: string): string[] {
  if (!s) return [];
  // Insert space before uppercase that follows a lowercase letter
  const split = s
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2'); // "USAce" -> "US Ace"
  return split
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length > 0);
}

/** Expand abbreviations in a token list, then re-tokenize (some expansions add boundaries). */
function expandTokens(tokens: string[]): string[] {
  const out: string[] = [];
  for (const t of tokens) {
    const expanded = ABBREV[t] || t;
    // Some expansions can be multi-word ("littlehavana") — re-split for fairness
    if (expanded !== t && /[a-z]+[a-z]+/.test(expanded)) {
      // Try splitting on common word boundaries within the expansion
      // For most ABBREV values it's a single word; if it's two glued words,
      // re-tokenize via CamelCase trick (lowercase so nothing happens) — just leave.
      out.push(expanded);
    } else {
      out.push(expanded);
    }
  }
  return out;
}

/** Fully normalized comparison key: tokens → expand → join. */
function normKey(s: string): string {
  return expandTokens(tokenize(s)).join('');
}

// ---------------------------------------------------------------------------
// Similarity metrics
// ---------------------------------------------------------------------------

/** Levenshtein distance (iterative DP). */
function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;
  const dp = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) dp[j] = j;
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] =
        a[i - 1] === b[j - 1]
          ? prev
          : 1 + Math.min(prev, dp[j], dp[j - 1]);
      prev = tmp;
    }
  }
  return dp[b.length];
}

/** Jaccard similarity over expanded token sets. */
function jaccard(aTokens: string[], bTokens: string[]): number {
  if (aTokens.length === 0 || bTokens.length === 0) return 0;
  const a = new Set(aTokens);
  const b = new Set(bTokens);
  let inter = 0;
  for (const t of a) if (b.has(t)) inter++;
  const union = a.size + b.size - inter;
  return union === 0 ? 0 : inter / union;
}

/** Combined similarity score in [0,1]. */
function score(excelName: string, sfName: string): { score: number; reasons: string[] } {
  const reasons: string[] = [];
  const excelTokens = expandTokens(tokenize(excelName));
  const sfTokens = expandTokens(tokenize(sfName));
  const excelKey = excelTokens.join('');
  const sfKey = sfTokens.join('');

  // 1. Normalized-key equality (highest signal)
  if (excelKey === sfKey) {
    reasons.push('normalized-keys-equal');
    return { score: 1.0, reasons };
  }

  // 2. Substring containment of normalized keys
  let containmentScore = 0;
  if (excelKey.length >= 4 && sfKey.length >= 4) {
    if (sfKey.includes(excelKey)) {
      containmentScore = excelKey.length / sfKey.length;
      reasons.push(`sf-contains-excel(${containmentScore.toFixed(2)})`);
    } else if (excelKey.includes(sfKey)) {
      containmentScore = sfKey.length / excelKey.length;
      reasons.push(`excel-contains-sf(${containmentScore.toFixed(2)})`);
    }
  }

  // 3. Token Jaccard (after abbreviation expansion)
  const jac = jaccard(excelTokens, sfTokens);
  if (jac > 0) reasons.push(`jaccard(${jac.toFixed(2)})`);

  // 4. Levenshtein over normalized keys, normalized by max length
  const dist = levenshtein(excelKey, sfKey);
  const lev = 1 - dist / Math.max(excelKey.length, sfKey.length);
  if (lev > 0.4) reasons.push(`lev(${lev.toFixed(2)})`);

  // Weighted combination — Jaccard weighted highest because abbreviation
  // expansion makes it most reliable for this domain.
  const combined = Math.max(
    containmentScore,
    0.55 * jac + 0.30 * lev + 0.15 * Math.min(containmentScore, 0.5)
  );

  return { score: combined, reasons };
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

interface OrphanResult {
  excelName: string;
  agents: string[];
  matchType: 'orphan';
  sfMatches: Array<{ id: string; name: string; leads: number }>;
}

interface SfOnly {
  id: string;
  name: string;
  leads: number;
}

interface DupCluster {
  normKey: string;
  rows: Array<{ id: string; name: string; leads: number }>;
  inExcel: boolean;
}

interface OrphanMatch {
  excelName: string;
  agents: string[];
  candidates: Array<{
    sfId: string;
    sfName: string;
    leads: number;
    score: number;
    reasons: string[];
  }>;
  bestScore: number;
  bucket: 'HIGH' | 'MEDIUM' | 'LOW';
}

interface ClusterPick {
  normKey: string;
  inExcel: boolean;
  canonical: { id: string; name: string; leads: number };
  toMerge: Array<{ id: string; name: string; leads: number }>;
  totalLeads: number;
}

const HIGH = 0.85;
const MEDIUM = 0.6;

function main() {
  if (!fs.existsSync(INPUT)) {
    console.error(`❌ Missing input: ${INPUT}`);
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(INPUT, 'utf8'));

  const orphans: OrphanResult[] = (data.results as any[]).filter(
    (r) => r.matchType === 'orphan'
  );
  const sfOnly: SfOnly[] = data.sf_only_groups;
  const dupClusters: DupCluster[] = data.sf_duplicate_clusters;

  console.log(
    `Loaded: ${orphans.length} orphans, ${sfOnly.length} SF-only, ${dupClusters.length} duplicate clusters`
  );

  // --- Orphan matching ---
  const matches: OrphanMatch[] = [];
  for (const orphan of orphans) {
    const scored = sfOnly
      .map((sf) => ({ sf, ...score(orphan.excelName, sf.name) }))
      .filter((c) => c.score > 0.15)
      .sort((a, b) => b.score - a.score);

    const top = scored.slice(0, 5).map((c) => ({
      sfId: c.sf.id,
      sfName: c.sf.name,
      leads: c.sf.leads,
      score: Number(c.score.toFixed(3)),
      reasons: c.reasons,
    }));

    const bestScore = top[0]?.score ?? 0;
    const bucket: 'HIGH' | 'MEDIUM' | 'LOW' =
      bestScore >= HIGH ? 'HIGH' : bestScore >= MEDIUM ? 'MEDIUM' : 'LOW';

    matches.push({
      excelName: orphan.excelName,
      agents: orphan.agents,
      candidates: top,
      bestScore,
      bucket,
    });
  }

  // --- Duplicate cluster canonical picker ---
  const clusterPicks: ClusterPick[] = dupClusters.map((c) => {
    // Canonical = most leads, tiebreaker = longest (most descriptive) name
    const sorted = [...c.rows].sort((a, b) => {
      if (b.leads !== a.leads) return b.leads - a.leads;
      return b.name.length - a.name.length;
    });
    const canonical = sorted[0];
    const toMerge = sorted.slice(1);
    return {
      normKey: c.normKey,
      inExcel: c.inExcel,
      canonical,
      toMerge,
      totalLeads: c.rows.reduce((s, r) => s + r.leads, 0),
    };
  });

  // --- Render text report ---
  const lines: string[] = [];
  lines.push('ORPHAN MATCHER + DUPLICATE-CLUSTER CANONICAL PICKER');
  lines.push(`Source: ${path.basename(INPUT)}`);
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push('');

  const high = matches.filter((m) => m.bucket === 'HIGH');
  const med = matches.filter((m) => m.bucket === 'MEDIUM');
  const low = matches.filter((m) => m.bucket === 'LOW');

  lines.push('─── SUMMARY ───');
  lines.push(`Orphans analyzed:        ${matches.length}`);
  lines.push(`  🟢 HIGH-confidence:    ${high.length} (recommend auto-rename)`);
  lines.push(`  🟡 MEDIUM-confidence:  ${med.length} (review manually)`);
  lines.push(`  🔴 LOW / no match:     ${low.length} (real new groups?)`);
  lines.push(`SF duplicate clusters:   ${clusterPicks.length} (canonical recommended)`);
  lines.push('');

  // HIGH bucket
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`🟢 HIGH-CONFIDENCE ORPHAN MATCHES (${high.length})`);
  lines.push('Excel orphan → SF canonical (score, leads)');
  lines.push('Recommendation: rename SF Group__c.Name → Excel canonical name.');
  lines.push('═══════════════════════════════════════════════════════════════════');
  for (const m of high) {
    const top = m.candidates[0];
    lines.push(
      `  "${m.excelName}"  →  "${top.sfName}"  [score=${top.score}, leads=${top.leads}]`
    );
    lines.push(`     SF id: ${top.sfId}`);
    lines.push(`     agents: ${m.agents.join(', ')}`);
    lines.push(`     why: ${top.reasons.join('; ')}`);
    if (m.candidates.length > 1) {
      lines.push(
        `     (next best: "${m.candidates[1].sfName}" score=${m.candidates[1].score})`
      );
    }
    lines.push('');
  }

  // MEDIUM bucket
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`🟡 MEDIUM-CONFIDENCE ORPHAN MATCHES (${med.length})`);
  lines.push('Plausible — review and decide:');
  lines.push('═══════════════════════════════════════════════════════════════════');
  for (const m of med) {
    lines.push(`  "${m.excelName}"   agents=${m.agents.join(', ')}`);
    for (const c of m.candidates.slice(0, 3)) {
      lines.push(`     candidate: "${c.sfName}"  [score=${c.score}, leads=${c.leads}]`);
      lines.push(`       reasons: ${c.reasons.join('; ')}`);
    }
    lines.push('');
  }

  // LOW bucket
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`🔴 LOW / NO MATCH (${low.length})`);
  lines.push('No good SF candidate. Likely a real new group — ask Fausto to confirm,');
  lines.push('then create empty Group__c records in SF.');
  lines.push('═══════════════════════════════════════════════════════════════════');
  for (const m of low) {
    lines.push(`  "${m.excelName}"   agents=${m.agents.join(', ')}`);
    if (m.candidates.length > 0) {
      const c = m.candidates[0];
      lines.push(
        `     (closest was "${c.sfName}" score=${c.score} — too weak to act on)`
      );
    }
  }
  lines.push('');

  // Cluster canonicals
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`🔁 DUPLICATE-CLUSTER CANONICAL RECOMMENDATIONS (${clusterPicks.length})`);
  lines.push('For each cluster: keep canonical, reassign leads from dups, delete dups.');
  lines.push('Sorted by total leads (most-impactful first).');
  lines.push('═══════════════════════════════════════════════════════════════════');
  const sortedPicks = [...clusterPicks].sort((a, b) => b.totalLeads - a.totalLeads);
  for (const p of sortedPicks) {
    const tag = p.inExcel ? '[in-excel]' : '[sf-only]';
    lines.push(`  cluster "${p.normKey}" ${tag}  totalLeads=${p.totalLeads}`);
    lines.push(`     KEEP    ${p.canonical.id}  "${p.canonical.name}"  leads=${p.canonical.leads}`);
    for (const m of p.toMerge) {
      lines.push(`     MERGE → ${m.id}  "${m.name}"  leads=${m.leads}`);
    }
    lines.push('');
  }

  fs.writeFileSync(OUTPUT_TXT, lines.join('\n'));
  fs.writeFileSync(
    OUTPUT_JSON,
    JSON.stringify(
      {
        generated_at: new Date().toISOString(),
        source_report: path.basename(INPUT),
        summary: {
          orphans: matches.length,
          high_confidence: high.length,
          medium_confidence: med.length,
          low_no_match: low.length,
          duplicate_clusters: clusterPicks.length,
        },
        thresholds: { high: HIGH, medium: MEDIUM },
        orphan_matches: matches,
        cluster_picks: sortedPicks,
      },
      null,
      2
    )
  );

  console.log(`\n📄 Wrote ${path.relative(REPO_ROOT, OUTPUT_TXT)}`);
  console.log(`📄 Wrote ${path.relative(REPO_ROOT, OUTPUT_JSON)}\n`);
  console.log(
    `HIGH=${high.length}  MEDIUM=${med.length}  LOW=${low.length}  Clusters=${clusterPicks.length}\n`
  );
}

main();
