/**
 * Flyer renderer.
 *
 * Builds an HTML flyer for a Property and returns either:
 *   - the rendered HTML (for preview/iteration with the marketing team), or
 *   - a PDF (when wired up to a PDF service)
 *
 * PDF backend choice — pick one in production:
 *   (A) PDFShift  — SaaS HTTP API, no Chromium install. Add PDFSHIFT_API_KEY
 *                   to env. Pay per render, simple.
 *   (B) Puppeteer — local headless Chromium. Free, full control, ~150MB install.
 *
 * The skeleton below leaves PDF rendering as a TODO so we don't lock in the
 * choice before the marketing team confirms templates. HTML preview works today.
 */

import { fetchPropertyForSync, type SFPropertyForSync } from '../salesforce';

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface FlyerRenderResult {
  ok: boolean;
  html?: string;
  pdfBuffer?: Buffer;
  contentType: 'text/html' | 'application/pdf';
  error?: string;
}

/**
 * Render a flyer for the given SF Property record.
 *
 * @param sfPropertyId  Salesforce Property__c record ID
 * @param format        'html' (preview) or 'pdf' (production output)
 */
export async function renderFlyerForProperty(
  sfPropertyId: string,
  format: 'html' | 'pdf' = 'html'
): Promise<FlyerRenderResult> {
  const property = await fetchPropertyForSync(sfPropertyId);
  if (!property) {
    return {
      ok: false,
      contentType: 'text/html',
      error: `Property__c ${sfPropertyId} not found`,
    };
  }

  const html = buildFlyerHtml(property);

  if (format === 'html') {
    return { ok: true, html, contentType: 'text/html' };
  }

  // format === 'pdf'
  const pdf = await renderPdfFromHtml(html);
  if (!pdf.ok) {
    return { ok: false, contentType: 'text/html', error: pdf.error };
  }
  return { ok: true, pdfBuffer: pdf.buffer, contentType: 'application/pdf' };
}

// ---------------------------------------------------------------------------
// Template
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Merge tags — the contract between the marketing template and our data.
//
// Whoever writes the HTML template (Elizabeth — converted from Illustrator/
// Canva) uses these tags in their HTML wherever data should appear. We replace
// them at render time. New tags can be added later without breaking templates.
//
// Tag syntax: {{tag_name}}  (case-sensitive, double-curly, no spaces inside)
// ---------------------------------------------------------------------------

export type FlyerTags = Record<string, string>;

/** Build the merge-tag values from an SF Property record. */
export function propertyToTags(p: SFPropertyForSync): FlyerTags {
  const fmtPrice = (n: number | null | undefined) =>
    n == null ? '' : `$${n.toLocaleString('en-US')}`;

  const fmtNum = (n: number | string | null | undefined) =>
    n == null || n === '' ? '' : Number(n).toLocaleString('en-US');

  const fmtSqft = (n: number | string | null | undefined) => {
    const v = fmtNum(n);
    return v ? `${v} ft²` : '';
  };

  const fmtYear = (v: string | null | undefined) =>
    v ? String(v).replace(/\.0+$/, '') : '';

  const title = p.marketingName || p.name || '';
  const fullAddress = [p.address, p.city, p.state, p.zipCode]
    .filter(Boolean)
    .join(', ');
  const propertyType = (p.propertyType || '').split(';')[0].trim();
  const isLease = (p.listingType || '').toLowerCase().includes('lease');

  return {
    title,
    address: p.address || '',
    city: p.city || '',
    state: p.state || '',
    zip: p.zipCode || '',
    full_address: fullAddress,
    listing_type: p.listingType || '',
    property_type: propertyType,
    price: fmtPrice(p.price),
    price_label: isLease ? 'Lease Rate' : 'Asking Price',
    building_sqft: fmtSqft(p.buildingSqft),
    lot_sqft: fmtSqft(p.lotSqft),
    units: p.units || '',
    year_built: fmtYear(p.yearBuilt),
    zoning: p.zoning || '',
    description: p.description || '',
    pricing_notes: p.pricing || '',
    // Static brand fields — change once if/when the brand updates
    brand_name: 'FAUSTO COMMERCIAL',
    brand_phone: '(305) 431-2258',
    brand_address: '1761 W Flagler St, Miami, FL 33135',
    brand_url: 'FaustoCommercial.com',
    generated_date: new Date().toLocaleDateString('en-US'),
  };
}

/**
 * Render a template by replacing {{tag}} occurrences. Empty tags collapse to ''.
 * HTML-escapes by default — if a template ever needs raw HTML in a tag, mark
 * with {{{tag}}} (triple-brace, mustache convention) and we won't escape.
 */
export function renderTemplate(template: string, tags: FlyerTags): string {
  // Triple-brace = raw (no escape)
  template = template.replace(/\{\{\{(\w+)\}\}\}/g, (_, name) => tags[name] ?? '');
  // Double-brace = escaped
  return template.replace(/\{\{(\w+)\}\}/g, (_, name) => htmlEscape(tags[name] ?? ''));
}

function htmlEscape(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * Default skeleton template using the merge-tag set above.
 * Replace this whole string with the marketing team's HTML — keep tag names
 * intact so the data binding still works.
 */
export const DEFAULT_FLYER_TEMPLATE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>{{title}} — {{brand_name}}</title>
  <style>
    @page { size: Letter; margin: 0.4in; }
    * { box-sizing: border-box; }
    body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #1a2332; margin: 0; padding: 0; }
    .flyer { padding: 0.4in; max-width: 8.5in; margin: 0 auto; }
    .header { display: flex; justify-content: space-between; align-items: flex-end;
      border-bottom: 3px solid #c9a961; padding-bottom: 16px; margin-bottom: 24px; }
    .brand { font-family: Georgia, serif; font-size: 24px; font-weight: bold; color: #1a2332; }
    .listing-type { font-size: 11px; letter-spacing: 4px; text-transform: uppercase;
      color: #c9a961; font-weight: bold; }
    h1 { font-family: Georgia, serif; font-size: 32px; margin: 8px 0 8px 0; color: #1a2332; }
    .address { font-size: 14px; color: #64748b; margin-bottom: 24px; }
    .price-row { display: flex; justify-content: space-between; align-items: baseline;
      background: #1a2332; color: #fff; padding: 14px 20px; border-radius: 4px; margin-bottom: 24px; }
    .price { font-family: Georgia, serif; font-size: 28px; font-weight: bold; color: #c9a961; }
    .price-label { font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: #cadcfc; }
    .specs { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
    .spec { border-left: 2px solid #c9a961; padding-left: 10px; }
    .spec-label { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: #64748b; }
    .spec-value { font-size: 16px; font-weight: bold; color: #1a2332; }
    .description { font-size: 13px; line-height: 1.5; color: #1a2332; white-space: pre-wrap; }
    .footer { border-top: 1px solid #e5e1d8; padding-top: 12px; margin-top: 24px;
      font-size: 10px; color: #64748b; display: flex; justify-content: space-between; }
  </style>
</head>
<body>
  <div class="flyer">

    <div class="header">
      <div class="brand">{{brand_name}}</div>
      <div class="listing-type">{{listing_type}}</div>
    </div>

    <h1>{{title}}</h1>
    <div class="address">{{full_address}}</div>

    <div class="price-row">
      <div class="price-label">{{price_label}}</div>
      <div class="price">{{price}}</div>
    </div>

    <div class="specs">
      <div class="spec"><div class="spec-label">Type</div><div class="spec-value">{{property_type}}</div></div>
      <div class="spec"><div class="spec-label">Building</div><div class="spec-value">{{building_sqft}}</div></div>
      <div class="spec"><div class="spec-label">Lot</div><div class="spec-value">{{lot_sqft}}</div></div>
      <div class="spec"><div class="spec-label">Units</div><div class="spec-value">{{units}}</div></div>
      <div class="spec"><div class="spec-label">Year Built</div><div class="spec-value">{{year_built}}</div></div>
      <div class="spec"><div class="spec-label">Zoning</div><div class="spec-value">{{zoning}}</div></div>
    </div>

    <div class="description">{{description}}</div>

    <div class="footer">
      <div>{{brand_url}}  ·  {{brand_address}}  ·  {{brand_phone}}</div>
      <div>Generated {{generated_date}}</div>
    </div>

  </div>
</body>
</html>`;

/**
 * Builds the flyer HTML from a Property record.
 *
 * Marketing flow: replace DEFAULT_FLYER_TEMPLATE with their HTML; same tags.
 */
export function buildFlyerHtml(
  p: SFPropertyForSync,
  template: string = DEFAULT_FLYER_TEMPLATE
): string {
  const tags = propertyToTags(p);
  return renderTemplate(template, tags);
}

// ---------------------------------------------------------------------------
// PDF rendering — PICK ONE BACKEND BEFORE PRODUCTION
// ---------------------------------------------------------------------------

interface PdfResult {
  ok: boolean;
  buffer?: Buffer;
  error?: string;
}

async function renderPdfFromHtml(html: string): Promise<PdfResult> {
  const pdfshiftKey = process.env.PDFSHIFT_API_KEY;
  if (pdfshiftKey) {
    return renderPdfViaPdfShift(html, pdfshiftKey);
  }

  // No backend configured — return a clear error so the caller can fall back
  // to HTML preview during development.
  return {
    ok: false,
    error:
      'No PDF backend configured. Set PDFSHIFT_API_KEY or wire Puppeteer in src/integrations/flyer.ts.',
  };
}

/** PDFShift backend — see https://docs.pdfshift.io */
async function renderPdfViaPdfShift(
  html: string,
  apiKey: string
): Promise<PdfResult> {
  const res = await fetch('https://api.pdfshift.io/v3/convert/pdf', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${Buffer.from(`api:${apiKey}`).toString('base64')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      source: html,
      format: 'Letter',
      margin: '0.4in',
      sandbox: process.env.NODE_ENV !== 'production',
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, error: `PDFShift ${res.status}: ${err.slice(0, 300)}` };
  }
  const buf = Buffer.from(await res.arrayBuffer());
  return { ok: true, buffer: buf };
}
