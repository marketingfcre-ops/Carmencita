# Fausto Commercial — "Carmencita" AI Phone Attendant & Salesforce Platform
## System Documentation & Project Handover

This document describes the complete system built for Fausto Commercial: a real-time AI
phone attendant ("Carmencita") and the Salesforce, website, marketing, and operations
platform built around it. It is written for two readers — a **business owner** who wants
to understand what was built, and a **technical successor** who needs to operate or
extend it.

---

## What this system is (in one minute)

A caller dials the business line and speaks naturally with an AI receptionist. In
real time, the system transcribes their speech, understands what property or area they're
asking about — even in vague or mixed English/Spanish terms — looks it up in Salesforce,
answers in a natural voice, and can **text or email** them the listing and flyer before
they hang up. Every call becomes a structured lead in Salesforce. Around that core sit a
full Salesforce lead-security system, a Salesforce↔website sync, marketing list
automation, automated backups, and an admin dashboard.

It is not a chatbot bolted onto a phone line. It is a low-latency voice system
(~1–1.5s to first words) with genuine domain intelligence about commercial real estate
and Miami geography, plus a production data and security layer underneath.

## Architecture at a glance

```
                         ┌─────────── Salesforce (leads, listings, agents, access) ───────────┐
                         │                                                                     │
  Caller → Twilio ──► WebSocket (/stream) ──► Deepgram STT ──► Claude (Haiku 4.5) ──► sentence │
                         ▲                                          │  split → ElevenLabs TTS  │
                         │                                          │         → back to Twilio │
                         └──────────────── voice reply ────────────┘                          │
                                                                                              │
   Outbound: Twilio SMS + Resend email (listing link / flyer PDF)                             │
   Sync:     Salesforce ⇄ WordPress (listings) · Salesforce → Campaign Monitor (email lists)  │
   Ops:      server-side SF automation · automated backups → Cloudflare R2 · admin dashboard  │
                                                                                              │
                         └──────────────────────────────────────────────────────────────────┘
```

**Stack:** Node + TypeScript, Fastify (HTTP + WebSocket), deployed on Railway.
**Voice:** Twilio Media Streams · Deepgram STT · Claude Haiku 4.5 · ElevenLabs TTS.
**Data/Integrations:** Salesforce (Professional Edition) · WordPress (Cloudways) ·
Campaign Monitor · Resend (email) · Cloudflare R2 (backups).

> ⚠️ **Doc-vs-code note:** the repo's `CLAUDE.md` says "Deepgram TTS," but the live code
> uses **ElevenLabs** for text-to-speech (`src/tts.ts`). Code is the source of truth.

## Table of contents

| # | Section | What it covers |
|---|---|---|
| 01 | [Voice call pipeline](01-voice-pipeline.md) | Real-time STT→Claude→TTS pipeline, barge-in, turn-taking, the assistant's tools, bilingual handling |
| 02 | [Search & geographic intelligence](02-intelligence-search-geo.md) | The "smart" layer: sqft↔acres, neighborhood/grid inference, proximity, fuzzy matching |
| 03 | [Salesforce security & sync](03-salesforce-security-sync.md) | Lead-access model (groups, assignments, the access Flow), OAuth client, agent review, SF→WP trigger |
| 04 | [SF automation, backups & ops](04-sf-automation-backups-ops.md) | Server-side LLA reconcile + notify, automated R2 backups, the ops/script library |
| 05 | [WordPress & marketing](05-wordpress-marketing.md) | SF→WP listing sync, publish/unpublish, Campaign Monitor lists, make.com (external) |
| 06 | [SMS, email & consent](06-sms-email-consent.md) | A2P consent flow, SMS link/flyer delivery, email capture, Resend |
| 07 | [Admin dashboard, architecture & env vars](07-admin-framework-deploy.md) | Admin dash, the framework structure, Railway deploy, **full env-var inventory** |
| 08 | [Handover & operations](08-handover-operations.md) | Accounts, transfer steps, ownership — *(business/IP; keep separate from the client-hosted copy)* |

## What was built — scope summary (for the owner)

- A **production AI phone receptionist** handling live calls with sub-2-second responses,
  in English and Spanish, with real estate and Miami-geography intelligence.
- A complete **Salesforce lead-security system**: agents edit only their assigned lists,
  exports locked down, multi-list-per-lead with an admin approval workflow, owner-bypass,
  change history, and a ~100,000-lead data cleanup/migration to make it all function.
- **Salesforce ⇄ Website sync** so listing changes (including price) flow automatically,
  and listings come down when marked Closed Won/Lost.
- **Marketing automation** — contacts synced to Campaign Monitor with lists by lead intent.
- **Texting and email delivery** of listings and flyers, fully A2P-compliant.
- **Automated daily + monthly backups** of the entire Salesforce database, off-site.
- An **admin dashboard** and a reusable **operations toolkit** (~140 scripts).

## Cross-cutting findings the next operator must know

These surfaced during documentation and matter for operation/handover:

1. **Two WordPress Code Snippets live outside this repo** (the custom `/fausto/v1/...`
   endpoints) and are **not backed up anywhere.** Preserve them — the SF→WP sync depends
   on them. (See §05.)
2. **Admin dashboard default key is public** (`ADMIN_KEY`, default `fausto2026`) and
   `/debug` is unauthenticated. Set a real `ADMIN_KEY` and lock `/debug` for production.
   (See §07.)
3. **Call logs are ephemeral** — stored in `/tmp/call-logs` and lost on every redeploy.
   Persisting them is unbuilt. (See §07.)
4. **Feature flags have differing on/off polarity** (`EMAIL_ENABLED`, `LLA_RECONCILE_ENABLED`,
   `LLA_NOTIFY_ENABLED` default OFF). (See §04, §06, §07.)
5. **TTS is ElevenLabs**, not Deepgram — it's a live account to transfer. (See §01, §08.)
6. Minor: backup-size figures differ between `scripts/backup/README.md` and the code
   comment; the measured real number is ~51 MB gzipped per backup. (See §04.)
