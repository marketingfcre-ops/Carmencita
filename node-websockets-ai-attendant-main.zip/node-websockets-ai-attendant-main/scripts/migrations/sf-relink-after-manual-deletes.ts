/**
 * Re-link 7 SF records to their canonical WP post after the user manually
 * deleted our duplicate drafts.
 *
 * Context: WP duplicate audit surfaced ~13 cases where our April-import +
 * May-recovery work created a NEW draft when an older marketing-curated
 * WP post already existed for the same property. The user reviewed each,
 * deleted our duplicates directly in WP admin. Now we need to re-point
 * SF.WP_Post_ID__c at the surviving canonical so the link isn't dangling.
 *
 * Also updates Public_URL__c to the canonical's permalink.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-relink-after-manual-deletes.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-relink-after-manual-deletes.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface ReassignOp {
  sfId: string;
  label: string;
  oldDeletedWp: number; // safety: SF should currently point here
  newCanonicalWp: number;
}

const OPS: ReassignOp[] = [
  // First batch (already run — kept for audit trail, but the safety gate will
  // skip them since SF no longer points at the deleted IDs):
  // { sfId: 'a0RJw000008GiznMAC', oldDeletedWp: 48972, newCanonicalWp: 23313, label: '440 sw 8 st' },
  // { sfId: 'a0RJw000008Gj1NMAS', oldDeletedWp: 48974, newCanonicalWp: 23371, label: '229 NW 22nd Ave' },
  // { sfId: 'a0RJw000008GlftMAC', oldDeletedWp: 48988, newCanonicalWp: 23302, label: '2597 SW 37th Ave' },
  // { sfId: 'a0RJw000008GlfvMAC', oldDeletedWp: 48989, newCanonicalWp: 23328, label: '2051 NW 112th Ave' },
  // { sfId: 'a0RJw000008GmaSMAS', oldDeletedWp: 63209, newCanonicalWp: 23177, label: '2310 nw 150 st' },
  // { sfId: 'a0RJw000008tQGbMAM', oldDeletedWp: 63438, newCanonicalWp: 48591, label: '2306 Van Buren St' },
  // { sfId: 'a0RJw0000098W0jMAE', oldDeletedWp: 63445, newCanonicalWp: 23475, label: '1812 Coolidge St' },

  // Second batch (5 — the user deleted these in a second round):
  { sfId: 'a0RJw000008GiwXMAS', label: '7030 NW 2nd Court (Closed Lost) → Prime Development Opportunity Little Haiti', oldDeletedWp: 48971, newCanonicalWp: 19814 },
  { sfId: 'a0RJw000008GkGpMAK', label: '4020 NW 30th Ter → Turnkey Investment 4-Unit Lauderdale Lakes', oldDeletedWp: 48978, newCanonicalWp: 22513 },
  { sfId: 'a0RJw000008GlkjMAC', label: '3204 NE 9th St → Renovated 10-Unit Pompano Beach', oldDeletedWp: 48992, newCanonicalWp: 22214 },
  { sfId: 'a0RJw000008GmIhMAK', label: '4831/4861/4871 W Flagler St → 34 Unit Multifamily/Motel', oldDeletedWp: 49019, newCanonicalWp: 23045 },
  { sfId: 'a0RJw000008GmNRMA0', label: '900 Palm Ave → 13,400 SF Auto Lot', oldDeletedWp: 49021, newCanonicalWp: 19708 },
];

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true } as const;
  return { ok: false as const, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true } as const;
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false as const, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false as const, error: lastError };
  }
  return { ok: false as const, error: lastError };
}

async function getWpLink(wpId: number): Promise<string | null> {
  const res = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}?context=edit&_fields=link`, { headers: { Authorization: WP_AUTH } });
  if (!res.ok) return null;
  const data = (await res.json()) as { link?: string };
  return data.link || null;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log(`\n🔗 Re-link 7 SF records after manual WP deletions ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();

  // Safety check
  console.log('── Verifying SF state ──\n');
  const sfRecs = await sfQuery<{ Id: string; WP_Post_ID__c: number | null }>(
    token,
    instance,
    `SELECT Id, WP_Post_ID__c FROM Property__c WHERE Id IN ('${OPS.map(o => o.sfId).join("','")}')`
  );
  const sfById = new Map(sfRecs.map(r => [r.Id, r]));

  let driftCount = 0;
  for (const op of OPS) {
    const sf = sfById.get(op.sfId);
    if (!sf) {
      console.error(`   ❌ ${op.sfId} not found`);
      process.exit(1);
    }
    if (sf.WP_Post_ID__c !== op.oldDeletedWp) {
      console.warn(`   ⚠️  ${op.sfId} expected WP=${op.oldDeletedWp} but found ${sf.WP_Post_ID__c}`);
      driftCount++;
    }
  }
  if (driftCount > 0 && !DRY_RUN) {
    console.error('\n   Drift detected — aborting. Re-investigate before running.');
    process.exit(1);
  }
  if (driftCount === 0) {
    console.log(`   ✓ All ${OPS.length} records confirmed pointing at expected (deleted) WP IDs.\n`);
  }

  // Pre-fetch permalinks for new canonicals
  console.log('── Fetching new canonical permalinks ──\n');
  const newLinks = new Map<number, string>();
  for (const op of OPS) {
    const link = await getWpLink(op.newCanonicalWp);
    if (!link) {
      console.error(`   ❌ wp:${op.newCanonicalWp} not fetchable — aborting`);
      process.exit(1);
    }
    newLinks.set(op.newCanonicalWp, link);
  }
  console.log(`   ✓ All ${newLinks.size} permalinks fetched.\n`);

  console.log('── Plan ──\n');
  for (const op of OPS) {
    console.log(`SF ${op.sfId}  ${op.label}`);
    console.log(`   WP_Post_ID__c: ${op.oldDeletedWp} (deleted)  →  ${op.newCanonicalWp}`);
    console.log(`   Public_URL__c: → ${newLinks.get(op.newCanonicalWp)}`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('── Executing ──\n');
  let ok = 0;
  let err = 0;
  for (const op of OPS) {
    const result = await sfUpdateWithRetry(token, instance, op.sfId, {
      WP_Post_ID__c: op.newCanonicalWp,
      Public_URL__c: newLinks.get(op.newCanonicalWp),
    });
    if (result.ok) {
      console.log(`   ✓ ${op.sfId} → wp:${op.newCanonicalWp}`);
      ok++;
    } else {
      console.warn(`   ❌ ${op.sfId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Re-linked:  ${ok} / ${OPS.length}`);
  console.log(`Failures:   ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
