# Operational Scripts

Tools that live outside the running server. Day-to-day SF→WP sync runs in
`src/webhooks/salesforce.ts`; these scripts are for setup, migration, testing,
and audit.

```
scripts/
├── setup/        ← idempotent, re-runnable. Run during initial dev-org setup
│                   or to refresh a sandbox.
├── migrations/   ← one-time data moves. Historical record once executed.
├── tests/        ← smoke tests, regression coverage, diagnostics.
└── audit/        ← read-only inspection / analytics reports.
```

## setup/ — re-runnable initialization

| Script | What it does |
|---|---|
| `seed-dev-org.ts` | Create custom fields + sample data in a fresh Dev org |
| `seed-dev-validation-rule.ts` | Deploy `Group_Edit_Restriction` validation rule + assign integration user to a group |
| `setup-test-agent.ts` | Set test-agent-001's `Group_ID__c` and print sample leads (in/out group) for the demo |
| `copy-prod-sample-to-dev.ts` | Copy ~25 groups, ~100 leads, ~30 properties from prod to Dev for agent-realistic testing |

## migrations/ — one-time data moves

| Script | What it does |
|---|---|
| `migrate-group-to-list-assignments.ts` | `Lead.Group__c` → `Lead_List_Assignment__c` junction records (Status='Approved') |
| `backfill-wp-post-ids.ts` | Populate `Property__c.WP_Post_ID__c` from existing `Public_URL__c` slugs |
| `cm-import.ts` | Bulk-import SF leads into Campaign Monitor lists |
| `sf-import-leads.ts` | Bulk-import leads into SF |

## tests/ — smoke + diagnostics + regression

| Script | What it does |
|---|---|
| `smoke-sf-to-wp.ts` | End-to-end test against one Property record |
| `test-flow-trigger.ts` | Trigger a Property change in Dev to fire the SF Flow |
| `test-validation-rule.ts` | Apex `@isTest` — non-admin BLOCKED on cross-group edit |
| `test-validation-rule-positive.ts` | Apex `@isTest` — non-admin ALLOWED on same-group edit |
| `test-closed-won-lost.ts` | Property → Closed Won → Closed Lost → Active cycle |
| `debug-validation-rule.ts` | Print actual field values + Apex anonymous eval |

## audit/ — read-only reports

| Script | What it does |
|---|---|
| `cm-discover.ts` | Inspect Campaign Monitor lists/segments |
| `cm-audit.ts` | Audit CM subscribers vs SF leads |
| `marketing-90-day-review.ts` | 90-day listing & marketing-material analytics report |
| `generate_audit_reports.py` | Property data-gap analysis (legacy Python) |

## How to run

```bash
# Format: tsx --env-file .env.local scripts/<folder>/<script>.ts
tsx --env-file .env.local scripts/setup/setup-test-agent.ts
tsx --env-file .env.local scripts/tests/smoke-sf-to-wp.ts
tsx --env-file .env.local scripts/migrations/backfill-wp-post-ids.ts --dry-run
```

## Architecture notes

- **Production sync runs in the server**, not in scripts. SF Flows post to
  `/webhooks/salesforce/event`; `src/handlers/sf-property-changed.ts` does the
  WP work. Scripts here are for setup, backfill, testing, and reporting only.
- **WP custom endpoints** (installed as Code Snippets in WordPress):
  - `POST /wp-json/fausto/v1/property-meta/{id}` — write Houzez `fave_*` meta
  - `GET  /wp-json/fausto/v1/push/{id}` — read property + meta in clean format
- **Houzez taxonomy term IDs** for `property_status`, `property_type`,
  `property_city`, `property_state` live in
  `src/integrations/wordpress-mappings.ts`.
- **Dev → Prod target switching** is automatic at the webhook layer based on
  which secret was sent (`SF_WEBHOOK_SECRET` vs `SF_DEV_WEBHOOK_SECRET`).
