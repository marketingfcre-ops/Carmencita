/**
 * Agent request workflow for Lead_List_Assignment__c.
 *
 * Goal: agents can REQUEST a lead-to-group assignment (Status=Pending);
 * Nathalie or another admin approves by editing Status to Approved.
 *
 * Three changes:
 *   1. Grant Account for Agents profile CREATE on Lead_List_Assignment__c
 *      (they already have Read). Add ObjectPermissions row.
 *
 *   2. FLS: Approved_By__c and Approved_Date__c are read-only for agents
 *      (they can see who approved + when, but can't fake an approval).
 *      Note: Status__c can't have FLS PATCHed via API because SF rejects
 *      FieldPermissions on required picklist fields. Instead we use a
 *      Validation Rule (next step) to enforce agents can only save with
 *      Status=Pending.
 *
 *   3. Validation Rule: block agents from saving with Status != Pending.
 *      Admins (System Administrator profile) bypass.
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const ACCOUNT_FOR_AGENTS_PPS = '0PSJw000000502bOAA';

async function toolingCreate(sf: SfClient, sobject: string, body: any) {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`POST ${sobject} → ${res.status}: ${text.slice(0, 500)}`);
  return JSON.parse(text);
}

async function restPost(sf: SfClient, path: string, body: any) {
  const url = `${sf.instance}/services/data/v59.0${path}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`POST ${path} → ${res.status}: ${text.slice(0, 500)}`);
  return JSON.parse(text);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected. ${DRY ? 'DRY-RUN' : 'APPLY'}\n`);

  // ============================================================
  // 1. Grant CREATE on Lead_List_Assignment__c for Account for Agents
  // ============================================================
  console.log('=== (1) Grant Create on Lead_List_Assignment__c ===');
  const existing: any[] = await (sf as any).soql(
    `SELECT Id, PermissionsRead, PermissionsCreate FROM ObjectPermissions
     WHERE ParentId = '${ACCOUNT_FOR_AGENTS_PPS}' AND SobjectType = 'Lead_List_Assignment__c'`
  );
  if (existing.length && existing[0].PermissionsCreate) {
    console.log('  ✓ Already has Create — skip');
  } else if (existing.length) {
    console.log(`  Found existing row ${existing[0].Id}. Updating Create=true.`);
    if (!DRY) {
      const url = `${sf.instance}/services/data/v59.0/sobjects/ObjectPermissions/${existing[0].Id}`;
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ PermissionsRead: true, PermissionsCreate: true }),
      });
      if (!res.ok) console.log(`  ✗ PATCH failed: ${await res.text()}`);
      else console.log(`  ✓ Updated existing ObjectPermissions row`);
    }
  } else {
    console.log('  Plan: CREATE ObjectPermissions (Read+Create)');
    if (!DRY) {
      const r = await restPost(sf, '/sobjects/ObjectPermissions/', {
        ParentId: ACCOUNT_FOR_AGENTS_PPS,
        SobjectType: 'Lead_List_Assignment__c',
        PermissionsRead: true,
        PermissionsCreate: true,
        PermissionsEdit: false,
        PermissionsDelete: false,
      });
      console.log(`  ✓ Created: ${JSON.stringify(r)}`);
    }
  }

  // ============================================================
  // 2. FLS on Approved_By__c and Approved_Date__c — Read=true, Edit=false
  // ============================================================
  console.log('\n=== (2) FLS — Approved_By / Approved_Date read-only for agents ===');
  // These should already have Read=true from earlier tonight's work; we want
  // to ensure Edit=false. If row exists, PATCH it; otherwise create.
  for (const field of ['Lead_List_Assignment__c.Approved_By__c', 'Lead_List_Assignment__c.Approved_Date__c']) {
    const fp: any[] = await (sf as any).soql(
      `SELECT Id, PermissionsRead, PermissionsEdit FROM FieldPermissions
       WHERE ParentId = '${ACCOUNT_FOR_AGENTS_PPS}' AND Field = '${field}'`
    );
    if (fp.length) {
      const row = fp[0];
      if (row.PermissionsRead && !row.PermissionsEdit) {
        console.log(`  ✓ ${field} already Read-only`);
        continue;
      }
      console.log(`  ${field} → PATCH to Read=true, Edit=false`);
      if (!DRY) {
        const url = `${sf.instance}/services/data/v59.0/sobjects/FieldPermissions/${row.Id}`;
        const res = await fetch(url, {
          method: 'PATCH',
          headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ PermissionsRead: true, PermissionsEdit: false }),
        });
        if (!res.ok) console.log(`    ✗ ${await res.text()}`);
        else console.log(`    ✓ Updated`);
      }
    } else {
      console.log(`  ${field} → CREATE Read=true, Edit=false`);
      if (!DRY) {
        try {
          const r = await restPost(sf, '/sobjects/FieldPermissions/', {
            ParentId: ACCOUNT_FOR_AGENTS_PPS,
            SobjectType: 'Lead_List_Assignment__c',
            Field: field,
            PermissionsRead: true,
            PermissionsEdit: false,
          });
          console.log(`    ✓ Created: ${JSON.stringify(r)}`);
        } catch (e: any) {
          console.log(`    ✗ ${e.message?.slice(0, 200)}`);
        }
      }
    }
  }

  // ============================================================
  // 3. Validation Rule — block agents from setting Status != Pending
  // ============================================================
  console.log('\n=== (3) Validation Rule — block agents from non-Pending status ===');
  // Check if it already exists
  const vrs: any[] = await (sf as any).toolingQuery(
    `SELECT Id, ValidationName, Active FROM ValidationRule
     WHERE EntityDefinition.QualifiedApiName = 'Lead_List_Assignment__c'
       AND ValidationName = 'Agents_Can_Only_Set_Pending'`
  );
  if (vrs.length) {
    console.log(`  ✓ Validation rule already exists: ${vrs[0].Id}  Active=${vrs[0].Active}`);
  } else {
    console.log(`  Plan: CREATE ValidationRule "Agents_Can_Only_Set_Pending"`);
    if (!DRY) {
      const body = {
        FullName: 'Lead_List_Assignment__c.Agents_Can_Only_Set_Pending',
        Metadata: {
          active: true,
          description: 'Account for Agents profile users can only save Lead List Assignment records with Status = Pending. Admins (System Administrator profile) bypass and can set Approved directly.',
          errorConditionFormula: "AND( $Profile.Name = 'Account for Agents', TEXT(Status__c) <> 'Pending' )",
          errorDisplayField: 'Status__c',
          errorMessage: 'Agents can only request assignments as Pending. An admin will approve.',
        },
      };
      try {
        const r = await toolingCreate(sf, 'ValidationRule', body);
        console.log(`  ✓ Created: ${JSON.stringify(r)}`);
      } catch (e: any) {
        console.log(`  ✗ ${e.message?.slice(0, 500)}`);
      }
    }
  }

  console.log('\nDone.');
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
