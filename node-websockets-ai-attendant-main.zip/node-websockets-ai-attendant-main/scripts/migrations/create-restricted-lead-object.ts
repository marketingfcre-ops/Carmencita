/**
 * Create the Restricted_Lead__c custom object + core fields via the Metadata API.
 *
 * The Tooling API can't create a CustomObject (it has no FullName column for that
 * entity), so this uses the SOAP Metadata API createMetadata() call — one shot for
 * the object + all fields. Additive + isolated: can't affect existing data or the
 * live phone service. Reversible (delete in Setup or via deleteMetadata).
 *
 * Dry-run by default; pass --execute to create.
 * Does NOT create: Restricted_List__c (wait for final list names), the sharing
 * Flow, the permission set, or the migration. See docs/restricted-leads-plan.md.
 *
 *   npx tsx --env-file .env.local scripts/migrations/create-restricted-lead-object.ts            # dry-run
 *   npx tsx --env-file .env.local scripts/migrations/create-restricted-lead-object.ts --execute  # create
 */

import { sfClient } from '../../src/integrations/sf-client';

const EXECUTE = process.argv.includes('--execute');
const API = '59.0';

const FIELDS: { fullName: string; label: string; type: string; length?: number; required?: boolean }[] = [
  { fullName: 'First_Name__c', label: 'First Name', type: 'Text', length: 40 },
  { fullName: 'Last_Name__c', label: 'Last Name', type: 'Text', length: 80, required: true },
  { fullName: 'Company__c', label: 'Company', type: 'Text', length: 255 },
  { fullName: 'Phone__c', label: 'Phone', type: 'Phone' },
  { fullName: 'Mobile__c', label: 'Mobile', type: 'Phone' },
  { fullName: 'Email__c', label: 'Email', type: 'Email' },
  { fullName: 'Property__c', label: 'Property', type: 'Text', length: 255 },
  { fullName: 'Prospecting_Notes__c', label: 'Prospecting Notes', type: 'LongTextArea', length: 32768 },
  { fullName: 'Owning_Entity_LLC_Name__c', label: 'Owning Entity / LLC Name', type: 'Text', length: 255 },
  { fullName: 'Source_Lead_Id__c', label: 'Source Lead Id', type: 'Text', length: 18 },
];
const STATUS_VALUES = ['Open', 'Contacted', 'On Hold', 'Unqualified', 'Closed'];

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function fieldXml(f: typeof FIELDS[number]): string {
  const parts = [`<fullName>${f.fullName}</fullName>`, `<label>${esc(f.label)}</label>`, `<type>${f.type}</type>`];
  if (f.type === 'Text') parts.push(`<length>${f.length}</length>`);
  if (f.type === 'LongTextArea') parts.push(`<length>${f.length}</length>`, `<visibleLines>5</visibleLines>`);
  if (f.required) parts.push(`<required>true</required>`);
  return `<fields>${parts.join('')}</fields>`;
}

function statusFieldXml(): string {
  const values = STATUS_VALUES.map(
    (v) => `<value><fullName>${esc(v)}</fullName><default>${v === 'Open'}</default><label>${esc(v)}</label></value>`
  ).join('');
  return `<fields><fullName>Status__c</fullName><label>Status</label><type>Picklist</type>` +
    `<valueSet><valueSetDefinition><sorted>false</sorted>${values}</valueSetDefinition></valueSet></fields>`;
}

function envelope(sessionId: string): string {
  const fields = FIELDS.map(fieldXml).join('') + statusFieldXml();
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns="http://soap.sforce.com/2006/04/metadata">
 <soapenv:Header><SessionHeader><sessionId>${sessionId}</sessionId></SessionHeader></soapenv:Header>
 <soapenv:Body>
  <createMetadata>
   <metadata xsi:type="CustomObject" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <fullName>Restricted_Lead__c</fullName>
    <label>Restricted Lead</label>
    <pluralLabel>Restricted Leads</pluralLabel>
    <nameField><type>AutoNumber</type><label>Restricted Lead ID</label><displayFormat>RL-{00000}</displayFormat></nameField>
    <deploymentStatus>Deployed</deploymentStatus>
    <sharingModel>Private</sharingModel>
    <enableActivities>true</enableActivities>
    <enableReports>true</enableReports>
    ${fields}
   </metadata>
  </createMetadata>
 </soapenv:Body>
</soapenv:Envelope>`;
}

async function main() {
  const sf = (await sfClient('prod')) as any;

  console.log(`\n🏗  Restricted_Lead__c — ${EXECUTE ? 'EXECUTE (Metadata API)' : 'DRY-RUN'}`);
  console.log('Object: Private OWD, Auto-Number RL-{00000}');
  console.log(`Fields: ${FIELDS.map((f) => f.fullName).join(', ')}, Status__c`);

  if (!EXECUTE) {
    console.log('\n(dry-run — re-run with --execute. See docs/restricted-leads-plan.md)\n');
    return;
  }

  const url = `${sf.instance}/services/Soap/m/${API}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'text/xml; charset=UTF-8', SOAPAction: '""' },
    body: envelope(sf.token),
  });
  const text = await res.text();
  // Pull out the result bits from the SOAP response.
  const success = /<success>true<\/success>/.test(text);
  const errMatch = text.match(/<errors>[\s\S]*?<message>([\s\S]*?)<\/message>[\s\S]*?<\/errors>/);
  const faultMatch = text.match(/<faultstring>([\s\S]*?)<\/faultstring>/);

  if (success) {
    console.log(`\n   ✓ Restricted_Lead__c created (object + ${FIELDS.length + 1} fields).`);
    console.log('   Next: permission set (grant ct@ View/Modify All) + Lightning Record Page (UI) +');
    console.log('         verify Flow→__Share + Restricted_List__c + migration.\n');
  } else {
    console.log(`\n   ✗ Not created. ${faultMatch ? 'Fault: ' + faultMatch[1] : ''}${errMatch ? 'Error: ' + errMatch[1] : ''}`);
    console.log('   (HTTP ' + res.status + ') — raw response head:\n' + text.slice(0, 600) + '\n');
    process.exit(1);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
