/**
 * Grant per-group User_Group_Access__c rows. For partnership scenarios where
 * an agent works on another agent's group leads.
 *
 *   - Ben Kunzle    → LHT Land Robin   (partnership with Robin Perez)
 *   - Kodiak Fields → Wynwood Norte    (helping Robin Perez on Lapidus lead)
 *
 * Idempotent. Dry-run by default. Pass --apply to commit.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const GRANTS: { user: string; group: string }[] = [
  { user: 'Benjamin Kunzle', group: 'LHT Land Robin' },
  { user: 'Kodiak Fields',   group: 'Wynwood Norte' },
  // Added 2026-06-05 after audit: Gio partners with Ashleen on Flagami Com
  // leads. Canonical is "Flagami Com" (with space), not "FlagamiCom".
  // No grandfathering bug — Gio owns 0 leads in Flagami Com.
  { user: 'Giovanni Bertolotti', group: 'Flagami Com' },
];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  for (const g of GRANTS) {
    const u: any[] = await sf.soql(
      `SELECT Id, Name, IsActive FROM User WHERE Name = '${g.user}' LIMIT 5`
    );
    if (u.length !== 1 || !u[0].IsActive) {
      console.log(`✗ ${g.user}: not found or inactive — skipping`);
      continue;
    }
    const grp: any[] = await sf.soql(
      `SELECT Id, Name FROM Group__c WHERE Name = '${g.group}' LIMIT 5`
    );
    if (grp.length !== 1) {
      console.log(`✗ Group "${g.group}": ${grp.length} matches — skipping`);
      continue;
    }
    const existing: any[] = await sf.soql(
      `SELECT Id, Status__c FROM User_Group_Access__c WHERE User__c = '${u[0].Id}' AND Group__c = '${grp[0].Id}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) {
      console.log(`✓ ${g.user} already has Approved access to "${g.group}". Skip.`);
      continue;
    }
    console.log(`  Plan: ${g.user} → "${g.group}"`);
    if (DRY) continue;
    const id = await sf.create('User_Group_Access__c', {
      User__c: u[0].Id,
      Group__c: grp[0].Id,
      Status__c: 'Approved',
    });
    console.log(`    ✓ Created User_Group_Access__c ${id}`);
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
