/**
 * SMS consent state — A2P/10DLC compliance.
 *
 * Tracks per-phone opt-in state for the double-opt-in flow:
 *   - pending:   Caller verbally agreed; we sent a "Reply YES to confirm" SMS
 *                and are waiting for confirmation.
 *   - confirmed: Caller replied YES (or replied to a HELP/OTHER message after
 *                opting in). Marketing SMS may be sent.
 *   - opted_out: Caller replied STOP at any point. No further SMS allowed
 *                until they explicitly text START.
 *
 * Persisted to sms-consent.json on a Railway volume (RAILWAY_VOLUME_MOUNT_PATH)
 * so consent + opt-outs survive redeploys; falls back to local data/ for dev.
 */

import * as fs from 'fs';
import * as path from 'path';

export type ConsentStatus = 'pending' | 'confirmed' | 'opted_out';

export interface ConsentRecord {
  phone: string; // E.164
  status: ConsentStatus;
  updatedAt: string; // ISO
  source: 'verbal_during_call' | 'inbound_yes' | 'inbound_stop' | 'inbound_start';
  // Properties queued for SMS, delivered on YES. A deduped list so a caller can
  // ask about several before opting in and get them all on one YES.
  pendingProperties?: { propertyId: string; propertyName: string; propertyAddress: string; publicUrl: string | null }[];
  pendingExpiresAt?: string; // ISO — queued SMS only fires before this
  // Flyer-by-email: the properties to email when the caller replies with their
  // email address. Accumulates across the call (deduped) so one reply delivers
  // every flyer they asked about. Set when we text them; consumed by EMAIL inbound.
  flyerProperties?: { propertyId: string; propertyName: string }[];
  flyerExpiresAt?: string; // ISO
  // When we last TEXTED the caller asking for their email. Used to dedupe
  // back-to-back text_for_email calls WITHOUT suppressing a fresh request
  // (the pending list above is also set passively by property texts).
  flyerPromptedAt?: string; // ISO
}

// Persist to a Railway volume when one is attached (RAILWAY_VOLUME_MOUNT_PATH is
// set automatically) so consent + opt-outs survive redeploys. Falls back to the
// local data/ dir for development. Override with CONSENT_STORE_DIR if needed.
const STORE_DIR =
  process.env.CONSENT_STORE_DIR ||
  process.env.RAILWAY_VOLUME_MOUNT_PATH ||
  path.join(__dirname, '..', 'data');
const STORE_PATH = path.join(STORE_DIR, 'sms-consent.json');
const PENDING_TTL_MS = 10 * 60 * 1000; // 10 minutes
const FLYER_TTL_MS = 30 * 60 * 1000; // 30 minutes — caller needs time to reply with email
const FLYER_PROMPT_DEDUP_MS = 2 * 60 * 1000; // only dedupe back-to-back prompts within 2 min

let store: Record<string, ConsentRecord> = {};
let loaded = false;

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      store = JSON.parse(raw);
    }
  } catch (err) {
    console.warn('⚠️ sms-consent: failed to load store, starting empty:', err);
    store = {};
  }
}

function persist(): void {
  try {
    fs.mkdirSync(STORE_DIR, { recursive: true });
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2));
  } catch (err) {
    console.error('❌ sms-consent: failed to persist:', err);
  }
}

function normalize(phone: string): string {
  return phone.trim();
}

export function getConsent(phone: string): ConsentRecord | null {
  load();
  return store[normalize(phone)] || null;
}

export function isConfirmed(phone: string): boolean {
  return getConsent(phone)?.status === 'confirmed';
}

export function isOptedOut(phone: string): boolean {
  return getConsent(phone)?.status === 'opted_out';
}

/** Append a property to the YES-gated SMS queue (deduped), refreshing the window. */
export function addPendingProperty(
  phone: string,
  property: {
    propertyId: string;
    propertyName: string;
    propertyAddress: string;
    publicUrl: string | null;
  }
): ConsentRecord {
  load();
  const key = normalize(phone);
  const existing = store[key];
  // If already opted out, don't move back to pending without explicit START.
  if (existing?.status === 'opted_out') return existing;

  const list = (existing?.pendingProperties || []).filter((p) => p.propertyId !== property.propertyId);
  list.push(property);
  const rec: ConsentRecord = {
    phone: key,
    status: existing?.status === 'confirmed' ? 'confirmed' : 'pending',
    updatedAt: new Date().toISOString(),
    source: 'verbal_during_call',
    pendingProperties: list,
    pendingExpiresAt: new Date(Date.now() + PENDING_TTL_MS).toISOString(),
  };
  store[key] = rec;
  persist();
  return rec;
}

export function setConfirmed(phone: string): ConsentRecord {
  load();
  const key = normalize(phone);
  const existing = store[key];
  const rec: ConsentRecord = {
    ...(existing || { phone: key, source: 'inbound_yes' }),
    phone: key,
    status: 'confirmed',
    updatedAt: new Date().toISOString(),
    source: 'inbound_yes',
  };
  store[key] = rec;
  persist();
  return rec;
}

export function setOptedOut(phone: string): ConsentRecord {
  load();
  const key = normalize(phone);
  const rec: ConsentRecord = {
    phone: key,
    status: 'opted_out',
    updatedAt: new Date().toISOString(),
    source: 'inbound_stop',
  };
  // Drop any queued property — they explicitly said no.
  store[key] = rec;
  persist();
  return rec;
}

export function setReSubscribed(phone: string): ConsentRecord {
  // START / UNSTOP clears the opt-out but does NOT confirm consent on its own.
  // The caller still needs a fresh pending → confirm cycle for a new SMS to fire.
  load();
  const key = normalize(phone);
  const rec: ConsentRecord = {
    phone: key,
    status: 'pending',
    updatedAt: new Date().toISOString(),
    source: 'inbound_start',
  };
  store[key] = rec;
  persist();
  return rec;
}

/** Return the queued SMS properties if still in-window, else []. */
export function getPendingProperties(
  phone: string
): { propertyId: string; propertyName: string; propertyAddress: string; publicUrl: string | null }[] {
  load();
  const rec = store[normalize(phone)];
  if (!rec?.pendingProperties?.length || !rec.pendingExpiresAt) return [];
  if (new Date(rec.pendingExpiresAt).getTime() < Date.now()) {
    clearPending(phone);
    return [];
  }
  return rec.pendingProperties;
}

export function clearPending(phone: string): void {
  load();
  const key = normalize(phone);
  const rec = store[key];
  if (!rec) return;
  delete rec.pendingProperties;
  delete rec.pendingExpiresAt;
  persist();
}

// ---------------------------------------------------------------------------
// Flyer-by-email pending — remembers which property to email when the caller
// replies to a text with their email address. Separate from the YES/SMS queue.
// ---------------------------------------------------------------------------

/** Append a property to the flyer-email queue (deduped), refreshing the window. */
export function addFlyerPending(
  phone: string,
  property: { propertyId: string; propertyName: string }
): void {
  load();
  const key = normalize(phone);
  const existing = store[key];
  if (existing?.status === 'opted_out') return; // never resurrect an opt-out
  const list = (existing?.flyerProperties || []).filter((p) => p.propertyId !== property.propertyId);
  list.push({ propertyId: property.propertyId, propertyName: property.propertyName });
  const rec: ConsentRecord = {
    ...(existing || { phone: key, status: 'pending', updatedAt: new Date().toISOString(), source: 'verbal_during_call' }),
    phone: key,
    flyerProperties: list,
    flyerExpiresAt: new Date(Date.now() + FLYER_TTL_MS).toISOString(),
  };
  store[key] = rec;
  persist();
}

/** Return the queued flyer properties if still in-window, else []. */
export function getFlyerPending(phone: string): { propertyId: string; propertyName: string }[] {
  load();
  const rec = store[normalize(phone)];
  if (!rec?.flyerProperties?.length || !rec.flyerExpiresAt) return [];
  if (new Date(rec.flyerExpiresAt).getTime() < Date.now()) {
    clearFlyerPending(phone);
    return [];
  }
  return rec.flyerProperties;
}

export function clearFlyerPending(phone: string): void {
  load();
  const rec = store[normalize(phone)];
  if (!rec) return;
  delete rec.flyerProperties;
  delete rec.flyerExpiresAt;
  delete rec.flyerPromptedAt;
  persist();
}

/** Record that we just texted the caller asking for their email. */
export function markFlyerPrompted(phone: string): void {
  load();
  const key = normalize(phone);
  const rec = store[key];
  if (!rec) return;
  rec.flyerPromptedAt = new Date().toISOString();
  persist();
}

/** Did we text a flyer-email prompt very recently (so don't send another)? */
export function wasRecentlyFlyerPrompted(phone: string): boolean {
  load();
  const rec = store[normalize(phone)];
  if (!rec?.flyerPromptedAt) return false;
  return Date.now() - new Date(rec.flyerPromptedAt).getTime() < FLYER_PROMPT_DEDUP_MS;
}
