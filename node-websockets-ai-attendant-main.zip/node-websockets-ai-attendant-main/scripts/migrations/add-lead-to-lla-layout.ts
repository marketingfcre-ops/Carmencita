/**
 * Add Lead__c lookup to the Lead_List_Assignment__c page layout.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const LAYOUT_ID = '00hJw000005JJk1IAG';

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH → ${res.status}: ${await res.text()}`);
}

const newItem = (field: string, behavior: string) => ({
  analyticsCloudComponent: null, behavior, canvas: null, component: null,
  customLink: null, emptySpace: null, field, height: null, page: null,
  reportChartComponent: null, scontrol: null, showLabel: null, showScrollbars: null, width: null,
});

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected. ${DRY ? 'DRY-RUN' : 'APPLY'}\n`);
  const full: any = await toolingGet(sf, 'Layout', LAYOUT_ID);
  const meta = full.Metadata || {};
  const sections = meta.layoutSections || [];

  let leadPresent = false;
  for (const s of sections) for (const c of s.layoutColumns || []) for (const it of c.layoutItems || []) {
    if (it.field === 'Lead__c') leadPresent = true;
  }
  console.log(`Lead__c present: ${leadPresent}`);
  if (leadPresent) { console.log('Nothing to do.'); return; }

  const infoIdx = sections.findIndex((s: any) => /information/i.test(s.label || ''));
  if (infoIdx === -1) { console.log('No Information section'); return; }

  const newSections = sections.map((s: any, i: number) => {
    if (i !== infoIdx) return s;
    const cols = s.layoutColumns || [];
    const newCols = cols.map((col: any, ci: number) => {
      if (ci !== 0) return col;
      // Insert Lead__c at TOP (above Group)
      return { ...col, layoutItems: [newItem('Lead__c', 'Required'), ...(col.layoutItems || [])] };
    });
    return { ...s, layoutColumns: newCols };
  });

  if (DRY) { console.log('Would PATCH'); return; }
  await toolingPatch(sf, 'Layout', LAYOUT_ID, { Metadata: { layoutSections: newSections } });
  console.log('✓ PATCH succeeded');
}
main().catch(e=>{console.error('💀',e);process.exit(1);});
