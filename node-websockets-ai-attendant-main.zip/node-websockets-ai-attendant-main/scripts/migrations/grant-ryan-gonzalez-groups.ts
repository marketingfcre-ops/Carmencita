/**
 * Grant Ryan Gonzalez Approved access to 16 groups. Idempotent.
 * Case-insensitive group name match — the source list has weird casing.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const USER_NAME = 'Ryan Gonzalez';
const GROUPS = [
  'NorthMultiFamily',
  'FlagamiApts',
  'VicenteRolodex',
  'NewFlagami',
  'FLAGAMI SOUTH',
  'HomesteadMultifamily',
  'MIAMI BEACH',
  'GablesMulti',
  'JRLitHaitiWyn',
  'SelfStorage',
  'OVERTOWN MULTIFAMILY',
  'NOBE',
  'ShenandoahApts',
  'CFM Big MF',
  'Bigmf',
  'GroveRIN',
];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // User
  const u: any[] = await sf.soql(
    `SELECT Id, Name, IsActive FROM User WHERE Name = '${USER_NAME}' AND IsActive = true LIMIT 5`
  );
  if (u.length !== 1) {
    console.error(`✗ ${USER_NAME}: ${u.length} match(es) — abort`);
    for (const x of u) console.log(`  ${x.Id}  active=${x.IsActive}`);
    process.exit(1);
  }
  const userId = u[0].Id;
  console.log(`User: ${userId}  ${u[0].Name}\n`);

  // Pull all groups (case-insensitive lookup)
  const allGroups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const byLower = new Map<string, any>();
  for (const g of allGroups) byLower.set(g.Name.toLowerCase().trim(), g);

  // Resolve each requested group
  type Plan = { requested: string; resolved?: any; status?: string; existingId?: string };
  const plans: Plan[] = [];
  for (const name of GROUPS) {
    const found = byLower.get(name.toLowerCase().trim());
    plans.push({ requested: name, resolved: found });
  }

  // Check existing access for the resolved groups
  const resolvedIds = plans.filter(p => p.resolved).map(p => p.resolved.Id);
  const existing: any[] = resolvedIds.length
    ? await sf.soql(
      `SELECT Id, Group__c, Status__c FROM User_Group_Access__c
       WHERE User__c = '${userId}' AND Group__c IN (${resolvedIds.map(i => `'${i}'`).join(',')})`
    )
    : [];
  const existingByGroup = new Map(existing.map((r: any) => [r.Group__c, r]));
  for (const p of plans) {
    if (!p.resolved) continue;
    const e = existingByGroup.get(p.resolved.Id);
    if (e) { p.status = e.Status__c; p.existingId = e.Id; }
  }

  // Report
  console.log('=== Plan ===');
  let toCreate = 0, alreadyOk = 0, notFound = 0;
  for (const p of plans) {
    if (!p.resolved) {
      console.log(`  NOT FOUND       "${p.requested}"`);
      notFound++;
      continue;
    }
    if (p.status === 'Approved') {
      console.log(`  ALREADY APPROVED  "${p.resolved.Name}"`);
      alreadyOk++;
      continue;
    }
    if (p.status) {
      console.log(`  EXISTS as ${p.status}  "${p.resolved.Name}"  (would upgrade to Approved if we PATCH)`);
      continue;
    }
    console.log(`  CREATE           "${p.resolved.Name}"  (id=${p.resolved.Id})`);
    toCreate++;
  }
  console.log(`\nSummary: create=${toCreate}  alreadyApproved=${alreadyOk}  notFound=${notFound}`);

  if (DRY) { console.log('\nDry-run. Re-run with --apply.'); return; }

  // Apply
  console.log('\n=== Apply ===');
  let created = 0, failed = 0;
  for (const p of plans) {
    if (!p.resolved || p.status === 'Approved') continue;
    try {
      const id = await sf.create('User_Group_Access__c', {
        User__c: userId,
        Group__c: p.resolved.Id,
        Status__c: 'Approved',
      });
      console.log(`  ✓ ${p.resolved.Name.padEnd(24)} → ${id}`);
      created++;
    } catch (e: any) {
      console.log(`  ✗ ${p.resolved.Name}: ${e.message?.slice(0, 200)}`);
      failed++;
    }
  }
  console.log(`\nCreated: ${created}  Failed: ${failed}  Not found: ${notFound}`);
  if (notFound) console.log('\nNot-found names (may need new Group__c records or different spelling):');
  for (const p of plans) if (!p.resolved) console.log(`  "${p.requested}"`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
