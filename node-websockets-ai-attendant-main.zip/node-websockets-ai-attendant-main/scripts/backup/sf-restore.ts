/**
 * Download a Salesforce backup from S3 storage to local disk (for the restore
 * drill or an actual recovery). It only RETRIEVES + decompresses — it never
 * writes back to Salesforce. Re-import is a deliberate, manual step (jsforce /
 * Data Loader / a targeted script), because a blind bulk re-insert would create
 * duplicates and is never what you want in a real incident.
 *
 * Usage:
 *   # list available backups
 *   npx tsx --env-file .env.local scripts/backup/sf-restore.ts --list
 *
 *   # download one backup (prefix as shown by --list) into ./restore/<stamp>/
 *   npx tsx --env-file .env.local scripts/backup/sf-restore.ts --get daily/2026-06-27T08-00-00-000Z
 *
 * Env: same BACKUP_S3_* as sf-backup.ts.
 */

import { gunzipSync } from 'zlib';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import {
  S3Client,
  ListObjectsV2Command,
  GetObjectCommand,
} from '@aws-sdk/client-s3';

const args = process.argv.slice(2);

function s3(): { client: S3Client; bucket: string } {
  for (const k of [
    'BACKUP_S3_ENDPOINT', 'BACKUP_S3_REGION', 'BACKUP_S3_BUCKET',
    'BACKUP_S3_ACCESS_KEY_ID', 'BACKUP_S3_SECRET_ACCESS_KEY',
  ]) {
    if (!process.env[k]) throw new Error(`Missing env var: ${k}`);
  }
  return {
    client: new S3Client({
      endpoint: process.env.BACKUP_S3_ENDPOINT,
      region: process.env.BACKUP_S3_REGION,
      credentials: {
        accessKeyId: process.env.BACKUP_S3_ACCESS_KEY_ID!,
        secretAccessKey: process.env.BACKUP_S3_SECRET_ACCESS_KEY!,
      },
      forcePathStyle: true,
    }),
    bucket: process.env.BACKUP_S3_BUCKET!,
  };
}

async function list(client: S3Client, bucket: string) {
  for (const tier of ['daily/', 'monthly/']) {
    const res = await client.send(
      new ListObjectsV2Command({ Bucket: bucket, Prefix: tier, Delimiter: '/' })
    );
    const folders = (res.CommonPrefixes || []).map((p) => p.Prefix!).sort();
    console.log(`\n${tier}  (${folders.length})`);
    for (const f of folders) console.log(`  ${f.replace(/\/$/, '')}`);
  }
  console.log('');
}

async function get(client: S3Client, bucket: string, prefix: string) {
  const clean = prefix.replace(/\/$/, '') + '/';
  const listed = await client.send(
    new ListObjectsV2Command({ Bucket: bucket, Prefix: clean })
  );
  const keys = (listed.Contents || []).map((o) => o.Key!).filter(Boolean);
  if (!keys.length) throw new Error(`No objects under ${clean}`);

  const outDir = join(process.cwd(), 'restore', clean.replace(/\//g, '_').replace(/_$/, ''));
  await mkdir(outDir, { recursive: true });
  console.log(`\n⬇️  ${keys.length} files → ${outDir}\n`);

  for (const key of keys) {
    const res = await client.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
    const buf = Buffer.from(await res.Body!.transformToByteArray());
    const name = key.slice(clean.length);
    const isGz = name.endsWith('.gz');
    const body = isGz ? gunzipSync(buf) : buf;
    const outName = isGz ? name.replace(/\.gz$/, '') : name;
    await writeFile(join(outDir, outName), body);
    console.log(`   ✓ ${outName.padEnd(38)} ${(body.length / 1e6).toFixed(2)} MB`);
  }
  console.log(`\n✅ restored to ${outDir}\n`);
}

async function main() {
  const { client, bucket } = s3();
  if (args.includes('--list')) return list(client, bucket);
  const prefix = args[args.indexOf('--get') + 1];
  if (args.includes('--get') && prefix) return get(client, bucket, prefix);
  console.log('Usage: --list  |  --get <tier>/<stamp>');
}

main().catch((e) => {
  console.error('Restore failed:', e);
  process.exit(1);
});
