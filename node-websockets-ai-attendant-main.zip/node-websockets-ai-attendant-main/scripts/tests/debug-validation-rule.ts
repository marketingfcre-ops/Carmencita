/**
 * Debug what $User.Group_ID__c and Lead.Group__c actually evaluate to in
 * formula context when the validation rule runs.
 *
 * Run: tsx --env-file .env.local scripts/debug-validation-rule.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = await sfClient('dev');

  const users = await sf.soql<{ Id: string; Username: string; Group_ID__c: string }>(
    `SELECT Id, Username, Group_ID__c FROM User WHERE Username = 'test-agent-001@27colab.com.dev'`
  );
  const testUser = users[0];
  console.log(`User Group_ID__c (database): ${JSON.stringify(testUser.Group_ID__c)}`);
  console.log(`Length: ${testUser.Group_ID__c?.length}`);
  console.log();

  const leads = await sf.soql<{ Id: string; Group__c: string }>(
    `SELECT Id, Group__c FROM Lead WHERE Group__c = '${testUser.Group_ID__c}' LIMIT 1`
  );
  console.log(`Lead Group__c (database): ${JSON.stringify(leads[0].Group__c)}`);
  console.log(`Length: ${leads[0].Group__c?.length}`);
  console.log();

  // Use Apex anonymous to inspect what's seen at runtime
  const apex = `
User u = [SELECT Id, Group_ID__c FROM User WHERE Id = '${testUser.Id}'];
System.debug('User.Group_ID__c=[' + u.Group_ID__c + ']  len=' + (u.Group_ID__c == null ? 0 : u.Group_ID__c.length()));

Lead l = [SELECT Id, Group__c FROM Lead WHERE Id = '${leads[0].Id}'];
System.debug('Lead.Group__c=[' + l.Group__c + ']  len=' + (l.Group__c == null ? 0 : String.valueOf(l.Group__c).length()));

System.debug('Equal? ' + (String.valueOf(l.Group__c) == u.Group_ID__c));
System.debug('CASESAFEID equal? ' + (String.valueOf(l.Group__c).left(15) == u.Group_ID__c.left(15)));
`;

  const url = `${sf.instance}/services/data/v59.0/tooling/executeAnonymous?anonymousBody=${encodeURIComponent(apex)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  const result = await res.json();
  console.log('Apex anonymous result:');
  console.log(JSON.stringify(result, null, 2));

  // Get the debug log
  const logsUrl = `${sf.instance}/services/data/v59.0/tooling/query?q=${encodeURIComponent(`SELECT Id, LogUserId, Operation, StartTime FROM ApexLog ORDER BY StartTime DESC LIMIT 1`)}`;
  const logsRes = await fetch(logsUrl, { headers: { Authorization: `Bearer ${sf.token}` } });
  const logs = (await logsRes.json()) as { records: { Id: string }[] };

  if (logs.records.length > 0) {
    console.log(`\nFetching debug log ${logs.records[0].Id}...`);
    const logBodyUrl = `${sf.instance}/services/data/v59.0/tooling/sobjects/ApexLog/${logs.records[0].Id}/Body`;
    const logBody = await fetch(logBodyUrl, { headers: { Authorization: `Bearer ${sf.token}` } });
    const text = await logBody.text();
    const debugLines = text.split('\n').filter((l) => l.includes('USER_DEBUG'));
    console.log(debugLines.join('\n'));
  }
}

main().catch((err) => {
  console.error('Crashed:', err);
  process.exit(1);
});
