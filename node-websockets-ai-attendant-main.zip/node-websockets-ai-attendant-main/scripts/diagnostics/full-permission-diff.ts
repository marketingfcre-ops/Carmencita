import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // 1. Carlos's permsets vs Bobby's
  console.log('=== Permission Set Assignments ===');
  const psas: any[] = await sf.soql(
    `SELECT Assignee.Name, PermissionSet.Name, PermissionSet.Label, PermissionSet.IsOwnedByProfile
     FROM PermissionSetAssignment
     WHERE Assignee.Name IN ('Carlos Fausto Miranda','Bobby Berrido','Reinier Moya','Nathalie Aguirre','Halain Suarez')
     ORDER BY Assignee.Name, PermissionSet.Label`
  );
  const byUser = new Map<string, string[]>();
  for (const r of psas) {
    const u = r.Assignee?.Name || '?';
    if (!byUser.has(u)) byUser.set(u, []);
    const tag = r.PermissionSet?.IsOwnedByProfile ? '(profile PPS)' : '';
    byUser.get(u)!.push(`${r.PermissionSet?.Label} ${tag}`);
  }
  for (const [u, sets] of byUser.entries()) {
    console.log(`\n${u}: ${sets.length} permsets`);
    for (const s of sets) console.log(`  ${s}`);
  }

  // 2. Diff ALL Permissions* fields on Sysadmin vs AfA
  console.log('\n\n=== Permission flag diff: Sysadmin vs Account for Agents ===');
  const desc: any = await sf.describe('Profile');
  const permFields = (desc.fields || []).filter((f: any) => f.name.startsWith('Permissions'));
  console.log(`Total Permission fields: ${permFields.length}`);
  const fieldList = permFields.map((f:any)=>f.name).join(',');
  const profs: any[] = await sf.soql(
    `SELECT Name, ${fieldList} FROM Profile WHERE Name IN ('System Administrator','Account for Agents')`
  );
  const sysadmin = profs.find(p => p.Name === 'System Administrator');
  const agents = profs.find(p => p.Name === 'Account for Agents');
  const differences: string[] = [];
  for (const f of permFields) {
    const s = sysadmin[f.name];
    const a = agents[f.name];
    if (s !== a) differences.push(`  ${f.name.padEnd(60)}  sysadmin=${s}  agents=${a}`);
  }
  console.log(`\nDifferences (${differences.length}):`);
  for (const d of differences) console.log(d);
}
main().catch(e=>{console.error(e);process.exit(1);});
