/**
 * Trigger the Property Sync to WordPress Flow by updating a property in Dev.
 * Useful for verifying end-to-end without navigating Dev UI.
 *
 * Run: tsx --env-file .env.local scripts/test-flow-trigger.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const dev = await sfClient('dev');
  // Use any property — pick the most recently modified
  const props = await dev.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Property__c ORDER BY LastModifiedDate DESC LIMIT 1`
  );
  if (props.length === 0) {
    console.error('No properties in Dev');
    process.exit(1);
  }
  // Toggle Price__c — exercises a different branch of the OR condition than Status
  const cur = await dev.retrieve<{ Price__c: number | null }>('Property__c', props[0].Id);
  const newPrice = (cur.Price__c ?? 1000000) + 1;
  console.log(`Updating ${props[0].Name} (${props[0].Id}): Price ${cur.Price__c} → ${newPrice}`);
  await dev.update('Property__c', props[0].Id, {
    Price__c: newPrice,
  });
  console.log('✅ Update sent. Flow should fire within seconds.');
}

main().catch((err) => {
  console.error('Crashed:', err);
  process.exit(1);
});
