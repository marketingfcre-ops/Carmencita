# Salesforce MFA Setup — Agents (Salesforce Authenticator App)

**Who:** all agents.
**Deadline:** **July 20, 2026.**
**Method:** any MFA method — the **Salesforce Authenticator app** is the easiest
(free, takes ~3 minutes).

## One-time setup (3 steps, ~3 minutes)

### 1. Install the app

On your phone, install **Salesforce Authenticator**:
- iPhone: App Store → search "Salesforce Authenticator"
- Android: Google Play → search "Salesforce Authenticator"

Open it and tap through to the screen showing a **two-word phrase** (e.g.
"music indigo"). Leave the app open.

### 2. Connect it to your account

1. On a computer, log in to Salesforce.
2. Click your **avatar** (top right) → **Settings**.
3. In Quick Find, search **"Advanced User Details"** → open it.
4. Find **App Registration: Salesforce Authenticator** → click **Connect**.
5. Salesforce shows a **two-word phrase**. Type that phrase into the app on your
   phone and tap **Connect**.

### 3. Approve

The app will ask you to **approve** the connection — tap **Approve**. Done.

## From now on

When you log in, the app sends a notification to your phone — just tap
**Approve**. (You can even enable location-based auto-approve from your usual
spots so it's one less tap.)

## No smartphone?

You can use SMS text codes instead — tell Nathalie and we'll set that up.

## Questions

Contact Nathalie. We'll hold a short Q&A session before July 20.
