# Lead Groups — Update & Go-Live Check

Hi Fausto,

Quick update on the lead groups.

**What we found & fixed:** the group data was a mess — the same list was being typed dozens of different ways (for example, "Little Havana Apartments" existed as 11 different spellings). That's why access rules could never work reliably. We consolidated every spelling into one clean group and linked all ~100,000 leads correctly. **Nothing was deleted** — agent-specific lists were kept exactly as they were.

**Where it stands:** 456 clean groups · ~100,000 leads linked · 51 active agents mapped to the lists they work.

**The switch:** with this fixed, we can turn on edit protection — each agent can only **edit** leads in their own groups (everyone can still **see** everything). It's a simple on/off switch. If anyone says they're wrongly blocked, you turn it off instantly:
**Setup → Flows → "Lead Group Access Check" → Deactivate.**

We checked it — no active agent gets blocked by turning it on. (A few old lists from agents who've left have no active owner; admins can still edit those, and we'll assign them to whoever you choose.)

**Do you want us to flip it on?**

Below: **(1)** the groups before & after, and **(2)** who's assigned to what.

---

# Part 1 — Groups: before & after


_Generated live from Salesforce. Each original spelling is shown under the single group where its leads actually live; stray legacy tags are not counted._

**456 groups total** · 100,273 leads linked · 71 groups cleaned up from spelling variants · 130 kept exactly as-is.


## 1. Cleaned up — spelling variants consolidated into one group

| Original spellings | Now (one group) | Leads |
|---|---|---:|
| VicenteRolodex, VicentePRolodex | **VicenteRolodex** | 4,001 |
| DORALINDUSTRIAL, DORAL INDUSTRIAL | **Doral Industrial** | 3,055 |
| LItHavApt, LItHavApts, LitHavAptHavApt, LitHavApt; BVM | **LittleHavanaApt** | 2,796 |
| PompanoBeach MF, PompanoMultiFam | **PompanoMultiFam** | 2,177 |
| SOUThMiamiAlberto, SOUthMiamiAlbertoU, SurDevRet | **SouthMiami** | 1,839 |
| SouthBrowardRetail, South Broward Retail | **SouthBrowardRetail** | 1,756 |
| FLAGAMICOM, Flagami Com, Flagami Commercial | **Flagami Com** | 1,654 |
| Hialeah Com, HialeahCom | **HialeahCom** | 1,510 |
| Design North | **DesignDist North** | 1,496 |
| SOUTHRETAIL, SouthMiamiAlberto, SouthMiamiOffices, RETAILSOUTH | **SouthRetail** | 1,347 |
| FTLApts, FTL Apts | **FTLApts** | 1,179 |
| SOUTHMIAMIIND | **SouthMiaInd** | 1,109 |
| FLAgamiAPTS, Flagami APTS, FlagamiApt | **Flagami Apts** | 1,099 |
| LIBCITYCOM, Libcity.com, LibCityCom; BVM | **LibCityCom** | 1,065 |
| NM Retail | **NoMiamiRetail** | 1,045 |
| MIAMI BEACH, Surfside | **Miami Beach** | 1,018 |
| RoadsShehnSilverApts, RoadsShehnSilverApt | **RoadsShehnSilverApts** | 982 |
| OpaLockaInd, OpaLockaInd; BVM, OpaLocka Ind | **OpaLockaInd** | 914 |
| HiaApts, HialeahApt | **HialeahApt** | 913 |
| HiaRetail | **HialeahRetail** | 888 |
| JRLitHaitiWyn, JRLitHaitiWyn;WWNAPT, JRLitHaitiWyn(Jorge) | **JRLitHaitiWyn** | 814 |
| HiaGarden, HIAGARDENS | **HiaGardens** | 814 |
| SouthBrowardApts, SouthBrowardApt | **SouthBrowardApt** | 684 |
| CID, CID; BVM | **CID** | 664 |
| FTL Industrial | **FTLInd** | 636 |
| NorthMiaApts, NoMiApts, NoMiaApts | **NorthMiaApts** | 632 |
| LITTLEHAITICORRIDORS, LittleaitiCorridors | **LittleHaitiCorridor** | 632 |
| CORALWAY, Coralwaycom, Coral Way MF | **CoralWay** | 606 |
| Homestead FL, HOMESTEAD | **Homestead** | 573 |
| LITHAVCOM, Little Havana Com, LittleHavanaCom, LilHavanacom, LitHavCom; BVM | **LittleHavanaCom** | 530 |
| CivCen, Civic Center | **CivCen** | 525 |
| NorthMultiFamily, NorthMultiFamily;BVM | **NorthMultiFamily** | 428 |
| SW&WC, SWEETINDUSTRIAL | **SW&WC** | 415 |
| WESTchersterCom, WESTCHESTERCOM | **WestchesterCom** | 398 |
| LitHat, LITTLEHAVANA, LIttle Havana, LittleHav, LitHav, LittHav _(+1 more)_ | **LittleHavana** | 383 |
| MIAMIBEACHCOMM | **MiamiBeachCom** | 363 |
| LibertyCityApts | **LibCityApt** | 307 |
| SMiaMulti, SOUTH MIAMIMULTIFAMI | **SouthMiamiMF** | 269 |
| NewFlagami, NEW FLAGAMI, NEW FAGAMI | **NewFlagami** | 263 |
| BIRDROAD COM, Bird RD | **BirdRoadCom** | 210 |
| GAS STATIONS, GAS STATION, GasStation | **GasStation** | 206 |
| NoMia Land, NM Land | **NorthMiaLand** | 172 |
| Overtown C | **OvertownComm** | 169 |
| HIAGardens Warehouse | **HiaGardensWare** | 160 |
| Allapattah; BVM, Allapattah | **Allapattah; BVM** | 111 |
| NoMiWrhse | **NorthMiaWrhse** | 97 |
| VACANT LAND, VACANT LAND; BVM | **Vacant Land** | 95 |
| LIBERTY Multifamily, Liberty Multi | **LibCityMF** | 85 |
| WestchesterRetail, Westchester Retail, WestchersterRetail | **WestchesterRetail** | 77 |
| Little Haiti, Robin LH | **LittleHaiti** | 65 |
| JJ, joshuas buyer | **Joshua Jimenez** | 53 |
| Pickle/Padel, Pickle Paddle | **Pickle/Padel** | 48 |
| COLLIERGAS, COLLIER GAS | **Collier Gas** | 47 |
| LITTLE RIVER, RIVER | **LittleRiver** | 38 |
| HiaGarden Warehouse | **HiaGardenWare** | 35 |
| exp listing | **Expired** | 24 |
| West Little River, West Little River Pa | **West Little River** | 23 |
| Opa LockaMultifamily | **OpaLockaMF** | 20 |
| preforeclosure, tax delinquent | **Distressed** | 19 |
| INSTITUCIONAL | **Institutional** | 18 |
| flagamiapts, Flagami Apt | **FlagamiApts** | 16 |
| West Little Havana | **Little HavanaWest** | 16 |
| Miami Gardens Multif | **Miami Gardens MF** | 15 |
| Tammysbuyers, Tammys Buyers | **TammysBuyers** | 12 |
| LitHavCom | **LittleHavanaCom** | 12 |
| allapattah multifamy | **AllapattahMF** | 12 |
| lil haiti multifam | **LittleHaitiMF** | 10 |
| Liberty City Comm | **LibertyCityCom** | 7 |
| LitHavLand | **LittleHavanaLand** | 6 |
| TAM AIRPOR WAREHOUSE | **AirportWarehouse** | 6 |
| SOUTH RETAIL | **SouthMiamiRetail** | 5 |

## 2. Kept exactly as-is — agent-specific / preserved groups

| Group | Leads |
|---|---:|
| BrowardMulti | 3,607 |
| FTL NE Ind | 2,898 |
| BrowardShopping | 2,739 |
| US1-Grovecom | 2,063 |
| Hollywood33020Resi | 1,543 |
| EastSide | 1,437 |
| CoralGablesCom | 1,408 |
| Allapattah | 1,346 |
| Doral HG&M&MS Retail | 1,335 |
| BobbyRetail | 1,229 |
| FTL MF East | 1,220 |
| JaxDwnTwnRet | 1,218 |
| EdgewaterOmniWyn | 1,146 |
| SouthBrowardInd | 1,107 |
| WestSideJax | 1,090 |
| W Fort Lauderdale MF | 1,049 |
| UniPrkSwtwtrSoDoral | 1,031 |
| DaniaMulti | 1,026 |
| HollywoodRetail | 998 |
| Hallandale MultiFam | 995 |
| NOBE | 988 |
| PlantationCom | 982 |
| DaniaIndustrial | 978 |
| The Roads | 965 |
| HollywoodApt33023_4 | 896 |
| LHT Land Robin | 884 |
| NoEastFlaHotel | 860 |
| LiquorKing | 852 |
| SURDEVRET | 805 |
| AllapattahMF | 804 |
| WestchesterWRetail | 787 |
| MiamiBeachRetail | 772 |
| Medley | 669 |
| JaxDwtwnSpring | 664 |
| CoralSpringsMF | 663 |
| VicenteLitHaiti | 656 |
| OaklandParkInd | 642 |
| HallandaleRetail | 629 |
| AirWest | 626 |
| NEMiamiRetail | 604 |
| SouthBrowardApt33020 | 580 |
| DeerfieldApts | 578 |
| Broward Gas | 533 |
| Broward MF 33021 | 523 |
| MiamiOfficesSouth | 500 |
| CoralTerrace | 500 |
| OrangeGas | 443 |
| GablesMulti | 439 |
| PalmBeachGas | 399 |
| Wynwood Norte | 350 |
| EHia | 343 |
| Name Brand Retailers | 329 |
| GroveRIN | 327 |
| HomesteadMultifamily | 301 |
| HillsboroughGas | 281 |
| NMB Land | 267 |
| LeeGas | 265 |
| WarehousesSouth | 236 |
| OvertownMultifamily | 209 |
| Big Game MF | 169 |
| Hialeah Gardens | 158 |
| ShenandoahApts | 140 |
| CalleOcho | 137 |
| Retail Leasing Leads | 114 |
| Overtown | 92 |
| Edgewater | 91 |
| MOBILE_HOMES | 82 |
| WWNAPT | 65 |
| MonroeGas | 62 |
| HendryGas | 58 |
| Bigmf | 50 |
| CivApts | 49 |
| Fausto | 40 |
| Westchester | 39 |
| US1 | 34 |
| SelfStorage | 34 |
| BirdroadRetail | 32 |
| Buyer broker | 31 |
| Big MF list | 30 |
| South Developers | 28 |
| Wynwood | 28 |
| Flagami South | 27 |
| DadeHotelMotel | 26 |
| EHia Industrial | 25 |
| 27 Ave | 23 |
| Upper east side | 20 |
| Miami Gardens Retail | 20 |

_Plus 43 smaller preserved groups (under 20 leads each, 429 leads total)._


---

# Part 2 — Agent → group assignments


_From Salesforce `User_Group_Access__c`. These are the groups each agent is allowed to edit once protection is on._

**51 agents · 764 assignments (active agents only).**

| Agent | # Groups | Groups |
|---|---:|---|
| Adam Hauptman | 10 | Broward Gas, BrowardMulti, Brownsville, FTLApts, HallandaleRetail, HollywoodRetail, NOBE, SouthBrowardApt, SouthBrowardInd, SouthBrowardRetail |
| Adir Bezalely | 4 | DaniaMulti, FTLApts, LakeWorthApt, PompanoMultiFam |
| Anne Mairura | 4 | MiamiBeachCom, MiamiBeachCom, MiamiBeachRetail, NNN Kodiak |
| Aria Fleming | 4 | JaxDwtwnSpring, NoEastFlaHotel, StAugustineOffice, WestSideJax |
| Ariel Levi | 3 | CoralSpringsMF, DeerfieldApts, SouthBrowardRetail |
| Armando Mercado | 2 | Doral Industrial, NorthMiaLand |
| Armando Sanchez-Bueno | 2 | AirWest, Doral Industrial |
| Arun Mohan | 5 | BrowardMulti, FTL MF East, HallandaleRetail, HollywoodRetail, PompanoMultiFam |
| Ashleen Cruz | 25 | BirdRoadCom, CoralGablesCom, CoralWay, DadeHotelMotel, Doral HG&M&MS Retail, Flagami, Flagami Apts, Flagami Com, LittleHavanaCom, NewFlagami, Other, QUAILROOST, ShenandoahApts, SouthMiami, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, UniPrkSwtwtrSoDoral, US1-Grovecom, WarehousesSouth, Westchester, WestchesterCom, WestchesterRetail, WestchesterWRetail |
| Avigail Gayer | 2 | BrowardShopping, Group |
| Ben Fernandez | 5 | Allapattah, BEN'S BUYERS, SouthMiaInd, SOUThMiamiAlberto, SouthMiamiInd |
| Benjamin Kunzle | 4 | EastSide, JRLitHaitiWyn, n/a, na |
| Bobby Berrido | 48 | AirWest, BirdRoadCom, BirdroadRetail, Bobby, BobbyRetail, BrevardGas, Broward Gas, CID, Collier Gas, CoralGables, CoralGablesOffice, CoralWay, Dade County, Doral, Doral Industrial, EHia, Flagami Apts, Flagami Com, GablesMulti, GasStation, HendryGas, HiaGardens, HiaGardenWare, Hialeah Gardens, HillsboroughGas, Homestead, LeeGas, LittleHavanaApt, LittleRiver, Medley, MIMO, MonroeGas, NewFlagami, OrangeGas, Other, PalmBeachGas, SouthBrowardRetail, SouthMiaInd, SouthMiami, StLucieGas, Unincorporated Dade, US1, WarehousesSouth, West Little River, WestchesterCom, WestchesterRetail, Wynwood, Wynwood Norte |
| Carlos A Temperan | 1 | Allapattah |
| Carlos Fausto Miranda | 82 | 203202, 305) 357-4700, 71st Ind, a, Allapattah, Allapattah; BVM, AllapattahMF, Big Game MF, Big MF list, Big MultiBay, Bigmf, BirdRoadCom, Brownsville, Buyer, CalleOcho, Central, CFM Big MF, CID, CIN, Cindi, CivApts, CivCen, CoralGables, CoralWay, DadeHotelMotel, Developers, Doral, Doral Industrial, Fausto, Flagami Apts, GablesMulti, GasStation, HiaGardens, Hialeah Industrial, HialeahApt, HialeahCom, HialeahRetail, HollywoodRetail, JRLitHaitiWyn, Land, LibCityCom, LibCityMF, LittleHaiti, LittleHaitiCom, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleHavanaLand, LittleRiver, Medley, MF Bay, Miami Beach, MiamiBeachCom, Naranja, NMB Land, NMB Retail, NoMiamiRetail, NorthMiaLand, NorthMultiFamily, Omni, OpaLockaInd, Other, Outer Land, Overtown, OvertownMultifamily, ResidentialSingleFamily, Retail, RoadsShehnSilverApts, SelfStorage, Shimon, SouthBrowardComm, SouthBrowardRetail, SouthMiaInd, SouthMiami, SouthMiamiMF, SouthRetail, VicenteRolodex, WarehousesSouth, WestchesterCom, WestchesterRetail, WestFlagler |
| Carlos Miranda-Brassac | 18 | Airport, Allapattah, Allapattah; BVM, AllapattahMF, CivApts, EHia Industrial, Flagami Apts, FlagamiApts, HialeahApt, HialeahCom, HialeahRetail, LibCityCom, LittleHavana, LittleHavanaApt, LittleHavanaCom, RoadsShehnSilverApts, SouthBrowardRetail, WarehousesSouth |
| Christopher Canizares | 9 | Flagami Apts, FlagamiApts, GablesMulti, JRLitHaitiWyn, JRLitHaitiWynAPT, Miami Beach, WWNAPT, Wynwood, Wynwood Norte |
| Christopher Carbonell | 11 | CoralWay, Flagami Com, LittleHavana, LittleHavanaApt, LittleHavanaCom, Other, Overtown, OvertownComm, OvertownMultifamily, Retail Leasing Leads, RoadsShehnSilverApts |
| Elior Levi | 22 | ALFs Broward Palm, Broward MF 33021, BrowardMulti, BrowardShopping, DaniaMulti, FTL MF East, FTLApts, Hallandale MultiFam, HallandaleRetail, Hollywood33020Resi, HollywoodApt33023_4, HollywoodRetail, NorthMiaApts, NorthMiaLand, Other, PompanoMultiFam, SouthBroward33021, SouthBrowardApt, SouthBrowardApt33020, SouthBrowardApts, SouthBrowardRetail, W Fort Lauderdale MF |
| Eric Cruz | 8 | CoralWay, LiquorKing, MiamiOfficesSouth, Other, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, US1-Grovecom |
| Erick Moretti | 4 | Developers, K2 Goulds, South Developers, South Miami Hotel |
| Ernesto Diaz | 27 | 27 Ave, Airport, Allapattah, Allapattah; BVM, AllapattahMF, BirdRoadCom, CalleOcho, CID, CID Condo, CIN, Commercial, EHia Industrial, HiaGardens, Hialeah, Hialeah Gardens, HialeahApt, HialeahCom, HialeahRetail, Homestead, LibCityCom, LittleRiver, NewFlagami, OpaLockaInd, Other, SouthMiaInd, SouthMiamiInd, WarehousesSouth |
| Giovanni Bertolotti | 29 | 71st Ind, Allapattah, BirdRoadCom, CID, City of Miami, Commercial, DesignDist North, GasStation, GioHotList, Institutional, JRLitHaitiWyn, LibCityApt, LibCityCom, LibCityMF, LittleHaitiCorridor, NNN Kodiak, NorthMultiFamily, Other, RoadsShehnSilverApts, SouthBrowardRetail, SouthMiami, SouthMiamiRetail, SouthRetail, SURDEVRET, Vacant Land, WarehousesSouth, WestchesterCom, WestchesterRetail, Wynwood Norte |
| Halain Suarez | 16 | AirWest, Doral Industrial, EHia, EHia Industrial, Fausto, FTL NE Ind, HiaGardens, HiaGardenWare, Hialeah Gardens, HialeahCom, HialeahRetail, LittleHavanaCom, Medley, OpaLockaInd, Pickle/Padel, SouthMiaInd |
| Ian Wilson | 2 | FTL NE Ind, FTLInd |
| Joshua Jimenez | 42 | 2421 nw 27 ave, AirWest, Allapattah, Allapattah Retail, Broker, Broker Buyer, Broker Tenant, Buyer, Buyer broker, CalleOcho, CivCen, CoralGablesCom, DesignDist North, Flagami Apts, Flagami Com, HialeahCom, Industrial, Joshua Jimenez, Leasee, Lessor, LiquorKing, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleHavanaCom, MiamiOfficesSouth, OaklandParkInd, Other, owner, Retail Broward, Seller, SouthMiaInd, SouthMiami, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, Tenant, Tenant Broker, Tenant Ish, VicenteRolodex |
| Kodiak Fields | 18 | CarWashBuyers, Doral Industrial, EastSide, Edgewater, HallandaleRetail, HollywoodRetail, KodiakBuyer, Medley, Miami Beach, MiamiBeachCom, MiamiBeachCom, MiamiBeachRetail, NNN Kodiak, NoMiamiRetail, OaklandParkInd, SouthBrowardRetail, VicenteLitHaiti, VicenteRolodex |
| Lourdes Ramia | 11 | Flagami Apts, Flagami South, Little HavanaWest, LittleHavana, LittleHavanaApt, LittleHavanaCom, Other, Overtown, RoadsShehnSilverApts, Shenandoah, WestLittleHavana |
| Lucia Villa | 13 | BirdRoadCom, CoralGablesCom, CoralWay, Flagami, Florida City, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, UniPrkSwtwtrSoDoral, US1-Grovecom, WestchesterRetail, WestchesterWRetail |
| Luna Graciana | 15 | City of Miami, CoralWay, DeerfieldBeach, Flagami Apts, Flagami Com, Flagami South, GroveRIN, Lighthouse MF, LittleHavanaApt, LittleHavanaCom, Overtown, OvertownMultifamily, RoadsShehnSilverApts, The Roads, Wynwood Norte |
| Marcel Perez | 2 | HialeahApt, HialeahApts |
| Marcos GodoyTorrent | 11 | BirdRoadCom, CoconutGrove, GroveRIN, HIA warehouse, HiaGardens, HiaGardensWare, HiaGardenWare, Hialeah, Hialeah Gardens, Medley, WarehousesSouth |
| Markos Bertolotti | 62 | Airport, Allapattah, Allapattah; BVM, AllapattahMF, BirdRoadCom, Biscayne Park, Biscayne Shores, Brownsville, Buyer, CID, City of Miami, CivCen, CoralGables, CoralTerrace, CoralWay, Dade County, Dadeland North, DaniaIndustrial, Doral, Doral Industrial, Flagami Apts, GablesMulti, Hallandale, HiaGardens, Hialeah, Hialeah Gardens, HialeahRetail, Homestead, JRLitHaitiWyn, LibCityCom, LittleHaiti, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleRiver, Medley, Miami, Miami Beach, Miami Dade, Miami Gardens, NOBE, North Bay Village, North Miami, NorthMultiFamily, OaklandParkInd, Opa Locka, OpaLockaInd, Other, Outer Land, RoadsShehnSilverApts, Shenandoah, SouthMiaInd, St. Petersburg, Sunrise, SunriseInd, Tamiami, The Roads, Unincorporated Dade, WarehousesSouth, West Little River, Wynwood, Wynwood Norte |
| Martina Smoláková | 30 | BirdRoadCom, BirdroadRetail, CoralGablesCom, CoralWay, Edgewater, EdgewaterOmniWyn, Hallandale MultiFam, JRLitHaitiWyn, Land Edge Midtown, LHT Land Robin, LibCityCom, LibertyCityCom, LittleHaitiCorridor, Miami Beach, MiamiOfficesSouth, MOBILE_HOMES, NEMiamiRetail, NMB Land, NoMiamiRetail, North Miami, NorthMiaLand, NorthMultiFamily, Other, OvertownMultifamily, Project 130, Retail, SouthBrowardInd, SouthBrowardRetail, US1-Grovecom, Wynwood Norte |
| Mauricio Villasuso | 37 | Allapattah, AllapattahMF, AllapattahMF, Bigmf, CalleOcho, CID, CivApts, CoralWay, Flagami, Flagami Apts, Flagami Com, Flagami South, GablesMulti, GasStation, HiaGardens, HialeahApt, HialeahApts, HialeahCom, HialeahRetail, Home Project, JRLitHaitiWyn, Little HavanaWest, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleHavanaLand, NewFlagami, Other, Overtown, OvertownComm, RoadsShehnSilverApts, Shenandoah, ShenandoahApts, SouthBrowardRetail, WarehousesSouth, WestLittleHavana, Wynwood |
| Michael Bell | 1 | JaxDwtwnSpring |
| Miguel Fuentes | 10 | Allapattah, AllapattahMF, AllapattahMF, CivApts, CivCen, Flagami Apts, Flagami Com, FlagamiApts, LibCityApt, OvertownMultifamily |
| Mitchell Lieberman | 1 | Hollywood33020Resi |
| Moises Figueroa | 11 | Commercial, CoralWay, DadeHotelMotel, Doral Industrial, EHia, HialeahApt, HialeahCom, HialeahRetail, HialeahRetail, Other, Retail |
| Nathalie Aguirre | 3 | HollywoodRetail, SouthBrowardInd, SURDEVRET |
| Nicholas Bazajou | 8 | Allapattah Retail, LittleHavana, LittleHavanaCom, LittleHavanaCom, OaklandParkInd, Other, SOUThMiamiAlberto, SouthMiamiInd |
| Reinier Moya | 20 | Allapattah, Allapattah; BVM, Big Game MF, CID, CoralGables, CoralWay, Edgewater, Flagami Apts, HomesteadMultifamily, JRLitHaitiWyn, JRLitHaitiWynAPT, LittleHavanaApt, NewFlagami, Open, Other, RoadsShehnSilverApts, SouthBrowardRetail, SouthMiamiMF, WarehousesSouth, Wynwood Norte |
| Robin Perez | 44 | AllapattahMF, Big Game MF, Broward Gas, Buyer, Buyers, CoralGablesOffice, DesignDist, DesignDist North, Distressed, EastSide, Edgewater, Edgewater Land, Expired, GasStation, GroveRIN, HiaGardens, HiaGardensWare, HiaGardenWare, JRLitHaitiWyn, JRLitHaitiWynAPT, LHT Land Robin, LibCityCom, LibCityMF, LibertyCity, LittleHaiti, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleRiver, Miami Beach, MOBILE_HOMES, North Miami, NorthMultiFamily, Opa Locka, Other, OvertownMultifamily, Pompano Beach, Project 130, Upper east side, VicenteLitHaiti, West Little River, WWNAPT, Wynwood, Wynwood Norte |
| Ryan Carney | 10 | Biscayne Park, FTLApts, GasStation, Hallandale MultiFam, NMB Land, NoMiamiRetail, NorthMiaApts, NorthMiaLand, NorthMultiFamily, W Fort Lauderdale MF |
| Ryan Gonzalez | 2 | Big Game MF, Bigmf |
| Swaraj Gaikwad | 1 | NoEastFlaHotel |
| Tony Saladrigas | 17 | BirdRoadCom, Buyers, Miami Beach, MiamiBeachCom, MiamiBeachCom, MiamiBeachRetail, Name Brand Retailers, NEMiamiRetail, OaklandParkInd, OvertownComm, PlantationCom, Retail Leasing Leads, RoadsShehnSilverApts, SouthBrowardRetail, TS Buyers, US1-Grovecom, WarehousesSouth |
| Veronica Rueda | 4 | Doral HG&M&MS Retail, Doral Retail, Miami Gardens Retail, WestchesterWRetail |
| Vicente Rodriguez | 17 | Big Game MF, CID, Edgewater, Expired, GablesMulti, JRLitHaitiWyn, LibCityApt, LittleHaiti, LittleHaitiMF, LittleHavana, LittleHavanaApt, LittleRiver, Miami Beach, Upper east side, VicenteLitHaiti, VicenteRolodex, Wynwood Norte |
| Yuniel De Varona | 15 | AirWest, Allapattah, DesignDist North, Hialeah Industrial, HialeahCom, LittleRiver, Miami Dade, NorthMiaApts, NorthMiaWrhse, Opa Locka, OpaLockaInd, SouthBrowardRetail, SouthMiamiMF, Unincorporated Dade, WarehousesSouth |
| Zenovia Varela | 12 | Buyer, DaniaInd, DaniaIndustrial, Industrial, JRLitHaitiWyn, LittleHaitiCorridor, LittleHavana, LittleRiver, Other, SouthBrowardInd, SouthBrowardRetail, VicenteLitHaiti |
