/**
 * Salesforce backup → S3-compatible object storage (Cloudflare R2 / Backblaze B2).
 *
 * Professional Edition caps the *native* scheduled Data Export at monthly and the
 * ZIPs aren't cleanly API-fetchable, so we write our own: global-describe → query
 * every queryable custom + core-standard object → gzip per object → upload under a
 * dated prefix → prune old backups. SOQL reads have no PE export limit, so we can
 * run any cadence.
 *
 * Designed to run in GitHub Actions on a schedule (daily + monthly), not on the
 * live call server. See .github/workflows/sf-backup.yml and scripts/backup/README.md.
 *
 * Usage:
 *   # measure only — no upload, no creds needed (read-only against prod)
 *   npx tsx --env-file .env.local scripts/backup/sf-backup.ts --dry-run
 *
 *   # real backup (needs BACKUP_S3_* env)
 *   npx tsx --env-file .env.local scripts/backup/sf-backup.ts --tier daily
 *   npx tsx --env-file .env.local scripts/backup/sf-backup.ts --tier monthly
 *
 * Retention (script-managed, hard caps total size): keep newest 30 under daily/
 * (a rolling month), newest 12 under monthly/ (a year of long-term recovery).
 * Older dated prefixes are deleted after a successful upload. (Bucket lifecycle
 * rules are age-only and can't express keep-N, so we prune ourselves.) At ~51 MB
 * per backup this totals ~2 GB — well within R2's 10 GB free tier.
 *
 * Env:
 *   SF_LOGIN_URL / SF_CLIENT_ID / SF_CLIENT_SECRET   — Salesforce (already set)
 *   BACKUP_S3_ENDPOINT      — e.g. https://<acct>.r2.cloudflarestorage.com
 *   BACKUP_S3_REGION        — "auto" (R2) or region (B2)
 *   BACKUP_S3_BUCKET        — bucket name
 *   BACKUP_S3_ACCESS_KEY_ID / BACKUP_S3_SECRET_ACCESS_KEY
 *   BACKUP_KEEP_DAILY  (default 30)   BACKUP_KEEP_MONTHLY (default 12)
 */

import { gzipSync } from 'zlib';
import {
  S3Client,
  PutObjectCommand,
  ListObjectsV2Command,
  DeleteObjectsCommand,
} from '@aws-sdk/client-s3';
import { sfClient, type SfClient } from '../../src/integrations/sf-client';

// --- args -------------------------------------------------------------------
const args = process.argv.slice(2);
const DRY_RUN = args.includes('--dry-run');
const tierArg = args[args.indexOf('--tier') + 1];
const TIER: 'daily' | 'monthly' = tierArg === 'monthly' ? 'monthly' : 'daily';
const onlyArg = args[args.indexOf('--only') + 1];
const ONLY =
  args.includes('--only') && onlyArg
    ? new Set(onlyArg.split(',').map((s) => s.trim()))
    : null;

const KEEP =
  TIER === 'monthly'
    ? parseInt(process.env.BACKUP_KEEP_MONTHLY || '12', 10)
    : parseInt(process.env.BACKUP_KEEP_DAILY || '30', 10);

// Standard objects worth backing up (custom __c are auto-included). Mirrors the
// sf-export spike — keep the two lists in sync if you add objects.
const STANDARD_KEEP = new Set([
  'Account', 'Contact', 'Lead', 'Opportunity', 'Task', 'Event',
  'Campaign', 'CampaignMember', 'User', 'ContentVersion', 'ContentDocument',
]);
const SKIP_SUFFIX = ['__Share', '__History', '__Feed', '__ChangeEvent', '__Tag', '__mdt'];
const SKIP_FIELD_TYPES = new Set(['address', 'location', 'base64']);

interface GlobalDescribe {
  sobjects: { name: string; queryable: boolean; custom: boolean }[];
}
interface FieldDescribe { name: string; type: string }

function fmtBytes(n: number): string {
  if (n > 1e9) return `${(n / 1e9).toFixed(2)} GB`;
  if (n > 1e6) return `${(n / 1e6).toFixed(1)} MB`;
  if (n > 1e3) return `${(n / 1e3).toFixed(1)} KB`;
  return `${n} B`;
}

function s3(): S3Client {
  for (const k of [
    'BACKUP_S3_ENDPOINT', 'BACKUP_S3_REGION', 'BACKUP_S3_BUCKET',
    'BACKUP_S3_ACCESS_KEY_ID', 'BACKUP_S3_SECRET_ACCESS_KEY',
  ]) {
    if (!process.env[k]) throw new Error(`Missing env var: ${k}`);
  }
  return new S3Client({
    endpoint: process.env.BACKUP_S3_ENDPOINT,
    region: process.env.BACKUP_S3_REGION,
    credentials: {
      accessKeyId: process.env.BACKUP_S3_ACCESS_KEY_ID!,
      secretAccessKey: process.env.BACKUP_S3_SECRET_ACCESS_KEY!,
    },
    forcePathStyle: true, // R2/B2 want path-style addressing
  });
}

async function listBackupTargets(sf: SfClient): Promise<string[]> {
  const res = await fetch(`${sf.instance}/services/data/v59.0/sobjects/`, {
    headers: { Authorization: `Bearer ${sf.token}` },
  });
  if (!res.ok) throw new Error(`global describe failed: ${res.status}`);
  const gd = (await res.json()) as GlobalDescribe;
  return gd.sobjects
    .filter((o) => o.queryable)
    .filter((o) => o.custom || STANDARD_KEEP.has(o.name))
    .filter((o) => !SKIP_SUFFIX.some((s) => o.name.endsWith(s)))
    .map((o) => o.name)
    .filter((name) => (ONLY ? ONLY.has(name) : true))
    .sort();
}

/** Query all rows for one object and return gzipped JSON + stats. */
async function dumpObject(
  sf: SfClient,
  obj: string
): Promise<{ gz: Buffer; rows: number; rawBytes: number }> {
  const desc = await sf.describe(obj);
  const fields = (desc.fields as FieldDescribe[])
    .filter((f) => !SKIP_FIELD_TYPES.has(f.type))
    .map((f) => f.name);
  const rows = await sf.soql(`SELECT ${fields.join(', ')} FROM ${obj}`);
  const json = JSON.stringify(rows);
  return { gz: gzipSync(json), rows: rows.length, rawBytes: Buffer.byteLength(json) };
}

/** Delete every dated prefix under <tier>/ except the newest KEEP. */
async function prune(client: S3Client, bucket: string): Promise<number> {
  const prefix = `${TIER}/`;
  const listed = await client.send(
    new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, Delimiter: '/' })
  );
  // CommonPrefixes are the dated folders, e.g. "daily/2026-06-27T.../".
  const folders = (listed.CommonPrefixes || [])
    .map((p) => p.Prefix!)
    .filter(Boolean)
    .sort(); // ISO stamps sort chronologically
  const stale = folders.slice(0, Math.max(0, folders.length - KEEP));

  let deleted = 0;
  for (const folder of stale) {
    const objs = await client.send(
      new ListObjectsV2Command({ Bucket: bucket, Prefix: folder })
    );
    const keys = (objs.Contents || []).map((o) => ({ Key: o.Key! }));
    if (keys.length) {
      await client.send(
        new DeleteObjectsCommand({ Bucket: bucket, Delete: { Objects: keys } })
      );
      deleted += keys.length;
    }
    console.log(`   🗑  pruned ${folder} (${keys.length} files)`);
  }
  return deleted;
}

async function main() {
  const sf = await sfClient('prod');
  const targets = await listBackupTargets(sf);

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  console.log(
    `\n📦 SF backup — tier=${TIER}, keep=${KEEP}, ${DRY_RUN ? 'DRY-RUN (no upload)' : `→ s3://${process.env.BACKUP_S3_BUCKET}/${TIER}/${stamp}/`}`
  );
  console.log(`   ${targets.length} objects\n`);

  const client = DRY_RUN ? null : s3();
  const bucket = process.env.BACKUP_S3_BUCKET!;
  const manifest: { object: string; records: number; rawBytes: number; gzBytes: number }[] = [];
  let totalRows = 0;
  let totalRaw = 0;
  let totalGz = 0;
  let failed = 0;

  for (const obj of targets) {
    try {
      const { gz, rows, rawBytes } = await dumpObject(sf, obj);
      if (client) {
        await client.send(
          new PutObjectCommand({
            Bucket: bucket,
            Key: `${TIER}/${stamp}/${obj}.json.gz`,
            Body: gz,
            ContentType: 'application/json',
            ContentEncoding: 'gzip',
          })
        );
      }
      manifest.push({ object: obj, records: rows, rawBytes, gzBytes: gz.length });
      totalRows += rows;
      totalRaw += rawBytes;
      totalGz += gz.length;
      console.log(
        `   ✓ ${obj.padEnd(34)} ${String(rows).padStart(7)} rows  ${fmtBytes(gz.length).padStart(10)} gz`
      );
    } catch (err: any) {
      failed++;
      console.log(`   ✗ ${obj.padEnd(34)} ERROR: ${err.message?.slice(0, 90)}`);
    }
  }

  const manifestBody = JSON.stringify(
    { stamp, tier: TIER, totalRows, totalRaw, totalGz, failed, objects: manifest },
    null,
    2
  );

  console.log(
    `\n   ── ${totalRows} records · ${fmtBytes(totalRaw)} raw · ${fmtBytes(totalGz)} gz · ${failed} failed ──`
  );

  if (!client) {
    console.log(`\n   (dry-run — set BACKUP_S3_* and drop --dry-run to upload)\n`);
    return;
  }

  // Manifest last, so its presence signals a complete upload.
  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: `${TIER}/${stamp}/manifest.json`,
      Body: Buffer.from(manifestBody),
      ContentType: 'application/json',
    })
  );
  console.log(`\n   ⬆️  uploaded to ${TIER}/${stamp}/`);

  const pruned = await prune(client, bucket);
  console.log(`   ✅ done — kept newest ${KEEP}, pruned ${pruned} old files\n`);

  // Non-zero exit if any object failed, so CI surfaces a partial backup.
  if (failed) process.exit(2);
}

main().catch((e) => {
  console.error('Backup failed:', e);
  process.exit(1);
});
