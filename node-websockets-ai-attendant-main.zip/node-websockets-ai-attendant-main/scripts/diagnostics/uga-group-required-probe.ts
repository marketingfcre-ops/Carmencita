import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log('instance:', sf.instanceUrl);

  // Describe-level
  const desc: any = await sf.describe('User_Group_Access__c');
  const f = (desc.fields || []).find((x: any) => x.name === 'Group__c');
  console.log(`\nGroup__c describe-level flags:`);
  console.log(`  type=${f?.type}  nillable=${f?.nillable}  createable=${f?.createable}  updateable=${f?.updateable}  defaultedOnCreate=${f?.defaultedOnCreate}`);
  // Tooling-level: CustomField record
  const tool: any[] = await sf.toolingQuery(
    `SELECT Id, DeveloperName, Required, RelationshipName FROM CustomField WHERE TableEnumOrId = '${desc.name}' AND DeveloperName = 'Group'`
  ).catch((e:any)=>{ console.log('tooling err:', e.message?.slice(0,200)); return []; });
  console.log(`\nCustomField (Tooling):`);
  for (const c of tool) console.log(`  ${c.Id}  required=${c.Required}  rel=${c.RelationshipName}`);
  // Validation rules on User_Group_Access__c
  const vrs: any[] = await sf.toolingQuery(
    `SELECT Id, ValidationName, Active, ErrorDisplayField FROM ValidationRule WHERE EntityDefinition.DeveloperName = 'User_Group_Access'`
  ).catch((e:any)=>{ console.log('vr err:', e.message?.slice(0,200)); return []; });
  console.log(`\nValidation Rules on User_Group_Access__c: ${vrs.length}`);
  for (const v of vrs) console.log(`  ${v.Id}  ${v.ValidationName}  active=${v.Active}  display=${v.ErrorDisplayField}`);

  // Existing rows: any with Group__c = null?
  const blanks: any[] = await sf.soql(
    `SELECT Id FROM User_Group_Access__c WHERE Group__c = null`
  );
  console.log(`\nExisting rows with Group__c = null: ${blanks.length}`);
}
main().catch(e=>{console.error('💀',e);process.exit(1);});
