/**
 * Handler — Salesforce Property__c change events.
 *
 * Triggered by the central /webhooks/salesforce/event endpoint when SF fires
 * a Flow HTTP Callout on Property__c create/update.
 *
 * Responsibilities:
 *   - On create (or first sync): create a WP draft, write back WP_Post_ID__c + Public_URL__c to SF
 *   - On update: refresh WP post fields + Houzez meta
 *   - On status change: drive post status (publish/draft) and listing-status taxonomy (For Sale/Lease/Sold)
 *
 * The handler is idempotent — same event fired twice produces the same result.
 */

import { sfClient, type SfTarget } from '../integrations/sf-client';
import type { SFPropertyForSync } from '../salesforce';
import {
  createPropertyDraft,
  updatePropertyPost,
  writeHouzezMeta,
  buildHouzezMeta,
  findPropertyIdBySlug,
  findPropertyIdByAddress,
  findPropertyIdByTitleSearch,
  extractSlugFromPublicUrl,
  getProperty,
  type PropertyInput,
} from '../integrations/wordpress';
import {
  mapSfStatusToWpAction,
  resolvePropertyStatusByKey,
  resolvePropertyStatusByListingType,
} from '../integrations/wordpress-mappings';

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

export interface PropertyChangedEvent {
  /** SF Property__c record ID. */
  recordId: string;
  /** Optional list of fields that changed. Empty/undefined = treat as full update. */
  changedFields?: string[];
  /** Trigger reason — for logs and routing. */
  reason: 'created' | 'updated' | 'status-changed' | 'price-changed';
}

export interface HandlerResult {
  ok: boolean;
  action: 'created' | 'updated' | 'unpublished' | 'noop';
  wpPostId?: number;
  permalink?: string;
  error?: string;
}

export async function handlePropertyChanged(
  event: PropertyChangedEvent,
  target: SfTarget = 'prod'
): Promise<HandlerResult> {
  const sfc = await sfClient(target);
  const sf = await fetchPropertyForSyncVia(sfc, event.recordId);
  if (!sf) {
    return {
      ok: false,
      action: 'noop',
      error: `Property__c ${event.recordId} not found in ${typeof target === 'string' ? target : 'custom'} org`,
    };
  }

  const action = mapSfStatusToWpAction(sf.status || '');

  // No WP_Post_ID__c yet. Two sub-cases:
  //   (a) Property already has Public_URL__c pointing to an existing WP post —
  //       backfill WP_Post_ID__c from the slug and proceed as an UPDATE.
  //   (b) No URL set — truly new, create a draft.
  if (!sf.wpPostId) {
    const backfilledId = await tryBackfillWpPostId(sfc, sf);
    if (backfilledId !== null) {
      sf.wpPostId = backfilledId;
      return await updateExistingListing(sfc, sf, action);
    }
    return await createNewListing(sfc, sf);
  }

  return await updateExistingListing(sfc, sf, action);
}

// ---------------------------------------------------------------------------
// Generic-client variants of the SF helpers (so we can target dev or prod)
// ---------------------------------------------------------------------------

async function fetchPropertyForSyncVia(
  sfc: Awaited<ReturnType<typeof sfClient>>,
  propertyId: string
): Promise<SFPropertyForSync | null> {
  const safeId = propertyId.replace(/'/g, "\\'");
  const records = await sfc.soql<any>(
    `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c,
            Zip_Code__c, County__c, Property_Type__c, Listing_Type__c, Status__c,
            Price__c, Building_Size_sqft__c, Lot_Size_sqft__c, Units__c,
            Year_Built__c, Zoning__c, Description__c, Pricing__c,
            Public_URL__c, WP_Post_ID__c
     FROM Property__c
     WHERE Id = '${safeId}'
     LIMIT 1`
  );
  if (records.length === 0) return null;
  const r = records[0];
  return {
    id: r.Id,
    name: r.Name || '',
    marketingName: r.Marketing_Name__c || null,
    address: r.Address__c || null,
    city: r.City__c || null,
    state: r.State__c || null,
    zipCode: r.Zip_Code__c || null,
    county: r.County__c || null,
    propertyType: r.Property_Type__c || null,
    listingType: r.Listing_Type__c || null,
    status: r.Status__c || null,
    price: r.Price__c ?? null,
    buildingSqft: r.Building_Size_sqft__c ?? null,
    lotSqft: r.Lot_Size_sqft__c ?? null,
    units: r.Units__c || null,
    yearBuilt: r.Year_Built__c || null,
    zoning: r.Zoning__c || null,
    description: r.Description__c || null,
    pricing: r.Pricing__c || null,
    publicUrl: r.Public_URL__c || null,
    wpPostId: r.WP_Post_ID__c ?? null,
  };
}

async function updatePropertyFieldVia(
  sfc: Awaited<ReturnType<typeof sfClient>>,
  propertyId: string,
  fields: Record<string, unknown>
): Promise<boolean> {
  try {
    await sfc.update('Property__c', propertyId, fields);
    return true;
  } catch (err) {
    console.error(`Failed to update Property__c ${propertyId}:`, err);
    return false;
  }
}

/**
 * Detect "WP post does not exist" 404 from a wordpress.ts error string.
 * Used to degrade gracefully when WP returns 404 instead of letting the
 * error propagate as 500 to make.com (which then retries forever).
 */
function isWpNotFound(error: string | undefined | null): boolean {
  if (!error) return false;
  return (
    error.includes('404') &&
    (error.includes('rest_post_invalid_id') ||
      error.includes('Invalid post ID'))
  );
}

/**
 * Look for an existing WP post that already corresponds to this SF Property
 * and write its ID back to SF as WP_Post_ID__c.
 *
 * Matching order:
 *   1. Slug parsed from Public_URL__c (fast — single REST call)
 *   2. Normalized street address against an in-memory WP address index
 *      (catches the ~150 April drafts where Public_URL__c never landed
 *      back in SF; without this we'd create duplicate posts every time
 *      SF Flow fires for those records).
 *
 * Returns the resolved WP post ID, or null if nothing matched.
 */
async function tryBackfillWpPostId(
  sfc: Awaited<ReturnType<typeof sfClient>>,
  sf: SFPropertyForSync
): Promise<number | null> {
  let wpId: number | null = null;
  let matchedBy = '';

  // 1) Slug match (existing behavior — preferred when Public_URL__c is set)
  const slug = extractSlugFromPublicUrl(sf.publicUrl);
  if (slug) {
    wpId = await findPropertyIdBySlug(slug);
    if (wpId) matchedBy = `slug "${slug}"`;
  }

  // 2) Address match against in-memory index (matches fave_property_address)
  if (!wpId && sf.address) {
    wpId = await findPropertyIdByAddress(sf.address);
    if (wpId) matchedBy = `address index "${sf.address}"`;
  }

  // 3) WP native search — catches posts where the address sits in the TITLE
  //    (marketing-curated titles like "Approved 36-Unit Development at
  //    2306 Van Buren") but NOT in fave_property_address. Without this we
  //    create duplicate drafts every time SF gets a record whose
  //    fave_property_address-twin doesn't exist on WP.
  if (!wpId && sf.address) {
    wpId = await findPropertyIdByTitleSearch(sf.address, sf.city);
    if (wpId) matchedBy = `WP search "${sf.address}"`;
  }

  if (!wpId) return null;

  console.log(
    `[sf-property-changed] Backfilling WP_Post_ID__c=${wpId} for SF ${sf.id} (matched ${matchedBy})`
  );
  const ok = await updatePropertyFieldVia(sfc, sf.id, { WP_Post_ID__c: wpId });
  if (!ok) {
    console.warn(
      `[sf-property-changed] Found WP post ${wpId} for SF ${sf.id} but failed to write WP_Post_ID__c back`
    );
  }
  return wpId;
}

// ---------------------------------------------------------------------------
// Branch: first-time sync → create WP draft
// ---------------------------------------------------------------------------

async function createNewListing(
  sfc: Awaited<ReturnType<typeof sfClient>>,
  sf: SFPropertyForSync
): Promise<HandlerResult> {
  // Skip creation if status indicates pre-publication draft only.
  if (sf.status === 'Draft/Pre-Market') {
    console.log(
      `[sf-property-changed] ${sf.id} is Draft/Pre-Market — skipping WP create`
    );
    return { ok: true, action: 'noop' };
  }

  const input = sfToPropertyInput(sf);
  const result = await createPropertyDraft(input);

  if (!result.ok || !result.wpId) {
    return {
      ok: false,
      action: 'noop',
      error: result.error || 'createPropertyDraft returned no wpId',
    };
  }

  // Write back to SF: WP_Post_ID__c (stable) and Public_URL__c (may change with slug)
  const updateOk = await updatePropertyFieldVia(sfc, sf.id, {
    WP_Post_ID__c: result.wpId,
    Public_URL__c: result.permalink,
  });

  if (!updateOk) {
    console.warn(
      `[sf-property-changed] WP draft created (id=${result.wpId}) but failed to write back to SF ${sf.id}`
    );
  }

  console.log(
    `[sf-property-changed] Created WP draft for ${sf.id} → wp:${result.wpId} (${result.permalink})`
  );
  return {
    ok: true,
    action: 'created',
    wpPostId: result.wpId,
    permalink: result.permalink,
  };
}

// ---------------------------------------------------------------------------
// Branch: existing sync → update WP post and meta
// ---------------------------------------------------------------------------

async function updateExistingListing(
  sfc: Awaited<ReturnType<typeof sfClient>>,
  sf: SFPropertyForSync,
  action: ReturnType<typeof mapSfStatusToWpAction>
): Promise<HandlerResult> {
  const wpId = sf.wpPostId!;
  const input = sfToPropertyInput(sf);

  // Fetch current WP post state once. Used for:
  //   1. Auto-publish fail-safe guard (do not promote drafts to publish)
  //   2. Public_URL__c sync (write the canonical WP permalink back to SF
  //      if it has drifted — happens any time a draft is published in WP
  //      or a slug changes, since WP→SF is not actively pushed)
  const currentPost = await getProperty(wpId);

  // Resolve listing-status taxonomy IDs based on action plan
  const listingStatusKey = action.listingStatusKey;
  let propertyStatusTermIds: number[] | undefined;

  if (listingStatusKey === 'inherit-from-listing-type') {
    propertyStatusTermIds = resolvePropertyStatusByListingType(
      sf.listingType || ''
    );
  } else if (
    listingStatusKey === 'sold' ||
    listingStatusKey === 'off-market' ||
    listingStatusKey === 'for-sale' ||
    listingStatusKey === 'for-lease'
  ) {
    const id = resolvePropertyStatusByKey(listingStatusKey);
    propertyStatusTermIds = id ? [id] : undefined;
  }

  // Build the post-update payload.
  //
  // IMPORTANT: We deliberately do NOT touch `title` or `content` on updates.
  // SF owns STRUCTURED data (price, address, sizes, status, listing taxonomy);
  // WP owns MARKETING copy (title, content/description, hand-curated SEO).
  // Marketers edit titles and descriptions on WP and we must not clobber them
  // on every SF status change. Only post status and listing-status taxonomy
  // are pushed from SF — that's the surface area SF should drive.
  const postUpdate: Parameters<typeof updatePropertyPost>[1] = {};

  // Guard against auto-publishing curated drafts.
  //
  // WP drafts (no photos yet, marketing hand-curating, etc.) must NEVER be
  // flipped to `publish` by a sync. Publishing is a deliberate human action.
  //
  // Before May 8 this code would flip any draft → publish whenever ANY SF
  // field changed (e.g. an agent submits a listing-review note), because
  // mapSfStatusToWpAction('Active') returns postStatus='publish'. That
  // accidentally published ~120 drafts without photos.
  //
  // Rule now: if the post is currently a draft, SF can only push it to
  // draft (no-op) or to private. SF cannot promote a draft to publish.
  //
  // FAIL-SAFE: if we can't determine the current WP post status (network
  // failure, 404, etc.), DO NOT publish. Better to leave the WP post's
  // status alone than to risk auto-publishing a curated draft. The original
  // bug here was that getProperty() pointed at a non-existent endpoint and
  // always returned null — making the `currentPost?.status === 'draft'`
  // check always false → every webhook published.
  if (action.postStatus && action.postStatus !== 'draft') {
    if (currentPost === null) {
      console.warn(
        `[sf-property-changed] wp:${wpId} status could not be determined — skipping status sync (fail-safe)`
      );
    } else if (currentPost.status === 'draft') {
      console.log(
        `[sf-property-changed] wp:${wpId} is a draft — skipping auto-publish (humans control draft → publish)`
      );
    } else {
      postUpdate.status = action.postStatus;
    }
  } else if (action.postStatus === 'draft') {
    // SF explicitly says "go back to draft" (Draft/Pre-Market) — honor it.
    postUpdate.status = 'draft';
  }
  if (propertyStatusTermIds && propertyStatusTermIds.length > 0) {
    postUpdate.property_status = propertyStatusTermIds;
  }

  // If nothing to update on the post itself, skip the call entirely
  const hasPostUpdate = Object.keys(postUpdate).length > 0;

  if (hasPostUpdate) {
    const postResult = await updatePropertyPost(wpId, postUpdate);
    if (!postResult.ok) {
      // Detect "WP post deleted externally" 404 and degrade gracefully.
      // Returning 500 here makes make.com retry the webhook with exponential
      // backoff and eventually freeze the whole scenario — we saw this with
      // wp:23555 (someone deleted a duplicate in WP admin, SF still pointed
      // at it, every retry hit 404). Better behavior: log, return noop with
      // 200 so make.com moves on, leave the orphaned SF link for the
      // periodic audit (sf-wp-link-audit.ts) to surface.
      if (isWpNotFound(postResult.error)) {
        console.warn(
          `[sf-property-changed] BROKEN LINK: wp:${wpId} no longer exists ` +
            `but SF ${sf.id} (${sf.address || sf.name}) still points at it. ` +
            `Returning noop to prevent make.com retry loop. ` +
            `Run scripts/diagnostics/sf-wp-link-audit.ts to clean up orphans.`
        );
        return {
          ok: true,
          action: 'noop',
          wpPostId: wpId,
          error: `WP post ${wpId} no longer exists — SF link is stale`,
        };
      }
      return {
        ok: false,
        action: 'noop',
        error: postResult.error,
        wpPostId: wpId,
      };
    }
  }

  // Refresh Houzez meta (prices, sizes, address, etc.)
  const metaResult = await writeHouzezMeta(wpId, buildHouzezMeta(input));
  if (!metaResult.ok) {
    if (isWpNotFound(metaResult.error)) {
      console.warn(
        `[sf-property-changed] BROKEN LINK: wp:${wpId} no longer exists ` +
          `(detected during Houzez meta sync) for SF ${sf.id}. Link is stale.`
      );
    } else {
      console.warn(
        `[sf-property-changed] Post updated but Houzez meta failed for wp:${wpId}: ${metaResult.error}`
      );
    }
  }

  // Keep SF.Public_URL__c in sync with the canonical WP permalink.
  //
  // SF is the source of truth for property data, but WP owns the URL slug.
  // When a draft gets published in WP, the slug-style URL appears in `.link`
  // but nothing pushes that change back to SF — so the URL silently drifts
  // (and may even 404 if the underlying post id was retired). We fix that
  // here on every successful update: if the SF value differs from WP's
  // current permalink, write the WP permalink back.
  //
  // No-op when already in sync. Failure is logged but not fatal.
  if (currentPost && currentPost.permalink && currentPost.permalink !== (sf.publicUrl || '')) {
    const urlWriteOk = await updatePropertyFieldVia(sfc, sf.id, {
      Public_URL__c: currentPost.permalink,
    });
    if (urlWriteOk) {
      console.log(
        `[sf-property-changed] Synced SF.Public_URL__c for ${sf.id}: "${sf.publicUrl || '(empty)'}" → "${currentPost.permalink}"`
      );
    } else {
      console.warn(
        `[sf-property-changed] Failed to sync Public_URL__c for ${sf.id} (non-fatal)`
      );
    }
  }

  const finalAction: HandlerResult['action'] =
    action.postStatus === 'draft' || action.postStatus === 'private'
      ? 'unpublished'
      : 'updated';

  console.log(
    `[sf-property-changed] Updated wp:${wpId} for SF ${sf.id} (status=${sf.status}, action=${finalAction})`
  );
  return { ok: true, action: finalAction, wpPostId: wpId };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function sfToPropertyInput(sf: SFPropertyForSync): PropertyInput {
  return {
    sfId: sf.id,
    name: sf.name,
    marketingName: sf.marketingName,
    address: sf.address,
    city: sf.city,
    state: sf.state,
    zipCode: sf.zipCode,
    county: sf.county,
    propertyType: sf.propertyType,
    listingType: sf.listingType,
    price: sf.price,
    buildingSqft: sf.buildingSqft,
    lotSqft: sf.lotSqft,
    units: sf.units,
    yearBuilt: sf.yearBuilt,
    zoning: sf.zoning,
    description: sf.description,
    pricing: sf.pricing,
  };
}

