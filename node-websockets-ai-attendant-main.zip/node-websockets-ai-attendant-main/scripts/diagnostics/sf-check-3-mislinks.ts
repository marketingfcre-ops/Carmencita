/**
 * Verify the current state of the 3 SF mislinks we just fixed.
 * Tells us whether the SF Flow webhook fired and createNewListing ran.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const IDS = ['a0RJw000008GimsMAC', 'a0RJw000008KCQDMA4', 'a0RJw000008c9AXMAY'];

async function main() {
  const tokenRes = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await tokenRes.json()) as any;

  const url = `${instance_url}/services/data/v59.0/query?q=${encodeURIComponent(
    `SELECT Id, Name, Address__c, WP_Post_ID__c, Public_URL__c, LastModifiedDate
       FROM Property__c
      WHERE Id IN ('${IDS.join("','")}')`
  )}`;
  const r = await fetch(url, { headers: { Authorization: `Bearer ${access_token}` } });
  const data = (await r.json()) as any;

  console.log('\n📋 Current state of the 3 mislink fixes:\n');
  for (const rec of data.records || []) {
    console.log(`SF ${rec.Id}  — ${rec.Address__c}`);
    console.log(`   WP_Post_ID__c:    ${rec.WP_Post_ID__c === null ? '(null) ⚠️ no draft created' : rec.WP_Post_ID__c + ' ✓'}`);
    console.log(`   Public_URL__c:    ${rec.Public_URL__c || '(null)'}`);
    console.log(`   LastModifiedDate: ${rec.LastModifiedDate}`);
    console.log('');
  }
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
