/**
 * Fausto Commercial AI Attendant — Streaming Server
 *
 * Fastify server that handles:
 *   1. POST /voice/answer — Twilio webhook, returns TwiML with <Connect><Stream>
 *   2. WS /stream — WebSocket endpoint for Twilio Media Streams
 *   3. GET /health — Health check for Railway
 *   4. GET /debug — View leads and system status
 */

import Fastify from 'fastify';
import fastifyWebsocket from '@fastify/websocket';
import fastifyFormbody from '@fastify/formbody';
import { CallHandler } from './call-handler';
import { getLeads } from './claude';
import { getPropertyList } from './listings';
import {
  initSalesforce,
  getProperties,
  getAgents,
  getLastRefresh,
} from './salesforce';
import { registerAdminRoutes } from './admin';
import { registerReportRoutes } from './report-routes';
import { registerReviewRoutes } from './agent-review';
import { registerSalesforceWebhookRoutes } from './webhooks/salesforce';
import { registerSmsWebhookRoutes } from './webhooks/sms';
import { registerFlyerRoutes } from './handlers/flyer';
import { registerEmailRoutes } from './handlers/email';
import { startLlaReconcileScheduler } from './integrations/lla-reconcile';

const PORT = parseInt(process.env.PORT || '3000', 10);
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

// Global error handlers — catch anything that might silently kill the process
process.on('uncaughtException', (err) => {
  console.error('💀 UNCAUGHT EXCEPTION:', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('💀 UNHANDLED REJECTION:', reason);
});

async function main() {
  const app = Fastify({
    logger: true,
  });

  // Register plugins
  await app.register(fastifyFormbody);
  await app.register(fastifyWebsocket);

  // Admin monitoring dashboard
  await registerAdminRoutes(app);

  // Marketing & Automation report (/report + /report/api/data), ADMIN_KEY gated
  await registerReportRoutes(app);

  // Agent listing review (temporary)
  await registerReviewRoutes(app);

  // Salesforce → WordPress sync webhook
  await registerSalesforceWebhookRoutes(app);

  // Inbound SMS webhook — STOP / HELP / YES / START for A2P compliance
  await registerSmsWebhookRoutes(app);

  // Flyer generator (HTML preview + PDF when configured)
  await registerFlyerRoutes(app);

  // Email delivery — flyer/listing to a lead via Resend (test route + orchestrator)
  await registerEmailRoutes(app);

  // ---------------------------------------------------------------------------
  // Health check
  // ---------------------------------------------------------------------------
  app.get('/health', async () => {
    return { status: 'ok', timestamp: new Date().toISOString() };
  });

  // ---------------------------------------------------------------------------
  // Debug endpoint
  // ---------------------------------------------------------------------------
  app.get('/debug', async () => {
    const sfProperties = getProperties();
    const sfAgents = getAgents();
    return {
      leads: getLeads(),
      salesforce: {
        properties: sfProperties.length,
        agents: sfAgents.length,
        lastRefresh: getLastRefresh()
          ? new Date(getLastRefresh()).toISOString()
          : 'never',
        sampleProperties: sfProperties.slice(0, 5).map((p) => ({
          id: p.id,
          name: p.marketingName || p.name,
          address: p.address,
          city: p.city,
          type: p.propertyType,
          price: p.price,
          agent: p.listingAgentName,
        })),
      },
      fallbackListings: getPropertyList()
        .slice(0, 5)
        .map(
          (l: {
            id: string;
            address: string;
            city: string;
            propertyType: string;
            price?: number;
          }) => ({
            id: l.id,
            address: `${l.address}, ${l.city}`,
            type: l.propertyType,
            price: l.price,
          })
        ),
      info: {
        totalLeads: getLeads().length,
        totalSFProperties: sfProperties.length,
        totalFallbackListings: getPropertyList().length,
        usingSource: sfProperties.length > 0 ? 'salesforce' : 'fallback',
        timestamp: new Date().toISOString(),
      },
    };
  });

  // ---------------------------------------------------------------------------
  // Twilio voice webhook — returns TwiML to start a Media Stream
  // ---------------------------------------------------------------------------
  // ---------------------------------------------------------------------------
  // Twilio voice webhook — connect directly to AI stream
  // The AI assistant handles language detection naturally in conversation
  // ---------------------------------------------------------------------------

  app.post('/voice/answer', async (request, reply) => {
    const body = request.body as Record<string, string>;
    const callSid = body.CallSid || 'unknown';
    const callerPhone = body.From || 'unknown';

    console.log(`📞 Incoming call: ${callerPhone} (CallSid: ${callSid})`);

    const wsUrl = APP_URL.replace(/^https?:\/\//, 'wss://') + '/stream';

    // Start call recording via Twilio API (fire-and-forget, dual-channel for QA)
    const accountSid = process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_SID || '';
    const authToken = process.env.TWILIO_AUTH_TOKEN || process.env.TWILIO_TOKEN || '';
    if (accountSid && authToken) {
      fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Calls/${callSid}/Recordings.json`,
        {
          method: 'POST',
          headers: {
            Authorization:
              'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: 'RecordingChannels=dual',
        }
      ).catch((err) => console.warn(`⚠️ Recording start failed:`, err.message));
    }

    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="${wsUrl}">
      <Parameter name="callerPhone" value="${callerPhone}" />
    </Stream>
  </Connect>
</Response>`;

    reply.type('text/xml').send(twiml);
  });

  // ---------------------------------------------------------------------------
  // Twilio call status webhook
  // ---------------------------------------------------------------------------
  app.post('/voice/status', async (request) => {
    const body = request.body as Record<string, string>;
    console.log(
      `📊 Call status: ${body.CallStatus} | From: ${body.From} | Duration: ${body.CallDuration}s | CallSid: ${body.CallSid}`
    );
    return { received: true };
  });

  // ---------------------------------------------------------------------------
  // WebSocket endpoint for Twilio Media Streams
  // ---------------------------------------------------------------------------
  app.register(async function (fastify) {
    fastify.get('/stream', { websocket: true }, (socket, _request) => {
      console.log('🔌 New WebSocket connection for media stream');
      // Each connection = one call. The CallHandler manages the full pipeline.
      new CallHandler(socket);
    });
  });

  // ---------------------------------------------------------------------------
  // Initialize Salesforce data (non-blocking — server starts even if SF fails)
  // ---------------------------------------------------------------------------
  await initSalesforce();

  // LLA scheduler: auto-create assignments for Leads with a Group set
  // (LLA_RECONCILE_ENABLED) and email the admin about new Pending requests
  // (LLA_NOTIFY_ENABLED). Replaces record-triggered Flows we can't add (PE
  // 5-flow cap). Off by default. See src/integrations/lla-reconcile.ts.
  startLlaReconcileScheduler();

  // ---------------------------------------------------------------------------
  // Start server
  // ---------------------------------------------------------------------------
  try {
    await app.listen({ port: PORT, host: '0.0.0.0' });
    console.log(`\n🚀 Fausto AI Attendant (Streaming) running on port ${PORT}`);
    console.log(`   Webhook URL: ${APP_URL}/voice/answer`);
    console.log(`   WebSocket:   ${APP_URL.replace('https', 'wss')}/stream`);
    console.log(`   Health:      ${APP_URL}/health`);
    console.log(`   Debug:       ${APP_URL}/debug`);
    console.log(`   Admin:       ${APP_URL}/admin\n`);
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

main();
