/**
 * Group-level access grants for 2026-06-08 batch:
 *   - Ernesto Diaz   → Brownsville
 *   - Robert Castriotta → EastSide
 *
 * Per the discussion, these are still group-level grants. Next iteration we
 * may move tonight's pattern to per-agent personal groups for one-off shares.
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const GRANTS: { user: string; group: string }[] = [
  { user: 'Ernesto Diaz',       group: 'Brownsville' },
  { user: 'Robert Castriotta',  group: 'EastSide' },
];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  for (const g of GRANTS) {
    const u: any[] = await sf.soql(
      `SELECT Id, Name, IsActive FROM User WHERE Name = '${g.user}' AND IsActive = true LIMIT 5`
    );
    if (u.length !== 1) { console.log(`✗ ${g.user}: ${u.length} matches — skip`); continue; }
    const grp: any[] = await sf.soql(
      `SELECT Id, Name FROM Group__c WHERE Name = '${g.group}' LIMIT 5`
    );
    if (grp.length !== 1) { console.log(`✗ Group "${g.group}": ${grp.length} matches — skip`); continue; }
    const existing: any[] = await sf.soql(
      `SELECT Id, Status__c FROM User_Group_Access__c WHERE User__c = '${u[0].Id}' AND Group__c = '${grp[0].Id}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) {
      console.log(`✓ ${g.user} already Approved on "${g.group}". Skip.`);
      continue;
    }
    console.log(`  Plan: ${g.user} → "${g.group}"`);
    if (DRY) continue;
    const id = await sf.create('User_Group_Access__c', {
      User__c: u[0].Id,
      Group__c: grp[0].Id,
      Status__c: 'Approved',
    });
    console.log(`    ✓ Created User_Group_Access__c ${id}`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
