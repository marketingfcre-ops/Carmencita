# 06 — SMS, A2P Consent Compliance & Email/Flyer Delivery

How Carmencita follows up with a caller *after* the call: texting them listing
links, emailing them property flyers, and doing it all in a way that satisfies
US carrier rules for automated texting (A2P 10DLC). This section is written so a
non-technical owner can understand *why* the flow looks the way it does, and a
technical successor can operate and extend it.

---

## 1. The big picture (plain English)

A caller talks to Carmencita on the phone. They ask about a property. Carmencita
can deliver the details two ways:

1. **By text (SMS)** — a link to the listing page on faustocommercial.com.
2. **By email** — a branded email with the property flyer PDF attached.

The clever part: **the caller never has to spell out their email on the phone.**
Instead, Carmencita texts them, and they simply *reply to that text with their
email address*. The system reads the reply, looks up which flyer(s) they wanted,
and emails them. No error-prone "is that gmail dot com? J-E-S-U-S?" on a live
call.

All of this is wrapped in a strict **consent and compliance layer**, because US
carriers will block (or fine) a business that texts people who didn't opt in.
That layer is the bulk of the code here.

---

## 2. SMS: texting listing links

### 2.1 What the assistant can do

Carmencita has a tool called `send_property_sms` (defined in
`src/claude.ts:392`). When a caller wants a listing by text, the model calls it
with the Salesforce property id, name, and address. The handler lives at
`src/claude.ts` ~line 600–695.

The whole SMS feature is gated by an env flag: `SMS_ENABLED` (default **on** —
`src/claude.ts:24`). Set `SMS_ENABLED=false` to remove the tool entirely.

### 2.2 The "is there even something worth texting?" guard

Before any consent logic, the handler checks whether the listing has a
**shareable public URL** (`isShareableListingUrl`, `src/listings.ts:52`). Many
listings are drafts not yet published to WordPress; their only URL is a
draft-style `?p=<id>` link that 404s for the recipient.

If there's no shareable URL, the handler **refuses to send** (`src/claude.ts:634`)
and returns a carefully worded instruction back to the model:

- If email is enabled: "offer to email the flyer instead" (pivot to
  `text_for_email`).
- If email is disabled: "tell the caller an agent will follow up" — and crucially
  *never claim a text was sent.*

This prevents Carmencita from cheerfully saying "I just texted you the link!"
when nothing went out — a real failure mode that erodes caller trust.

### 2.3 A2P 10DLC compliance — the double-opt-in dance

**Why this exists:** US carriers require Application-to-Person (A2P) traffic on
standard 10-digit long codes (10DLC) to be from a registered brand/campaign, and
require honoring opt-out keywords. Texting a first-time number "here's your
listing" with no recorded opt-in risks the number being filtered/blocked.

**Transactional vs. marketing distinction** (called out in code comments at
`src/sms.ts:48–51` and `:268–270`):

- **Transactional** messages — the "Reply YES to confirm" prompt, `HELP`
  replies, and `STOP` confirmations — are sent via the low-level `sendSms()`
  (`src/sms.ts:53`) with **no consent gating**. A2P treats these compliance
  replies separately; you're *required* to send them.
- **Marketing** messages — the actual property details — are gated. They only go
  out through `sendPropertySms()` (`src/sms.ts:128`), which checks
  `isConfirmed(to)` and `isOptedOut(to)` first and no-ops if consent isn't on
  file.

**The opt-in flow** (`requestPropertyConfirmation`, `src/sms.ts:160`):

1. If the caller previously opted out → return `'opted_out'`, send nothing.
2. If the caller already confirmed (returning caller) → **skip the dance** and
   send the property SMS immediately (`'sent_immediately'`).
3. Otherwise (first-time) → queue the property and text them:
   *"Fausto Commercial: Reply YES to receive property details by text. Msg & data
   rates may apply. Reply STOP to opt out. Reply HELP for help."*
   (`src/sms.ts:185`). Returns `'confirmation_sent'`.

When the caller texts **YES**, the inbound webhook (below) flips them to
`confirmed` and fires `deliverPendingPropertySms()` (`src/sms.ts:194`), which
sends **all** queued properties — so a caller can ask about three listings on the
call and get all three with a single YES.

Every marketing body carries the `Reply STOP to opt out.` footer
(`STOP_FOOTER`, `src/sms.ts:42`; appended in `buildPropertyBody`, `:120`).

### 2.4 Inbound keyword handling (STOP / START / HELP / YES / email)

Inbound texts hit `POST /sms/incoming` (`src/webhooks/sms.ts:33`), registered in
`server.ts:61`. Configure this URL in the Twilio Messaging Service ("A message
comes in"). The webhook always replies with an **empty `<Response/>` TwiML**
(`src/webhooks/sms.ts:30`) because all actual replies are sent via the REST API
(which gives delivery SIDs and richer errors than TwiML `<Message>`).

Classification is in `classifyInboundSms()` (`src/sms-keywords.ts:38`). It looks
only at the **first word** (lowercased, punctuation stripped) — matching how
carriers themselves parse opt-out keywords:

| Keyword bucket | Trigger words | Action (`src/webhooks/sms.ts:48`) |
|---|---|---|
| `STOP`  | stop, stopall, unsubscribe, end, quit, cancel, opt-out, optout, revoke | `setOptedOut()` + send stop-confirmation |
| `START` | start, unstop, yes-resubscribe | `setReSubscribed()` + send resubscribe reply |
| `HELP`  | help, info | send HELP reply (brand, msg-freq, rates, callback #) |
| `YES`   | yes, y, ok, okay, sure, confirm, sí, si | `setConfirmed()` + deliver pending property SMS |
| `EMAIL` | *(any message containing an email address)* | extract email, deliver pending flyer(s) by email |
| `OTHER` | anything else | logged only, no auto-reply |

Note the Spanish `sí`/`si` in the YES set (`src/sms-keywords.ts:33`) — many
callers are Spanish-speaking. The email detector is a deliberately loose regex
(`EMAIL_RE`, `src/sms-keywords.ts:36`), not full RFC 5322, because SMS replies
are short and a strict validator would reject more real addresses than it should.

**Subtle but important — START does not re-grant consent.** `setReSubscribed()`
(`src/sms-consent.ts:158`) clears the opt-out but sets status back to `pending`,
not `confirmed`. The caller must go through a fresh opt-in cycle before any new
marketing text fires. The START reply text says exactly this:
*"We'll text you again only after you opt in to a specific property on a call."*
(`src/sms.ts:283`).

### 2.5 Consent persistence across redeploys (Railway volume)

Consent state is the legally important data here — losing an opt-out and texting
someone again is exactly what compliance forbids. So it is persisted to disk.

`src/sms-consent.ts:44` picks the store directory in this order:
1. `CONSENT_STORE_DIR` (explicit override)
2. `RAILWAY_VOLUME_MOUNT_PATH` (set automatically by Railway when a volume is
   attached) → survives redeploys
3. `path.join(__dirname, '..', 'data')` (local dev fallback)

State is a JSON file `sms-consent.json` (`src/sms-consent.ts:48`), loaded lazily
on first access (`load()`, `:56`) and written synchronously after every change
(`persist()`, `:70`). Each record (`ConsentRecord`, `:21`) holds the phone
(E.164), status (`pending` / `confirmed` / `opted_out`), timestamp, source, and
the two pending queues described below.

> **Operational note:** because this is a flat JSON file on a single volume,
> there's no concurrency control beyond Node's single-threaded writes, and the
> store is *not* shared across multiple instances. The attendant runs as one
> Railway service, so this is fine today — but if it's ever horizontally scaled,
> consent state must move to a shared store (DB / Redis).

---

## 3. Email delivery: flyers by reply-to-text

### 3.1 The two pending queues

A `ConsentRecord` carries **two independent queues** (`src/sms-consent.ts:21–39`):

- **`pendingProperties`** — properties waiting on a **YES** to be texted
  (the SMS opt-in queue). TTL 10 min (`PENDING_TTL_MS`, `:49`).
- **`flyerProperties`** — properties to **email** when the caller replies with
  their email address. TTL 30 min (`FLYER_TTL_MS`, `:50`) — longer, because the
  caller needs time to hang up and type their email.

Keeping these separate is deliberate: the SMS-link flow and the email-flyer flow
have different consent semantics and different lifetimes.

### 3.2 The SMS-reply email-capture pattern (the clever bit)

The assistant tool is `text_for_email` (`src/claude.ts:442`, handler ~`:768`).
When a caller wants a flyer by email, Carmencita calls it. That triggers
`requestFlyerByEmail()` (`src/sms.ts:217`), which:

1. Refuses if opted out.
2. Adds the property to the `flyerProperties` queue (`addFlyerPending`).
3. Texts the caller:
   *"Reply to this text with your email and we'll send you the flyer for
   {property} (plus any others you ask about). One-time send — Msg & data rates
   may apply. Reply STOP to opt out, HELP for help."* (`src/sms.ts:232`).

This first text is itself the transactional opt-in message (it carries STOP), so
**no prior YES is required** — the comment at `src/sms.ts:212–216` explains this.

When the caller replies with an email, the inbound webhook's `EMAIL` case
(`src/webhooks/sms.ts:64`) calls `deliverFlyerByEmail()` (`src/sms.ts:244`),
which emails **every** queued flyer in one message, clears the queue, and texts
back a confirmation ("Sent! Check your inbox (and spam)…", `src/sms.ts:261`) or a
failure message with the office number (`:264`).

**De-dup subtlety** (`src/sms.ts:222–230`, `wasRecentlyFlyerPrompted`
`src/sms-consent.ts:257`): if the model calls `text_for_email` several times in
the same breath (multiple properties), only the *first* call sends the "reply
with your email" text; the rest are silently added to the queue. This dedup is
keyed off `flyerPromptedAt` (a 2-minute window, `FLYER_PROMPT_DEDUP_MS`,
`src/sms-consent.ts:51`) — **not** off the pending list, because property SMS
sends also populate that list passively and would wrongly suppress a genuine new
request. (This is exactly the bug the comment at `src/sms.ts:225` warns about.)

### 3.3 Multi-property batching into one email

`emailListingsToLead()` (`src/handlers/email.ts:67`) is the heart of email:

- Dedups the property ids, resolves each from Salesforce
  (`resolveListingForEmail`, `:46`).
- Keeps only "usable" listings — those with **either a flyer or a public URL**
  (`:70`). If none are usable, returns `notSent` so the assistant offers a
  callback instead (the product rule from the file header).
- Builds **one** email: every flyer PDF attached, every public link listed
  (`buildListingsEmailHtml`, `:116` — single-listing vs. multi-listing layouts).
- Subject is singular or "{N} properties" (`:79`).

`emailListingToLead()` (`:97`) is a thin single-property wrapper over the same
function, used by the verbal `send_email` path.

### 3.4 Reply-to = the listing agent

Each resolved listing carries `agentEmail` from Salesforce
(`listingAgentEmail`, `src/handlers/email.ts:58`). When **all** usable listings
share exactly one agent, that agent's address is set as the email's `Reply-To`
(`src/handlers/email.ts:86`). So when a lead replies to the flyer email, it goes
straight to the right agent — not to a generic inbox. If the batch spans multiple
agents, reply-to is left unset (no single right answer).

### 3.5 The verbal `send_email` fallback

`send_email` (`src/claude.ts:419`, handler ~`:699`) is the path where the caller
*insists* on saying their email out loud. The system prompt steers Carmencita to
**prefer `text_for_email`** and only use `send_email` if the caller insists,
reading the address back to confirm spelling (`src/claude.ts:231`). Both paths
converge on `emailListingsToLead`.

### 3.6 Resend transport + domain verification

Email is sent via **Resend** (`src/integrations/resend.ts`), swapped in for
SendGrid (now trial-only). It's a raw `fetch` against `https://api.resend.com/emails`
(no SDK), matching the codebase style.

- `sendEmail()` (`src/integrations/resend.ts:74`) hard-stops if
  `EMAIL_ENABLED !== 'true'` (`:75`) or if not configured (`:76`).
- Attachments are base64-encoded inline (`:86`).
- A plain-text alternative is auto-derived from the HTML (`htmlToText`, `:58`)
  for deliverability.
- **Every failure returns `{ok:false}`** — callers must treat a failed send as
  "not delivered" and fall back, never as success (header comment `:70`).

**Domain verification** (header `src/integrations/resend.ts:7–19`): for the very
first smoke test before verifying a domain, Resend only allows sending from
`onboarding@resend.dev` to your own account email. For production you must verify
`faustocommercial.com` in Resend (adds SPF/DKIM DNS records) before sending from
`listings@faustocommercial.com` to real leads, or mail lands in spam.

---

## 4. Flyer handling: which PDF gets attached

Two distinct flyer mechanisms exist; don't confuse them:

### 4.1 Flyer **selection** from Salesforce Files (the live email path)

`src/integrations/sf-files.ts` finds and downloads an *existing* flyer PDF that
the marketing team uploaded to the Property record. Flyers attach to `Property__c`
as modern Salesforce Files (ContentDocumentLink → ContentVersion). The naming
convention is `<ADDRESS>-<AGENT>-FLYER.pdf` in `PathOnClient`.

`findFlyerVersion()` (`src/integrations/sf-files.ts:51`) picks the best PDF using
a **deliberately conservative** order (header `:8–16`):

1. A PDF whose Title **or** filename contains "flyer" (`FLYER_RE`, `:34`).
2. Else, if there's exactly **one** PDF on the record, use it.
3. Else **null** — ambiguous; the caller does *not* attach a guess.

Returning null when uncertain is intentional: emailing the wrong document (e.g.
a survey or a lease) to a lead is worse than emailing nothing. When there's no
confident flyer and no public URL, the email path returns `notSent` and
Carmencita offers a callback. `propertyHasFlyer()` (`:71`) is a cheap
no-download existence check; `getFlyerForProperty()` (`:80`) downloads the
`VersionData` bytes (`downloadVersion`, `:98`) for attachment.

### 4.2 Flyer **generation** from a template (the on-demand render path)

`src/integrations/flyer.ts` + `src/handlers/flyer.ts` are a *separate* feature:
generating a flyer from listing data when no PDF exists. `renderFlyerForProperty()`
(`src/integrations/flyer.ts:37`) pulls the Property from SF, fills an HTML
template via a `{{merge_tag}}` system (`propertyToTags` `:81`, `renderTemplate`
`:135` — double-brace escaped, triple-brace raw, mustache-style), and optionally
converts to PDF.

- Route: `GET /api/flyer/:sfPropertyId` (HTML preview) or `?pdf=1` (PDF), in
  `src/handlers/flyer.ts:21`, registered at `server.ts:64`. Auth is a shared
  secret `FLYER_SHARED_SECRET` via `X-Auth` header or `?secret=` query param
  (so a Salesforce formula-button link can carry it).
- **PDF rendering is a deliberate TODO.** `renderPdfFromHtml()`
  (`src/integrations/flyer.ts:244`) only works if `PDFSHIFT_API_KEY` is set
  (PDFShift SaaS backend, `:260`); otherwise it returns a clear error. The
  alternative (Puppeteer/headless Chromium) is documented in the header but not
  wired, intentionally left open until the marketing team finalizes templates.
- The default template (`DEFAULT_FLYER_TEMPLATE`, `:155`) is a styled skeleton
  meant to be replaced wholesale by marketing's HTML — **keeping the tag names
  intact** preserves the data binding.

> The live email path (4.1) uses **selection**, not generation. The generation
> path (4.2) is built but its PDF backend is unconfigured; today it serves HTML
> previews for template iteration.

---

## 5. Non-obvious / clever engineering worth calling out

1. **Email capture by SMS reply** — eliminates spelling email addresses aloud on
   a live, latency-sensitive call. Probably the single highest-leverage UX
   decision in this subsystem (§3.2).
2. **Two-queue model** — separate `pendingProperties` (YES-gated SMS, 10-min) and
   `flyerProperties` (email-on-reply, 30-min) with different TTLs reflect their
   different real-world timing.
3. **Batch-on-confirm** — both YES and email-reply deliver *all* queued items at
   once, so multi-property calls produce one clean follow-up, not a spam burst
   (`deliverPendingPropertySms` `src/sms.ts:194`, `deliverFlyerByEmail` `:244`).
4. **The prompt-dedup-vs-pending-list trap** — keying flyer-prompt dedup off a
   dedicated `flyerPromptedAt` timestamp instead of the pending list avoids a
   real bug where a passive property-text would suppress a genuine email request
   (`src/sms.ts:225`).
5. **Refuse-and-instruct, never silently lie** — when no shareable URL exists,
   the SMS handler returns prose telling the model *exactly* what to say (and not
   say) so Carmencita never claims a text went out that didn't
   (`src/claude.ts:637–643`).
6. **Conservative flyer selection** — null-on-ambiguity rather than attach-a-guess
   (`src/integrations/sf-files.ts:67`).
7. **Reply-to routing** — flyer-email replies land in the listing agent's inbox
   automatically (`src/handlers/email.ts:86`).
8. **MessagingServiceSid-first send** — A2P approval lives on the Twilio
   Messaging Service, so `sendSms` prefers `MessagingServiceSid` over a raw
   `From` number when configured (`src/sms.ts:66–73`).
9. **Lazy import to break a module cycle** — `deliverFlyerByEmail` imports the
   email handler at call time (`src/sms.ts:252`).

---

## 6. Key files & functions (quick reference)

| File | Purpose | Key symbols |
|---|---|---|
| `src/sms.ts` | SMS send + opt-in orchestration | `sendSms:53`, `sendPropertySms:128`, `requestPropertyConfirmation:160`, `deliverPendingPropertySms:194`, `requestFlyerByEmail:217`, `deliverFlyerByEmail:244`, `sendHelpReply:272`, `sendStopConfirmation:277`, `sendStartReply:282` |
| `src/sms-consent.ts` | Persisted consent + pending queues | `STORE_DIR:44`, `load:56`, `persist:70`, `isConfirmed:88`, `isOptedOut:92`, `addPendingProperty:97`, `setConfirmed:127`, `setOptedOut:143`, `setReSubscribed:158`, `addFlyerPending:204`, `getFlyerPending:225`, `wasRecentlyFlyerPrompted:257` |
| `src/sms-keywords.ts` | Inbound keyword classification | `classifyInboundSms:38`, `extractEmail:54` |
| `src/webhooks/sms.ts` | Inbound `POST /sms/incoming` | `registerSmsWebhookRoutes:32` |
| `src/handlers/email.ts` | Email orchestration / batching | `emailListingsToLead:67`, `emailListingToLead:97`, `buildListingsEmailHtml:116`, `registerEmailRoutes:160` |
| `src/integrations/resend.ts` | Resend transport | `isEmailConfigured:54`, `sendEmail:74` |
| `src/integrations/sf-files.ts` | Flyer selection + download from SF | `findFlyerVersion:51`, `propertyHasFlyer:71`, `getFlyerForProperty:80` |
| `src/integrations/flyer.ts` | Flyer generation (HTML→PDF) | `renderFlyerForProperty:37`, `propertyToTags:81`, `renderTemplate:135`, `DEFAULT_FLYER_TEMPLATE:155`, `renderPdfFromHtml:244` |
| `src/handlers/flyer.ts` | `GET /api/flyer/:id` route | `registerFlyerRoutes:20` |
| `src/claude.ts` | Tool defs + handlers | `send_property_sms:392`, `send_email:419`, `text_for_email:442`; handlers ~`600`, ~`699`, ~`768` |
| `src/server.ts` | Route wiring | `:61` SMS webhook, `:64` flyer, `:67` email |

---

## 7. Configuration / environment variables

| Var | Used in | Meaning |
|---|---|---|
| `TWILIO_ACCOUNT_SID` (or `TWILIO_SID`) | `src/sms.ts:31` | Twilio account (shared with voice) |
| `TWILIO_AUTH_TOKEN` (or `TWILIO_TOKEN`) | `src/sms.ts:33` | Twilio auth token |
| `TWILIO_PHONE_NUMBER` | `src/sms.ts:35` | From-number for SMS (fallback if no service) |
| `TWILIO_MESSAGING_SERVICE_SID` | `src/sms.ts:39` | **Preferred** — A2P 10DLC routing lives on the Messaging Service; send via it once the number is attached |
| `SMS_ENABLED` | `src/claude.ts:24` | Default **true**; `false` removes the SMS tool |
| `EMAIL_ENABLED` | `src/sms.ts:46`, `resend.ts:24`, `claude.ts:25` | Default **false**; `true` turns on email tools + the "reply with email" SMS lines |
| `RESEND_API_KEY` | `src/integrations/resend.ts:21` | Resend key (`re_…`) |
| `EMAIL_FROM` | `src/integrations/resend.ts:22` | Verified sender (default `listings@faustocommercial.com`) |
| `EMAIL_FROM_NAME` | `src/integrations/resend.ts:23` | Display name (default "Fausto Commercial") |
| `CONSENT_STORE_DIR` | `src/sms-consent.ts:45` | Override for consent store dir |
| `RAILWAY_VOLUME_MOUNT_PATH` | `src/sms-consent.ts:46` | Auto-set by Railway; where `sms-consent.json` lives in prod |
| `FLYER_SHARED_SECRET` | `src/handlers/flyer.ts:29` | Auth for the `/api/flyer/:id` route |
| `PDFSHIFT_API_KEY` | `src/integrations/flyer.ts:245` | Enables PDF generation via PDFShift (else HTML only) |
| `ADMIN_KEY` | `src/handlers/email.ts:24` | Guards `POST /email/test` (default `fausto2026`) |

**Test endpoint:** `POST /email/test?key=<ADMIN_KEY>` with `{ to, propertyId }`
(`src/handlers/email.ts:161`) verifies Resend + flyer fetch end-to-end.

---

## 8. Gotchas & maintenance notes

- **A2P registration is tied to the Twilio account/brand/campaign**, not the
  code. If the Twilio number, brand, or Messaging Service changes, the 10DLC
  registration must be redone and `TWILIO_MESSAGING_SERVICE_SID` updated.
  Marketing SMS through an unregistered service gets carrier-filtered.
- **The inbound webhook URL must be set in Twilio** to `POST {APP_URL}/sms/incoming`
  on the Messaging Service. If it isn't, STOP/HELP/YES/email replies are silently
  lost — a compliance hazard for STOP in particular.
- **Consent store is a single-instance JSON file.** Don't horizontally scale the
  service without moving consent to a shared store, or you'll get inconsistent
  opt-out state across instances (§2.5).
- **Don't lose the Railway volume.** It holds opt-outs. If `RAILWAY_VOLUME_MOUNT_PATH`
  isn't mounted, the store silently falls back to ephemeral `data/` and opt-outs
  vanish on redeploy.
- **Flyer identification is heuristic.** Selection only works reliably when the
  PDF is named with "flyer" or is the only PDF on the record. Properties with
  several unnamed PDFs return null (no attachment). The standing fix is the
  bulk-rename cleanup to `<ADDRESS>-<AGENT>-FLYER.pdf` (see the listing-data-model
  memory); until then, expect some misses.
- **Email defaults OFF.** `EMAIL_ENABLED` gates not just sending but the assistant
  prompt lines that *offer* email and the `send_email`/`text_for_email` tools
  (`src/claude.ts:416`). Flip it on only after Resend domain verification.
- **PDF generation backend is unconfigured.** The `/api/flyer` route serves HTML
  unless `PDFSHIFT_API_KEY` is set. This is independent of the live email path,
  which attaches *existing* SF flyer PDFs, not generated ones.
- **Resend `contentType` on attachments is ignored** — Resend infers MIME from
  filename (`src/integrations/resend.ts:33`); the field is kept only for interface
  parity. Make sure attachment filenames end in `.pdf` (they're normalized to in
  `getFlyerForProperty`, `src/integrations/sf-files.ts:90`).
- **START ≠ re-consent.** A resubscribed caller is `pending`, not `confirmed`;
  they need a fresh opt-in before any marketing text fires (§2.4).
