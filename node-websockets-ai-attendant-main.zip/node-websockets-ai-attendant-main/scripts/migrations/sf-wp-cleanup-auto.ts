/**
 * Auto-fix the obvious data-integrity issues from the May 2026 cleanup.
 *
 * Three categories:
 *   A — ORPHANS:  SF.WP_Post_ID__c points at a deleted WP post (fix link)
 *   C — UNLINKED+MATCH:  SF has no link but a clear WP post exists at the same address
 *   B — WE-CREATED-DUPE:  SF is linked to a draft we created today, but an
 *       older marketing-curated WP post already existed for that property
 *       → relink SF to older, retire our new duplicate to draft
 *
 * What this script does NOT touch:
 *   - Cases needing human judgement (different listing types, same building
 *     different unit, ambiguous title matches, etc.)
 *   - False-positive number matches (e.g., wp:23429 vs wp:20483 — different
 *     cities, my matcher was too loose)
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-wp-cleanup-auto.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-wp-cleanup-auto.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

// ─── The fix list ────────────────────────────────────────────────────────────
interface SfLinkOp {
  sfId: string;
  label: string;
  // Either set a WP id or explicitly null both link fields
  setWpId: number | null;
  expectCurrentWpId?: number | null; // safety: confirms current state before write
}

interface WpRetireOp {
  wpId: number;
  canonicalWpId: number;
  reason: string;
}

const SF_LINKS: SfLinkOp[] = [
  // A — ORPHANS
  { sfId: 'a0RJw000008GleLMAS', label: '1360 NW 88 Ave Doral (orphan)', setWpId: 23357, expectCurrentWpId: 63207 },
  { sfId: 'a0RJw000008GmX7MAK', label: '700 E 1 AVE Hialeah Closed Lost (orphan, no canonical)', setWpId: null, expectCurrentWpId: 23555 },

  // C — UNLINKED + clear match
  { sfId: 'a0RJw000008Giy9MAC', label: '13405 SW 128th St #205B (Closed Lost)', setWpId: 22961, expectCurrentWpId: null },
  { sfId: 'a0RJw000008GlfuMAC', label: '1432 W Flagler St (Closed Lost)', setWpId: 22413, expectCurrentWpId: null },
  { sfId: 'a0RJw000008GljAMAS', label: '5201 NW 36th Ave (Closed Lost)', setWpId: 23546, expectCurrentWpId: null },
  // SKIPPED: a0RJw000008GnPzMAK (21 W 49th St Hialeah) — user found 3 published
  //   duplicates at this address (predates our work). Will investigate which is
  //   canonical before linking SF.
  { sfId: 'a0RJw000008HYDbMAO', label: '943 SW 9 ave (will fail unless Listing Agent set in SF first)', setWpId: 49056, expectCurrentWpId: null },
  { sfId: 'a0RJw000008wN7hMAE', label: '1610 N Dixie Hwy Hollywood', setWpId: 52235, expectCurrentWpId: null },
  { sfId: 'a0RJw0000092GGPMA2', label: '3600 NW 95 St', setWpId: 62141, expectCurrentWpId: null },
  { sfId: 'a0RJw000009DgXJMA0', label: '752-776 W Flagler St', setWpId: 22496, expectCurrentWpId: null },
  { sfId: 'a0RJw000009DipFMAS', label: '7657-7667 NW 50th St', setWpId: 49057, expectCurrentWpId: null },
  // SKIPPED: a0RJw0000093RPtMAM (2395 NW 36 St) — user found wp:62148 is the ACTIVE
  //   listing ($10K/mo) and wp:22434 is off-market. The "older wins" heuristic
  //   doesn't apply here; user will reconcile manually.

  // B — WE-CREATED-DUPE → link SF to older, retire newer
  { sfId: 'a0RJw000008GimtMAC', label: '720 N Federal Hwy (relink to original)', setWpId: 22376, expectCurrentWpId: 48964 },
  { sfId: 'a0RJw000008Su13MAC', label: 'Allapattah 27th Ave Auto Shop (relink to original)', setWpId: 34024, expectCurrentWpId: 49069 },
  { sfId: 'a0RJw000008wNSfMAM', label: '4343 NW 17 Ave Sanctuary (relink to original)', setWpId: 63125, expectCurrentWpId: 63142 },
  { sfId: 'a0RJw000008xlW9MAI', label: '3901 Orange Ave Car Wash — for-sale (relink to original wp:57510)', setWpId: 57510, expectCurrentWpId: 63133 },
  { sfId: 'a0RJw00000958B3MAI', label: '6029 Miramar Parkway (relink to original)', setWpId: 62161, expectCurrentWpId: 63176 },
  // SKIPPED based on user review:
  //   - a0RJw000008Ggl8MAC (1050 SW 7th St) — keep current wp:48951
  //   - a0RJw000008GiWlMAK (1902 Rogero Rd) — keep current wp:48955
  //   - a0RJw000008GmCBMA0 (997 NE 125 ST) — both look like dupes in SF too,
  //     user will ask agent which is canonical
  //   - a0RJw0000093SCHMA2 (4634 NW 27 Ave) — duplicate SF records, user will ask
];

// WP posts to retire — move to draft AND prefix title with `[DUPLICATE - see
// wp:N]` so they're easy to find in WP admin (Properties → Draft → search
// "[DUPLICATE"). We do NOT delete: the user trashes them manually in WP UI
// once they've verified.
const WP_RETIRES: WpRetireOp[] = [
  { wpId: 48964, canonicalWpId: 22376, reason: '720 N Federal Hwy' },
  { wpId: 49069, canonicalWpId: 34024, reason: 'Allapattah 27th Ave Auto Shop' },
  { wpId: 63142, canonicalWpId: 63125, reason: '4343 NW 17 Ave Sanctuary' },
  { wpId: 63133, canonicalWpId: 57510, reason: '3901 Orange Ave for-sale — user confirmed' },
  { wpId: 63176, canonicalWpId: 62161, reason: '6029 Miramar Parkway' },
  // SKIPPED:
  //   - wp:23511 (21 W 49th St Hialeah) — user found 3 dups at this address,
  //     will investigate canonical first
  //   - wp:48951, wp:48955 (1050 SW 7th, 1902 Rogero) — user keeping current
  //   - wp:49012 (997 NE 125 ST) — user to investigate
  //   - wp:63150 (4634 NW 27 Ave) — user to investigate
  //   - wp:62148 (2395 NW 36 St) — user said this is the ACTIVE listing, do NOT retire
  //   - wp:23511 (21 W 49th St) — user to investigate the 3 dups first
];

// ─── Helpers ─────────────────────────────────────────────────────────────────
async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true } as const;
  return { ok: false as const, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true } as const;
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false as const, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false as const, error: lastError };
  }
  return { ok: false as const, error: lastError };
}

async function getWpLink(wpId: number): Promise<string | null> {
  const res = await fetch(
    `${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}?context=edit&_fields=link`,
    { headers: { Authorization: WP_AUTH } }
  );
  if (!res.ok) return null;
  const data = (await res.json()) as { link?: string };
  return data.link || null;
}

async function wpRetire(
  wpId: number,
  canonicalWpId: number
): Promise<{ ok: boolean; error?: string }> {
  // Two-step retire: move to draft, then prefix title with [DUPLICATE - see wp:N].
  //
  // We do these as TWO separate PATCH calls because Houzez has a hook that
  // silently drops the status field when title and status are sent together
  // (we discovered this empirically earlier this session). Splitting them
  // makes both stick.
  //
  // We do NOT call DELETE — the user trashes manually in WP UI after
  // verifying. The [DUPLICATE - see wp:N] prefix makes them easy to find.

  // Fetch current title and status so we can:
  //   - skip status PATCH if already draft (idempotent)
  //   - skip title PATCH if already prefixed (idempotent — re-runs are safe)
  //   - preserve the original title content after the prefix
  const fetchRes = await fetch(
    `${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}?context=edit&_fields=title,status`,
    { headers: { Authorization: WP_AUTH } }
  );
  if (!fetchRes.ok) {
    return { ok: false, error: `Fetch failed: ${fetchRes.status}` };
  }
  const data = (await fetchRes.json()) as {
    title?: { rendered?: string; raw?: string };
    status?: string;
  };
  const currentTitle = (data.title?.raw || data.title?.rendered || '').toString();
  const currentStatus = data.status || '';

  // Step 1: status → draft (only if currently not draft)
  if (currentStatus !== 'draft') {
    const r1 = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}`, {
      method: 'POST',
      headers: { Authorization: WP_AUTH, 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'draft' }),
    });
    if (!r1.ok) {
      return {
        ok: false,
        error: `Status PATCH failed: ${r1.status} ${(await r1.text()).slice(0, 200)}`,
      };
    }
  }

  // Step 2: prepend [DUPLICATE] tag if not already
  if (!currentTitle.startsWith('[DUPLICATE')) {
    const newTitle = `[DUPLICATE - see wp:${canonicalWpId}] ${currentTitle}`;
    const r2 = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties/${wpId}`, {
      method: 'POST',
      headers: { Authorization: WP_AUTH, 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: newTitle }),
    });
    if (!r2.ok) {
      return {
        ok: false,
        error: `Title PATCH failed: ${r2.status} ${(await r2.text()).slice(0, 200)}`,
      };
    }
  }

  return { ok: true };
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

// ─── Main ────────────────────────────────────────────────────────────────────
async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log(`\n🧹 Auto-fix obvious SF↔WP cleanup ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();

  // Safety: confirm current state of each SF record matches expectations
  console.log('── Safety check: verifying current SF state ──\n');
  const ids = SF_LINKS.map((op) => op.sfId);
  const sfRecs = await sfQuery<{ Id: string; WP_Post_ID__c: number | null; Address__c: string | null }>(
    token,
    instance,
    `SELECT Id, WP_Post_ID__c, Address__c FROM Property__c WHERE Id IN ('${ids.join("','")}')`
  );
  const sfById = new Map(sfRecs.map((r) => [r.Id, r]));

  let driftCount = 0;
  for (const op of SF_LINKS) {
    const sf = sfById.get(op.sfId);
    if (!sf) {
      console.error(`   ❌ ${op.sfId} not found in SF — aborting`);
      process.exit(1);
    }
    const current = sf.WP_Post_ID__c;
    if (op.expectCurrentWpId !== undefined && current !== op.expectCurrentWpId) {
      console.warn(
        `   ⚠️  ${op.sfId} (${op.label}): expected current WP_Post_ID__c=${op.expectCurrentWpId} but found ${current}`
      );
      driftCount++;
    }
  }
  if (driftCount > 0) {
    console.warn(`\n   ${driftCount} drift(s) detected. The audit data may be stale.`);
    console.warn(`   Proceeding will overwrite these records — review the warnings above.\n`);
    if (!DRY_RUN) {
      console.warn(`   ABORTING for safety. Re-run the audit, update this script's expectCurrentWpId values, and try again.`);
      process.exit(1);
    }
  } else {
    console.log(`   ✓ All ${SF_LINKS.length} records in expected state.\n`);
  }

  // Pre-fetch WP permalinks for each target
  console.log('── Fetching WP permalinks for SF link targets ──\n');
  const wpLinks = new Map<number, string>();
  for (const op of SF_LINKS) {
    if (op.setWpId === null) continue;
    const link = await getWpLink(op.setWpId);
    if (!link) {
      console.error(`   ❌ wp:${op.setWpId} not fetchable — aborting`);
      process.exit(1);
    }
    wpLinks.set(op.setWpId, link);
  }
  console.log(`   ✓ All ${wpLinks.size} permalinks fetched.\n`);

  // Show plan
  console.log('── Plan ──\n');
  console.log(`SF link updates:    ${SF_LINKS.length}`);
  console.log(`WP retires (draft): ${WP_RETIRES.length}`);
  console.log('');
  for (const op of SF_LINKS) {
    console.log(`SF ${op.sfId}  ${op.label}`);
    console.log(`   WP_Post_ID__c: ${op.expectCurrentWpId ?? '(null)'}  →  ${op.setWpId ?? '(null)'}`);
    if (op.setWpId !== null) {
      console.log(`   Public_URL__c: → ${wpLinks.get(op.setWpId)}`);
    } else {
      console.log(`   Public_URL__c: → (null)`);
    }
  }
  console.log('');
  for (const op of WP_RETIRES) {
    console.log(`Retire wp:${op.wpId} → status=draft + title prefix "[DUPLICATE - see wp:${op.canonicalWpId}]"  (${op.reason})`);
  }
  console.log('');

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  // Execute SF link updates
  console.log('── Executing SF link updates ──\n');
  let sfOk = 0;
  let sfErr = 0;
  for (const op of SF_LINKS) {
    const fields: Record<string, unknown> = {
      WP_Post_ID__c: op.setWpId,
      Public_URL__c: op.setWpId === null ? null : wpLinks.get(op.setWpId),
    };
    const result = await sfUpdateWithRetry(token, instance, op.sfId, fields);
    if (result.ok) {
      console.log(`   ✓ ${op.sfId} → wp:${op.setWpId ?? 'null'}`);
      sfOk++;
    } else {
      console.warn(`   ❌ ${op.sfId}: ${result.error}`);
      sfErr++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  // Execute WP retires
  console.log('\n── Executing WP retires (draft + [DUPLICATE] title prefix) ──\n');
  let wpOk = 0;
  let wpErr = 0;
  for (const op of WP_RETIRES) {
    const r = await wpRetire(op.wpId, op.canonicalWpId);
    if (r.ok) {
      console.log(`   ✓ wp:${op.wpId} → draft + tagged [DUPLICATE - see wp:${op.canonicalWpId}]`);
      wpOk++;
    } else {
      console.warn(`   ❌ wp:${op.wpId}: ${r.error}`);
      wpErr++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`SF link updates:    ${sfOk} / ${SF_LINKS.length}  (errors: ${sfErr})`);
  console.log(`WP retires:         ${wpOk} / ${WP_RETIRES.length}  (errors: ${wpErr})`);
  console.log('');
  console.log('Next steps:');
  console.log('  1. Find the retired posts in WP admin: Properties → Draft → search "[DUPLICATE"');
  console.log('     The title prefix shows which canonical WP id to verify against.');
  console.log('     Trash them manually once verified (we never auto-delete).');
  console.log('  2. The remaining cases (different-listing-type, same-building-different-unit, etc.) need team input.');
  console.log('  3. SF a0RJw000008HYDbMAO will keep failing until you set Listing Agent in SF.');
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
