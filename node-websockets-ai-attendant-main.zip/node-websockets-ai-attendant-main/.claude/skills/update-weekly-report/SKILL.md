---
name: update-weekly-report
description: Use to update the weekly marketing report's manual numbers from a GA4 screenshot (and the project-work log), then open a PR. Triggers — "update this week's report", "update the report numbers", "new GA4 numbers", user drops a GA4 screenshot and asks to refresh the report. Edits ONLY src/report-manual.ts; the live sections (Salesforce, Campaign Monitor, ClickUp) update themselves.
---

# Update the weekly marketing report (manual numbers → PR)

The report at `GET /report` pulls Salesforce, Campaign Monitor, and ClickUp
**live** — those never need touching. Only two things are entered by hand each
week, and both live in **`src/report-manual.ts`** (no logic, safe to edit):

1. `MANUAL_GA4` — the GA4 traffic numbers (from a screenshot)
2. `AUTOMATION_LOG` — the Automation & Project Work list

**Never edit `src/report.ts` or `src/report-routes.ts` for a weekly update.**
If you find yourself changing windowing, metrics, or HTML, stop — that's not this
task.

## Inputs you need from the user
- A **GA4 screenshot** (or numbers) for the **current** window, and ideally the
  **prior** window. If only current is given, roll the existing `current` block
  down into `prior` (see below).
- Optionally, the week's **project-work items** for `AUTOMATION_LOG` (or a note
  like "no changes to the work log").

## The two report windows (so you screenshot/label the right ranges)
Anchored to the **report Friday** (the most recent Friday):
- **Current (GA4):** Saturday–Friday — **7 days, includes the weekend**
  (e.g. report Fri Jul 3 → Jun 27–Jul 3).
- **Prior:** the previous **Monday–Friday**, 5 days (e.g. Jun 22–26).

If the user's screenshot covers a different range, tell them the exact dates to
pull and ask for a corrected shot rather than guessing.

## Procedure

1. **Read the numbers** from the screenshot. Map GA4's labels → fields:
   | GA4 label | field |
   |---|---|
   | Active users | `activeUsers` |
   | New users | `newUsers` |
   | Sessions | `sessions` |
   | Views / Page views | `screenPageViews` |
   | Key events | `keyEvents` |
   | Avg engagement time per active user | `avgEngagementPerUserSec` — **convert to seconds** (2m 22s → 142) |

2. **Roll forward** in `MANUAL_GA4`: if the user gave only the current week, copy
   the existing `current` block into `prior` first, then overwrite `current` with
   the new numbers. `userEngagementDuration` is `activeUsers × avgEngagementPerUserSec`
   (the file uses `CURRENT_ACTIVE_USERS` / `CURRENT_ENGAGEMENT_SEC` consts for the
   current block — update those two and the derived field follows).

3. **Update `AUTOMATION_LOG`** if the user gave work items:
   - Set `periodLabel` to the current **Mon–Fri** work week (e.g. `'Jun 29 – Jul 3, 2026'`).
   - **One entry per item** — never cluster multiple items into one bullet.
   - Optional `status`: `LIVE | DONE | IN PROGRESS | NEW | NEEDS`.
   - **Do not** include work done by Cristi (attribute clearly if it must appear).

4. **Verify** it still compiles (Node isn't always on PATH — use the local tsc):
   ```bash
   node ./node_modules/typescript/bin/tsc --noEmit
   ```
   Optionally preview the numbers: `npm run dev` then open
   `http://localhost:3000/report?key=$ADMIN_KEY` — confirm the GA4 cards + WoW
   deltas match the screenshot. (The live SF/CM/ClickUp sections may be empty
   locally if those creds aren't in `.env.local` — that's fine.)

5. **Open a PR** (do not merge — the report owner reviews it):
   - Branch: `report/week-<report-friday>` (e.g. `report/week-2026-07-03`).
   - Commit only `src/report-manual.ts`. End the message with:
     `Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>`
   - Push (uses the cached GitHub credential). Open the PR with `gh pr create`
     if available; otherwise POST to
     `https://api.github.com/repos/vasquezjesus2710/node-websockets-ai-attendant/pulls`
     using the token from `git credential fill` (never print the token).
   - Reply with the PR URL and a one-line summary of the numbers changed.

## Guardrails
- Read-only for the live data — you are only typing numbers a human read off GA4.
- If a number looks implausible (e.g. 10× last week), flag it and confirm before writing.
- Keep the framing rules intact: this task changes numbers only, never the layout
  or the positive-framing logic in the renderer.
- Once `GA4_SA_JSON` is configured in the environment, GA4 goes live and
  `MANUAL_GA4` is ignored automatically — at that point this skill only maintains
  the `AUTOMATION_LOG`.
