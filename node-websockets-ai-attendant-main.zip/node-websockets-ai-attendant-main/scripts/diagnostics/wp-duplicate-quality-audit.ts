/**
 * Re-audit every dedupe decision using a STRICTER address-normalization that
 * handles the Houzez-geocoded format ("1800, Northwest 19th Terrace, Miami,
 * Miami-Dade County, Florida, 33125, United States").
 *
 * The old normalize used `addr.split(',')[0]` — which for the geocoded format
 * returned just the house number ("1800"), causing false-positive matches
 * between completely different streets that happened to share a number.
 *
 * What this script audits:
 *   A. Each of the 48 [DUPLICATE]-tagged WP posts → does its real address
 *      actually match the canonical's real address? TRUE / FALSE / ambiguous.
 *   B. Each SF record's WP_Post_ID__c → does the linked WP post's address
 *      actually match the SF.Address__c? Or did the dedupe relink it to a
 *      different building?
 *
 * Read-only. No fixes.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';
const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/**
 * Smart normalizer. Handles BOTH:
 *   - "440 sw 8 st, miami"                                 → "440 sw 8 st"
 *   - "1800, Northwest 19th Terrace, Miami, Florida, ..."  → "1800 nw 19 ter"
 *
 * Strategy:
 *   - Split by comma
 *   - If first part is JUST digits (and dashes/spaces), it's the geocoded
 *     format — also consume the next part(s) until we have a token with
 *     letters (the street name)
 *   - Then strip city/state/zip/country tail by looking for street-type
 *     suffix and cutting after it
 *   - Apply standard direction/suffix normalization
 */
function smartNormalize(addr: string | null | undefined): string {
  if (!addr) return '';
  const parts = addr
    .toLowerCase()
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (parts.length === 0) return '';

  // Build the street portion by consuming parts until we have something
  // resembling "number + street name". If the first part is just digits,
  // combine with subsequent parts.
  let streetPart = parts[0];
  let i = 1;
  while (i < parts.length && /^[\d\s\-#]+$/.test(streetPart)) {
    streetPart = streetPart + ' ' + parts[i];
    i++;
  }

  let a = streetPart;
  a = a.replace(/[#.]/g, ' ');
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  a = a.replace(/\b(highway|hwy)\b/g, 'hwy');
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

// The OLD broken normalize, for comparison
function oldNormalize(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().split(',')[0];
  a = a.replace(/[#.]/g, ' ');
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

function extractCanonicalRef(title: string): number | null {
  const decoded = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const m = decoded.match(/\[DUPLICATE[\s\S]*?see wp:(\d+)\]/i);
  return m ? parseInt(m[1], 10) : null;
}

function isDuplicateTagged(title: string): boolean {
  return /\[DUPLICATE/i.test(title);
}

async function main() {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET || !WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔍 Dedupe-quality audit (smart-normalize re-check)\n');

  // Load both sides
  const { token, instance } = await sfAuth();
  const [sfRecords, wpPosts] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Name, Address__c, WP_Post_ID__c
         FROM Property__c
        WHERE WP_Post_ID__c != NULL`
    ),
    fetchAllWpPosts(),
  ]);
  console.log(`SF records with WP link: ${sfRecords.length}`);
  console.log(`WP posts: ${wpPosts.length}\n`);

  const wpById = new Map<number, WpPost>();
  for (const p of wpPosts) wpById.set(p.id, p);

  // ───────────────────────────────────────────────────────────────────
  // PART A: re-verify each [DUPLICATE]-tagged post
  // ───────────────────────────────────────────────────────────────────
  console.log('═'.repeat(70));
  console.log('PART A — verify each [DUPLICATE]-tagged post is REALLY a duplicate');
  console.log('═'.repeat(70));

  const tagged = wpPosts.filter((p) => isDuplicateTagged(p.title));
  const truePositives: { post: WpPost; canonical: WpPost }[] = [];
  const falsePositives: { post: WpPost; canonical: WpPost | null; canonicalId: number | null }[] = [];
  const ambiguous: { post: WpPost; reason: string }[] = [];

  for (const post of tagged) {
    const canonicalId = extractCanonicalRef(post.title);
    if (!canonicalId) {
      ambiguous.push({ post, reason: 'could not extract canonical id from title' });
      continue;
    }
    const canonical = wpById.get(canonicalId);
    if (!canonical) {
      ambiguous.push({ post, reason: `canonical wp:${canonicalId} no longer exists` });
      continue;
    }
    if (!post.fave_property_address || !canonical.fave_property_address) {
      ambiguous.push({ post, reason: 'missing address on one or both posts' });
      continue;
    }
    const a = smartNormalize(post.fave_property_address);
    const b = smartNormalize(canonical.fave_property_address);
    if (a === b) {
      truePositives.push({ post, canonical });
    } else {
      falsePositives.push({ post, canonical, canonicalId });
    }
  }

  console.log(`\n  ✅ TRUE duplicates (addresses match):     ${truePositives.length}`);
  console.log(`  ❌ FALSE positives (addresses differ):    ${falsePositives.length}`);
  console.log(`  ⚠️  Ambiguous (can't determine):           ${ambiguous.length}\n`);

  if (falsePositives.length > 0) {
    console.log(`── FALSE POSITIVES — these should NOT be tagged as duplicates ──\n`);
    for (const fp of falsePositives) {
      console.log(`  wp:${fp.post.id}  (tagged duplicate of wp:${fp.canonicalId})`);
      console.log(`     "${fp.post.title.replace(/&#8211;/g, '–').slice(0, 70)}"`);
      console.log(`     address: "${fp.post.fave_property_address}"`);
      console.log(`     normalized: "${smartNormalize(fp.post.fave_property_address)}"`);
      if (fp.canonical) {
        console.log(`  vs wp:${fp.canonical.id}`);
        console.log(`     "${fp.canonical.title.replace(/&#8211;/g, '–').slice(0, 70)}"`);
        console.log(`     address: "${fp.canonical.fave_property_address}"`);
        console.log(`     normalized: "${smartNormalize(fp.canonical.fave_property_address)}"`);
      }
      console.log('');
    }
  }

  if (ambiguous.length > 0) {
    console.log(`── AMBIGUOUS — manual review needed ──\n`);
    for (const a of ambiguous) {
      console.log(`  wp:${a.post.id}  "${a.post.title.replace(/&#8211;/g, '–').slice(0, 60)}" — ${a.reason}`);
    }
    console.log('');
  }

  // ───────────────────────────────────────────────────────────────────
  // PART B: SF records linked to a WP post whose address doesn't match
  // ───────────────────────────────────────────────────────────────────
  console.log('═'.repeat(70));
  console.log('PART B — SF records linked to a WP post at a DIFFERENT address');
  console.log('═'.repeat(70));

  const mislinkedSf: {
    sf: SfProperty;
    wp: WpPost;
    sfNorm: string;
    wpNorm: string;
  }[] = [];

  for (const sf of sfRecords) {
    if (!sf.WP_Post_ID__c) continue;
    const wp = wpById.get(sf.WP_Post_ID__c);
    if (!wp) continue; // already reported separately as orphans
    if (!sf.Address__c || !wp.fave_property_address) continue;
    const sfNorm = smartNormalize(sf.Address__c);
    const wpNorm = smartNormalize(wp.fave_property_address);
    if (sfNorm !== wpNorm) {
      mislinkedSf.push({ sf, wp, sfNorm, wpNorm });
    }
  }

  console.log(`\n  ❌ SF records linked to a different-address WP post: ${mislinkedSf.length}\n`);

  if (mislinkedSf.length > 0) {
    for (const m of mislinkedSf) {
      console.log(`  SF ${m.sf.Id}`);
      console.log(`     SF.Address: "${m.sf.Address__c}"   (norm: "${m.sfNorm}")`);
      console.log(`     → wp:${m.wp.id}  status=${m.wp.status}`);
      console.log(`     WP.address: "${m.wp.fave_property_address}"   (norm: "${m.wpNorm}")`);
      console.log(`     WP.title:   "${m.wp.title.replace(/&#8211;/g, '–').slice(0, 70)}"`);
      console.log('');
    }
  }

  // ───────────────────────────────────────────────────────────────────
  // Summary
  // ───────────────────────────────────────────────────────────────────
  console.log('═'.repeat(70));
  console.log('SUMMARY');
  console.log('═'.repeat(70));
  console.log(`
  Tagged [DUPLICATE] posts:        ${tagged.length}
     • Real duplicates:            ${truePositives.length}
     • False positives (un-tag):   ${falsePositives.length}
     • Ambiguous:                  ${ambiguous.length}

  SF→WP mislinked records:         ${mislinkedSf.length}
     (SF record points at a WP post for a different building — needs
      relink to the WP post matching SF.Address__c, or unlink if no match)
  `);

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
