/**
 * Admin Monitoring Dashboard — server-rendered HTML on Fastify.
 *
 * Routes:
 *   GET /admin           — full dashboard page
 *   GET /admin/api/status — JSON data for auto-refresh
 *
 * No dependencies — just template literals, inline CSS/JS.
 */

import type { FastifyInstance } from 'fastify';
import { readdir, readFile, stat } from 'fs/promises';
import { join } from 'path';
import { getLeads } from './claude';
import { getProperties, getAgents, getLastRefresh } from './salesforce';
import { DOCS } from './docs-bundle';

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const LOG_DIR = process.env.CALL_LOG_DIR || '/tmp/call-logs';
const STATUS_CACHE_MS = 5 * 60 * 1000; // 5 minutes
const MAX_CALL_SUMMARIES = 100;

const TWILIO_SID = process.env.TWILIO_ACCOUNT_SID || '';
const TWILIO_TOKEN = process.env.TWILIO_AUTH_TOKEN || '';
const ELEVENLABS_KEY = process.env.ELEVENLABS_API_KEY || '';
const DEEPGRAM_KEY = process.env.DEEPGRAM_API_KEY || '';
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY || '';
const SMS_ENABLED = process.env.SMS_ENABLED !== 'false';
const EMAIL_ENABLED = process.env.EMAIL_ENABLED === 'true';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface CallSummary {
  callSid: string;
  callerPhone: string;
  startTime: string;
  durationSec: number;
  totalTurns: number;
  firstCallerText: string;
  leadLogged: boolean;
  avgClaudeLatencyMs: number;
}

interface ServiceStatus {
  name: string;
  status: 'ok' | 'error' | 'unknown';
  detail: string;
  lastChecked: number;
}

interface CreditInfo {
  twilio: { balance: string; currency: string } | null;
  elevenlabs: {
    characterCount: number;
    characterLimit: number;
    percentUsed: number;
  } | null;
  deepgram: { status: string } | null;
}

// ---------------------------------------------------------------------------
// In-memory stores
// ---------------------------------------------------------------------------

let callSummaries: CallSummary[] = [];
let lastLogScan = 0;
let serviceStatusCache: ServiceStatus[] = [];
let creditCache: CreditInfo = { twilio: null, elevenlabs: null, deepgram: null };
let lastStatusCheck = 0;

// ---------------------------------------------------------------------------
// Call log parsing
// ---------------------------------------------------------------------------

async function loadCallLogs(): Promise<void> {
  try {
    const files = await readdir(LOG_DIR);
    const jsonFiles = files
      .filter((f) => f.endsWith('.json'))
      .sort()
      .slice(-MAX_CALL_SUMMARIES);

    const summaries: CallSummary[] = [];
    for (const file of jsonFiles) {
      try {
        const raw = await readFile(join(LOG_DIR, file), 'utf-8');
        const log = JSON.parse(raw);
        summaries.push(parseLogToSummary(log));
      } catch {
        // Skip corrupt files
      }
    }
    callSummaries = summaries;
    lastLogScan = Date.now();
  } catch {
    // LOG_DIR doesn't exist yet — that's fine
    callSummaries = [];
    lastLogScan = Date.now();
  }
}

async function refreshCallLogs(): Promise<void> {
  try {
    const files = await readdir(LOG_DIR);
    const jsonFiles = files.filter((f) => f.endsWith('.json'));

    for (const file of jsonFiles) {
      const filepath = join(LOG_DIR, file);
      try {
        const fstat = await stat(filepath);
        if (fstat.mtimeMs > lastLogScan) {
          const raw = await readFile(filepath, 'utf-8');
          const log = JSON.parse(raw);
          const summary = parseLogToSummary(log);
          // Avoid duplicates
          if (!callSummaries.find((s) => s.callSid === summary.callSid)) {
            callSummaries.push(summary);
          }
        }
      } catch {
        // Skip
      }
    }

    // Cap size, keep newest
    if (callSummaries.length > MAX_CALL_SUMMARIES) {
      callSummaries = callSummaries.slice(-MAX_CALL_SUMMARIES);
    }
    lastLogScan = Date.now();
  } catch {
    // LOG_DIR doesn't exist
  }
}

function parseLogToSummary(log: any): CallSummary {
  const turns = log.turns || {};
  let firstCallerText = '';
  let totalTurns = 0;
  let claudeLatencies: number[] = [];
  let leadLogged = false;

  for (const [, turn] of Object.entries(turns) as [string, any][]) {
    if (turn.callerText) {
      totalTurns++;
      if (!firstCallerText) firstCallerText = turn.callerText;
    }
    if (turn.claudeCallAt && turn.claudeFirstTokenAt) {
      claudeLatencies.push(turn.claudeFirstTokenAt - turn.claudeCallAt);
    }
  }

  // Check events for lead logging
  const events = log.events || [];
  leadLogged = events.some(
    (e: any) => e.evt === 'complete' && e.data?.toolCalls?.includes('log_lead')
  );
  // Fallback: check if description mentions lead
  if (!leadLogged) {
    leadLogged = events.some(
      (e: any) => e.msg && e.msg.includes('log_lead')
    );
  }

  return {
    callSid: log.callSid || '',
    callerPhone: log.callerPhone || '',
    startTime: log.startTime || '',
    durationSec: Math.round((log.durationMs || 0) / 1000),
    totalTurns,
    firstCallerText: firstCallerText.substring(0, 100),
    leadLogged,
    avgClaudeLatencyMs: claudeLatencies.length
      ? Math.round(
          claudeLatencies.reduce((a, b) => a + b, 0) / claudeLatencies.length
        )
      : 0,
  };
}

// ---------------------------------------------------------------------------
// Service health checks
// ---------------------------------------------------------------------------

async function checkServices(): Promise<void> {
  if (Date.now() - lastStatusCheck < STATUS_CACHE_MS) return;

  const checks = await Promise.allSettled([
    checkTwilio(),
    checkAnthropic(),
    checkElevenLabs(),
    checkDeepgram(),
    checkSalesforce(),
    checkServer(),
  ]);

  serviceStatusCache = checks.map((r) =>
    r.status === 'fulfilled'
      ? r.value
      : { name: 'Unknown', status: 'error' as const, detail: 'Check failed', lastChecked: Date.now() }
  );

  lastStatusCheck = Date.now();
}

async function checkTwilio(): Promise<ServiceStatus> {
  try {
    const r = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_SID}/Balance.json`,
      {
        headers: {
          Authorization:
            'Basic ' + Buffer.from(`${TWILIO_SID}:${TWILIO_TOKEN}`).toString('base64'),
        },
        signal: AbortSignal.timeout(10000),
      }
    );
    if (r.ok) {
      const d = (await r.json()) as { balance: string; currency: string };
      creditCache.twilio = { balance: d.balance, currency: d.currency };
      const bal = parseFloat(d.balance);
      return {
        name: 'Twilio',
        status: bal < 5 ? 'error' : bal < 15 ? 'unknown' : 'ok',
        detail: `Balance: $${bal.toFixed(2)}`,
        lastChecked: Date.now(),
      };
    }
    return { name: 'Twilio', status: 'error', detail: `HTTP ${r.status}`, lastChecked: Date.now() };
  } catch (e: any) {
    return { name: 'Twilio', status: 'error', detail: e.message, lastChecked: Date.now() };
  }
}

async function checkAnthropic(): Promise<ServiceStatus> {
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': ANTHROPIC_KEY,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1,
        messages: [{ role: 'user', content: 'ping' }],
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (r.ok) {
      return {
        name: 'Claude API',
        status: 'ok',
        detail: 'Connected (Haiku 4.5) — billing: check console.anthropic.com',
        lastChecked: Date.now(),
      };
    }
    if (r.status === 429) {
      return {
        name: 'Claude API',
        status: 'unknown',
        detail: 'Rate limited — may need higher tier',
        lastChecked: Date.now(),
      };
    }
    if (r.status === 401) {
      return {
        name: 'Claude API',
        status: 'error',
        detail: 'Invalid API key',
        lastChecked: Date.now(),
      };
    }
    return { name: 'Claude API', status: 'error', detail: `HTTP ${r.status}`, lastChecked: Date.now() };
  } catch (e: any) {
    return { name: 'Claude API', status: 'error', detail: e.message, lastChecked: Date.now() };
  }
}

async function checkElevenLabs(): Promise<ServiceStatus> {
  try {
    // Try subscription endpoint first
    const r = await fetch('https://api.elevenlabs.io/v1/user/subscription', {
      headers: { 'xi-api-key': ELEVENLABS_KEY },
      signal: AbortSignal.timeout(10000),
    });
    if (r.ok) {
      const d = (await r.json()) as {
        character_count: number;
        character_limit: number;
      };
      const pct = Math.round((d.character_count / d.character_limit) * 100);
      creditCache.elevenlabs = {
        characterCount: d.character_count,
        characterLimit: d.character_limit,
        percentUsed: pct,
      };
      return {
        name: 'ElevenLabs',
        status: pct > 95 ? 'error' : 'ok',
        detail: `${pct}% used (${d.character_count.toLocaleString()} / ${d.character_limit.toLocaleString()})`,
        lastChecked: Date.now(),
      };
    }
    // 401 likely means key lacks user_read scope — test TTS connectivity instead
    if (r.status === 401) {
      const voiceCheck = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: { 'xi-api-key': ELEVENLABS_KEY },
        signal: AbortSignal.timeout(10000),
      });
      if (voiceCheck.ok) {
        creditCache.elevenlabs = null; // Can't read credits with this key
        return {
          name: 'ElevenLabs',
          status: 'ok',
          detail: 'Connected (credits: check dashboard — key lacks read scope)',
          lastChecked: Date.now(),
        };
      }
    }
    return { name: 'ElevenLabs', status: 'error', detail: `HTTP ${r.status}`, lastChecked: Date.now() };
  } catch (e: any) {
    return { name: 'ElevenLabs', status: 'error', detail: e.message, lastChecked: Date.now() };
  }
}

async function checkDeepgram(): Promise<ServiceStatus> {
  try {
    const r = await fetch('https://api.deepgram.com/v1/projects', {
      headers: { Authorization: `Token ${DEEPGRAM_KEY}` },
      signal: AbortSignal.timeout(10000),
    });
    if (r.ok) {
      const d = (await r.json()) as { projects?: { project_id: string; name: string }[] };
      const projectId = d.projects?.[0]?.project_id;
      // Try to get balances (may be 403 depending on key scope)
      if (projectId) {
        try {
          const br = await fetch(
            `https://api.deepgram.com/v1/projects/${projectId}/balances`,
            {
              headers: { Authorization: `Token ${DEEPGRAM_KEY}` },
              signal: AbortSignal.timeout(10000),
            }
          );
          if (br.ok) {
            const bd = (await br.json()) as {
              balances?: { balance_id: string; amount: number; units: string }[];
            };
            const bal = bd.balances?.[0];
            if (bal) {
              creditCache.deepgram = {
                status: `$${bal.amount.toFixed(2)} ${bal.units}`,
              };
              return {
                name: 'Deepgram',
                status: bal.amount < 5 ? 'error' : 'ok',
                detail: `Balance: $${bal.amount.toFixed(2)}`,
                lastChecked: Date.now(),
              };
            }
          }
        } catch {
          // Balances endpoint not available — that's fine
        }
      }
      creditCache.deepgram = { status: 'Connected' };
      return { name: 'Deepgram', status: 'ok', detail: 'Connected (credits: check dashboard)', lastChecked: Date.now() };
    }
    return { name: 'Deepgram', status: 'error', detail: `HTTP ${r.status}`, lastChecked: Date.now() };
  } catch (e: any) {
    return { name: 'Deepgram', status: 'error', detail: e.message, lastChecked: Date.now() };
  }
}

async function checkSalesforce(): Promise<ServiceStatus> {
  const props = getProperties();
  const lastRefresh = getLastRefresh();
  if (props.length > 0 && lastRefresh > 0) {
    const ago = Math.round((Date.now() - lastRefresh) / 60000);
    return {
      name: 'Salesforce',
      status: 'ok',
      detail: `${props.length} properties, refreshed ${ago}m ago`,
      lastChecked: Date.now(),
    };
  }
  return {
    name: 'Salesforce',
    status: props.length === 0 ? 'error' : 'ok',
    detail: props.length === 0 ? 'No properties loaded' : `${props.length} properties (fallback)`,
    lastChecked: Date.now(),
  };
}

async function checkServer(): Promise<ServiceStatus> {
  const uptime = process.uptime();
  const hours = Math.floor(uptime / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  return {
    name: 'Server',
    status: 'ok',
    detail: `Uptime: ${hours}h ${mins}m`,
    lastChecked: Date.now(),
  };
}

// ---------------------------------------------------------------------------
// Quick stats
// ---------------------------------------------------------------------------

function getQuickStats() {
  const today = new Date().toISOString().split('T')[0];
  const callsToday = callSummaries.filter((c) => c.startTime.startsWith(today));
  const leadsToday = getLeads().filter((l) => l.timestamp?.startsWith(today));
  const latencies = callsToday
    .filter((c) => c.avgClaudeLatencyMs > 0)
    .map((c) => c.avgClaudeLatencyMs);
  const avgLatency = latencies.length
    ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length)
    : 0;

  return {
    callsToday: callsToday.length,
    leadsToday: leadsToday.length,
    avgResponseMs: avgLatency,
    totalCalls: callSummaries.length,
    totalLeads: getLeads().length,
  };
}

// ---------------------------------------------------------------------------
// Data sync health (from SF properties in memory)
// ---------------------------------------------------------------------------

function getDataSyncStatus() {
  const props = getProperties();
  const total = props.length;
  const hasUrl = props.filter((p) => p.publicUrl && p.publicUrl.startsWith('http')).length;
  const noUrl = total - hasUrl;
  const hasDescription = props.filter((p) => p.description && p.description.length > 20).length;

  return {
    totalProperties: total,
    withWebsiteUrl: hasUrl,
    withoutWebsiteUrl: noUrl,
    withDescription: hasDescription,
    syncHealth: total > 0 ? Math.round((hasUrl / total) * 100) : 0,
  };
}

// ---------------------------------------------------------------------------
// API response
// ---------------------------------------------------------------------------

async function getStatusData() {
  await refreshCallLogs();
  await checkServices();

  const sfProps = getProperties();
  const sfAgents = getAgents();
  const lastRefresh = getLastRefresh();

  return {
    stats: getQuickStats(),
    services: serviceStatusCache,
    credits: creditCache,
    smsEnabled: SMS_ENABLED,
    emailEnabled: EMAIL_ENABLED,
    salesforce: {
      properties: sfProps.length,
      agents: sfAgents.length,
      lastRefresh: lastRefresh
        ? new Date(lastRefresh).toISOString()
        : 'never',
    },
    dataSync: getDataSyncStatus(),
    recentCalls: callSummaries
      .slice(-20)
      .reverse()
      .map((c) => ({
        ...c,
        callerPhone: maskPhone(c.callerPhone),
      })),
    serverUptime: Math.round(process.uptime()),
  };
}

function maskPhone(phone: string): string {
  if (!phone || phone.length < 4) return '***';
  return '***' + phone.slice(-4);
}

// ---------------------------------------------------------------------------
// HTML rendering
// ---------------------------------------------------------------------------

function renderHtml(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fausto AI — Admin</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #1a1a2e; color: #e0e0e0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 20px; }
    h1 { color: #fff; font-size: 20px; margin-bottom: 4px; }
    .subtitle { color: #888; font-size: 13px; margin-bottom: 20px; }
    .grid { display: grid; gap: 12px; margin-bottom: 20px; }
    .grid-3 { grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); }
    .grid-5 { grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); }
    .card { background: #16213e; border-radius: 8px; padding: 16px; border: 1px solid #1a1a3e; }
    .card-header { font-size: 11px; text-transform: uppercase; color: #888; letter-spacing: 1px; margin-bottom: 8px; }
    .card-value { font-size: 28px; font-weight: 700; color: #fff; font-family: 'SF Mono', 'Fira Code', monospace; }
    .card-detail { font-size: 12px; color: #888; margin-top: 4px; }
    .status-card { display: flex; align-items: center; gap: 10px; }
    .dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .dot-ok { background: #00c853; box-shadow: 0 0 6px #00c853; }
    .dot-error { background: #ff1744; box-shadow: 0 0 6px #ff1744; }
    .dot-unknown { background: #ffd600; }
    .svc-name { font-weight: 600; font-size: 14px; }
    .svc-detail { font-size: 12px; color: #888; }
    .credit-warn { border-color: #ffd600 !important; }
    .credit-crit { border-color: #ff1744 !important; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th { text-align: left; padding: 8px 12px; color: #888; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #2a2a4e; }
    td { padding: 8px 12px; border-bottom: 1px solid #1a1a3e; }
    tr:hover { background: #1a1a3e; }
    .lead-yes { color: #00c853; }
    .lead-no { color: #555; }
    .section-title { font-size: 14px; font-weight: 600; color: #ccc; margin-bottom: 10px; margin-top: 20px; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
    .badge-on { background: #00c85333; color: #00c853; }
    .badge-off { background: #ff174433; color: #ff1744; }
    .refresh-indicator { position: fixed; top: 10px; right: 20px; font-size: 11px; color: #555; }
    @media (max-width: 600px) {
      .grid-5 { grid-template-columns: 1fr 1fr; }
      .grid-3 { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <h1>🏢 Fausto AI Attendant — Admin</h1>
  <div class="subtitle">
    <span id="uptime"></span> ·
    SMS: <span id="sms-badge"></span> ·
    Last refresh: <span id="last-refresh">loading...</span> ·
    <a id="docs-link" href="/admin/docs" style="color:#4da3ff;text-decoration:none">📖 System Docs</a>
  </div>
  <script>var _dl=document.getElementById('docs-link'); if(_dl) _dl.href='/admin/docs'+location.search;</script>
  <div class="refresh-indicator" id="refresh-indicator">⟳</div>

  <div class="section-title">Quick Stats</div>
  <div class="grid grid-3" id="stats"></div>

  <div class="section-title">Services</div>
  <div class="grid grid-5" id="services"></div>

  <div class="section-title">Credits & Usage</div>
  <div class="grid grid-3" id="credits"></div>

  <div class="section-title">Salesforce</div>
  <div class="grid grid-3" id="salesforce"></div>

  <div class="section-title">Data Sync Health</div>
  <div class="grid grid-3" id="datasync"></div>

  <div class="section-title">Recent Calls</div>
  <div class="card" style="overflow-x:auto;">
    <table>
      <thead><tr><th>Time</th><th>Caller</th><th>Duration</th><th>Turns</th><th>Summary</th><th>Latency</th><th>Lead</th></tr></thead>
      <tbody id="calls"></tbody>
    </table>
  </div>

  <script>
    function renderStats(s) {
      return \`
        <div class="card"><div class="card-header">Calls Today</div><div class="card-value">\${s.callsToday}</div><div class="card-detail">\${s.totalCalls} total</div></div>
        <div class="card"><div class="card-header">Leads Today</div><div class="card-value">\${s.leadsToday}</div><div class="card-detail">\${s.totalLeads} total</div></div>
        <div class="card"><div class="card-header">Avg Response</div><div class="card-value">\${s.avgResponseMs}<span style="font-size:14px">ms</span></div><div class="card-detail">Claude TTFT</div></div>
      \`;
    }

    function renderServices(svcs) {
      return svcs.map(s => \`
        <div class="card status-card">
          <div class="dot dot-\${s.status}"></div>
          <div><div class="svc-name">\${s.name}</div><div class="svc-detail">\${s.detail}</div></div>
        </div>
      \`).join('');
    }

    function renderCredits(c) {
      const tw = c.twilio ? \`$\${parseFloat(c.twilio.balance).toFixed(2)}\` : 'N/A';
      const twClass = c.twilio && parseFloat(c.twilio.balance) < 10 ? 'credit-warn' : '';

      const el = c.elevenlabs;
      const elPct = el ? el.percentUsed : 0;
      const elClass = elPct > 95 ? 'credit-crit' : elPct > 80 ? 'credit-warn' : '';
      const elText = el ? \`\${elPct}% (\${el.characterCount.toLocaleString()} / \${el.characterLimit.toLocaleString()})\` : 'N/A';

      const dg = c.deepgram;

      return \`
        <div class="card \${twClass}"><div class="card-header">Twilio Balance</div><div class="card-value">\${tw}</div></div>
        <div class="card \${elClass}"><div class="card-header">ElevenLabs Characters</div><div class="card-value">\${elPct}%</div><div class="card-detail">\${elText}</div></div>
        <div class="card"><div class="card-header">Deepgram</div><div class="card-value">\${dg ? dg.status : 'N/A'}</div></div>
      \`;
    }

    function renderSalesforce(sf) {
      return \`
        <div class="card"><div class="card-header">Properties</div><div class="card-value">\${sf.properties}</div></div>
        <div class="card"><div class="card-header">Agents</div><div class="card-value">\${sf.agents}</div></div>
        <div class="card"><div class="card-header">Last Refresh</div><div class="card-value" style="font-size:14px">\${sf.lastRefresh === 'never' ? 'Never' : new Date(sf.lastRefresh).toLocaleTimeString()}</div></div>
      \`;
    }

    function renderDataSync(ds) {
      const healthColor = ds.syncHealth >= 80 ? '#00c853' : ds.syncHealth >= 50 ? '#ffd600' : '#ff1744';
      return \`
        <div class="card"><div class="card-header">Website URLs</div><div class="card-value" style="color:\${healthColor}">\${ds.syncHealth}%</div><div class="card-detail">\${ds.withWebsiteUrl} of \${ds.totalProperties} have URLs</div></div>
        <div class="card"><div class="card-header">Missing URLs</div><div class="card-value">\${ds.withoutWebsiteUrl}</div><div class="card-detail">Properties need website pages</div></div>
        <div class="card"><div class="card-header">Has Description</div><div class="card-value">\${ds.withDescription}</div><div class="card-detail">of \${ds.totalProperties} total</div></div>
      \`;
    }

    function renderCalls(calls) {
      if (!calls.length) return '<tr><td colspan="7" style="text-align:center;color:#555;padding:20px">No calls yet</td></tr>';
      return calls.map(c => {
        const time = c.startTime ? new Date(c.startTime).toLocaleTimeString() : '—';
        const dur = c.durationSec ? \`\${Math.floor(c.durationSec/60)}:\${String(c.durationSec%60).padStart(2,'0')}\` : '—';
        return \`<tr>
          <td>\${time}</td>
          <td>\${c.callerPhone}</td>
          <td>\${dur}</td>
          <td>\${c.totalTurns}</td>
          <td>\${c.firstCallerText || '—'}</td>
          <td>\${c.avgClaudeLatencyMs ? c.avgClaudeLatencyMs + 'ms' : '—'}</td>
          <td class="\${c.leadLogged ? 'lead-yes' : 'lead-no'}">\${c.leadLogged ? '✓' : '—'}</td>
        </tr>\`;
      }).join('');
    }

    function formatUptime(sec) {
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      return \`Uptime: \${h}h \${m}m\`;
    }

    async function refresh() {
      try {
        document.getElementById('refresh-indicator').style.color = '#00c853';
        const params = new URLSearchParams(window.location.search);
        const r = await fetch('/admin/api/status?key=' + params.get('key'));
        const d = await r.json();
        document.getElementById('stats').innerHTML = renderStats(d.stats);
        document.getElementById('services').innerHTML = renderServices(d.services);
        document.getElementById('credits').innerHTML = renderCredits(d.credits);
        document.getElementById('salesforce').innerHTML = renderSalesforce(d.salesforce);
        document.getElementById('datasync').innerHTML = renderDataSync(d.dataSync);
        document.getElementById('calls').innerHTML = renderCalls(d.recentCalls);
        document.getElementById('uptime').textContent = formatUptime(d.serverUptime);
        document.getElementById('sms-badge').innerHTML = d.smsEnabled
          ? '<span class="badge badge-on">ON</span>'
          : '<span class="badge badge-off">OFF</span>';
        document.getElementById('last-refresh').textContent = new Date().toLocaleTimeString();
        setTimeout(() => { document.getElementById('refresh-indicator').style.color = '#555'; }, 1000);
      } catch(e) {
        document.getElementById('refresh-indicator').style.color = '#ff1744';
      }
    }

    refresh();
    setInterval(refresh, 30000);
  </script>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// Route registration
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// System documentation viewer (/admin/docs) — renders the bundled handoff
// markdown with a sidebar. Content is trusted (our own docs) and gated by
// ADMIN_KEY. Markdown is rendered client-side via marked (CDN).
// ---------------------------------------------------------------------------

function renderDocsHtml(key: string): string {
  const esc = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // Escape "<" so the JSON can't break out of the <script> block.
  const docsJson = JSON.stringify(DOCS).replace(/</g, '\\u003c');
  const dash = '/admin?key=' + encodeURIComponent(key);
  const nav = DOCS.map(
    (d) => `<a href="#${d.id}" data-id="${d.id}">${esc(d.title)}</a>`
  ).join('\n');

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Fausto Commercial — System Documentation</title>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<style>
  :root { --bg:#0f1419; --panel:#1a212b; --line:#2a323d; --text:#e6edf3; --muted:#9aa7b4; --accent:#4da3ff; }
  * { box-sizing: border-box; }
  body { margin:0; font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; background:var(--bg); color:var(--text); }
  .layout { display:flex; min-height:100vh; }
  .sidebar { width:280px; flex:0 0 280px; background:var(--panel); border-right:1px solid var(--line); padding:20px 14px; position:sticky; top:0; height:100vh; overflow:auto; }
  .sidebar h1 { font-size:15px; margin:0 0 4px; }
  .sidebar .sub { color:var(--muted); font-size:12px; margin:0 0 16px; }
  .nav a { display:block; padding:9px 12px; margin:2px 0; border-radius:7px; color:var(--text); text-decoration:none; font-size:14px; }
  .nav a:hover { background:#222c38; }
  .nav a.active { background:var(--accent); color:#04101f; font-weight:600; }
  .back { display:inline-block; margin-top:18px; color:var(--muted); font-size:12px; text-decoration:none; }
  .back:hover { color:var(--accent); }
  .main { flex:1; height:100vh; overflow:auto; }
  .content { max-width:880px; margin:0 auto; padding:40px 48px 120px; line-height:1.6; }
  .content h1 { font-size:28px; border-bottom:1px solid var(--line); padding-bottom:10px; }
  .content h2 { font-size:21px; margin-top:32px; border-bottom:1px solid var(--line); padding-bottom:6px; }
  .content h3 { font-size:17px; margin-top:24px; }
  .content code { background:#222c38; padding:2px 6px; border-radius:4px; font-size:13px; }
  .content pre { background:#0b0f14; border:1px solid var(--line); padding:14px; border-radius:8px; overflow:auto; }
  .content pre code { background:none; padding:0; }
  .content table { border-collapse:collapse; width:100%; margin:16px 0; font-size:14px; }
  .content th, .content td { border:1px solid var(--line); padding:8px 10px; text-align:left; vertical-align:top; }
  .content th { background:#222c38; }
  .content a { color:var(--accent); }
  .content blockquote { border-left:3px solid var(--accent); margin:16px 0; padding:4px 16px; color:var(--muted); background:#161d26; }
</style>
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h1>System Documentation</h1>
    <p class="sub">Fausto Commercial — Carmencita platform</p>
    <nav class="nav">
${nav}
    </nav>
    <a class="back" href="${dash}">&larr; Back to dashboard</a>
  </aside>
  <main class="main"><div class="content" id="content"></div></main>
</div>
<script>
  var DOCS = ${docsJson};
  function render(id){
    var d = DOCS.find(function(x){return x.id===id;}) || DOCS[0];
    document.getElementById('content').innerHTML = marked.parse(d.md);
    var links = document.querySelectorAll('.nav a');
    for (var i=0;i<links.length;i++){ links[i].classList.toggle('active', links[i].getAttribute('data-id')===d.id); }
    if (location.hash.slice(1)!==d.id) history.replaceState(null,'','#'+d.id);
    document.querySelector('.main').scrollTo(0,0);
  }
  var navlinks = document.querySelectorAll('.nav a');
  for (var i=0;i<navlinks.length;i++){
    navlinks[i].addEventListener('click', function(e){ e.preventDefault(); render(this.getAttribute('data-id')); });
  }
  render(location.hash.slice(1) || DOCS[0].id);
</script>
</body>
</html>`;
}

export async function registerAdminRoutes(
  fastify: FastifyInstance
): Promise<void> {
  // Load existing call logs on startup
  await loadCallLogs();

  const ADMIN_KEY = process.env.ADMIN_KEY || 'fausto2026';

  fastify.get('/admin', async (req, reply) => {
    const query = req.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) {
      reply.code(404).send('Not found');
      return;
    }
    reply.type('text/html').send(renderHtml());
  });

  fastify.get('/admin/api/status', async (req, reply) => {
    const query = req.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) {
      reply.code(404).send('Not found');
      return;
    }
    return getStatusData();
  });

  fastify.get('/admin/docs', async (req, reply) => {
    const query = req.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) {
      reply.code(404).send('Not found');
      return;
    }
    reply.type('text/html').send(renderDocsHtml(query.key));
  });
}
