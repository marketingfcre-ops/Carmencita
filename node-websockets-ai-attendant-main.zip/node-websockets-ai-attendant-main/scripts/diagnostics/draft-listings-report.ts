/**
 * Draft-listings report — read-only.
 *
 * Lists every property that is NOT live on the website (WP status != publish, or
 * no/broken WP link), and for each flags whether the SF Photo_URL__c is populated
 * and whether it has a flyer attached. Splits the work:
 *   - has photos  → low-hanging fruit (marketing can finish + publish)
 *   - no photos   → the list to give agents (they source photos); has-flyer means
 *                   it's at least covered for email delivery in the meantime.
 *
 * Writes data/draft-listings-<date>.csv. Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/draft-listings-report.ts
 */

import { sfClient } from '../../src/integrations/sf-client';
import { writeFile } from 'fs/promises';

const API_BASE = `${(process.env.WP_SITE_URL || 'https://faustocommercial.com').replace(/\/$/, '')}/wp-json`;
const authHeader = () =>
  `Basic ${Buffer.from(`${process.env.WP_USER || ''}:${process.env.WP_APP_PASSWORD || ''}`).toString('base64')}`;
const postIdFromUrl = (u: string | null) => { const m = u?.match(/[?&]p=(\d+)/); return m ? Number(m[1]) : null; };
const chunk = <T,>(a: T[], n: number) => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
const FLYER_RE = /flyer/i;

async function main() {
  const sf = (await sfClient('prod')) as any;
  const props: any[] = await sf.soql(
    `SELECT Id, Name, Status__c, Public_URL__c, WP_Post_ID__c, Photo_URL__c FROM Property__c`
  );

  // Classify the free-text Photo_URL__c: a real Dropbox/Drive/URL folder link means
  // images EXIST and just need manual download→upload to WP. "pending"/bare-domain = junk.
  const photoSource = (u: string | null): 'dropbox' | 'gdrive' | 'other-url' | 'junk' | 'none' => {
    if (!u) return 'none';
    const s = u.trim();
    if (/dropbox\.com\/(scl|sh|s|home)\//i.test(s)) return 'dropbox';
    if (/drive\.google|docs\.google/i.test(s)) return 'gdrive';
    if (/^https?:\/\/[^\/\s]+\/\S+/i.test(s)) return 'other-url';
    return 'junk';
  };

  // WP status per property
  const wpIdByProp = new Map<string, number>();
  for (const p of props) {
    const id = p.WP_Post_ID__c ? Number(p.WP_Post_ID__c) : postIdFromUrl(p.Public_URL__c);
    if (id) wpIdByProp.set(p.Id, id);
  }
  // featured_media>0 is the real "has photos" signal. SF Photo_URL__c is junk
  // free-text ("pending", "faustocommercial.com", dropbox links) — do not use it.
  const wp = new Map<number, { status: string; featured: number }>();
  for (const ids of chunk([...new Set(wpIdByProp.values())], 100)) {
    const url = `${API_BASE}/wp/v2/properties?include=${ids.join(',')}&per_page=100&status=publish,draft,private,pending,future&context=edit&_fields=id,status,featured_media`;
    const res = await fetch(url, { headers: { Authorization: authHeader() } });
    if (res.ok) for (const r of (await res.json()) as any[]) wp.set(r.id, { status: r.status, featured: r.featured_media || 0 });
  }

  // Which properties are NOT live?
  const notLive = props.filter((p) => {
    const id = wpIdByProp.get(p.Id);
    const w = id ? wp.get(id) : undefined;
    return !(w && w.status === 'publish'); // draft/pending/private/unlinked/missing
  });

  // Flyer presence for the not-live set
  const notLiveIds = notLive.map((p) => p.Id);
  const flyerProps = new Set<string>();
  const docByProp = new Map<string, string[]>();
  const allDocs = new Set<string>();
  for (const ids of chunk(notLiveIds, 150)) {
    const inList = ids.map((i) => `'${i}'`).join(',');
    const links: any[] = await sf.soql(`SELECT LinkedEntityId, ContentDocumentId FROM ContentDocumentLink WHERE LinkedEntityId IN (${inList})`);
    for (const l of links) if (l.LinkedEntityId?.startsWith('a')) { const a = docByProp.get(l.LinkedEntityId) || []; a.push(l.ContentDocumentId); docByProp.set(l.LinkedEntityId, a); allDocs.add(l.ContentDocumentId); }
  }
  const flyerDocs = new Set<string>();
  for (const ids of chunk([...allDocs], 150)) {
    const inList = ids.map((i) => `'${i}'`).join(',');
    const vers: any[] = await sf.soql(`SELECT ContentDocumentId, Title, PathOnClient FROM ContentVersion WHERE ContentDocumentId IN (${inList}) AND IsLatest = true`);
    for (const v of vers) if (FLYER_RE.test(v.Title || '') || FLYER_RE.test(v.PathOnClient || '')) flyerDocs.add(v.ContentDocumentId);
  }
  for (const [pid, docs] of docByProp) if (docs.some((d) => flyerDocs.has(d))) flyerProps.add(pid);

  const wpState = (p: any) => {
    const id = wpIdByProp.get(p.Id);
    if (!id) return 'no-wp-link';
    const w = wp.get(id);
    return w ? w.status : 'wp-missing';
  };

  // Build rows + counts. hasPhoto = WP featured image present.
  const rows = notLive.map((p) => {
    const id = wpIdByProp.get(p.Id);
    const featured = id ? (wp.get(id)?.featured || 0) : 0;
    return {
      name: p.Name, id: p.Id, sfStatus: p.Status__c || '', wp: wpState(p),
      hasPhoto: featured > 0, hasFlyer: flyerProps.has(p.Id), url: p.Public_URL__c || '',
      photoSrc: photoSource(p.Photo_URL__c), photoUrl: (p.Photo_URL__c || '').trim(),
    };
  });
  const withPhoto = rows.filter((r) => r.hasPhoto);
  const noPhoto = rows.filter((r) => !r.hasPhoto);

  console.log(`\n📝 Not-live listings: ${rows.length}  (of ${props.length} total)`);
  console.log(`   WP draft/pending/private: ${rows.filter(r=>['draft','pending','private','future'].includes(r.wp)).length}` +
    `  | no WP link: ${rows.filter(r=>r.wp==='no-wp-link').length}  | WP post missing: ${rows.filter(r=>r.wp==='wp-missing').length}`);
  console.log(`\n   ✅ HAS photo on WP (low-hanging): ${withPhoto.length}  (of those, ${withPhoto.filter(r=>r.hasFlyer).length} also have a flyer)`);
  console.log(`   📷 NO photo on WP:                ${noPhoto.length}  (of those, ${noPhoto.filter(r=>r.hasFlyer).length} have a flyer → email-covered)`);

  // Of the no-photo set, where might images already exist (Photo_URL__c)?
  const srcCount = (s: string) => noPhoto.filter((r) => r.photoSrc === s).length;
  console.log(`\n   No-photo listings by stored Photo_URL__c source (images may already exist → manual upload to WP):`);
  console.log(`      Dropbox link:   ${srcCount('dropbox')}   ← images likely exist, need download→WP`);
  console.log(`      Google Drive:   ${srcCount('gdrive')}`);
  console.log(`      Other real URL: ${srcCount('other-url')}`);
  console.log(`      junk/none ("pending", bare domain, empty): ${srcCount('junk') + srcCount('none')}`);
  const dbNoFlyer = noPhoto.filter((r) => r.photoSrc === 'dropbox' && !r.hasFlyer).length;
  console.log(`   (Of the ${noPhoto.filter(r=>!r.hasFlyer).length} with NEITHER photo nor flyer, ${dbNoFlyer} still have a Dropbox link to mine.)`);
  console.log(`\n   Sample Dropbox links:`);
  for (const r of noPhoto.filter((r) => r.photoSrc === 'dropbox').slice(0, 6)) console.log(`      ${r.name}: ${r.photoUrl.slice(0, 75)}`);

  const csv = ['Name,SF_Id,SF_Status,WP_State,Has_Photo,Has_Flyer,Photo_Source,Photo_URL,Public_URL']
    .concat(rows.map((r) => [r.name, r.id, r.sfStatus, r.wp, r.hasPhoto ? 'YES' : 'no', r.hasFlyer ? 'YES' : 'no', r.photoSrc, r.photoUrl, r.url]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')));
  const path = 'data/draft-listings-2026-06-22.csv';
  await writeFile(path, csv.join('\n'));
  console.log(`\n   📄 wrote ${rows.length} rows → ${path}\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
