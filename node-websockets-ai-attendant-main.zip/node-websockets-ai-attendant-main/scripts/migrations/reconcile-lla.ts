/**
 * Manual runner for the Lead → Lead_List_Assignment__c reconciliation.
 *
 * This calls the SAME function the in-process scheduler runs
 * (src/integrations/lla-reconcile.ts), so a dry-run here is an exact preview of
 * what the server will do once LLA_RECONCILE_ENABLED=true.
 *
 * Create-only + idempotent: it inserts missing assignments (Status='Approved')
 * for Leads that have Group__c set, and never updates or deletes.
 *
 *   # preview (no writes) — do this first
 *   npx tsx --env-file .env.local scripts/migrations/reconcile-lla.ts --dry-run
 *
 *   # apply (writes to PROD Salesforce)
 *   npx tsx --env-file .env.local scripts/migrations/reconcile-lla.ts --apply
 */

import { reconcileLeadGroupAssignments } from '../../src/integrations/lla-reconcile';

async function main() {
  const apply = process.argv.includes('--apply');
  const dryRun = !apply; // dry-run unless --apply is passed explicitly

  console.log(
    `\n🔁 LLA reconcile (target=prod, ${dryRun ? 'DRY RUN — no writes' : 'APPLY — writing to prod'})\n`
  );

  const r = await reconcileLeadGroupAssignments({ dryRun });

  console.log(`  Leads with Group set : ${r.candidates}`);
  console.log(`  Assignments existing : ${r.existing}`);
  console.log(`  Already in place     : ${r.skipped}`);
  console.log(
    `  ${dryRun ? 'Would create' : 'Created'}        : ${r.created}` +
      (r.capped ? `  ⚠️ capped — re-run to finish the rest` : '')
  );
  if (!dryRun) console.log(`  Failed               : ${r.failed}`);

  if (r.failures.length) {
    console.log('\n  Failures:');
    for (const f of r.failures.slice(0, 20)) {
      console.log(`    Lead ${f.leadId} / Group ${f.groupId} → ${f.error}`);
    }
    if (r.failures.length > 20) {
      console.log(`    …and ${r.failures.length - 20} more`);
    }
  }

  if (dryRun && r.created > 0) {
    console.log('\n  Re-run with --apply to create these assignments.');
  }
  console.log('');
}

main().catch((err) => {
  console.error('❌ reconcile-lla failed:', err);
  process.exit(1);
});
