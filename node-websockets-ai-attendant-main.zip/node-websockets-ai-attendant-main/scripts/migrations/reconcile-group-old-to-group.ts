/**
 * Reconcile Lead.Group_old2__c (legacy free-form text) into Group__c (lookup),
 * using clustering so typo-variants merge with each other before deciding
 * whether to create a new canonical.
 *
 * Algorithm:
 *   1. Collect every distinct Group_old2__c text value (with lead count) +
 *      every existing Group__c canonical (with id).
 *   2. Compute pairwise similarity across all of them (clustering signal).
 *   3. Union-Find merge any pair that scores ≥ MERGE_THRESHOLD.
 *   4. For each resulting cluster:
 *        a. If the cluster contains one or more existing canonicals, pick the
 *           one with the most leads as the cluster's canonical.
 *        b. Otherwise, pick the highest-lead-count text value as the new
 *           canonical to create.
 *   5. Build a map: text value → canonical Group__c.Id (existing or to-create).
 *   6. Phase 2 — create new Group__c rows (one per cluster that needs one).
 *   7. Phase 3 — update Lead.Group__c (where null) to point at the canonical.
 *
 * Similarity is a weighted combination of:
 *   - Normalized-key equality (after abbreviation expansion + plural strip)
 *   - Jaccard on token sets
 *   - Levenshtein on the normalized keys (length-normalized)
 *   - Substring containment of the normalized keys
 *
 * Dry-run by default. Output report to data/archive/.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/reconcile-group-old-to-group.ts
 *   tsx --env-file .env.local scripts/migrations/reconcile-group-old-to-group.ts --commit
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const REPORT_PATH = path.join(
  REPO_ROOT,
  'data',
  'archive',
  `group-old-reconcile-${new Date().toISOString().slice(0, 10)}.txt`
);
const OVERRIDES_PATH = path.join(REPO_ROOT, 'data', 'group-old-overrides.json');
const API_VERSION = '59.0';
const BATCH_SIZE = 200;

// ---------------------------------------------------------------------------
// Manual overrides — semantic decisions a human (or LLM) made that the
// similarity algorithm can't make on its own. Loaded from data/group-old-
// overrides.json. Each key is an exact Group_old2__c text value; each value
// is one of:
//   "SKIP"                  → no Group__c assignment for leads with this value
//   "MERGE:<canonicalName>" → force-link this text to the existing Group__c
//                             with this Name (must exist in the org)
//   "NEW:<canonicalName>"   → put this text into a new canonical with this
//                             Name; multiple text values can share a name to
//                             land in the same new group
// Keys starting with '_' are ignored (used for doc/section markers in the
// JSON file).
// ---------------------------------------------------------------------------
function loadOverrides(): {
  skip: Set<string>;
  mergeTo: Map<string, string>;
  newName: Map<string, string>;
} {
  const out = { skip: new Set<string>(), mergeTo: new Map<string, string>(), newName: new Map<string, string>() };
  if (!fs.existsSync(OVERRIDES_PATH)) {
    console.log(`(no overrides file at ${path.relative(REPO_ROOT, OVERRIDES_PATH)})`);
    return out;
  }
  const raw = JSON.parse(fs.readFileSync(OVERRIDES_PATH, 'utf8')) as Record<string, string>;
  for (const [k, v] of Object.entries(raw)) {
    if (k.startsWith('_')) continue;
    if (v === 'SKIP') out.skip.add(k);
    else if (v.startsWith('MERGE:')) out.mergeTo.set(k, v.slice(6));
    else if (v.startsWith('NEW:')) out.newName.set(k, v.slice(4));
    else console.warn(`  (override "${k}" → "${v}" malformed, ignoring)`);
  }
  console.log(`Loaded overrides: ${out.skip.size} SKIP, ${out.mergeTo.size} MERGE, ${out.newName.size} NEW`);
  return out;
}

// Clustering threshold — pairs with similarity ≥ this are considered the
// same group. Dropped from 0.78 to 0.70 after adding the dual-strategy
// (tokenized + plain-key) similarity. Hialeah vs HialeahRetail still scores
// 0.61, so 0.70 is safely above "really different concepts" but below
// "one-letter-typo variants" like VicentePRolodex (0.74).
const MERGE_THRESHOLD = 0.70;

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) { out[key] = next; i++; }
      else out[key] = true;
    }
  }
  return out;
}
const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';
const COMMIT = args.commit === true;

// ---------------------------------------------------------------------------
// Abbreviation table
// ---------------------------------------------------------------------------
const ABBREV: Record<string, string> = {
  lit: 'little', hav: 'havana', lithav: 'littlehavana',
  hia: 'hialeah', mia: 'miami', bch: 'beach', ftl: 'fortlauderdale',
  jax: 'jacksonville', dwn: 'down', dwntwn: 'downtown', dwtwn: 'downtown',
  twn: 'town', swtwtr: 'sweetwater', wynwd: 'wynwood',
  no: 'north', so: 'south', n: 'north', s: 'south', e: 'east', w: 'west',
  ne: 'northeast', nw: 'northwest', se: 'southeast', sw: 'southwest',
  nm: 'northmiami',
  com: 'commercial', comm: 'commercial', apt: 'apartments', apts: 'apartments',
  ind: 'industrial', ret: 'retail', mf: 'multifamily', multifam: 'multifamily',
  resi: 'residential', warehouse: 'warehouse', wrhse: 'warehouse',
  alf: 'assistedliving', alfs: 'assistedliving',
  ts: 'tonysaladrigas', aac: 'ashleencruz', smia: 'southmiami',
};

// ---------------------------------------------------------------------------
// Normalization
// ---------------------------------------------------------------------------
function tokenize(s: string): string[] {
  if (!s) return [];
  const split = s
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]{2,})([A-Z][a-z])/g, '$1 $2');
  return split.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 0);
}
function expandTokens(tokens: string[]): string[] {
  return tokens.map((t) => ABBREV[t] || t);
}
function stripPlural(word: string): string {
  // Strip trailing 's' for words 4+ chars. "Gardens" → "garden", "apartments"
  // → "apartment". Don't strip "is", "us" etc.
  if (word.length >= 5 && word.endsWith('s') && !word.endsWith('ss')) {
    return word.slice(0, -1);
  }
  return word;
}
function greedyExpand(lower: string): string {
  const keys = Object.keys(ABBREV).sort((a, b) => b.length - a.length);
  let result = '';
  let pos = 0;
  outer: while (pos < lower.length) {
    for (const k of keys) {
      if (k.length < 2) continue;
      if (!lower.startsWith(k, pos)) continue;
      const expansion = ABBREV[k];
      const rest = expansion.slice(k.length);
      if (rest && lower.startsWith(rest, pos + k.length)) {
        continue; // word already fully spelled out in source
      }
      result += expansion;
      pos += k.length;
      continue outer;
    }
    result += lower[pos];
    pos++;
  }
  return result;
}
function normKey(s: string): string {
  const tokens = expandTokens(tokenize(s)).map(stripPlural);
  const key1 = tokens.join('');
  if (!/[a-z]/.test(s)) {
    const plain = (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const greedy = stripPlural(greedyExpand(plain));
    if (greedy.length > key1.length) return greedy;
  }
  return key1;
}

// ---------------------------------------------------------------------------
// Similarity
// ---------------------------------------------------------------------------
function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const dp = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) dp[j] = j;
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0]; dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1]);
      prev = tmp;
    }
  }
  return dp[b.length];
}
function jaccard(a: string[], b: string[]): number {
  if (!a.length || !b.length) return 0;
  const sa = new Set(a), sb = new Set(b);
  let inter = 0; for (const t of sa) if (sb.has(t)) inter++;
  return inter / (sa.size + sb.size - inter);
}
function plainKey(s: string): string {
  // Lowercase + strip non-alphanumeric. Ignores case and punctuation entirely,
  // unlike tokenize() which is sensitive to CamelCase patterns.
  return (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}
function pairSim(aKey: string, bKey: string, aTok: string[], bTok: string[]): number {
  if (aKey === bKey) return 1.0;
  let cont = 0;
  if (aKey.length >= 4 && bKey.length >= 4) {
    if (bKey.includes(aKey)) cont = aKey.length / bKey.length;
    else if (aKey.includes(bKey)) cont = bKey.length / aKey.length;
  }
  const jac = aTok.length && bTok.length ? jaccard(aTok, bTok) : 0;
  const dist = levenshtein(aKey, bKey);
  const lev = 1 - dist / Math.max(aKey.length, bKey.length);
  return Math.max(cont, 0.40 * jac + 0.40 * lev + 0.20 * cont);
}
function similarity(aName: string, bName: string): number {
  // Try TWO normalization strategies and take the max — tokenized (handles
  // abbreviation expansion) AND plain (ignores case/punctuation entirely).
  // Some inputs (like "SOUTh" vs "SOUt...") tokenize inconsistently because
  // of case-pattern quirks; plain-key sidesteps that.
  const aTok = expandTokens(tokenize(aName)).map(stripPlural);
  const bTok = expandTokens(tokenize(bName)).map(stripPlural);
  const aTokKey = aTok.join('');
  const bTokKey = bTok.join('');
  const tokScore = pairSim(aTokKey, bTokKey, aTok, bTok);

  const aPlain = plainKey(aName);
  const bPlain = plainKey(bName);
  // For plain comparison, use char-level pseudo-tokens for jaccard
  const aChars = [...aPlain];
  const bChars = [...bPlain];
  const plainScore = pairSim(aPlain, bPlain, aChars, bChars);

  return Math.max(tokScore, plainScore);
}

// ---------------------------------------------------------------------------
// Union-Find for clustering
// ---------------------------------------------------------------------------
class UnionFind {
  parent: number[];
  rank: number[];
  constructor(n: number) {
    this.parent = Array(n).fill(0).map((_, i) => i);
    this.rank = Array(n).fill(0);
  }
  find(x: number): number {
    if (this.parent[x] !== x) this.parent[x] = this.find(this.parent[x]);
    return this.parent[x];
  }
  union(x: number, y: number): void {
    const rx = this.find(x), ry = this.find(y);
    if (rx === ry) return;
    if (this.rank[rx] < this.rank[ry]) this.parent[rx] = ry;
    else if (this.rank[rx] > this.rank[ry]) this.parent[ry] = rx;
    else { this.parent[ry] = rx; this.rank[rx]++; }
  }
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface Node {
  kind: 'canonical' | 'text';
  name: string;
  sfId: string | null; // populated only for kind='canonical'
  leadCount: number;   // text: count from Group_old2__c; canonical: count from Lead.Group__c
}
interface Cluster {
  members: Node[];
  canonicalNode: Node | null; // existing or to-be-created
  isNew: boolean;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
  console.log(`\n🔗 Group_old2__c → Group__c reconciliation (clustering)`);
  console.log(`   target: ${TARGET}`);
  console.log(`   mode:   ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}`);
  console.log(`   merge threshold: ${MERGE_THRESHOLD}\n`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}`);

  // 1. Pull text values + canonicals
  console.log('\nPulling distinct Group_old2__c text values...');
  const distinct: any[] = await sf.soql(
    `SELECT Group_old2__c, COUNT(Id) cnt FROM Lead WHERE Group_old2__c != null GROUP BY Group_old2__c ORDER BY COUNT(Id) DESC`
  );
  console.log(`  ${distinct.length} distinct text values`);

  console.log('Pulling current Group__c records + lead counts...');
  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const leadCountsByGroup: any[] = await sf.soql(
    `SELECT Group__c, COUNT(Id) cnt FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const leadCountById = new Map<string, number>(leadCountsByGroup.map((r) => [r.Group__c, r.cnt]));
  console.log(`  ${groups.length} canonical Group__c records`);

  // 2. Build node list
  const nodes: Node[] = [];
  for (const g of groups) {
    nodes.push({ kind: 'canonical', name: g.Name, sfId: g.Id, leadCount: leadCountById.get(g.Id) || 0 });
  }
  for (const d of distinct) {
    nodes.push({ kind: 'text', name: d.Group_old2__c, sfId: null, leadCount: d.cnt });
  }
  console.log(`\nTotal nodes for clustering: ${nodes.length}`);

  // 2b. Load manual overrides
  const overrides = loadOverrides();
  const indexByName = new Map<string, number>();
  for (let i = 0; i < nodes.length; i++) indexByName.set(nodes[i].name, i);

  // Texts with any override are "locked" — they get excluded from BOTH the
  // normKey pre-bucket AND the similarity loop so the algorithm can't pull
  // them back into a cluster the human is explicitly routing them out of.
  const lockedTexts = new Set<string>([
    ...overrides.skip,
    ...overrides.mergeTo.keys(),
    ...overrides.newName.keys(),
  ]);

  // Warn about overrides that don't apply to any current text/canonical
  for (const text of overrides.skip) {
    if (!indexByName.has(text)) console.warn(`  ⚠ SKIP override "${text}" — text value not in DB`);
  }
  for (const [text, target] of overrides.mergeTo) {
    if (!indexByName.has(text)) console.warn(`  ⚠ MERGE override "${text}" → "${target}" — text value not in DB`);
    else if (!indexByName.has(target)) console.warn(`  ⚠ MERGE override "${text}" → "${target}" — canonical not in DB`);
  }
  for (const text of overrides.newName.keys()) {
    if (!indexByName.has(text)) console.warn(`  ⚠ NEW override "${text}" — text value not in DB`);
  }

  // 3. Pairwise similarity + union-find
  console.log(`\nClustering (similarity ≥ ${MERGE_THRESHOLD})...`);
  const uf = new UnionFind(nodes.length);
  // Pre-compute normalized keys for fast first-pass cluster suggestions.
  const keys = nodes.map((n) => normKey(n.name));
  // Bucket by normKey first — exact-key matches are guaranteed merges
  // (skip locked texts so overrides aren't undone via key-equality)
  const byKey = new Map<string, number[]>();
  for (let i = 0; i < nodes.length; i++) {
    const ni = nodes[i];
    if (ni.kind === 'text' && lockedTexts.has(ni.name)) continue;
    const k = keys[i];
    if (!byKey.has(k)) byKey.set(k, []);
    byKey.get(k)!.push(i);
  }
  for (const indices of byKey.values()) {
    for (let j = 1; j < indices.length; j++) uf.union(indices[0], indices[j]);
  }

  // 3a. Apply MERGE overrides — force-union text with its target canonical
  //     BEFORE the similarity loop so the rest of the pipeline sees the
  //     forced cluster membership.
  for (const [text, canonicalName] of overrides.mergeTo) {
    const ti = indexByName.get(text);
    const ci = indexByName.get(canonicalName);
    if (ti != null && ci != null) uf.union(ti, ci);
  }
  // 3b. Apply NEW overrides — force-union text values sharing the same new
  //     canonical name into one cluster.
  const newSeedRoots = new Map<string, number>(); // newName -> first index
  for (const [text, newName] of overrides.newName) {
    const ti = indexByName.get(text);
    if (ti == null) continue;
    const existing = newSeedRoots.get(newName);
    if (existing == null) newSeedRoots.set(newName, ti);
    else uf.union(existing, ti);
  }

  // Now full O(n²) similarity for pairs not already merged.
  // lockedTexts (defined above) prevents overridden texts from being pulled
  // into a different cluster by similarity.
  let mergedFromSim = 0;
  const total = nodes.length;
  for (let i = 0; i < total; i++) {
    if (i % 100 === 0) process.stdout.write(`  [${i}/${total}]\r`);
    const ni = nodes[i];
    if (ni.kind === 'text' && lockedTexts.has(ni.name)) continue;
    for (let j = i + 1; j < total; j++) {
      const nj = nodes[j];
      if (nj.kind === 'text' && lockedTexts.has(nj.name)) continue;
      if (uf.find(i) === uf.find(j)) continue; // already same cluster
      const s = similarity(ni.name, nj.name);
      if (s >= MERGE_THRESHOLD) {
        uf.union(i, j);
        mergedFromSim++;
      }
    }
  }
  console.log(`  Pairs merged via similarity: ${mergedFromSim}`);

  // 4. Collect clusters
  const clustersByRoot = new Map<number, Cluster>();
  for (let i = 0; i < nodes.length; i++) {
    const root = uf.find(i);
    let c = clustersByRoot.get(root);
    if (!c) { c = { members: [], canonicalNode: null, isNew: false }; clustersByRoot.set(root, c); }
    c.members.push(nodes[i]);
  }
  const clusters = [...clustersByRoot.values()];

  // For each cluster, pick canonical
  for (const c of clusters) {
    const canonicals = c.members.filter((m) => m.kind === 'canonical');
    if (canonicals.length > 0) {
      // Pick existing canonical with most leads (tiebreak: longest name)
      canonicals.sort((a, b) => b.leadCount - a.leadCount || b.name.length - a.name.length);
      c.canonicalNode = canonicals[0];
      c.isNew = false;
    } else {
      // No existing canonical — pick text value with most leads as the to-be-created name
      const texts = c.members.filter((m) => m.kind === 'text');
      texts.sort((a, b) => b.leadCount - a.leadCount || b.name.length - a.name.length);
      c.canonicalNode = texts[0];
      c.isNew = true;

      // If any text in this cluster has a NEW:<name> override, use that name
      // for the new canonical instead of the highest-lead text value's name.
      for (const t of texts) {
        const overrideName = overrides.newName.get(t.name);
        if (overrideName) {
          // Synthesize a renamed canonical node — leadCount stays as the sum
          // of the cluster (informational only; the new SF record gets a
          // fresh Id when created).
          c.canonicalNode = {
            kind: 'text',
            name: overrideName,
            sfId: null,
            leadCount: texts.reduce((s, x) => s + x.leadCount, 0),
          };
          break;
        }
      }
    }
  }

  // Stats — exclude clusters whose only text members were SKIP'd (those
  // would result in a Group__c created for a placeholder like "JJ" or "n/a").
  const clusterHasAssignableText = (c: Cluster): boolean =>
    c.members.some((m) => m.kind === 'text' && !overrides.skip.has(m.name));
  const clustersWithExisting = clusters.filter((c) => !c.isNew);
  const clustersToCreate = clusters.filter((c) => c.isNew && clusterHasAssignableText(c));
  const totalNewToCreate = clustersToCreate.length;
  const orphanCanonicals = clustersWithExisting.filter((c) =>
    c.members.every((m) => m.kind === 'canonical')
  ).length;

  console.log(`\n=== Clustering results ===`);
  console.log(`  Total clusters:                       ${clusters.length}`);
  console.log(`  Clusters with existing canonical:     ${clustersWithExisting.length}`);
  console.log(`    of which: canonical-only (no text): ${orphanCanonicals}`);
  console.log(`    of which: canonical + ≥1 text:      ${clustersWithExisting.length - orphanCanonicals}`);
  console.log(`  Clusters to CREATE NEW canonical:     ${totalNewToCreate}`);
  console.log(`  Avg cluster size: ${(nodes.length / clusters.length).toFixed(2)}`);

  // 5. Build text-value → canonical Group__c.Id map (only known IDs in dry-run)
  //    SKIP'd text values are deliberately omitted — leads with those values
  //    stay with Group__c=null.
  const textToCanonicalId = new Map<string, string | null>();
  let skippedTextCount = 0;
  for (const c of clusters) {
    for (const m of c.members) {
      if (m.kind === 'text') {
        if (overrides.skip.has(m.name)) { skippedTextCount++; continue; }
        textToCanonicalId.set(m.name, c.canonicalNode?.sfId ?? null);
      }
    }
  }
  if (skippedTextCount > 0) {
    console.log(`  Text values explicitly SKIPped by override: ${skippedTextCount}`);
  }

  // 6. Count leads that WOULD update
  console.log(`\nScanning Leads for potential updates...`);
  const leadsToUpdate: any[] = await sf.soql(
    `SELECT Id, Group_old2__c FROM Lead WHERE Group__c = null AND Group_old2__c != null`
  );
  const leadsResolvable = leadsToUpdate.filter((l) => textToCanonicalId.has(l.Group_old2__c));
  console.log(`  Leads with Group__c=null + Group_old2__c set: ${leadsToUpdate.length}`);
  console.log(`  Of those, will resolve to a canonical (after creation): ${leadsResolvable.length}`);

  // 7. Write report
  writeReport(clusters, overrides);
  console.log(`\n📄 Report: ${path.relative(REPO_ROOT, REPORT_PATH)}`);

  if (!COMMIT) {
    console.log(`\n🧪 Dry-run only. Review the report and re-run with --commit when ready.`);
    return;
  }

  // -------- COMMIT path --------
  // Create new canonicals
  console.log(`\nPhase 2: creating ${totalNewToCreate} new Group__c records...`);
  for (let off = 0; off < clustersToCreate.length; off += BATCH_SIZE) {
    const chunk = clustersToCreate.slice(off, off + BATCH_SIZE);
    const records = chunk.map((c) => ({ attributes: { type: 'Group__c' }, Name: c.canonicalNode!.name }));
    const url = `${sf.instanceUrl}/services/data/v${API_VERSION}/composite/sobjects`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ allOrNone: false, records }),
    });
    if (!res.ok) { console.error(`Batch ${off}: ${res.status} ${await res.text()}`); continue; }
    const results: any[] = await res.json();
    for (let i = 0; i < results.length; i++) {
      if (results[i].success) {
        chunk[i].canonicalNode!.sfId = results[i].id;
        for (const m of chunk[i].members) {
          if (m.kind !== 'text') continue;
          if (overrides.skip.has(m.name)) continue; // never assign SKIP'd values
          textToCanonicalId.set(m.name, results[i].id);
        }
      }
    }
    console.log(`  [${Math.min(off + BATCH_SIZE, clustersToCreate.length)}/${clustersToCreate.length}] created`);
  }

  // Update Lead.Group__c
  console.log(`\nPhase 3: updating Lead.Group__c on ${leadsToUpdate.length} leads...`);
  const batches: any[] = [];
  for (const lead of leadsToUpdate) {
    const cid = textToCanonicalId.get(lead.Group_old2__c);
    if (cid) batches.push({ attributes: { type: 'Lead' }, Id: lead.Id, Group__c: cid });
  }
  for (let off = 0; off < batches.length; off += BATCH_SIZE) {
    const chunk = batches.slice(off, off + BATCH_SIZE);
    const url = `${sf.instanceUrl}/services/data/v${API_VERSION}/composite/sobjects`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ allOrNone: false, records: chunk }),
    });
    if (!res.ok) { console.error(`Lead batch ${off}: ${res.status} ${await res.text()}`); continue; }
    const results: any[] = await res.json();
    const failed = results.filter((r) => !r.success).length;
    console.log(`  [${Math.min(off + BATCH_SIZE, batches.length)}/${batches.length}] ${failed > 0 ? `(${failed} failed)` : 'ok'}`);
  }

  console.log(`\n✅ Commit complete. Re-run the junction + user-access migrations next.`);
}

function writeReport(
  clusters: Cluster[],
  overrides: { skip: Set<string>; mergeTo: Map<string, string>; newName: Map<string, string> }
): void {
  const lines: string[] = [];
  lines.push(`GROUP_OLD → GROUP CLUSTERING REPORT`);
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push('');

  const clustersWithText = clusters.filter((c) =>
    c.members.some((m) => m.kind === 'text' && !overrides.skip.has(m.name))
  );
  const clustersWithExisting = clustersWithText.filter((c) => !c.isNew);
  const toCreate = clustersWithText.filter((c) => c.isNew);

  lines.push(`Total clusters: ${clusters.length}`);
  lines.push(`Clusters containing assignable text values: ${clustersWithText.length}`);
  lines.push(`  Auto-merging to existing canonical: ${clustersWithExisting.length}`);
  lines.push(`  Would create NEW canonical:         ${toCreate.length}`);
  lines.push(`Overrides applied: ${overrides.skip.size} SKIP, ${overrides.mergeTo.size} MERGE, ${overrides.newName.size} NEW`);
  lines.push('');

  // SKIP section — show what we're dropping so the user can sanity-check.
  // Include lead counts so we know the cleanup scope.
  if (overrides.skip.size > 0) {
    const skipNodeByName = new Map<string, Node>();
    for (const c of clusters) for (const m of c.members) {
      if (m.kind === 'text' && overrides.skip.has(m.name)) skipNodeByName.set(m.name, m);
    }
    const skippedSorted = [...overrides.skip]
      .map((n) => ({ name: n, leadCount: skipNodeByName.get(n)?.leadCount ?? 0 }))
      .sort((a, b) => b.leadCount - a.leadCount);
    const totalSkippedLeads = skippedSorted.reduce((s, x) => s + x.leadCount, 0);

    lines.push(`══════ SKIPPED BY OVERRIDE (${overrides.skip.size} values, ${totalSkippedLeads} leads) ══════`);
    lines.push(`These text values get NO Group__c assignment (Lead.Group__c stays null).`);
    lines.push(`Sorted by lead count desc — top entries are best cleanup-discussion candidates.`);
    lines.push('');
    for (const s of skippedSorted) {
      lines.push(`  ⊘ "${s.name}"  (${s.leadCount} leads)`);
    }
    lines.push('');
  }

  // Sort merging clusters by canonical lead count
  clustersWithExisting.sort((a, b) =>
    (b.canonicalNode!.leadCount) - (a.canonicalNode!.leadCount)
  );
  lines.push(`══════ AUTO-MERGING TO EXISTING CANONICAL (${clustersWithExisting.length}) ══════`);
  lines.push(`Each text value gets linked to the existing Group__c shown.`);
  lines.push('');
  for (const c of clustersWithExisting) {
    const can = c.canonicalNode!;
    const texts = c.members
      .filter((m) => m.kind === 'text' && !overrides.skip.has(m.name))
      .sort((a, b) => b.leadCount - a.leadCount);
    lines.push(`  → "${can.name}"  (canonical, ${can.leadCount} leads, id=${can.sfId})`);
    for (const t of texts) {
      lines.push(`      • "${t.name}"  (${t.leadCount} leads)`);
    }
    lines.push('');
  }

  // To-create clusters by total lead count desc (excluding SKIP'd members)
  toCreate.sort((a, b) => {
    const ta = a.members
      .filter((m) => m.kind === 'text' && !overrides.skip.has(m.name))
      .reduce((s, m) => s + m.leadCount, 0);
    const tb = b.members
      .filter((m) => m.kind === 'text' && !overrides.skip.has(m.name))
      .reduce((s, m) => s + m.leadCount, 0);
    return tb - ta;
  });
  lines.push('');
  lines.push(`══════ WOULD CREATE NEW CANONICAL (${toCreate.length}) ══════`);
  lines.push(`Each cluster needs a new Group__c. Member text values listed.`);
  lines.push('');
  for (const c of toCreate) {
    const can = c.canonicalNode!;
    const texts = c.members
      .filter((m) => m.kind === 'text' && !overrides.skip.has(m.name))
      .sort((a, b) => b.leadCount - a.leadCount);
    const total = texts.reduce((s, t) => s + t.leadCount, 0);
    if (texts.length === 1) {
      lines.push(`  NEW "${can.name}"  (${can.leadCount} leads)`);
    } else {
      lines.push(`  NEW "${can.name}"  (canonical of ${texts.length}-member cluster, ${total} total leads)`);
      for (const t of texts) {
        const marker = t.name === can.name ? '⭐' : '  ';
        lines.push(`     ${marker} "${t.name}"  (${t.leadCount} leads)`);
      }
    }
    lines.push('');
  }

  fs.writeFileSync(REPORT_PATH, lines.join('\n'));
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
