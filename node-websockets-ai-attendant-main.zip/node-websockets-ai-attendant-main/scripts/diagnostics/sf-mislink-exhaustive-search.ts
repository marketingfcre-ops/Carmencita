/**
 * Exhaustive search for WP posts that could be the "correct" match for the 3
 * SF mislinks. Uses RAW substring matching (no normalize) on multiple fields
 * to maximize recall.
 *
 * For each SF record, lists EVERY WP post whose address, title, OR slug
 * contains any of the SF address tokens. Lets a human visually confirm.
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';
const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const TARGETS = [
  { sfId: 'a0RJw000008GimsMAC', sfAddress: '700 SW 16th Ave', city: 'Fort Lauderdale', currentWp: 39894 },
  { sfId: 'a0RJw000008KCQDMA4', sfAddress: '1395 NW 22 ST', city: 'Miami', currentWp: 19819 },
  { sfId: 'a0RJw000008c9AXMAY', sfAddress: '2811 SW 3rd Ave', city: 'Miami', currentWp: 19778 },
];

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  slug: string;
  fave_property_address: string;
  fave_property_size: string;
  fave_property_price: string;
  excerpt: string;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,slug,excerpt,fave_property_address,fave_property_size,fave_property_price`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          slug: p.slug || '',
          fave_property_address: p.fave_property_address || '',
          fave_property_size: p.fave_property_size || '',
          fave_property_price: p.fave_property_price || '',
          excerpt: (p.excerpt?.rendered || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').slice(0, 100),
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

async function main() {
  if (!WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔎 Exhaustive WP search for the 3 SF mislinks\n');
  const wp = await fetchAllWpPosts();
  console.log(`Loaded ${wp.length} WP posts.\n`);

  for (const t of TARGETS) {
    console.log('═'.repeat(72));
    console.log(`SF ${t.sfId}`);
    console.log(`   Address:  "${t.sfAddress}"`);
    console.log(`   City:     ${t.city}`);
    console.log(`   Currently linked: wp:${t.currentWp}`);
    console.log('═'.repeat(72));

    // Extract tokens from the SF address
    const addrLower = t.sfAddress.toLowerCase();
    const tokens = addrLower
      .split(/[\s,#./]+/)
      .filter((s) => s.length > 0);
    const houseNumber = tokens.find((tok) => /^\d+/.test(tok)) || '';

    console.log(`\nSearch tokens: ${JSON.stringify(tokens)}`);
    console.log(`House number: "${houseNumber}"`);
    console.log(`City: "${t.city.toLowerCase()}"\n`);

    // Find every WP post whose address starts with the house number OR
    // contains the house number adjacent to a direction token
    const candidates: { post: WpPost; reason: string }[] = [];
    for (const p of wp) {
      const addr = p.fave_property_address.toLowerCase();
      const title = p.title.toLowerCase();
      const slug = p.slug.toLowerCase();
      const excerpt = p.excerpt.toLowerCase();

      const matchReasons: string[] = [];

      // House number presence in address (as a word)
      const houseRegex = new RegExp(`\\b${houseNumber}\\b`);
      if (houseRegex.test(addr)) matchReasons.push(`addr contains "${houseNumber}"`);
      if (houseRegex.test(title)) matchReasons.push(`title contains "${houseNumber}"`);
      if (slug.includes(houseNumber)) matchReasons.push(`slug contains "${houseNumber}"`);
      if (excerpt && houseRegex.test(excerpt)) matchReasons.push(`excerpt contains "${houseNumber}"`);

      // City match in address
      const cityLower = t.city.toLowerCase();
      const cityInAddr = addr.includes(cityLower);

      if (matchReasons.length > 0) {
        candidates.push({
          post: p,
          reason: matchReasons.join(', ') + (cityInAddr ? ` + city match` : ''),
        });
      }
    }

    console.log(`Found ${candidates.length} WP posts containing house number "${houseNumber}" anywhere:\n`);

    // Sort: city-matches first, then exact-house-number-in-address, then others
    candidates.sort((a, b) => {
      const cityA = a.post.fave_property_address.toLowerCase().includes(t.city.toLowerCase()) ? 0 : 1;
      const cityB = b.post.fave_property_address.toLowerCase().includes(t.city.toLowerCase()) ? 0 : 1;
      return cityA - cityB || a.post.id - b.post.id;
    });

    for (const c of candidates) {
      const flag = c.post.id === t.currentWp ? '  ← currently linked' : '';
      console.log(`   wp:${c.post.id} ${c.post.status.padEnd(8)} ${c.post.date.slice(0, 10)}${flag}`);
      console.log(`     title:  "${c.post.title.replace(/&#8211;/g, '–').slice(0, 72)}"`);
      console.log(`     addr:   "${c.post.fave_property_address}"`);
      console.log(`     slug:   ${c.post.slug}`);
      if (c.post.excerpt) console.log(`     excerpt: ${c.post.excerpt}`);
      console.log(`     match: ${c.reason}`);
      console.log('');
    }

    console.log('');
  }

  console.log('═'.repeat(72));
  console.log('INTERPRETATION:');
  console.log('═'.repeat(72));
  console.log(`
  For each SF record, look through every WP post above and find the one
  whose ADDRESS or TITLE actually matches the SF address (same street,
  same direction, same city). If you see one — that's the correct link.
  If none of them are actually at that address, NULL is the right call.
  `);

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
