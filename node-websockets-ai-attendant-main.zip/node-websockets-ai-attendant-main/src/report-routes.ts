/**
 * Marketing & Automation Report — Fastify routes.
 *
 *   GET /report            — server-rendered HTML dashboard (ADMIN_KEY gated)
 *   GET /report/api/data   — the underlying ReportData as JSON (ADMIN_KEY gated)
 *
 * The HTML is a faithful port of the static GitHub Pages report
 * (../fausto-reports/index.html) — identical CSS — rendered from live
 * `ReportData`. Follows the Weekly Report Build Rules handoff: Friday-anchored
 * windows (weekend intakes counted), 4 KPI cards per section, no CM
 * campaign-by-campaign table, no Q1 comparisons, no window-size caveats,
 * positive framing (improvements green, declines muted — never alarm-red).
 *
 * Query params: `?refresh=1` bypasses the 5-min cache; `?friday=YYYY-MM-DD`
 * backfills a specific week (default: most recent Friday).
 */

import type { FastifyInstance } from 'fastify';
import {
  getReportData,
  fmtDuration,
  type ReportData,
  type Delta,
  type IntakeRow,
} from './report';
import type { ClickupTask } from './integrations/clickup';

// ---------------------------------------------------------------------------
// Small render helpers
// ---------------------------------------------------------------------------

function esc(s: unknown): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function num(n: number): string {
  return n.toLocaleString('en-US');
}

/**
 * Delta span for KPI compare lines. Framing rule: improvements are green,
 * everything else is muted grey (never alarm-red). `lowerIsBetter` flips which
 * direction counts as an improvement (e.g. unsubscribes going down).
 */
function deltaSpan(d: Delta, lowerIsBetter = false): string {
  if (d.pct == null) return `<span class="neu">n/a</span>`;
  const improving = lowerIsBetter ? d.direction === 'down' : d.direction === 'up';
  const cls = improving ? 'up' : 'neu';
  const arrow = d.direction === 'up' ? '▲' : d.direction === 'down' ? '▼' : '';
  return `<span class="${cls}">${arrow} ${Math.abs(d.pct)}%</span>`;
}

/** Table-cell change span — same framing (green improvement, muted otherwise). */
function changeCell(d: Delta, lowerIsBetter = false): string {
  if (d.pct == null) return '—';
  const improving = lowerIsBetter ? d.direction === 'down' : d.direction === 'up';
  const color = improving ? '#2ecc71' : '#aaa';
  const arrow = d.direction === 'up' ? '▲ ' : d.direction === 'down' ? '▼ ' : '';
  return `<span style="color:${color};">${arrow}${Math.abs(d.pct)}%</span>`;
}

// ---------------------------------------------------------------------------
// Section renderers
// ---------------------------------------------------------------------------

function renderHeader(d: ReportData): string {
  const w = d.windows;
  const gen = new Date(w.generatedAt).toLocaleString('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
  return `
<div class="report-header">
  <div class="eyebrow">Fausto Commercial Realty Consultants</div>
  <h1>MARKETING &amp; AUTOMATION REPORT</h1>
  <div class="subtitle">Weekly Performance &amp; Deliverables Report &nbsp;·&nbsp; Prepared for the weekly objectives review</div>
  <div class="meta">
    <span><strong>Current Week</strong> ${esc(w.currentWorkWeekLabel)}</span>
    <span><strong>Prior Week</strong> ${esc(w.priorWorkWeekLabel)}</span>
    <span><strong>Generated</strong> ${esc(gen)}</span>
  </div>
</div>`;
}

function renderWarnings(d: ReportData): string {
  if (!d.warnings.length && !d.email.clientAmbiguous) return '';
  const items: string[] = [...d.warnings];
  if (d.email.clientAmbiguous) {
    items.push(
      `Campaign Monitor client was auto-selected as "<strong>${esc(d.email.clientName)}</strong>" — confirm this is the Fausto account (set CM_CLIENT_ID to pin it).`
    );
  }
  return `
<div class="section" style="padding-bottom:0;border-bottom:none;">
  <div class="warn-box">
    <strong>Operator notes (${items.length}):</strong>
    <ul style="margin:6px 0 0 18px;">${items.map((i) => `<li>${i}</li>`).join('')}</ul>
  </div>
</div>`;
}

function renderGa4(d: ReportData): string {
  const g = d.ga4;
  if (g.source === 'pending' || !g.current || !g.prior || !g.deltas) {
    return `
<div class="section">
  <div class="section-title">Website Traffic — Google Analytics 4</div>
  <div class="warn-box">${esc(g.note)}</div>
</div>`;
  }
  const c = g.current, p = g.prior, dl = g.deltas;
  const srcTag = g.source === 'manual' ? ' &nbsp;·&nbsp; manual read' : '';
  return `
<div class="section">
  <div class="section-title">Website Traffic — Google Analytics 4${srcTag}</div>
  <div class="kpi-row">
    <div class="kpi">
      <div class="label">Active Users</div>
      <div class="value">${num(c.activeUsers)}</div>
      <div class="compare">${deltaSpan(dl.activeUsers)} vs prior week &nbsp;·&nbsp; New users: <strong>${num(c.newUsers)}</strong> ${deltaSpan(dl.newUsers)}</div>
    </div>
    <div class="kpi">
      <div class="label">Total Sessions</div>
      <div class="value">${num(c.sessions)}</div>
      <div class="compare">${deltaSpan(dl.sessions)} vs prior week</div>
    </div>
    <div class="kpi">
      <div class="label">Avg Engagement Time</div>
      <div class="value">${esc(fmtDuration(c.avgEngagementPerUserSec))}</div>
      <div class="compare">Per active user &nbsp;·&nbsp; Page views: <strong>${num(c.screenPageViews)}</strong></div>
    </div>
    <div class="kpi">
      <div class="label">Key Events (Conversions)</div>
      <div class="value">${num(c.keyEvents)}</div>
      <div class="compare">${deltaSpan(dl.keyEvents)} vs prior wk (${num(p.keyEvents)})</div>
    </div>
  </div>
  <div class="tbl-wrap">
    <table>
      <thead><tr>
        <th>Metric</th>
        <th>${esc(d.windows.priorWorkWeekLabel)} (Prior)</th>
        <th>${esc(d.windows.trafficCurrentLabel)} (Current)</th>
        <th>Change</th>
      </tr></thead>
      <tbody>
        <tr><td>Sessions</td><td>${num(p.sessions)}</td><td>${num(c.sessions)}</td><td>${changeCell(dl.sessions)}</td></tr>
        <tr class="row-alt"><td>Active users</td><td>${num(p.activeUsers)}</td><td>${num(c.activeUsers)}</td><td>${changeCell(dl.activeUsers)}</td></tr>
        <tr><td>New users</td><td>${num(p.newUsers)}</td><td><strong style="color:#2ecc71;">${num(c.newUsers)}</strong></td><td>${changeCell(dl.newUsers)}</td></tr>
        <tr class="row-alt"><td>Page views</td><td>${num(p.screenPageViews)}</td><td>${num(c.screenPageViews)}</td><td>${changeCell(dl.screenPageViews)}</td></tr>
        <tr><td>Key events (conversions)</td><td>${num(p.keyEvents)}</td><td><strong style="color:#2ecc71;">${num(c.keyEvents)}</strong></td><td>${changeCell(dl.keyEvents)}</td></tr>
        <tr class="row-alt"><td>Avg engagement time</td><td>${esc(fmtDuration(p.avgEngagementPerUserSec))}</td><td>${esc(fmtDuration(c.avgEngagementPerUserSec))} / user</td><td>—</td></tr>
      </tbody>
    </table>
  </div>
</div>`;
}

function renderEmail(d: ReportData): string {
  const e = d.email;
  if (!e.configured) {
    return `
<div class="section">
  <div class="section-title">Email Marketing — Campaign Monitor</div>
  <div class="warn-box">Campaign Monitor data unavailable — see operator notes.</div>
</div>`;
  }
  return `
<div class="section">
  <div class="section-title">Email Marketing — Campaign Monitor</div>
  <div class="kpi-row">
    <div class="kpi">
      <div class="label">Campaigns Sent</div>
      <div class="value">${num(e.campaignsSent)}</div>
      <div class="compare">${num(e.totalRecipients)} emails delivered</div>
    </div>
    <div class="kpi">
      <div class="label">Unsubscribes</div>
      <div class="value">${num(e.totalUnsubscribes)}</div>
      <div class="compare">${deltaSpan(e.unsubDelta, true)} vs prior wk (${num(e.priorUnsubscribes)}) &nbsp;·&nbsp; Bounce rate: <strong>${e.bounceRatePct}%</strong></div>
    </div>
    <div class="kpi">
      <div class="label">Avg Open Rate</div>
      <div class="value">${e.avgOpenRatePct}%</div>
      <div class="compare">Prior wk: ${e.priorAvgOpenRatePct}%</div>
    </div>
    <div class="kpi">
      <div class="label">Avg Click Rate</div>
      <div class="value">${e.avgClickRatePct}%</div>
      <div class="compare">Across ${num(e.campaignsSent)} send(s) this week</div>
    </div>
  </div>
</div>`;
}

function intakeTable(rows: IntakeRow[]): string {
  if (!rows.length) return `<p class="note">No intakes in this window.</p>`;
  return `<div class="tbl-wrap"><table>
    <thead><tr><th>Listing</th><th>Agent</th><th style="text-align:right;">Price</th><th>Date</th><th></th></tr></thead>
    <tbody>${rows
      .map((r, i) => {
        const badge = r.isElior
          ? '<span class="badge badge-star">★L</span>'
          : r.isFullPackage
          ? '<span class="badge badge-star">★</span>'
          : '';
        const price = r.listingType && /lease/i.test(r.listingType)
          ? `${esc(r.priceLabel)} <span style="color:#888;">lease</span>`
          : esc(r.priceLabel);
        return `<tr class="${i % 2 ? 'row-alt' : ''}">
        <td>${esc(r.name)}</td><td>${esc(r.agent)}</td>
        <td style="text-align:right;">${price}</td><td>${esc(r.dateLabel)}</td><td>${badge}</td></tr>`;
      })
      .join('')}</tbody></table></div>`;
}

function renderIntakes(d: ReportData): string {
  const s = d.intakes;
  const curLabel = d.windows.trafficCurrentLabel; // Sat–Fri, incl. weekend
  const priLabel = d.windows.priorWorkWeekLabel; // Mon–Fri
  return `
<div class="section">
  <div class="section-title">Salesforce — New Listing Intakes</div>
  <div class="kpi-row">
    <div class="kpi">
      <div class="label">New Listings · ${esc(priLabel)}</div>
      <div class="value">${num(s.priorCount)}</div>
      <div class="compare">Prior week</div>
    </div>
    <div class="kpi">
      <div class="label">New Listings · ${esc(curLabel)}</div>
      <div class="value">${num(s.currentCount)}</div>
      <div class="compare">Current week · incl. weekend</div>
    </div>
    <div class="kpi">
      <div class="label">Total Intakes</div>
      <div class="value">${num(s.totalCount)}</div>
      <div class="compare">Both weeks</div>
    </div>
    <div class="kpi">
      <div class="label">Full Pkg Triggered ★</div>
      <div class="value">${num(s.fullPackageCount)}</div>
      <div class="compare">≥ $3M or Elior Levi &nbsp;·&nbsp; OM + flyer + page + LoopNet</div>
    </div>
  </div>
  <div class="two-col">
    <div>
      <div style="font-size:11px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;">${esc(priLabel)} &nbsp;·&nbsp; ${num(s.priorCount)} listings</div>
      ${intakeTable(s.priorRows)}
    </div>
    <div>
      <div style="font-size:11px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;">${esc(curLabel)} &nbsp;·&nbsp; ${num(s.currentCount)} listings (incl. weekend)</div>
      ${intakeTable(s.currentRows)}
    </div>
  </div>
  <p class="note">${esc(s.note)}</p>
</div>`;
}

const STATUS_BADGE: Record<string, string> = {
  LIVE: 'badge-live',
  DONE: 'badge-live',
  'IN PROGRESS': 'badge-inprog',
  NEW: 'badge-new',
  NEEDS: 'badge-needs',
};

function renderAutomation(d: ReportData): string {
  const a = d.automation;
  return `
<div class="section">
  <div class="section-title">Automation &amp; Project Work Delivered</div>
  <div class="col-card" style="margin-top:0;">
    <div class="col-head">${esc(a.periodLabel)}</div>
    <ul>
      ${a.entries
        .map((e) => {
          const badge = e.status
            ? ` &nbsp;<span class="${STATUS_BADGE[e.status] || 'badge-new'}">${esc(e.status)}</span>`
            : '';
          return `<li>${esc(e.text)}${badge}<span class="tag">${esc(e.tag)}</span></li>`;
        })
        .join('\n      ')}
    </ul>
  </div>
</div>`;
}

function priorityDot(p: string | null): string {
  if (!p) return '';
  const cls = p === 'urgent' ? 'pri-urgent' : p === 'high' ? 'pri-high' : 'pri-normal';
  return `<div class="cu-pri ${cls}">● ${esc(p)}</div>`;
}

function cuColumn(title: string, colClass: string, count: number, tasks: ClickupTask[]): string {
  const items = tasks.length
    ? tasks
        .map(
          (t) => `<div class="cu-item">
        <a href="${esc(t.url)}" target="_blank" rel="noopener" style="color:#ccc;text-decoration:none;">${esc(t.name)}</a>
        <span class="cu-tag">${esc(t.listName)}</span>
        ${priorityDot(t.priority)}
      </div>`
        )
        .join('\n      ')
    : `<div class="cu-item" style="color:#666;">None</div>`;
  return `<div class="cu-col ${colClass}">
      <div class="cu-col-head">${title} <span>${count}</span></div>
      ${items}
    </div>`;
}

function renderClickup(d: ReportData): string {
  const cu = d.clickup;
  if (!cu.configured || !cu.board) {
    return `
<div class="section">
  <div class="section-title">Project Deliverables Board &nbsp;·&nbsp; ClickUp Snapshot</div>
  <div class="warn-box">${esc(cu.note)}</div>
</div>`;
  }
  const b = cu.board;
  const gen = new Date(d.windows.generatedAt).toLocaleDateString('en-US', { dateStyle: 'medium' });
  return `
<div class="section">
  <div class="section-title">Project Deliverables Board &nbsp;·&nbsp; ClickUp Snapshot, ${esc(gen)}</div>
  <div style="display:flex;gap:28px;margin-bottom:14px;">
    <span style="font-size:13px;">✅ Shipped &nbsp;<strong style="color:#2ecc71;font-size:18px;">${b.counts.shipped}</strong></span>
    <span style="font-size:13px;">⏸ On Hold &nbsp;<strong style="color:#3a82f7;font-size:18px;">${b.counts.onHold}</strong></span>
    <span style="font-size:13px;">⛔ Blocked / Stuck &nbsp;<strong style="color:#e74c3c;font-size:18px;">${b.counts.blocked}</strong></span>
  </div>
  <div class="cu-board">
    ${cuColumn('✅ Shipped', 'cu-ship', b.counts.shipped, b.shipped)}
    ${cuColumn('⏸ On Hold', 'cu-prog', b.counts.onHold, b.onHold)}
    ${cuColumn('⛔ Blocked / Stuck', 'cu-blk', b.counts.blocked, b.blocked)}
  </div>
  <p class="note" style="margin-top:14px;">${esc(cu.note)}</p>
</div>`;
}

function renderHandoff(d: ReportData): string {
  const board = d.clickup.board;
  if (!board || !board.handoff.length) return '';

  // Group the folder-09 tasks by their list (e.g. "Knowledge Handoff Plan",
  // "Account & Access Migration") and render each as a checklist card.
  const groups = new Map<string, ClickupTask[]>();
  for (const t of board.handoff) {
    const arr = groups.get(t.listName) || [];
    arr.push(t);
    groups.set(t.listName, arr);
  }

  const cards = [...groups.entries()]
    .map(([listName, tasks]) => {
      const done = tasks.filter((t) => t.done).length;
      const items = tasks
        .map((t) => {
          const mark = t.done
            ? '<span style="color:#2ecc71;">✓</span>'
            : '<span style="color:#666;">○</span>';
          const pri =
            t.priority === 'urgent' || t.priority === 'high'
              ? ` <span style="color:#e67e22;font-size:10px;">● ${esc(t.priority)}</span>`
              : '';
          return `<li>${mark} <a href="${esc(t.url)}" target="_blank" rel="noopener" style="color:#ccc;text-decoration:none;">${esc(t.name)}</a>${pri}</li>`;
        })
        .join('\n        ');
      return `<div class="col-card">
      <div class="col-head">${esc(listName)} &nbsp;·&nbsp; ${done}/${tasks.length} done</div>
      <ul>${items}</ul>
    </div>`;
    })
    .join('\n    ');

  return `
<div class="section">
  <div class="section-title">Transition &amp; Handoff Plan &nbsp;·&nbsp; ClickUp #9</div>
  <div class="two-col">
    ${cards}
  </div>
</div>`;
}

function renderFooter(d: ReportData): string {
  return `
<div class="footer">
  <strong style="color:#666;">Sources:</strong> ${esc(d.sources)}
</div>`;
}

// ---------------------------------------------------------------------------
// Full page — CSS is a verbatim copy of the static report (identical styling).
// ---------------------------------------------------------------------------

function renderPage(d: ReportData): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fausto Commercial — Marketing &amp; Automation Report</title>
<style>
:root{--bg:#0d0d0d;--card:#161616;--card2:#1c1c1c;--border:#2a2a2a;--text:#ddd;--muted:#888;--accent:#3a82f7;--green:#27ae60;--lgreen:#1a3d28;--red:#c0392b;--gold:#d4a017;--ship:#1a3d28;--prog:#1a2d3d;--blk:#3d1a1a;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:var(--text);font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.55;}
a{color:var(--accent);}
.report-header{background:#111;border-bottom:2px solid var(--gold);padding:22px 36px 18px;}
.report-header .eyebrow{font-size:10px;letter-spacing:.18em;color:var(--gold);text-transform:uppercase;margin-bottom:6px;}
.report-header h1{font-size:22px;font-weight:700;color:#fff;letter-spacing:.04em;margin-bottom:4px;}
.report-header .subtitle{font-size:12px;color:var(--muted);}
.report-header .meta{margin-top:10px;font-size:11px;color:#999;display:flex;gap:28px;flex-wrap:wrap;}
.report-header .meta span strong{color:#ccc;}
.section{padding:28px 36px 20px;border-bottom:1px solid var(--border);}
.section-title{font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);margin-bottom:14px;display:flex;align-items:center;gap:10px;}
.section-title::after{content:'';flex:1;height:1px;background:var(--border);}
.kpi-row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}
.kpi{background:var(--card);border:1px solid var(--border);border-radius:5px;padding:14px 16px;}
.kpi .label{font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;}
.kpi .value{font-size:22px;font-weight:700;color:#fff;line-height:1;}
.kpi .compare{font-size:11px;color:var(--muted);margin-top:5px;}
.kpi .up{color:#2ecc71;} .kpi .dn{color:#e74c3c;} .kpi .neu{color:#aaa;}
.up{color:#2ecc71;} .dn{color:#e74c3c;} .neu{color:#aaa;}
.tbl-wrap{overflow-x:auto;margin-bottom:8px;}
table{width:100%;border-collapse:collapse;font-size:12px;}
th{background:#1e1e1e;color:#aaa;font-weight:600;font-size:10px;letter-spacing:.08em;text-transform:uppercase;padding:8px 10px;border-bottom:1px solid #333;text-align:left;}
td{padding:7px 10px;border-bottom:1px solid #222;vertical-align:top;}
tr:last-child td{border-bottom:none;}
.row-alt td{background:#141414;}
.badge{display:inline-block;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700;}
.badge-star{background:#1c2e1a;color:#2ecc71;}
.badge-warn{background:#3d2a10;color:#e67e22;}
.badge-blk{background:#3d1515;color:#e74c3c;}
.badge-prog{background:#102030;color:#3a82f7;}
.note{font-size:11px;color:var(--muted);margin-top:8px;font-style:italic;}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.col-card{background:var(--card);border:1px solid var(--border);border-radius:5px;padding:16px;}
.col-card .col-head{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border);}
.col-card ul{list-style:none;padding:0;}
.col-card ul li{padding:5px 0;border-bottom:1px solid #1e1e1e;font-size:12px;color:#ccc;line-height:1.4;}
.col-card ul li:last-child{border-bottom:none;}
.col-card ul li .tag{font-size:10px;color:var(--muted);display:block;margin-top:2px;}
.badge-live{color:#2ecc71;font-weight:700;font-size:10px;}
.badge-new{color:#3a82f7;font-weight:700;font-size:10px;}
.badge-inprog{color:#e67e22;font-weight:700;font-size:10px;}
.badge-needs{color:#e74c3c;font-weight:700;font-size:10px;}
.cu-board{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:14px;}
.cu-col{border-radius:5px;overflow:hidden;}
.cu-col-head{padding:10px 14px;font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;}
.cu-ship .cu-col-head{background:var(--lgreen);color:#2ecc71;}
.cu-prog .cu-col-head{background:var(--prog);color:#3a82f7;}
.cu-blk  .cu-col-head{background:var(--blk);color:#e74c3c;}
.cu-col-head span{float:right;font-size:16px;font-weight:700;}
.cu-item{background:var(--card2);border-bottom:1px solid var(--border);padding:9px 14px;font-size:12px;color:#ccc;}
.cu-item:last-child{border-bottom:none;}
.cu-item .cu-tag{font-size:10px;color:var(--muted);display:block;margin-top:2px;}
.cu-item .cu-pri{font-size:10px;margin-top:2px;}
.pri-urgent{color:#e74c3c;} .pri-high{color:#e67e22;} .pri-normal{color:#aaa;}
.warn-box{background:#221a0a;border:1px solid #664d00;border-radius:5px;padding:12px 16px;margin-bottom:18px;font-size:12px;color:#cc9900;}
.warn-box strong{color:#e6b800;}
.footer{padding:18px 36px;font-size:10px;color:#555;border-top:1px solid #1e1e1e;line-height:1.7;}
@media print{
  body{background:#fff!important;color:#111!important;}
  .report-header{background:#1F3864!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
  .section{page-break-inside:avoid;}
}
</style>
</head>
<body>
${renderHeader(d)}
${renderWarnings(d)}
${renderGa4(d)}
${renderEmail(d)}
${renderIntakes(d)}
${renderAutomation(d)}
${renderClickup(d)}
${renderHandoff(d)}
${renderFooter(d)}
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// Route registration
// ---------------------------------------------------------------------------

export async function registerReportRoutes(fastify: FastifyInstance): Promise<void> {
  const ADMIN_KEY = process.env.ADMIN_KEY || 'fausto2026';

  fastify.get('/report', async (req, reply) => {
    const query = req.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) {
      reply.code(404).send('Not found');
      return;
    }
    try {
      const data = await getReportData(query.refresh === '1', query.friday);
      reply.type('text/html').send(renderPage(data));
    } catch (err: any) {
      req.log.error({ err }, 'report render failed');
      reply.code(500).type('text/html').send(
        `<pre style="color:#e74c3c;background:#111;padding:20px;font-family:monospace;">Report failed to assemble:\n\n${esc(err?.stack || err?.message || err)}</pre>`
      );
    }
  });

  fastify.get('/report/api/data', async (req, reply) => {
    const query = req.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) {
      reply.code(404).send('Not found');
      return;
    }
    try {
      return await getReportData(query.refresh === '1', query.friday);
    } catch (err: any) {
      req.log.error({ err }, 'report data failed');
      reply.code(500).send({ error: err?.message || String(err) });
      return;
    }
  });
}
