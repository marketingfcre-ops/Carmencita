/**
 * Import LoopNet email leads CSV into Campaign Monitor, bucketed by
 * (asset type, intent). Uses src/campaign-monitor.ts for CM calls and
 * hits SF directly for Property__c lookups by LoopNet ID.
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/cm-import.ts --csv <path>
 *   npx tsx --env-file .env.local scripts/cm-import.ts --csv <path> --live
 *   npx tsx --env-file .env.local scripts/cm-import.ts --csv <path> --bucket-only
 *
 * Env:
 *   SF_LOGIN_URL, SF_CLIENT_ID, SF_CLIENT_SECRET
 *   CM_API_KEY
 */

import { readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';

import {
  listClients,
  listLists,
  importSubscribersBatched,
  CMSubscriberInput,
} from '../../src/campaign-monitor';

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const OUTPUT_DIR = join(process.cwd(), 'data', 'cm_import');
const FALLBACK_LIST_NAME = 'General FCom List';

// Desired list-name mapping: (asset_type, intent) → exact CM list name.
// We resolve to real list IDs at runtime by fetching lists from the client.
const BUCKET_LIST_NAMES: Record<string, string> = {
  'industrial|lease':       'Loopnet Industrial For Lease',
  'industrial|sale':        'Loopnet Industrial For Sale',
  'land development|sale':  'Loopnet Land Development for Sale',
  'land|lease':             'Loopnet Land for Lease',
  'medical office|lease':   'Loopnet Medical Office for Lease',
  'medical office|sale':    'Loopnet Medical Office for Sale',
  'multi-family|sale':      'Loopnet Multi-Family for Sale',
  'office|lease':           'Loopnet Office for Lease',
  'office|sale':            'Loopnet Office for Sale',
  'retail|lease':           'Loopnet Retail for Lease',
  'retail|sale':            'Loopnet Retail for Sale',
};

const FALLBACK_SF_TYPES = new Set(['commercial', 'other', 'special purpose']);

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface LeadRow {
  date: string;
  listing_id: string;
  type: string; // "For Sale" | "For Lease"
  first: string;
  last: string;
  phone: string;
  email: string;
  address: string;
}

interface SFPropMini {
  sf_id: string;
  name: string;
  property_type: string;
  city: string;
  listing_type: string;
}

// ---------------------------------------------------------------------------
// Salesforce helpers (inline — this script only needs a few calls)
// ---------------------------------------------------------------------------

async function sfAuth(): Promise<{ token: string; instance: string }> {
  const params = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: (process.env.SF_CLIENT_ID || '').trim(),
    client_secret: (process.env.SF_CLIENT_SECRET || '').trim(),
  });
  const r = await fetch(`${process.env.SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
  });
  if (!r.ok) throw new Error(`SF auth failed: ${r.status} ${await r.text()}`);
  const d = (await r.json()) as { access_token: string; instance_url: string };
  return { token: d.access_token, instance: d.instance_url };
}

async function sfQueryByLoopnetIds(
  token: string,
  instance: string,
  loopnetIds: string[]
): Promise<Map<string, SFPropMini>> {
  const out = new Map<string, SFPropMini>();
  const ids = [...new Set(loopnetIds.filter(Boolean))];
  const CHUNK = 300;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const chunk = ids.slice(i, i + CHUNK);
    const inClause = chunk.map((v) => `'${v}'`).join(',');
    const soql =
      `SELECT Id, Name, Loopnet_ID__c, Property_Type__c, City__c, Listing_Type__c ` +
      `FROM Property__c WHERE Loopnet_ID__c IN (${inClause})`;
    const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
    const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) throw new Error(`SOQL failed: ${r.status} ${await r.text()}`);
    const data = (await r.json()) as { records: any[] };
    for (const rec of data.records) {
      const lid = rec.Loopnet_ID__c;
      if (!lid) continue;
      out.set(lid, {
        sf_id: rec.Id,
        name: rec.Name || '',
        property_type: rec.Property_Type__c || '',
        city: rec.City__c || '',
        listing_type: rec.Listing_Type__c || '',
      });
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// CSV parsing (tolerant of embedded newlines inside quoted fields)
// ---------------------------------------------------------------------------

function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else {
        field += c;
      }
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
      else if (c === '\r') { /* ignore */ }
      else field += c;
    }
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  if (!rows.length) return [];
  const header = rows[0];
  return rows.slice(1)
    .filter((r) => r.some((v) => v.trim().length))
    .map((r) => {
      const obj: Record<string, string> = {};
      header.forEach((h, i) => { obj[h] = r[i] ?? ''; });
      return obj;
    });
}

function readLeads(csvPath: string): LeadRow[] {
  const text = readFileSync(csvPath, 'utf-8').replace(/^\uFEFF/, '');
  const rows = parseCsv(text);
  const out: LeadRow[] = [];
  for (const r of rows) {
    const email = (r['Sender Email'] || '').trim().toLowerCase();
    const listing_id = (r['Listing ID'] || '').trim();
    if (!email || !listing_id) continue;
    out.push({
      date:       (r['Date Submitted'] || '').trim(),
      listing_id,
      type:       (r['Listing Type'] || '').trim(),
      first:      (r['Sender First Name'] || '').trim(),
      last:       (r['Sender Last Name'] || '').trim(),
      phone:      (r['Sender Phone Number'] || '').trim(),
      email,
      address:    (r['Lead Subject'] || '').trim(),
    });
  }
  return out;
}

// ---------------------------------------------------------------------------
// Bucketing
// ---------------------------------------------------------------------------

function parseIntent(listingType: string): 'sale' | 'lease' | null {
  const s = listingType.toLowerCase();
  if (s.includes('sale')) return 'sale';
  if (s.includes('lease')) return 'lease';
  return null;
}

function splitTypes(sfType: string): string[] {
  return sfType.split(';').map((s) => s.trim()).filter(Boolean);
}

interface ResolveResult {
  keys: Set<string>; // set of "asset|intent" keys
  useFallback: boolean;
}

function resolveCmKeys(sfTypes: string[], intent: 'sale' | 'lease'): ResolveResult {
  const lower = new Set(sfTypes.map((t) => t.toLowerCase()));
  const hasHealthcare = lower.has('healthcare');
  const keys = new Set<string>();
  let sawFallback = false;

  for (const t of lower) {
    if (t === 'healthcare') {
      keys.add(`medical office|${intent}`);
    } else if (t === 'office') {
      if (!hasHealthcare) keys.add(`office|${intent}`);
    } else if (t === 'multi-family') {
      if (intent === 'sale') keys.add('multi-family|sale');
    } else if (t === 'land') {
      if (intent === 'sale') keys.add('land development|sale');
      else if (intent === 'lease') keys.add('land|lease');
    } else if (t === 'land development') {
      if (intent === 'sale') keys.add('land development|sale');
    } else if (t === 'industrial' || t === 'retail') {
      keys.add(`${t}|${intent}`);
    } else if (FALLBACK_SF_TYPES.has(t)) {
      sawFallback = true;
    }
  }

  return { keys, useFallback: sawFallback && keys.size === 0 };
}

interface BucketResult {
  buckets: Map<string, Map<string, LeadRow>>; // key → email → lead
  fallback: Map<string, LeadRow>;
  unmatched: LeadRow[];
  noList: LeadRow[];
}

function bucketLeads(rows: LeadRow[], sfByLoopnet: Map<string, SFPropMini>): BucketResult {
  const buckets = new Map<string, Map<string, LeadRow>>();
  const fallback = new Map<string, LeadRow>();
  const unmatched: LeadRow[] = [];
  const noList: LeadRow[] = [];

  const upsert = (m: Map<string, LeadRow>, lead: LeadRow) => {
    const prev = m.get(lead.email);
    if (!prev || lead.date > prev.date) m.set(lead.email, lead);
  };

  for (const lead of rows) {
    const intent = parseIntent(lead.type);
    if (!intent) { noList.push(lead); continue; }
    const sf = sfByLoopnet.get(lead.listing_id);
    if (!sf) { unmatched.push(lead); continue; }
    const types = splitTypes(sf.property_type);
    if (!types.length) { noList.push(lead); continue; }
    const { keys, useFallback } = resolveCmKeys(types, intent);
    if (keys.size) {
      for (const k of keys) {
        if (!buckets.has(k)) buckets.set(k, new Map());
        upsert(buckets.get(k)!, lead);
      }
    } else if (useFallback) {
      upsert(fallback, lead);
    } else {
      noList.push(lead);
    }
  }

  return { buckets, fallback, unmatched, noList };
}

// ---------------------------------------------------------------------------
// Output
// ---------------------------------------------------------------------------

function writeCsv(path: string, rows: LeadRow[]): void {
  const fields: (keyof LeadRow)[] = ['email', 'first', 'last', 'phone',
                                     'listing_id', 'date', 'type', 'address'];
  const esc = (v: string) => `"${(v || '').replace(/"/g, '""')}"`;
  const lines = [fields.join(',')];
  for (const r of rows) lines.push(fields.map((f) => esc(r[f])).join(','));
  writeFileSync(path, lines.join('\n'));
}

function writeAllCsvs(res: BucketResult) {
  mkdirSync(OUTPUT_DIR, { recursive: true });
  for (const [key, byEmail] of res.buckets) {
    const safe = key.replace('|', '_').replace(/[^\w.-]/g, '_');
    const path = join(OUTPUT_DIR, `bucket_${safe}.csv`);
    writeCsv(path, [...byEmail.values()]);
    console.log(`  wrote ${String(byEmail.size).padStart(4)} → ${path.split('/').pop()}`);
  }
  if (res.fallback.size) {
    const path = join(OUTPUT_DIR, 'fallback.csv');
    writeCsv(path, [...res.fallback.values()]);
    console.log(`  wrote ${String(res.fallback.size).padStart(4)} → fallback.csv`);
  }
  if (res.unmatched.length) {
    writeCsv(join(OUTPUT_DIR, 'unmatched.csv'), res.unmatched);
    console.log(`  wrote ${String(res.unmatched.length).padStart(4)} → unmatched.csv`);
  }
  if (res.noList.length) {
    writeCsv(join(OUTPUT_DIR, 'no_list.csv'), res.noList);
    console.log(`  wrote ${String(res.noList.length).padStart(4)} → no_list.csv`);
  }
}

// ---------------------------------------------------------------------------
// CM push
// ---------------------------------------------------------------------------

function toCmSubscriber(lead: LeadRow): CMSubscriberInput {
  const name = `${lead.first} ${lead.last}`.trim() || lead.email;
  return {
    EmailAddress: lead.email,
    Name: name,
    CustomFields: [
      { Key: 'Phone',           Value: lead.phone },
      { Key: 'LastLoopNetID',   Value: lead.listing_id },
      { Key: 'LastLeadDate',    Value: lead.date },
      { Key: 'LastListingType', Value: lead.type },
      { Key: 'LastAddress',     Value: lead.address },
    ],
    ConsentToTrack: 'Yes',
  };
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function parseArgs(): { csv: string; live: boolean; bucketOnly: boolean } {
  const a = process.argv.slice(2);
  let csv = '';
  let live = false;
  let bucketOnly = false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--csv') csv = a[++i] || '';
    else if (a[i] === '--live') live = true;
    else if (a[i] === '--bucket-only') bucketOnly = true;
  }
  if (!csv) {
    console.error('Usage: --csv <path> [--live] [--bucket-only]');
    process.exit(1);
  }
  return { csv, live, bucketOnly };
}

async function main() {
  const args = parseArgs();

  console.log(`Reading ${args.csv}…`);
  const rows = readLeads(args.csv);
  console.log(`  ${rows.length} lead rows with email+listing_id`);
  const loopnetIds = [...new Set(rows.map((r) => r.listing_id))];
  console.log(`  ${loopnetIds.length} distinct LoopNet IDs`);

  console.log('Authenticating with Salesforce…');
  const sf = await sfAuth();
  console.log('Querying Property__c…');
  const sfByLoopnet = await sfQueryByLoopnetIds(sf.token, sf.instance, loopnetIds);
  console.log(`  matched ${sfByLoopnet.size} / ${loopnetIds.length} LoopNet IDs`);

  const result = bucketLeads(rows, sfByLoopnet);
  console.log('\nBucket summary (unique emails per list):');
  for (const [k, m] of [...result.buckets].sort(([a], [b]) => a.localeCompare(b))) {
    const [type, intent] = k.split('|');
    console.log(`  ${`${type} ${intent}`.padEnd(28)} ${String(m.size).padStart(4)}`);
  }
  console.log(`  ${'FALLBACK'.padEnd(28)} ${String(result.fallback.size).padStart(4)} (→ ${FALLBACK_LIST_NAME})`);
  console.log(`  ${'UNMATCHED'.padEnd(28)} ${String(result.unmatched.length).padStart(4)} (LoopNet ID not in SF)`);
  console.log(`  ${'NO_LIST'.padEnd(28)} ${String(result.noList.length).padStart(4)} (routing rule dropped)`);

  console.log(`\nWriting preview CSVs to ${OUTPUT_DIR}…`);
  writeAllCsvs(result);

  if (args.bucketOnly) {
    console.log('\n--bucket-only: skipping Campaign Monitor.');
    return;
  }

  // Resolve CM list IDs from list names
  const apiKey = process.env.CM_API_KEY;
  if (!apiKey) { console.error('CM_API_KEY not set.'); process.exit(1); }
  const clients = await listClients(apiKey);
  if (!clients.length) { console.error('No CM clients found.'); process.exit(1); }
  const clientId = clients[0].ClientID;
  const cmLists = await listLists(apiKey, clientId);
  const byName = new Map(cmLists.map((l) => [l.Name.toLowerCase(), l.ListID]));

  const targets: Array<{ label: string; listId: string; subs: CMSubscriberInput[] }> = [];
  for (const [key, byEmail] of result.buckets) {
    const listName = BUCKET_LIST_NAMES[key];
    if (!listName) { console.error(`No list-name mapping for bucket ${key}`); process.exit(1); }
    const listId = byName.get(listName.toLowerCase());
    if (!listId) { console.error(`CM list not found by name: ${listName}`); process.exit(1); }
    targets.push({
      label: key.replace('|', ' '),
      listId,
      subs: [...byEmail.values()].map(toCmSubscriber),
    });
  }
  if (result.fallback.size) {
    const listId = byName.get(FALLBACK_LIST_NAME.toLowerCase());
    if (!listId) { console.error(`CM fallback list not found: ${FALLBACK_LIST_NAME}`); process.exit(1); }
    targets.push({
      label: `fallback → ${FALLBACK_LIST_NAME}`,
      listId,
      subs: [...result.fallback.values()].map(toCmSubscriber),
    });
  }

  if (!args.live) {
    console.log('\nDry-run — would push to:');
    for (const t of targets) {
      console.log(`  ${t.label.padEnd(40)} list=${t.listId}  subs=${t.subs.length}`);
    }
    console.log('\nRe-run with --live to actually send.');
    return;
  }

  console.log('\nPushing to Campaign Monitor…');
  for (const t of targets) {
    const res = await importSubscribersBatched(apiKey, t.listId, t.subs);
    console.log(
      `  ${t.label.padEnd(40)} new=${res.TotalNewSubscribers} existing=${res.TotalExistingSubscribers} failures=${res.FailureDetails.length}`
    );
    if (res.FailureDetails.length) {
      const safe = t.label.replace(/[^\w.-]/g, '_');
      const path = join(OUTPUT_DIR, `failures_${safe}.json`);
      writeFileSync(path, JSON.stringify(res.FailureDetails, null, 2));
      console.log(`    → ${path.split('/').pop()}`);
    }
  }
  console.log('\nDone.');
}

main().catch((e) => { console.error(e); process.exit(1); });
