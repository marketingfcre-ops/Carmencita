/**
 * Targeted fix for the 3 stuck Group_old2 clusters as of 2026-06-05.
 *
 *   1. W_HIA_IND  (388 leads, Halain Suarez owner)  → new "WHialeahInd"
 *   2. NoMiaApts  (1 lead)                          → new "NoMiamiApts"
 *   3. NM Retail  (1 lead)                          → existing "NM Retail/MG"
 *
 * For each:
 *   - Create the Group__c if needed (idempotent: skips if Name already exists)
 *   - Update Lead.Group__c
 *   - Create a Lead_List_Assignment__c (Lead, Group, Status=Approved) if missing
 * For W_HIA_IND:
 *   - Add Halain Suarez Approved User_Group_Access__c to WHialeahInd if missing
 *
 * Idempotent. Dry-run by default. Pass --apply to commit.
 *
 *   npx tsx --env-file .env.local scripts/migrations/fix-orphan-leads-2026-06-05.ts
 *   npx tsx --env-file .env.local scripts/migrations/fix-orphan-leads-2026-06-05.ts --apply
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

interface Cluster {
  oldText: string;
  newCanonicalName?: string;       // if creating a new Group__c
  mergeToCanonicalName?: string;   // if MERGE to existing
  grantAccessToUserName?: string;  // optional: user to add Approved access for
}

const CLUSTERS: Cluster[] = [
  { oldText: 'W_HIA_IND',  newCanonicalName: 'WHialeahInd',  grantAccessToUserName: 'Halain Suarez' },
  { oldText: 'NoMiaApts',  newCanonicalName: 'NoMiamiApts' },
  { oldText: 'NM Retail',  mergeToCanonicalName: 'NM Retail/MG' },
];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply to commit.\n' : 'APPLY mode.\n');

  // ---- Resolve / create canonical Group__c ids ----
  const allGroups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const byNameExact = new Map(allGroups.map((g) => [g.Name, g.Id] as const));

  const oldToCanonicalId = new Map<string, string>();
  const createdNew: Array<{ name: string; id: string }> = [];
  for (const c of CLUSTERS) {
    if (c.newCanonicalName) {
      const existing = byNameExact.get(c.newCanonicalName);
      if (existing) {
        console.log(`  Group "${c.newCanonicalName}" already exists → ${existing}`);
        oldToCanonicalId.set(c.oldText, existing);
        continue;
      }
      console.log(`  Plan: CREATE Group__c "${c.newCanonicalName}" for "${c.oldText}"`);
      if (!DRY) {
        const id = await sf.create('Group__c', { Name: c.newCanonicalName });
        oldToCanonicalId.set(c.oldText, id);
        createdNew.push({ name: c.newCanonicalName, id });
        console.log(`    ✓ Created ${id}`);
      }
    } else if (c.mergeToCanonicalName) {
      const id = byNameExact.get(c.mergeToCanonicalName);
      if (!id) {
        console.error(`  ✗ MERGE target "${c.mergeToCanonicalName}" not found in Group__c. Aborting.`);
        process.exit(1);
      }
      console.log(`  Plan: MERGE "${c.oldText}" → existing "${c.mergeToCanonicalName}" (${id})`);
      oldToCanonicalId.set(c.oldText, id);
    }
  }

  // ---- For each cluster: update Lead.Group__c + create Lead_List_Assignment ----
  for (const c of CLUSTERS) {
    const cid = oldToCanonicalId.get(c.oldText);
    if (!cid && DRY) {
      console.log(`  (dry-run) Skipping ${c.oldText} updates — canonical not yet created`);
      continue;
    }
    if (!cid) continue;

    const leads: any[] = await sf.soql(
      `SELECT Id FROM Lead WHERE Group_old2__c = '${c.oldText.replace(/'/g, "\\'")}' AND Group__c = null`
    );
    console.log(`\n  ${c.oldText} → ${cid}: ${leads.length} lead(s) to update`);

    if (!leads.length) continue;

    if (DRY) {
      console.log(`    (dry-run) Would PATCH ${leads.length} Lead.Group__c values`);
      console.log(`    (dry-run) Would INSERT ${leads.length} Lead_List_Assignment__c rows`);
      continue;
    }

    // Update Lead.Group__c in batches of 200
    const BATCH = 200;
    let patched = 0;
    for (let off = 0; off < leads.length; off += BATCH) {
      const chunk = leads.slice(off, off + BATCH);
      const records = chunk.map((l) => ({
        attributes: { type: 'Lead' },
        Id: l.Id,
        Group__c: cid,
      }));
      const url = `${sf.instanceUrl}/services/data/v59.0/composite/sobjects`;
      const res = await fetch(url, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${sf.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ allOrNone: false, records }),
      });
      const results: any[] = await res.json();
      patched += results.filter((r) => r.success).length;
    }
    console.log(`    ✓ Updated Lead.Group__c on ${patched}/${leads.length}`);

    // Create Lead_List_Assignment__c rows (skip dupes)
    const existingAssigns: any[] = await sf.soql(
      `SELECT Lead__c FROM Lead_List_Assignment__c WHERE Group__c = '${cid}' AND Lead__c IN (${leads.map((l) => `'${l.Id}'`).join(',')})`
    );
    const haveAssign = new Set(existingAssigns.map((a) => a.Lead__c));
    const toCreate = leads.filter((l) => !haveAssign.has(l.Id));
    console.log(`    ${toCreate.length}/${leads.length} need Lead_List_Assignment__c (others already have one)`);

    let inserted = 0;
    for (let off = 0; off < toCreate.length; off += BATCH) {
      const chunk = toCreate.slice(off, off + BATCH);
      const records = chunk.map((l) => ({
        attributes: { type: 'Lead_List_Assignment__c' },
        Lead__c: l.Id,
        Group__c: cid,
        Status__c: 'Approved',
      }));
      const url = `${sf.instanceUrl}/services/data/v59.0/composite/sobjects`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${sf.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ allOrNone: false, records }),
      });
      const results: any[] = await res.json();
      inserted += results.filter((r) => r.success).length;
    }
    console.log(`    ✓ Inserted ${inserted} Lead_List_Assignment__c rows`);
  }

  // ---- Grant access ----
  for (const c of CLUSTERS) {
    if (!c.grantAccessToUserName) continue;
    const cid = oldToCanonicalId.get(c.oldText);
    if (!cid) {
      console.log(`  (dry-run) Skipping access grant — canonical not yet known`);
      continue;
    }
    const u: any[] = await sf.soql(
      `SELECT Id, Name FROM User WHERE Name = '${c.grantAccessToUserName}' AND IsActive = true LIMIT 5`
    );
    if (!u.length) {
      console.log(`  ✗ User "${c.grantAccessToUserName}" not found`);
      continue;
    }
    if (u.length > 1) {
      console.log(`  ✗ User "${c.grantAccessToUserName}" ambiguous (${u.length})`);
      continue;
    }
    const userId = u[0].Id;
    const existing: any[] = await sf.soql(
      `SELECT Id, Status__c FROM User_Group_Access__c WHERE User__c = '${userId}' AND Group__c = '${cid}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) {
      console.log(`  ${c.grantAccessToUserName} already has Approved access to "${c.newCanonicalName}". Skip.`);
      continue;
    }
    console.log(`  Plan: grant ${c.grantAccessToUserName} Approved access to "${c.newCanonicalName}"`);
    if (DRY) continue;
    const newId = await sf.create('User_Group_Access__c', {
      User__c: userId,
      Group__c: cid,
      Status__c: 'Approved',
    });
    console.log(`    ✓ Created User_Group_Access__c ${newId}`);
  }

  console.log('\nDone.');
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
