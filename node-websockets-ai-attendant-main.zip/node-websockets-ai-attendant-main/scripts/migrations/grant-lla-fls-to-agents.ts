/**
 * Grant Field-Level Security (Read) on Lead_List_Assignment__c custom fields
 * to the Account for Agents profile. Object Read is already granted but
 * without FLS Read, the related list renders empty / collapses entirely.
 *
 * Idempotent.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const ACCOUNT_FOR_AGENTS_PPS = '0PSJw000000502bOAA';

const FIELDS = [
  'Lead_List_Assignment__c.Lead__c',
  'Lead_List_Assignment__c.Group__c',
  'Lead_List_Assignment__c.Status__c',
  'Lead_List_Assignment__c.Approved_By__c',
  'Lead_List_Assignment__c.Approved_Date__c',
];

async function main() {
  const sf = await sfClient('prod') as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  for (const field of FIELDS) {
    console.log(`\n=== ${field} ===`);
    const existing: any[] = await sf.soql(
      `SELECT Id, PermissionsRead FROM FieldPermissions
       WHERE ParentId = '${ACCOUNT_FOR_AGENTS_PPS}' AND Field = '${field}'`
    );
    if (existing.length && existing[0].PermissionsRead) {
      console.log(`  ✓ Already has Read — skip`);
      continue;
    }
    if (DRY) { console.log(`  Plan: CREATE FieldPermissions (Read=true)`); continue; }
    const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/FieldPermissions/`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ParentId: ACCOUNT_FOR_AGENTS_PPS,
        SobjectType: 'Lead_List_Assignment__c',
        Field: field,
        PermissionsRead: true,
        PermissionsEdit: false,
      }),
    });
    const text = await res.text();
    if (!res.ok) console.log(`  ✗ ${res.status}: ${text.slice(0, 300)}`);
    else console.log(`  ✓ Created: ${text}`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
