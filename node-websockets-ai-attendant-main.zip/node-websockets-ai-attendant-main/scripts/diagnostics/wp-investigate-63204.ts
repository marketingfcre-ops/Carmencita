/**
 * Investigate wp:63204 — was it a real duplicate of wp:37725 or a false match?
 *
 * Cristina stripped the [DUPLICATE] tag at 3:25pm today. Before we let the
 * decision stand, verify whether the dedupe match was correct:
 *   1. Does wp:37725 actually exist?
 *   2. Is its address the same as wp:63204's address?
 *   3. Are there OTHER posts at the same address (3-way duplicate?)
 *   4. Visual diff of titles + key meta so a human can judge
 *
 * Read-only.
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

async function fetchJson(path: string): Promise<{ status: number; body: any }> {
  const res = await fetch(`${WP_SITE_URL}${path}`, {
    headers: { Authorization: WP_AUTH },
  });
  let body: any = null;
  try { body = await res.json(); } catch { body = null; }
  return { status: res.status, body };
}

async function getPost(id: number) {
  const r = await fetchJson(`/wp-json/wp/v2/properties/${id}?context=edit&_fields=id,date,modified,status,title,fave_property_address,fave_property_size,fave_property_price,fave_property_year,featured_media,author,slug,content`);
  return r;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = await res.json() as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function main() {
  console.log('\n🔎 wp:63204 investigation\n');

  // 1. Both posts side by side
  console.log('── wp:63204 (currently published, was tagged duplicate) ──');
  const a = await getPost(63204);
  if (a.status === 200) {
    console.log(`   status:           ${a.body.status}`);
    console.log(`   author:           ${a.body.author}`);
    console.log(`   date:             ${a.body.date}`);
    console.log(`   modified:         ${a.body.modified}`);
    console.log(`   title:            "${(a.body.title?.rendered || '').slice(0, 80)}"`);
    console.log(`   slug:             ${a.body.slug}`);
    console.log(`   address:          "${a.body.fave_property_address || '(empty)'}"`);
    console.log(`   size:             ${a.body.fave_property_size || '(empty)'}`);
    console.log(`   price:            ${a.body.fave_property_price || '(empty)'}`);
    console.log(`   year:             ${a.body.fave_property_year || '(empty)'}`);
    console.log(`   featured_media:   ${a.body.featured_media}`);
    const excerpt = (a.body.content?.rendered || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').slice(0, 200);
    console.log(`   content excerpt:  "${excerpt}..."`);
  } else {
    console.log(`   ❌ ${a.status}`);
  }

  console.log('\n── wp:37725 (the canonical the dedupe said it pointed at) ──');
  const b = await getPost(37725);
  if (b.status === 200) {
    console.log(`   status:           ${b.body.status}`);
    console.log(`   author:           ${b.body.author}`);
    console.log(`   date:             ${b.body.date}`);
    console.log(`   modified:         ${b.body.modified}`);
    console.log(`   title:            "${(b.body.title?.rendered || '').slice(0, 80)}"`);
    console.log(`   slug:             ${b.body.slug}`);
    console.log(`   address:          "${b.body.fave_property_address || '(empty)'}"`);
    console.log(`   size:             ${b.body.fave_property_size || '(empty)'}`);
    console.log(`   price:            ${b.body.fave_property_price || '(empty)'}`);
    console.log(`   year:             ${b.body.fave_property_year || '(empty)'}`);
    console.log(`   featured_media:   ${b.body.featured_media}`);
    const excerpt = (b.body.content?.rendered || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').slice(0, 200);
    console.log(`   content excerpt:  "${excerpt}..."`);
  } else {
    console.log(`   ❌ ${b.status}  — wp:37725 may not exist anymore`);
  }

  // 2. Find all WP posts at the same address as wp:63204
  if (a.status === 200 && a.body.fave_property_address) {
    const addr = a.body.fave_property_address;
    console.log(`\n── Other WP posts at "${addr}" ──`);
    const search = await fetchJson(`/wp-json/wp/v2/properties?per_page=20&context=edit&search=${encodeURIComponent(addr.slice(0, 30))}&_fields=id,date,status,title,fave_property_address,featured_media`);
    if (search.status === 200 && Array.isArray(search.body)) {
      // filter to address actually matching
      const norm = (s: string) => (s || '').toLowerCase().replace(/[#.,]/g, ' ').replace(/\s+/g, ' ').trim();
      const target = norm(addr).split(/\s+/).slice(0, 3).join(' ');
      const matches = search.body.filter((p: any) => norm(p.fave_property_address || '').includes(target));
      if (matches.length === 0) console.log('   (no other matches by address search)');
      for (const p of matches) {
        const flag = p.id === 63204 ? '  ← THIS ONE' : '';
        const photo = p.featured_media > 0 ? '📷' : '🚫';
        console.log(`   wp:${p.id}  ${p.status.padEnd(8)} ${p.date.slice(0,10)} ${photo} "${(p.title?.rendered || '').slice(0, 60)}"  addr:"${p.fave_property_address}"${flag}`);
      }
    }
  }

  // 3. SF: anyone pointing at 63204 or 37725, or anything at this address?
  if (SF_CLIENT_ID) {
    const { token, instance } = await sfAuth();
    const url = (q: string) => `${instance}/services/data/v59.0/query?q=${encodeURIComponent(q)}`;

    console.log(`\n── SF records linked to wp:63204 or wp:37725 ──`);
    const both = await fetch(
      url(`SELECT Id, Name, Address__c, WP_Post_ID__c, Status__c FROM Property__c WHERE WP_Post_ID__c IN (63204, 37725)`),
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const j = await both.json() as any;
    if ((j.records || []).length === 0) {
      console.log('   (none)');
    } else {
      for (const r of j.records) {
        console.log(`   ${r.Id}  WP=${r.WP_Post_ID__c}  Status=${r.Status__c}  ${r.Name || ''}  ${r.Address__c || ''}`);
      }
    }
  }

  console.log('');
  process.exit(0);
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
