/**
 * Three read-only audits over WP drafts:
 *
 *   A. Agent-review vs SF-status mismatch:
 *      Drafts where the most recent agent review says SOLD/LOST/INACTIVE
 *      but SF.Status__c is still Active. Agent verdict has not been
 *      reflected in SF yet → these are the real "should be closed" cases.
 *
 *   B. Orphan drafts (no SF backing):
 *      WP drafts that no SF Property__c record points at. Could be
 *      pre-SF content, leftover duplicates, or manually-created posts.
 *
 *   C. Already-closed drafts:
 *      Drafts where SF.Status__c is already Closed Lost / Closed Won /
 *      Off Market / etc. Candidates for being tagged "Sold" / "Off Market"
 *      in the WP property_status taxonomy.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-drafts-three-audits.ts
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Address__c: string | null;
  Status__c: string | null;
  Listing_Type__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  Notes_for_Marketing__c: string | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllDrafts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (let page = 1; page <= 20; page++) {
    const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=draft&context=edit&_fields=id,date,status,title,fave_property_address,featured_media`;
    const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
    if (!res.ok) break;
    const batch = (await res.json()) as any[];
    if (!Array.isArray(batch) || batch.length === 0) break;
    for (const p of batch) {
      out.push({
        id: p.id,
        date: p.date || '',
        status: p.status || '',
        title: (p.title?.rendered || '').toString(),
        fave_property_address: p.fave_property_address || '',
        featured_media: p.featured_media || 0,
      });
    }
    if (batch.length < 100) break;
  }
  return out;
}

interface PriorReview {
  date: string;
  agent: string;
  status: string;
  notes: string;
}

function parseLastReview(notes: string | null): PriorReview | null {
  if (!notes) return null;
  const re =
    /\[Agent Review (\d{4}-\d{2}-\d{2})\]\s*([^:]+):\s*([A-Z/ ]+?)(?:\s*—\s*(.*?))?(?=\[Agent Review|\s*$)/gs;
  let last: PriorReview | null = null;
  let m: RegExpExecArray | null;
  while ((m = re.exec(notes)) !== null) {
    last = {
      date: m[1],
      agent: m[2].trim(),
      status: m[3].trim().toUpperCase(),
      notes: (m[4] || '').trim(),
    };
  }
  return last;
}

function reviewIndicatesClosed(status: string): boolean {
  const v = status.toUpperCase();
  return v === 'SOLD' || v === 'LOST' || v === 'INACTIVE/SOLD' || v === 'INACTIVE';
}

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔬 WP drafts × SF Status × agent-review three-way audit (read-only)\n');

  const { token, instance } = await sfAuth();
  const [sfAll, drafts] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Address__c, Status__c, Listing_Type__c, Listing_Agent__r.Name,
              Notes_for_Marketing__c, WP_Post_ID__c
         FROM Property__c
        WHERE WP_Post_ID__c != NULL`
    ),
    fetchAllDrafts(),
  ]);

  const sfByWpId = new Map<number, SfProperty>();
  for (const r of sfAll) if (r.WP_Post_ID__c) sfByWpId.set(r.WP_Post_ID__c, r);

  console.log(`WP drafts:                 ${drafts.length}`);
  console.log(`SF records with WP link:   ${sfAll.length}\n`);

  // ─── Audit A: agent-review says closed, SF still Active ─────────────
  console.log('═'.repeat(78));
  console.log('AUDIT A — Agent review says SOLD/LOST but SF.Status__c is still Active');
  console.log('═'.repeat(78));

  const mismatches: { wp: WpPost; sf: SfProperty; review: PriorReview }[] = [];
  for (const wp of drafts) {
    const sf = sfByWpId.get(wp.id);
    if (!sf) continue;
    if ((sf.Status__c || '').toLowerCase() !== 'active') continue;
    const review = parseLastReview(sf.Notes_for_Marketing__c);
    if (!review) continue;
    if (reviewIndicatesClosed(review.status)) {
      mismatches.push({ wp, sf, review });
    }
  }

  console.log(`\nFound ${mismatches.length} mismatches — agent verdict not yet reflected in SF.Status__c\n`);
  if (mismatches.length > 0) {
    // Sort by review date (newest first)
    mismatches.sort((a, b) => b.review.date.localeCompare(a.review.date));
    for (const m of mismatches) {
      console.log(`SF ${m.sf.Id}  →  wp:${m.wp.id}`);
      console.log(`   Address:      ${m.sf.Address__c || '—'}`);
      console.log(`   Listing type: ${m.sf.Listing_Type__c || '—'}`);
      console.log(`   Listing agent: ${m.sf.Listing_Agent__r?.Name || '—'}`);
      console.log(`   SF Status:    ${m.sf.Status__c}`);
      console.log(`   Agent review: [${m.review.date}] ${m.review.agent}: ${m.review.status}${m.review.notes ? ' — ' + trunc(m.review.notes, 60) : ''}`);
      console.log('');
    }
    // Group by review status
    const byStatus = new Map<string, number>();
    for (const m of mismatches) byStatus.set(m.review.status, (byStatus.get(m.review.status) || 0) + 1);
    console.log('Breakdown by agent verdict:');
    for (const [s, n] of [...byStatus.entries()].sort((a, b) => b[1] - a[1])) {
      console.log(`   ${s.padEnd(20)} ${n}`);
    }
  }

  // ─── Audit B: orphan drafts ─────────────────────────────────────────
  console.log('\n' + '═'.repeat(78));
  console.log('AUDIT B — WP drafts with no SF backing (orphan drafts)');
  console.log('═'.repeat(78));

  const orphans = drafts.filter((d) => !sfByWpId.has(d.id));
  console.log(`\nFound ${orphans.length} orphan drafts\n`);
  orphans.sort((a, b) => a.date.localeCompare(b.date));
  for (const wp of orphans) {
    const photo = wp.featured_media > 0 ? '📷' : '🚫';
    const isDup = wp.title.includes('[DUPLICATE') ? '  ← [DUPLICATE]-tagged' : '';
    console.log(`   wp:${String(wp.id).padEnd(6)} ${wp.date.slice(0, 10)} ${photo}  "${trunc(wp.title.replace(/&#8211;/g, '–'), 60)}"${isDup}`);
    if (wp.fave_property_address) console.log(`     addr: "${trunc(wp.fave_property_address, 70)}"`);
  }

  // ─── Audit C: already-closed drafts ─────────────────────────────────
  console.log('\n' + '═'.repeat(78));
  console.log('AUDIT C — Drafts where SF.Status__c is already CLOSED');
  console.log('═'.repeat(78));

  const closedDrafts: { wp: WpPost; sf: SfProperty }[] = [];
  for (const wp of drafts) {
    const sf = sfByWpId.get(wp.id);
    if (!sf) continue;
    const v = (sf.Status__c || '').toLowerCase();
    if (
      v === 'closed lost' ||
      v === 'closed won' ||
      v === 'off market' ||
      v === 'sold' ||
      v === 'lost'
    ) {
      closedDrafts.push({ wp, sf });
    }
  }

  console.log(`\nFound ${closedDrafts.length} drafts with closed SF status\n`);
  closedDrafts.sort((a, b) =>
    (a.sf.Status__c || '').localeCompare(b.sf.Status__c || '') ||
    (a.sf.Address__c || '').localeCompare(b.sf.Address__c || '')
  );
  for (const m of closedDrafts) {
    console.log(`SF ${m.sf.Id}  →  wp:${m.wp.id}`);
    console.log(`   Address:      ${m.sf.Address__c || '—'}`);
    console.log(`   SF Status:    ${m.sf.Status__c}`);
    console.log(`   Listing type: ${m.sf.Listing_Type__c || '—'}`);
    console.log(`   Listing agent: ${m.sf.Listing_Agent__r?.Name || '—'}`);
    console.log(`   WP title:     "${trunc(m.wp.title.replace(/&#8211;/g, '–'), 60)}"`);
    console.log('');
  }

  // ─── Summary ────────────────────────────────────────────────────────
  console.log('═'.repeat(78));
  console.log('SUMMARY');
  console.log('═'.repeat(78));
  console.log(`
  WP drafts total:                                  ${drafts.length}
  A) Mismatch (agent verdict ≠ SF status):          ${mismatches.length}
  B) Orphan drafts (no SF backing):                 ${orphans.length}
  C) Already-closed drafts (per SF.Status__c):      ${closedDrafts.length}
  Active+no-review drafts (curation needed):        ${drafts.length - mismatches.length - orphans.length - closedDrafts.length}
  `);
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
