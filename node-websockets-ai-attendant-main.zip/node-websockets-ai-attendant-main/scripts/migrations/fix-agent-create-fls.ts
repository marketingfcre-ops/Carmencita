/**
 * Fix FLS on Lead_List_Assignment__c so agents can actually create assignments.
 * Need Edit FLS on Lead__c (and try Group__c if possible) so they can set the
 * value when filling in the New dialog.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const PPS = '0PSJw000000502bOAA';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(DRY ? 'DRY-RUN\n' : 'APPLY\n');

  // 1. PATCH Lead__c FLS to Edit=true
  const fp: any[] = await sf.soql(
    `SELECT Id, PermissionsRead, PermissionsEdit FROM FieldPermissions
     WHERE ParentId = '${PPS}' AND Field = 'Lead_List_Assignment__c.Lead__c'`
  );
  if (!fp.length) { console.log('Lead__c FLS row not found, would CREATE'); }
  else {
    console.log(`Lead__c currently Read=${fp[0].PermissionsRead} Edit=${fp[0].PermissionsEdit}`);
    if (!fp[0].PermissionsEdit) {
      console.log(`  → PATCH to Edit=true`);
      if (!DRY) {
        const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/FieldPermissions/${fp[0].Id}`;
        const res = await fetch(url, {
          method: 'PATCH',
          headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ PermissionsRead: true, PermissionsEdit: true }),
        });
        console.log(`  ${res.status === 204 ? '✓' : '✗'} ${res.status} ${await res.text() || '(empty)'}`);
      }
    }
  }

  // 2. Try to create Group__c FLS (Edit=true). May fail because Group is Required.
  const fpG: any[] = await sf.soql(
    `SELECT Id FROM FieldPermissions
     WHERE ParentId = '${PPS}' AND Field = 'Lead_List_Assignment__c.Group__c'`
  );
  if (fpG.length) {
    console.log(`\nGroup__c FLS exists (${fpG[0].Id}), skipping create attempt`);
  } else {
    console.log(`\nGroup__c FLS missing — try CREATE`);
    if (!DRY) {
      const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/FieldPermissions/`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ParentId: PPS,
          SobjectType: 'Lead_List_Assignment__c',
          Field: 'Lead_List_Assignment__c.Group__c',
          PermissionsRead: true,
          PermissionsEdit: true,
        }),
      });
      const text = await res.text();
      console.log(`  ${res.ok ? '✓' : '✗'} ${res.status} ${text.slice(0, 250)}`);
      if (!res.ok && text.includes('restricted picklist')) {
        console.log(`  (Required field — Edit FLS is auto-implied. Agents should already be able to set it.)`);
      }
    }
  }
}
main().catch(e=>{console.error('💀',e);process.exit(1);});
