/**
 * Build the CORRECT before→after group list for the Fausto announcement.
 *
 * IMPORTANT — why this is built the way it is:
 *   The naive approach ("for each canonical, list the old-text values its leads
 *   carry") is WRONG. Many leads had Group__c set long before the cleanup, while
 *   their legacy free-text Group_old2__c holds unrelated junk. That junk shows up
 *   as fake "merged variants" and makes the same name appear in several clusters
 *   AND in the as-is list (contamination).
 *
 *   Fix: assign each old-text to its DOMINANT home only — the single canonical
 *   where the majority of that text's leads actually live. Stray leads (the 1-6%
 *   contamination) are dropped. Result: every old name appears exactly once, no
 *   overlap between the merged and as-is tables.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/group-before-after-tables.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/group-before-after-tables.ts --asis-min 20
 */
import fs from 'node:fs';
import path from 'node:path';
import { sfClient } from '../../src/integrations/sf-client';

function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) { out[key] = next; i++; } else out[key] = true;
    }
  }
  return out;
}
const args = parseArgs(process.argv.slice(2));
const ASIS_MIN = args['asis-min'] ? parseInt(args['asis-min'] as string, 10) : 20;
const MEANINGFUL = 3;            // a member spelling must really live here this many times
const DOMINANT_MIN_SHARE = 0.5;  // a text must have >50% of its leads here to count as "home"

const norm = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const tokens = (s: string) =>
  (s || '')
    .replace(/([a-z])([A-Z])/g, '$1 $2')   // split camelCase
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length >= 4);

// Catch-all / placeholder canonicals — real leads, not announce-able groups.
const JUNK = new Set(
  ['other', 'open', 'buyer', 'buyers', 'na', 'n/a', 'none', 'lead', 'delete', 'group',
   'a', 'owner', 'seller', 'lessor', 'leasee', 'tenant', 'broker', 'central', 'land',
   'industrial', 'retail', 'commercial', 'assemblage'].map((s) => s)
);
const isJunk = (name: string) =>
  JUNK.has((name || '').toLowerCase()) || /^\d[\d)\-\s.]*$/.test(name) || /\d{3}[)\-]/.test(name);

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const nameById = new Map<string, string>(groups.map((g) => [g.Id, g.Name]));

  // current total leads per canonical (authoritative "how many leads in this group")
  const totals: any[] = await sf.soql(
    `SELECT Group__c gid, COUNT(Id) c FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const totalById = new Map<string, number>();
  for (const r of totals) totalById.set(r.gid, Number(r.c));

  // cross-tab: how each old-text's leads distribute across canonicals
  const cross: any[] = await sf.soql(
    `SELECT Group_old2__c t, Group__c gid, COUNT(Id) c
     FROM Lead WHERE Group__c != null AND Group_old2__c != null
     GROUP BY Group_old2__c, Group__c`
  );

  // per NORMALIZED text → dist across canonicals, aggregating casing variants.
  // Keying on the normalized name (not the exact string) is the fix for the same
  // name showing under two groups just because it was stored in different
  // capitalizations (e.g. "SOUThMiamiAlberto" vs "SouthMiamiAlberto").
  const byText = new Map<string, { display: string; displayCount: number; total: number; dist: Map<string, number> }>();
  for (const r of cross) {
    const raw = (r.t as string) ?? '';
    const key = norm(raw);
    if (!key) continue;
    const c = Number(r.c);
    if (!byText.has(key)) byText.set(key, { display: raw, displayCount: 0, total: 0, dist: new Map() });
    const e = byText.get(key)!;
    e.total += c;
    e.dist.set(r.gid, (e.dist.get(r.gid) || 0) + c);
    if (c > e.displayCount) { e.display = raw; e.displayCount = c; }  // label = most common casing
  }

  // assign each normalized text to its single DOMINANT canonical (drop contamination)
  type Member = { text: string; here: number };
  const membersByCanonical = new Map<string, Member[]>();
  for (const [, e] of byText) {
    const dist = [...e.dist.entries()].map(([gid, c]) => ({ gid, c })).sort((a, b) => b.c - a.c);
    const top = dist[0];
    if (!top) continue;
    if (top.c / e.total < DOMINANT_MIN_SHARE) continue;  // ambiguous — skip
    if (top.c < MEANINGFUL) continue;                    // too small to list
    if (!membersByCanonical.has(top.gid)) membersByCanonical.set(top.gid, []);
    membersByCanonical.get(top.gid)!.push({ text: e.display, here: top.c });
  }

  type Cluster = {
    canonical: string;
    members: Member[];
    differing: Member[];   // member spellings that differ from the canonical name
    review: Member[];      // members that introduce a genuinely new word (e.g. "Alberto")
    total: number;
    isCleanup: boolean;
  };
  const clusters: Cluster[] = [];
  for (const [gid, members] of membersByCanonical) {
    const canonical = nameById.get(gid) || gid;
    if (isJunk(canonical)) continue;
    members.sort((a, b) => b.here - a.here);
    const cTokens = new Set(tokens(canonical));
    const differing = members.filter((m) => norm(m.text) !== norm(canonical));
    // common asset-type / geo words that are NOT evidence of a different list
    const STOP = new Set(['multi','multifamily','multifam','commercial','industrial','retail','apartment','apartments','warehouse','beach','north','south','east','west','little','miami','land','office','offices','gardens','park','city','corridor','corridors','grove','road']);
    // "review" = a meaningful, large member that introduces a proper-noun-ish word
    // the canonical lacks (likely a genuinely different list, e.g. "Alberto", "Surfside").
    const review = differing.filter((m) =>
      m.here >= 40 &&
      tokens(m.text).some((w) => w.length >= 5 && !STOP.has(w) && !cTokens.has(w) && !canonical.toLowerCase().includes(w.slice(0, 5)) && norm(w).length === w.length)
    );
    const isCleanup = members.length >= 2 || differing.length >= 1;
    clusters.push({ canonical, members, differing, review, total: totalById.get(gid) || 0, isCleanup });
  }

  const merged = clusters.filter((c) => c.isCleanup).sort((a, b) => b.total - a.total);
  const asIsAll = clusters.filter((c) => !c.isCleanup).sort((a, b) => b.total - a.total);
  const asIs = asIsAll.filter((c) => c.total >= ASIS_MIN);
  const asIsTail = asIsAll.filter((c) => c.total < ASIS_MIN);
  const tailLeads = asIsTail.reduce((s, c) => s + c.total, 0);

  const lines: string[] = [];
  lines.push(`# Lead Groups — Current State\n`);
  lines.push(`_Generated live from Salesforce. Each original spelling is shown under the single group where its leads actually live; stray legacy tags are not counted._\n`);
  lines.push(
    `**${groups.length} groups total** · ${[...totalById.values()].reduce((s, n) => s + n, 0).toLocaleString()} leads linked · ` +
      `${merged.length} groups cleaned up from spelling variants · ${asIsAll.length} kept exactly as-is.\n`
  );

  lines.push(`\n## 1. Cleaned up — spelling variants consolidated into one group\n`);
  lines.push(`| Original spellings | Now (one group) | Leads |`);
  lines.push(`|---|---|---:|`);
  for (const c of merged) {
    const shown = c.members.slice(0, 6).map((m) => m.text).join(', ');
    const extra = c.members.length > 6 ? ` _(+${c.members.length - 6} more)_` : '';
    lines.push(`| ${shown}${extra} | **${c.canonical}** | ${c.total.toLocaleString()} |`);
  }

  lines.push(`\n## 2. Kept exactly as-is — agent-specific / preserved groups\n`);
  lines.push(`| Group | Leads |`);
  lines.push(`|---|---:|`);
  for (const c of asIs) lines.push(`| ${c.canonical} | ${c.total.toLocaleString()} |`);
  if (asIsTail.length) {
    lines.push(`\n_Plus ${asIsTail.length} smaller preserved groups (under ${ASIS_MIN} leads each, ${tailLeads.toLocaleString()} leads total)._\n`);
  }

  const outPath = path.resolve(__dirname, '..', '..', 'docs', 'group-before-after-tables.md');
  fs.writeFileSync(outPath, lines.join('\n') + '\n');

  // plain-text version (markdown tables don't render when pasted into email)
  const txt: string[] = [];
  txt.push(`GROUPS — BEFORE & AFTER`);
  txt.push(`${groups.length} groups | ${[...totalById.values()].reduce((s, n) => s + n, 0).toLocaleString()} leads | ${merged.length} cleaned up from spellings | ${asIsAll.length} kept as-is`);
  txt.push(``);
  txt.push(`CLEANED UP (spelling variants combined into one group):`);
  for (const c of merged) {
    const was = c.members.slice(0, 8).map((m) => m.text).join(', ');
    txt.push(`- ${c.canonical}  —  ${c.total.toLocaleString()} leads   (was: ${was}${c.members.length > 8 ? ', …' : ''})`);
  }
  txt.push(``);
  txt.push(`KEPT AS-IS (agent-specific lists, unchanged):`);
  for (const c of asIs) txt.push(`- ${c.canonical}  —  ${c.total.toLocaleString()} leads`);
  if (asIsTail.length) txt.push(`- (plus ${asIsTail.length} smaller lists under ${ASIS_MIN} leads each)`);
  fs.writeFileSync(outPath.replace(/\.md$/, '.txt'), txt.join('\n') + '\n');

  const reviewClusters = merged.filter((c) => c.review.length);
  console.log(`Cleaned-up groups: ${merged.length}`);
  console.log(`As-is groups:      ${asIsAll.length}`);
  console.log(`\nGenuine cross-name merges to review (${reviewClusters.length}):`);
  for (const c of reviewClusters) console.log(`  ⚠️  ${c.canonical}  ← ${c.review.map((m) => `${m.text} (${m.here})`).join(', ')}`);
  console.log(`\nWrote ${outPath}`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
