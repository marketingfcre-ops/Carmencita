/**
 * CallLogger — Structured timeline logger for debugging call quality.
 *
 * Captures every event in the call pipeline with high-resolution timestamps:
 *   - Deepgram STT: interim → final → UtteranceEnd (with confidence, word count)
 *   - Speech Analyzer: decisions (respond/discard), noise gating, fast-trigger
 *   - Claude: first token, total time, tool calls, token usage
 *   - ElevenLabs TTS: stream start, first audio chunk, completion
 *   - Twilio: marks sent/confirmed, barge-in, audio clear
 *   - System: filler sent, stash/unstash, lock/unlock, hangup
 *
 * Output:
 *   1. Visual timeline printed to console at end of call
 *   2. Structured JSON written to /tmp/call-logs/ for post-hoc analysis
 */

import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type EventCategory =
  | 'stt'       // Deepgram speech-to-text
  | 'analyzer'  // SpeechAnalyzer decisions
  | 'claude'    // Claude API calls
  | 'tts'       // ElevenLabs text-to-speech
  | 'twilio'    // Twilio mark events, audio, WebSocket
  | 'filler'    // Filler phrases
  | 'bargein'   // Barge-in events
  | 'system';   // Lock/unlock, stash, hangup, etc.

export interface CallEvent {
  /** High-resolution timestamp (ms since epoch) */
  ts: number;
  /** Event category for filtering */
  cat: EventCategory;
  /** Short event name (e.g., "stt_final", "claude_first_token") */
  evt: string;
  /** Human-readable description */
  msg: string;
  /** Optional structured data for analysis */
  data?: Record<string, any>;
  /** Generation ID at time of event */
  gen: number;
}

export interface TurnSummary {
  turnNumber: number;
  callerText: string;
  aiText: string;
  /** Time from caller speech end to first audio reaching caller (ms) */
  totalLatency: number;
  /** Breakdown */
  sttLatency: number;       // Final transcript → decision
  analyzerLatency: number;  // Decision → Claude call
  claudeFirstToken: number; // Claude call → first token
  claudeTotal: number;      // Claude call → full response
  ttsFirstChunk: number;    // TTS stream open → first audio chunk
  fillerPlayed: boolean;
  fillerDuration: number;   // Time filler held the line
  bargeIn: boolean;
  markConfirmed: boolean;
  markTimeout: boolean;
}

// ---------------------------------------------------------------------------
// CallLogger
// ---------------------------------------------------------------------------

const LOG_DIR = process.env.CALL_LOG_DIR || '/tmp/call-logs';

export class CallLogger {
  private events: CallEvent[] = [];
  private callSid: string;
  private callerPhone: string;
  private callStartTime: number;
  private currentGen = 0;

  // Track timestamps for latency calculation
  private turnTimestamps = new Map<number, {
    sttFinalAt?: number;
    decisionAt?: number;
    claudeCallAt?: number;
    claudeFirstTokenAt?: number;
    claudeTotalAt?: number;
    ttsStartAt?: number;
    ttsFirstChunkAt?: number;
    ttsCompleteAt?: number;
    fillerStartAt?: number;
    fillerMarkAt?: number;
    respMarkAt?: number;
    respMarkTimeout?: boolean;
    callerText?: string;
    aiText?: string;
    fillerPlayed?: boolean;
    bargeIn?: boolean;
  }>();

  constructor(callSid: string, callerPhone: string) {
    this.callSid = callSid;
    this.callerPhone = callerPhone;
    this.callStartTime = Date.now();
  }

  // ---------------------------------------------------------------------------
  // Core event logging
  // ---------------------------------------------------------------------------

  setGen(gen: number): void {
    this.currentGen = gen;
  }

  event(cat: EventCategory, evt: string, msg: string, data?: Record<string, any>): void {
    this.events.push({
      ts: Date.now(),
      cat,
      evt,
      msg,
      data,
      gen: this.currentGen,
    });
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — STT
  // ---------------------------------------------------------------------------

  sttInterim(text: string): void {
    this.event('stt', 'interim', text, { words: text.split(/\s+/).length });
  }

  sttFinal(text: string, confidence: number, wordCount: number): void {
    this.event('stt', 'final', text, { confidence, wordCount });
    this.ensureTurn(this.currentGen).sttFinalAt = Date.now();
  }

  sttUtteranceEnd(): void {
    this.event('stt', 'utterance_end', 'UtteranceEnd fired');
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — Analyzer
  // ---------------------------------------------------------------------------

  analyzerDecision(action: string, debug: string, filler: string | null): void {
    this.event('analyzer', 'decision', `${action}: ${debug}`, { action, debug, filler });
    this.ensureTurn(this.currentGen).decisionAt = Date.now();
  }

  analyzerFastTrigger(): void {
    this.event('analyzer', 'fast_trigger', 'Thought complete — fast-triggering');
  }

  analyzerNoise(text: string, confidence: number): void {
    this.event('analyzer', 'noise', `Discarded: "${text}"`, { confidence });
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — Claude
  // ---------------------------------------------------------------------------

  claudeCall(transcript: string): void {
    this.event('claude', 'call', `Sending: "${transcript.substring(0, 80)}"`, {
      transcript: transcript.substring(0, 200),
    });
    const turn = this.ensureTurn(this.currentGen);
    turn.claudeCallAt = Date.now();
    turn.callerText = transcript;
  }

  claudeFirstToken(latencyMs: number): void {
    this.event('claude', 'first_token', `${latencyMs}ms`, { latencyMs });
    this.ensureTurn(this.currentGen).claudeFirstTokenAt = Date.now();
  }

  claudeComplete(totalMs: number, text: string, toolCalls?: string[]): void {
    this.event('claude', 'complete', `${totalMs}ms — "${text.substring(0, 80)}..."`, {
      totalMs,
      textLength: text.length,
      wordCount: text.split(/\s+/).length,
      toolCalls,
    });
    const turn = this.ensureTurn(this.currentGen);
    turn.claudeTotalAt = Date.now();
    turn.aiText = text;
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — TTS
  // ---------------------------------------------------------------------------

  ttsStart(text: string, lang: string): void {
    this.event('tts', 'start', `TTS stream opened (${lang})`, {
      textLength: text.length,
      wordCount: text.split(/\s+/).length,
      lang,
    });
    this.ensureTurn(this.currentGen).ttsStartAt = Date.now();
  }

  ttsFirstChunk(): void {
    this.event('tts', 'first_chunk', 'First audio chunk received');
    this.ensureTurn(this.currentGen).ttsFirstChunkAt = Date.now();
  }

  ttsComplete(): void {
    this.event('tts', 'complete', 'TTS stream finished');
    this.ensureTurn(this.currentGen).ttsCompleteAt = Date.now();
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — Filler
  // ---------------------------------------------------------------------------

  fillerSent(key: string, phrase: string): void {
    this.event('filler', 'sent', `${key}: "${phrase}"`, { key, phrase });
    const turn = this.ensureTurn(this.currentGen);
    turn.fillerStartAt = Date.now();
    turn.fillerPlayed = true;
  }

  fillerMark(): void {
    this.event('filler', 'mark_confirmed', 'Filler playback confirmed');
    this.ensureTurn(this.currentGen).fillerMarkAt = Date.now();
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — Twilio
  // ---------------------------------------------------------------------------

  twilioMarkSent(name: string): void {
    this.event('twilio', 'mark_sent', `Mark sent: ${name}`, { markName: name });
  }

  twilioMarkConfirmed(name: string): void {
    this.event('twilio', 'mark_confirmed', `Mark confirmed: ${name}`, { markName: name });
    if (name.startsWith('resp_')) {
      this.ensureTurn(this.currentGen).respMarkAt = Date.now();
    } else if (name.startsWith('filler_')) {
      this.ensureTurn(this.currentGen).fillerMarkAt = Date.now();
    }
  }

  twilioMarkTimeout(name: string, timeoutMs: number): void {
    this.event('twilio', 'mark_timeout', `Timeout: ${name} (${timeoutMs}ms)`, {
      markName: name, timeoutMs,
    });
    if (name.startsWith('resp_')) {
      this.ensureTurn(this.currentGen).respMarkTimeout = true;
    }
  }

  twilioAudioClear(): void {
    this.event('twilio', 'audio_clear', 'Twilio buffer cleared');
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — Barge-in
  // ---------------------------------------------------------------------------

  bargeIn(text: string, wordCount: number): void {
    this.event('bargein', 'interrupt', `Barge-in (${wordCount}w): "${text}"`, { wordCount });
    this.ensureTurn(this.currentGen).bargeIn = true;
  }

  bargeInContext(spokenWords: number, unspokenWords: number, spokenText: string): void {
    this.event('bargein', 'context', `Spoken: ${spokenWords}w, Unspoken: ${unspokenWords}w`, {
      spokenWords, unspokenWords, spokenText: spokenText.substring(0, 100),
    });
  }

  bargeInStash(text: string, reason: string): void {
    this.event('bargein', 'stash', `Stashed (${reason}): "${text}"`, { reason });
  }

  // ---------------------------------------------------------------------------
  // Convenience methods — System
  // ---------------------------------------------------------------------------

  lockAcquired(reason: string): void {
    this.event('system', 'lock', `AI locked: ${reason}`);
  }

  lockReleased(reason: string): void {
    this.event('system', 'unlock', `AI unlocked: ${reason}`);
  }

  stashProcessed(text: string): void {
    this.event('system', 'stash_processed', `Processing stashed: "${text}"`);
  }

  pendingQuestion(type: string): void {
    this.event('system', 'pending_question', `Pending question: ${type}`, { type });
  }

  transcriptCorrection(from: string, to: string, reason: string): void {
    this.event('system', 'transcript_correction', `"${from}" → "${to}" (${reason})`, {
      from, to, reason,
    });
  }

  hangup(reason: string): void {
    this.event('system', 'hangup', `Call ended: ${reason}`);
  }

  // ---------------------------------------------------------------------------
  // Turn tracking helper
  // ---------------------------------------------------------------------------

  private ensureTurn(gen: number) {
    if (!this.turnTimestamps.has(gen)) {
      this.turnTimestamps.set(gen, {});
    }
    return this.turnTimestamps.get(gen)!;
  }

  // ---------------------------------------------------------------------------
  // End of call — print timeline + save JSON
  // ---------------------------------------------------------------------------

  async flush(): Promise<void> {
    this.printTimeline();
    await this.saveJSON();
  }

  private printTimeline(): void {
    if (this.events.length === 0) return;

    const t0 = this.callStartTime;
    const duration = ((Date.now() - t0) / 1000).toFixed(1);

    console.log(`\n${'━'.repeat(80)}`);
    console.log(`📊 CALL TIMELINE: ${this.callSid} | ${this.callerPhone} | ${duration}s`);
    console.log(`${'━'.repeat(80)}`);

    // Group events into conversation turns (by gen)
    const turns = new Map<number, CallEvent[]>();
    for (const e of this.events) {
      if (!turns.has(e.gen)) turns.set(e.gen, []);
      turns.get(e.gen)!.push(e);
    }

    // Print per-turn summary
    let turnNum = 0;
    for (const [gen, events] of turns) {
      turnNum++;
      const turnData = this.turnTimestamps.get(gen) || {};

      // Header
      const callerText = turnData.callerText || '';
      const aiText = turnData.aiText || '';
      if (!callerText && !aiText && turnNum > 1) continue; // Skip empty turns

      console.log(`\n┌─ Turn ${turnNum} (gen ${gen}) ${'─'.repeat(55)}`);

      if (callerText) {
        console.log(`│ 🎤 CALLER: "${callerText.substring(0, 100)}${callerText.length > 100 ? '...' : ''}"`);
      }
      if (aiText) {
        console.log(`│ 🤖 AI:     "${aiText.substring(0, 100)}${aiText.length > 100 ? '...' : ''}"`);
      }

      // Latency breakdown
      const latencies: string[] = [];

      if (turnData.claudeCallAt && turnData.claudeFirstTokenAt) {
        latencies.push(`Claude TTFT: ${turnData.claudeFirstTokenAt - turnData.claudeCallAt}ms`);
      }
      if (turnData.claudeCallAt && turnData.claudeTotalAt) {
        latencies.push(`Claude total: ${turnData.claudeTotalAt - turnData.claudeCallAt}ms`);
      }
      if (turnData.fillerPlayed && turnData.fillerStartAt && turnData.fillerMarkAt) {
        latencies.push(`Filler: ${turnData.fillerMarkAt - turnData.fillerStartAt}ms`);
      }
      if (turnData.ttsStartAt && turnData.ttsCompleteAt) {
        latencies.push(`TTS gen: ${turnData.ttsCompleteAt - turnData.ttsStartAt}ms`);
      }
      if (turnData.sttFinalAt && turnData.claudeCallAt) {
        latencies.push(`STT→Claude: ${turnData.claudeCallAt - turnData.sttFinalAt}ms`);
      }
      if (turnData.respMarkAt && turnData.ttsStartAt) {
        latencies.push(`Playback: ${turnData.respMarkAt - turnData.ttsStartAt}ms`);
      }

      if (latencies.length > 0) {
        console.log(`│ ⏱️  ${latencies.join(' | ')}`);
      }

      // Flags
      const flags: string[] = [];
      if (turnData.fillerPlayed) flags.push('💭 filler');
      if (turnData.bargeIn) flags.push('🛑 barge-in');
      if (turnData.respMarkTimeout) flags.push('⏰ mark timeout');
      if (turnData.respMarkAt) flags.push('🏁 mark confirmed');

      if (flags.length > 0) {
        console.log(`│ ${flags.join(' | ')}`);
      }

      // Detailed event timeline for this turn
      console.log(`│`);
      const t0_turn = events[0]?.ts || t0;
      for (const e of events) {
        const relMs = e.ts - t0;
        const catIcon = {
          stt: '📝', analyzer: '🔬', claude: '🧠',
          tts: '🔊', twilio: '📡', filler: '💭',
          bargein: '🛑', system: '⚙️',
        }[e.cat] || '•';
        const sec = (relMs / 1000).toFixed(2).padStart(7);
        console.log(`│  ${sec}s ${catIcon} ${e.evt}: ${e.msg.substring(0, 70)}`);
      }
      console.log(`└${'─'.repeat(79)}`);
    }

    // Overall stats
    console.log(`\n📈 CALL STATS:`);
    console.log(`   Total events: ${this.events.length}`);
    console.log(`   Total turns: ${turnNum}`);
    const markTimeouts = this.events.filter(e => e.evt === 'mark_timeout').length;
    const markConfirms = this.events.filter(e => e.evt === 'mark_confirmed').length;
    console.log(`   Marks: ${markConfirms} confirmed, ${markTimeouts} timed out`);
    const bargeIns = this.events.filter(e => e.evt === 'interrupt').length;
    console.log(`   Barge-ins: ${bargeIns}`);
    const fillers = this.events.filter(e => e.cat === 'filler' && e.evt === 'sent').length;
    console.log(`   Fillers played: ${fillers}`);
    console.log(`${'━'.repeat(80)}\n`);
  }

  private async saveJSON(): Promise<void> {
    try {
      await mkdir(LOG_DIR, { recursive: true });

      const filename = `call-${this.callSid}-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
      const filepath = join(LOG_DIR, filename);

      const logData = {
        callSid: this.callSid,
        callerPhone: this.callerPhone,
        startTime: new Date(this.callStartTime).toISOString(),
        endTime: new Date().toISOString(),
        durationMs: Date.now() - this.callStartTime,
        events: this.events,
        turns: Object.fromEntries(this.turnTimestamps),
        stats: {
          totalEvents: this.events.length,
          markConfirmed: this.events.filter(e => e.evt === 'mark_confirmed').length,
          markTimeout: this.events.filter(e => e.evt === 'mark_timeout').length,
          bargeIns: this.events.filter(e => e.evt === 'interrupt').length,
          fillersPlayed: this.events.filter(e => e.cat === 'filler' && e.evt === 'sent').length,
        },
      };

      await writeFile(filepath, JSON.stringify(logData, null, 2));
      console.log(`📁 Call log saved: ${filepath}`);
    } catch (err) {
      console.error(`❌ Failed to save call log:`, err);
    }
  }
}
