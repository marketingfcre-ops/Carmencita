/**
 * Fix the "all-tagged cycle" duplicate groups.
 *
 * In some address groups, every post got tagged `[DUPLICATE - see wp:N]`
 * pointing at another tagged post — a cycle. The cause: the dedupe migration
 * picked a different canonical between Run 1 and Run 3 for the same group,
 * so each pass tagged a different member.
 *
 * Fix:
 *   - In each cycle group, elect the post with the LOWEST WP ID as canonical
 *     (lowest ID = oldest in WP's lifetime, irrespective of the `date` field
 *     which may have been touched by the May auto-publish bug)
 *   - Strip the `[DUPLICATE - see wp:N] ` prefix from the canonical's title
 *   - Leave non-canonical posts alone — they already correctly point at the
 *     elected canonical (the only one of the pair with a lower ID)
 *
 * Does NOT touch:
 *   - "Multiple-untagged" groups (legitimate pre-May situations needing human
 *     review — different units, intentional re-listings, etc.)
 *   - Well-formed groups
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/wp-reconcile-cycles.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/wp-reconcile-cycles.ts
 */

import { updatePropertyPost } from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 150;

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function fetchAll(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function normalizeAddress(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().split(',')[0];
  a = a.replace(/[#.]/g, ' ');
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

function isDuplicateTagged(title: string): boolean {
  return /\[DUPLICATE/i.test(title);
}

/** Strip the leading `[DUPLICATE ... ]` prefix from a title. Returns the
 *  cleaned title. Handles both literal en-dash and `&#8211;` entity form. */
function stripDuplicatePrefix(title: string): string {
  // Decode the entity so the regex can match either input form
  const decoded = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const stripped = decoded.replace(/^\[DUPLICATE[\s\S]*?\]\s*/i, '');
  return stripped;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP creds.');
    process.exit(1);
  }

  console.log(`\n🔧 Reconcile cycle duplicate groups ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const all = await fetchAll();
  console.log(`Fetched ${all.length} WP posts.\n`);

  // Group by normalized address
  const byAddr = new Map<string, WpPost[]>();
  for (const p of all) {
    const key = normalizeAddress(p.fave_property_address);
    if (!key) continue;
    const arr = byAddr.get(key) || [];
    arr.push(p);
    byAddr.set(key, arr);
  }

  // Find cycle groups: 2+ posts at same address, ALL tagged [DUPLICATE]
  const cycles: { address: string; posts: WpPost[]; canonical: WpPost; toFix: WpPost }[] = [];
  for (const [addr, posts] of byAddr.entries()) {
    if (posts.length < 2) continue;
    const allTagged = posts.every((p) => isDuplicateTagged(p.title));
    if (!allTagged) continue;
    // Elect canonical = lowest WP id
    const sorted = [...posts].sort((a, b) => a.id - b.id);
    const canonical = sorted[0];
    cycles.push({ address: addr, posts, canonical, toFix: canonical });
  }

  console.log(`Cycle groups detected: ${cycles.length}\n`);

  if (cycles.length === 0) {
    console.log('Nothing to do.\n');
    process.exit(0);
  }

  // Show plan
  console.log('── Plan ──\n');
  for (const c of cycles) {
    console.log(`Address: "${c.address}"`);
    console.log(`   ELECT canonical:   wp:${c.canonical.id}`);
    const newTitle = stripDuplicatePrefix(c.canonical.title);
    console.log(`   STRIP prefix from: wp:${c.canonical.id}`);
    console.log(`      Before: "${c.canonical.title.replace(/&#8211;/g, '–').slice(0, 75)}"`);
    console.log(`      After:  "${newTitle.slice(0, 75)}"`);
    const others = c.posts.filter((p) => p.id !== c.canonical.id);
    for (const o of others) {
      console.log(
        `   KEEP tagged:       wp:${o.id} → already points at wp:${
          c.canonical.id
        } ${
          /see wp:(\d+)/.exec(o.title.replace(/&#8211;/g, '–'))?.[1] ===
          c.canonical.id.toString()
            ? '✓'
            : `(currently points at wp:${
                /see wp:(\d+)/.exec(o.title.replace(/&#8211;/g, '–'))?.[1]
              } — will rewrite)`
        }`
      );
    }
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  // ---------------------------------------------------------------------------
  // Execute
  // ---------------------------------------------------------------------------
  console.log('→ Executing changes...\n');

  let canonicalOk = 0;
  let canonicalErr = 0;
  let rewriteOk = 0;
  let rewriteErr = 0;

  for (const c of cycles) {
    // 1. Strip prefix from canonical
    const newTitle = stripDuplicatePrefix(c.canonical.title);
    const result = await updatePropertyPost(c.canonical.id, { title: newTitle });
    if (result.ok) {
      canonicalOk++;
    } else {
      canonicalErr++;
      console.warn(`   ❌ wp:${c.canonical.id} strip-prefix: ${result.error}`);
    }
    await sleep(REQUEST_DELAY_MS);

    // 2. For each non-canonical that points at the wrong target, rewrite
    const others = c.posts.filter((p) => p.id !== c.canonical.id);
    for (const o of others) {
      const decoded = o.title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
      const currentTarget = parseInt(/see wp:(\d+)/.exec(decoded)?.[1] || '0', 10);
      if (currentTarget === c.canonical.id) continue; // already correct
      const cleanedBody = stripDuplicatePrefix(o.title);
      const rewritten = `[DUPLICATE - see wp:${c.canonical.id}] ${cleanedBody}`;
      const r2 = await updatePropertyPost(o.id, { title: rewritten });
      if (r2.ok) {
        rewriteOk++;
      } else {
        rewriteErr++;
        console.warn(`   ❌ wp:${o.id} rewrite-target: ${r2.error}`);
      }
      await sleep(REQUEST_DELAY_MS);
    }
  }

  // ---------------------------------------------------------------------------
  // Verify
  // ---------------------------------------------------------------------------
  console.log('\n→ Verifying...\n');
  const after = await fetchAll();
  const stillCycles: string[] = [];
  const byAddrAfter = new Map<string, WpPost[]>();
  for (const p of after) {
    const key = normalizeAddress(p.fave_property_address);
    if (!key) continue;
    const arr = byAddrAfter.get(key) || [];
    arr.push(p);
    byAddrAfter.set(key, arr);
  }
  for (const c of cycles) {
    const posts = byAddrAfter.get(c.address) || [];
    if (posts.length >= 2 && posts.every((p) => isDuplicateTagged(p.title))) {
      stillCycles.push(c.address);
    }
  }

  console.log('=== Summary ===');
  console.log(`Canonicals stripped:  ${canonicalOk} / ${cycles.length}  (errors: ${canonicalErr})`);
  console.log(`Targets rewritten:    ${rewriteOk}                  (errors: ${rewriteErr})`);
  console.log(`Cycles still broken:  ${stillCycles.length}  ${stillCycles.length === 0 ? '✅' : '⚠️'}`);
  if (stillCycles.length > 0) {
    for (const a of stillCycles) console.log(`   "${a}"`);
  }
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
