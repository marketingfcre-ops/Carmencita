import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  const groupId = 'a0SJw000007fAwlMAE';
  const userId = '005Jw00001S5g9FIAR'; // Ryan Gonzalez
  const g: any[] = await sf.soql(`SELECT Id, Name FROM Group__c WHERE Id = '${groupId}'`);
  console.log(`Group: ${g[0]?.Id}  "${g[0]?.Name}"`);
  // Already exists?
  const existing: any[] = await sf.soql(
    `SELECT Id, Status__c FROM User_Group_Access__c WHERE User__c = '${userId}' AND Group__c = '${groupId}'`
  );
  if (existing.find((r:any) => r.Status__c === 'Approved')) {
    console.log('Already Approved.'); return;
  }
  const id = await sf.create('User_Group_Access__c', {
    User__c: userId, Group__c: groupId, Status__c: 'Approved',
  });
  console.log(`✓ Created ${id}`);
}
main().catch(e=>{console.error(e);process.exit(1);});
