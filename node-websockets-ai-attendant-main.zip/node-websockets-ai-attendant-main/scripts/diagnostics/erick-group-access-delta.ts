/**
 * Erick Moretti — User_Group_Access__c delta report. Read-only.
 *
 * Goal: figure out exactly which User_Group_Access__c records need to be
 * created so Erick can edit leads in every group (matching the wildcard
 * semantics the Lead_Group_Access_Check Flow enforces today: an Approved
 * row per Group).
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/erick-group-access-delta.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

const TARGET_NAME = 'Erick Moretti';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Resolve Erick's User Id
  const users: any[] = await sf.soql(
    `SELECT Id, Name, IsActive, Profile.Name, Username
     FROM User
     WHERE Name = '${TARGET_NAME}'`
  );
  if (users.length === 0) {
    console.error(`❌ No User found with Name = "${TARGET_NAME}"`);
    process.exit(1);
  }
  if (users.length > 1) {
    console.log(`⚠️  ${users.length} users match "${TARGET_NAME}":`);
    for (const u of users) {
      console.log(`   - ${u.Id}  active=${u.IsActive}  profile=${u.Profile?.Name}  username=${u.Username}`);
    }
  }
  const erick = users[0];
  console.log(`Erick: ${erick.Id}  active=${erick.IsActive}  profile=${erick.Profile?.Name}\n`);

  // 2. Every Group (custom object — read all rows)
  const allGroups: any[] = await sf.soql(
    `SELECT Id, Name FROM Group__c ORDER BY Name`
  );
  console.log(`Total Group__c rows in org: ${allGroups.length}`);

  // 3. Groups that actually have approved Lead_List_Assignment__c rows
  const assignedGroups: any[] = await sf.soql(
    `SELECT Group__c, Group__r.Name, COUNT(Id) cnt
     FROM Lead_List_Assignment__c
     WHERE Status__c = 'Approved' AND Group__c != null
     GROUP BY Group__c, Group__r.Name`
  );
  const assignedSet = new Set(assignedGroups.map((g) => g.Group__c));
  console.log(`Groups with ≥1 approved Lead_List_Assignment__c: ${assignedGroups.length}\n`);

  // 4. Erick's existing User_Group_Access__c rows
  const existing: any[] = await sf.soql(
    `SELECT Id, Group__c, Group__r.Name, Status__c
     FROM User_Group_Access__c
     WHERE User__c = '${erick.Id}'`
  );
  const existingByGroup = new Map<string | null, any>();
  for (const e of existing) existingByGroup.set(e.Group__c, e);
  console.log(`Erick already has ${existing.length} User_Group_Access__c rows:`);
  for (const e of existing) {
    console.log(`   - ${e.Id}  ${e.Status__c.padEnd(10)} ${e.Group__r?.Name || '(null group)'}`);
  }
  console.log('');

  // 5. Compute delta — create-or-flip for every Group__c row
  type Action =
    | { kind: 'create'; groupId: string; groupName: string }
    | { kind: 'approve'; recordId: string; groupId: string; groupName: string; currentStatus: string }
    | { kind: 'ok'; recordId: string; groupId: string; groupName: string };

  const actions: Action[] = [];
  for (const g of allGroups) {
    const e = existingByGroup.get(g.Id);
    if (!e) {
      actions.push({ kind: 'create', groupId: g.Id, groupName: g.Name });
    } else if (e.Status__c !== 'Approved') {
      actions.push({
        kind: 'approve',
        recordId: e.Id,
        groupId: g.Id,
        groupName: g.Name,
        currentStatus: e.Status__c,
      });
    } else {
      actions.push({ kind: 'ok', recordId: e.Id, groupId: g.Id, groupName: g.Name });
    }
  }

  const toCreate = actions.filter((a): a is Extract<Action, { kind: 'create' }> => a.kind === 'create');
  const toApprove = actions.filter((a): a is Extract<Action, { kind: 'approve' }> => a.kind === 'approve');
  const alreadyOk = actions.filter((a): a is Extract<Action, { kind: 'ok' }> => a.kind === 'ok');

  console.log(`=== Delta vs. all Group__c rows (${allGroups.length}) ===`);
  console.log(`  Already approved:  ${alreadyOk.length}`);
  console.log(`  Need flip→Approved: ${toApprove.length}`);
  console.log(`  Need to create:    ${toCreate.length}\n`);

  if (toApprove.length) {
    console.log(`-- Flip to Approved (${toApprove.length}):`);
    for (const a of toApprove) {
      console.log(`   ${a.recordId}  (${a.currentStatus.padEnd(10)} → Approved)  ${a.groupName}`);
    }
    console.log('');
  }

  if (toCreate.length) {
    console.log(`-- Create new User_Group_Access__c (${toCreate.length}) — first 25:`);
    for (const a of toCreate.slice(0, 25)) {
      const assignedFlag = assignedSet.has(a.groupId) ? '*' : ' ';
      console.log(`  ${assignedFlag} ${a.groupId}  ${a.groupName}`);
    }
    if (toCreate.length > 25) {
      console.log(`   ... ${toCreate.length - 25} more`);
    }
    console.log(`\n   (* = group has ≥1 approved Lead_List_Assignment__c today)`);
  }

  // 6. Sanity: are there any groups assigned to leads that AREN'T in Group__c?
  const orphanAssignmentGroups = assignedGroups.filter(
    (g) => !allGroups.some((all) => all.Id === g.Group__c)
  );
  if (orphanAssignmentGroups.length) {
    console.log(`\n⚠️  ${orphanAssignmentGroups.length} groups referenced by Lead_List_Assignment__c but not present in Group__c (unexpected):`);
    for (const g of orphanAssignmentGroups) {
      console.log(`   ${g.Group__c}  ${g.Group__r?.Name}  (${g.cnt} leads)`);
    }
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
