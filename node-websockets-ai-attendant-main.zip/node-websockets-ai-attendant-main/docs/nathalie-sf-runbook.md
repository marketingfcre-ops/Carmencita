# Salesforce Runbook — Nathalie

Five things you'll do most often. Bookmark the links, follow the steps.

---

## Bookmarks

- **User Group Access** (who can edit which group):
  https://d30000001hp0jeas.lightning.force.com/lightning/o/User_Group_Access__c/home
- **Lead Group Assignments** (which group a lead is in):
  https://d30000001hp0jeas.lightning.force.com/lightning/o/Lead_List_Assignment__c/home
- **Groups** (the master list of groups):
  https://d30000001hp0jeas.lightning.force.com/lightning/o/Group__c/home

**When a tab opens empty**: click the **gear icon** top-right → **New** → create your own "All" list view. Name it `All`, leave the filter empty, **Save**. ~30 sec, once per tab. PE doesn't let us share list views between users so each admin makes their own.

---

## 1. Give someone access to a Group

When an agent says "I work all of X's leads" or there's evidence they work the group regularly (5+ leads).

1. Open the [**User Group Access**](https://d30000001hp0jeas.lightning.force.com/lightning/o/User_Group_Access__c/home) tab → **New**.
2. **User**: the agent. **Group**: the group name. **Status**: `Approved`. **Save**.

To revoke later: open the record and delete it.

If the group doesn't exist yet, create it first: [**Groups**](https://d30000001hp0jeas.lightning.force.com/lightning/o/Group__c/home) → **New** → name it → **Save**. Then do step 1.

---

## 2. Fix a lead that says "you don't have approved access"

The lead has the old Group text filled but the new Group lookup empty.

1. Open the lead → **Edit** → fill the **Group** field (the lookup, with the dropdown) → **Save**.
2. Scroll to the **Lead Group Assignments** related list → **New** → same Group, **Status** = `Approved` → **Save**.

Step 2 is the actual permission row the Flow checks. Without it, the Flow still blocks the edit.

If you don't see the related list on the lead page: **Setup → Object Manager → Lead → Page Layouts** → open the layout → drag *Lead Group Assignments* onto it → Save. Direct link to that screen:
https://d30000001hp0jeas.lightning.force.com/lightning/setup/ObjectManager/Lead/PageLayouts/view

---

## 3. Personal-group trick — one-off lead share

When someone needs access to **one specific lead** (not the whole group). This way they don't get edit rights on the rest of the group.

**Once per agent (one-time setup):**

1. [**Groups**](https://d30000001hp0jeas.lightning.force.com/lightning/o/Group__c/home) → **New** → Name: `Personal — <Agent Name>` (e.g. `Personal — Kodiak Fields`) → **Save**.
2. [**User Group Access**](https://d30000001hp0jeas.lightning.force.com/lightning/o/User_Group_Access__c/home) → **New** → User: the agent. Group: their personal group. Status: `Approved`. **Save**.

**Each time you want to share a lead with them:**

1. Open the lead → **Lead Group Assignments** related list → **New** → Group: `Personal — <Agent Name>`. Status: `Approved`. **Save**.

They can now edit that one lead, nothing else. To revoke: delete the assignment.

**Rule of thumb:**
- 5+ leads or recurring pattern → §1 (group-level access)
- One-off or two-off → §3 (personal group)

---

## 4. Weekly backup

PE only schedules backups monthly. For a weekly cadence, request one manually:

1. Open [**Data Export**](https://d30000001hp0jeas.lightning.force.com/lightning/setup/DataManagementExport/home) → **Export Now**.
2. **Include all data** + check **Include images, documents, and attachments**.
3. **Start Export**. Salesforce emails you when the ZIP is ready (~few hours later).
4. Download the ZIP → save to Dropbox / Google Drive. Label it `salesforce-backup-YYYY-MM-DD.zip`.

---

## 5. If something blows up (mass-edit / data vandalism)

1. **Find the scope**: run the *Bulk Edit Detector* report. (If it doesn't exist: Reports → New Report → Lead History → filter by Edited Date > yesterday, GROUP BY Edited By.)
2. **Export the current state** of the affected lead IDs to a CSV (Data Loader query) — this preserves anything legitimate that happened concurrently.
3. **Restore from backup**: download the latest backup ZIP → extract Lead.csv → filter to the affected IDs → Data Loader **UPDATE** to overwrite.
4. **Reconcile**: compare current-state CSV against backup, manually keep any legit edits you don't want overwritten.
5. **Document** who/what/when/scope.

**Always ping Jesus before step 3** — restoring is destructive to anything that legitimately changed since the backup.

---

## Cheat sheet — what's what

- **Group** = the list itself ("Hialeah Industrial")
- **Lead Group Assignment** = "this Lead belongs to this Group" (one row per Lead↔Group)
- **User Group Access** = "this User can edit Leads in this Group" (one row per User↔Group)

Both the **Assignment** AND the **Access** must exist as `Approved` for an agent to edit a lead. The Flow checks both.

## When to ping Jesus

- Schema changes / new fields / new objects
- Flow edits
- Mass cleanup or re-running scripts
- Backup automation
- Anything that touches lots of records at once or you're not sure about
