# 07 — Admin Dashboard, Server Framework & Deployment

This section documents the "glue" that ties the whole system together: the live
admin dashboard, the server entry point and its plug-in route architecture, how
the service is deployed on Railway, and a complete inventory of every
environment variable the system reads.

It is written for two readers:

- **The owner** — to understand *what exists* and *why it matters*. Wherever
  something is non-obvious, there is a plain-language "What this means" note.
- **The technical successor** — to *operate, configure, and extend* it. Every
  claim is backed by a `file:line` reference so you can jump straight to the code.

---

## 1. The Admin Dashboard

**File:** `src/admin.ts` (registered in `src/server.ts:52`).

### 1.1 What it is

A single, self-contained, server-rendered monitoring dashboard. It has **no
front-end framework, no build step, and no external dependencies** — the entire
page (HTML + CSS + JavaScript) is produced by template literals inside
`renderHtml()` (`src/admin.ts:502`). This was a deliberate choice: the dashboard
ships with the server, costs nothing to host, and can never "fall out of sync"
with a separate front-end.

> **What this means (owner):** There is a private web page you can open in any
> browser that shows, at a glance, whether the phone attendant and all the
> services it depends on are healthy — how many calls and leads came in today,
> how much credit is left at each vendor, and a log of recent calls. It updates
> itself every 30 seconds.

### 1.2 How it's accessed and secured

Two routes are exposed (`src/admin.ts:689`–`714`):

| Route | Method | Purpose |
|---|---|---|
| `GET /admin` | HTML | The full dashboard page |
| `GET /admin/api/status` | JSON | The live data the page polls every 30s |

**Security model — a shared secret in the query string.** Both routes require
`?key=<ADMIN_KEY>`. The key is read from the `ADMIN_KEY` env var, defaulting to
the hard-coded string `'fausto2026'` (`src/admin.ts:695`). If the key is wrong
or missing, the route returns **`404 Not found`** rather than `401`/`403`
(`src/admin.ts:699-702`, `708-711`) — a small "security through obscurity"
touch so the endpoint doesn't advertise its own existence.

> **Gotcha / maintenance:** This is light-weight protection, not real
> authentication. The key travels in the URL (so it can land in browser history
> and server logs), and the default `'fausto2026'` is public in this repo. **Set
> a strong `ADMIN_KEY` in Railway** and treat the dashboard URL as a secret. For
> a hardening pass, consider moving the key to a header or adding Basic Auth.

The browser-side JS forwards the same key when it polls the JSON endpoint:
`fetch('/admin/api/status?key=' + params.get('key'))` (`src/admin.ts:659`).

### 1.3 What it shows

`getStatusData()` (`src/admin.ts:460`) assembles the payload. The page renders
seven sections:

1. **Quick Stats** (`getQuickStats()`, `src/admin.ts:416`) — calls today, leads
   today, average Claude time-to-first-token (TTFT) in ms, plus all-time totals.
2. **Services** (`checkServices()`, `src/admin.ts:188`) — a colored health dot
   per dependency: **Twilio, Claude API, ElevenLabs, Deepgram, Salesforce,
   Server**. Each check is a live API ping wrapped in `Promise.allSettled` with a
   10-second timeout, and results are cached for 5 minutes (`STATUS_CACHE_MS`,
   `src/admin.ts:22`) so the dashboard never hammers the vendors.
   - Twilio: hits the Balance API; flags `<$5` red, `<$15` amber (`:209`).
   - Claude: sends a 1-token `ping` to `claude-haiku-4-5-20251001`; distinguishes
     401 (bad key) and 429 (rate-limited) (`:238`).
   - ElevenLabs: reads subscription usage; falls back to a `/voices` connectivity
     check if the key lacks `user_read` scope (`:284`).
   - Deepgram: lists projects, then tries the balances endpoint (`:331`).
   - Salesforce: in-memory check — property count + minutes since last refresh
     (`:380`); no network call.
   - Server: process uptime (`:400`).
3. **Credits & Usage** — Twilio balance, ElevenLabs character %, Deepgram
   balance, cached in `creditCache` (`src/admin.ts:72`).
4. **Salesforce** — property count, agent count, last refresh time.
5. **Data Sync Health** (`getDataSyncStatus()`, `src/admin.ts:440`) — how many
   listings have a public website URL and a real description (a proxy for
   Salesforce↔WordPress sync quality).
6. **Recent Calls** — last 20 calls, **newest first**, with caller phone
   **masked to last 4 digits** (`maskPhone()`, `src/admin.ts:493`).

> **Note on ElevenLabs:** The dashboard still health-checks and shows ElevenLabs
> credits, but the live call path now uses **Deepgram TTS** (see the call-path
> section of CLAUDE.md and `src/tts.ts`). `ELEVENLABS_API_KEY` is consumed only
> by the admin health check (`src/admin.ts:27`). Treat the ElevenLabs panel as
> legacy/informational unless TTS is switched back.

### 1.4 Where call data comes from

The dashboard reads the **call logs written by the call logger** rather than a
database:

- `LOG_DIR` defaults to `/tmp/call-logs` (`src/admin.ts:21`, overridable via
  `CALL_LOG_DIR`).
- `loadCallLogs()` runs once at startup (`src/admin.ts:79`, called from `:693`)
  and reads the most recent 100 JSON logs (`MAX_CALL_SUMMARIES`, `:23`).
- `refreshCallLogs()` runs on every status poll and incrementally ingests only
  files modified since the last scan (`src/admin.ts:106`).
- `parseLogToSummary()` (`src/admin.ts:139`) extracts per-call metrics: turn
  count, first caller utterance, average Claude latency, and whether a lead was
  logged (detected from a `log_lead` tool call in the event stream, `:158`).

> **Gotcha:** `/tmp` is **ephemeral on Railway** — it is wiped on every deploy
> and restart. Call summaries on the dashboard are therefore a rolling, in-memory
> view (capped at 100), not a durable record. If durable call history is needed,
> point `CALL_LOG_DIR` at a mounted Railway volume (the same
> `RAILWAY_VOLUME_MOUNT_PATH` pattern used for SMS consent).

---

## 2. Overall Architecture — the "mini-framework"

**Entry point:** `src/server.ts`. The whole application is a single
[Fastify](https://fastify.dev) server. There is no separate API gateway, job
runner, or front-end server — one process does everything.

### 2.1 Startup sequence (`main()`, `src/server.ts:42`)

1. Create the Fastify instance with logging on (`:43`).
2. Register two core plugins (`:48-49`):
   - `@fastify/formbody` — parses `application/x-www-form-urlencoded`, which is
     how **Twilio webhooks** post data.
   - `@fastify/websocket` — enables the `/stream` WebSocket for Twilio Media
     Streams.
3. Register every feature module via its `register*Routes(app)` function (`:52-67`).
4. Define inline `/health`, `/debug`, `/voice/answer`, `/voice/status`, and the
   `/stream` WebSocket (`:72-193`).
5. `await initSalesforce()` — load listings/agents into memory. **Non-blocking
   by design**: if Salesforce is down the server still boots and falls back to
   static listing data (`:198`).
6. `startLlaReconcileScheduler()` — kick off the background Salesforce
   reconcile + notify job (`:204`; see section on LLA below).
7. `app.listen({ port: PORT, host: '0.0.0.0' })` (`:210`) and print the route map
   to the console.

Two process-level safety nets are installed *before* `main()` runs so a stray
error can't silently kill the process: `uncaughtException` and
`unhandledRejection` handlers that log but do **not** exit (`src/server.ts:35-40`).

> **What this means (owner):** The server is built to stay up. If Salesforce or
> any single integration hiccups, the phone line keeps answering — it just uses
> backup data until the integration recovers.

### 2.2 The plug-in route pattern (why it's "reusable")

This is the structural idea the owner referred to as a *mini-framework*. Every
feature is a self-contained module that exports **one async registration
function** taking the Fastify app:

```
export async function registerXxxRoutes(app: FastifyInstance): Promise<void> { ... }
```

`server.ts` simply lists them (`src/server.ts:52-67`):

| Registration call | Module | Routes it owns |
|---|---|---|
| `registerAdminRoutes` | `src/admin.ts:689` | `/admin`, `/admin/api/status` |
| `registerReviewRoutes` | `src/agent-review.ts:430` | `/review`, `/review/results`, `/review/submit` |
| `registerSalesforceWebhookRoutes` | `src/webhooks/salesforce.ts:43` | SF→WordPress sync webhook |
| `registerSmsWebhookRoutes` | `src/webhooks/sms.ts:32` | `/sms/incoming` (STOP/HELP/YES/START A2P flow) |
| `registerFlyerRoutes` | `src/handlers/flyer.ts:20` | flyer HTML preview + PDF |
| `registerEmailRoutes` | `src/handlers/email.ts:160` | `/email/test` + email orchestration |

**To add a feature:** create a module with a `register*Routes` export, then add
one line to `server.ts`. Nothing else in the system needs to change. This is what
makes the codebase extensible without a heavyweight framework.

The directory layout reinforces the pattern (matches CLAUDE.md's directory map):

- `src/handlers/` — user-facing request handlers (flyer, email).
- `src/webhooks/` — inbound webhooks from external systems (Salesforce, SMS).
- `src/integrations/` — outbound API clients / background jobs (WordPress,
  Resend, flyer/PDF, LLA reconcile).
- Top-level `src/*.ts` — core domain logic (call handling, STT/TTS, Claude,
  Salesforce, listings, search, SMS).

> **What this means (technical successor):** Read `server.ts` top-to-bottom and
> you have the entire route surface. Each `register*` function is a single,
> testable unit you can read in isolation. There is no hidden auto-discovery or
> decorator magic.

### 2.3 The live call flow (request/WebSocket path)

The voice pipeline is the heart of the product (full detail lives in the call-path
docs; summarized here for architectural context):

1. **`POST /voice/answer`** (`src/server.ts:134`) — Twilio's webhook when a call
   arrives. The handler:
   - Logs the inbound call (`:139`).
   - **Fire-and-forget starts dual-channel recording** via the Twilio REST API
     for QA (`:144-159`) — failures are caught and warned, never block the call.
   - Returns TwiML: `<Connect><Stream url="wss://.../stream">` with the caller's
     phone passed as a `<Parameter>` (`:161-168`). The `wss://` URL is derived
     from `APP_URL` (`:141`).
2. **`WS /stream`** (`src/server.ts:187-193`) — Twilio opens a Media Stream
   WebSocket. **Each connection = one call.** A new `CallHandler(socket)` is
   instantiated per connection and owns the entire real-time pipeline (Deepgram
   STT → Claude streaming → sentence splitter → Deepgram TTS → mulaw back to
   Twilio).
3. **`POST /voice/status`** (`src/server.ts:176`) — Twilio call-status callbacks;
   currently logged for observability.

> **What this means (owner):** When someone calls, Twilio first asks our server
> what to do (`/voice/answer`), we tell it to open a live audio pipe
> (`/stream`), and from there the AI listens and talks back in real time. We also
> quietly record the call for quality review.

### 2.4 Health & debug endpoints

- **`GET /health`** (`src/server.ts:72`) — returns `{status:'ok', timestamp}`.
  This is what **Railway polls** to decide if the deployment is live
  (`railway.json` → `healthcheckPath: "/health"`).
- **`GET /debug`** (`src/server.ts:79`) — an open, unauthenticated JSON dump of
  current leads, Salesforce property/agent counts, last refresh time, sample
  listings, and which data source is active (`salesforce` vs `fallback`).

> **Gotcha:** `/debug` is **not secured** and exposes captured lead data and
> business listing internals. It's useful in dev but should be locked down or
> removed before treating the public URL as fully exposed. (Contrast with
> `/admin`, which at least requires a key.)

---

## 3. Deployment

### 3.1 Hosting: Railway

Deployment is configured in `railway.json`:

```json
{
  "build":  { "builder": "NIXPACKS", "buildCommand": "npm install && npm run build" },
  "deploy": { "startCommand": "npm start",
              "healthcheckPath": "/health",
              "restartPolicyType": "ON_FAILURE",
              "restartPolicyMaxRetries": 3 }
}
```

- **Build:** Nixpacks runs `npm install && npm run build`. `npm run build` is
  `tsc` (`package.json:6`), compiling TypeScript `src/` → `dist/`.
- **Start:** `npm start` → `node dist/server.js` (`package.json:8`).
- **Health:** Railway hits `/health`; if it fails the deploy is considered
  unhealthy.
- **Restart policy:** auto-restart on failure, up to 3 retries — pairs with the
  process-level error handlers so transient crashes self-heal.
- **Runtime:** Node `>=20` (`package.json:27-29`).

### 3.2 How code reaches production

(From CLAUDE.md "Deploy".)

- **Prod:** **merge to `main` → Railway auto-deploys.** There is no manual deploy
  step.
- **PR previews:** **opening a PR spins up a Railway PR preview environment** —
  an isolated running copy of the app for that branch, so changes can be tested
  live before merge.

> **Workflow gate (from CLAUDE.md):** Opening a PR and any deploy (merge to
> `main`, or pushing Salesforce metadata) are **approval gates** — summarize and
> wait for sign-off. Read-only ops are pre-approved.

### 3.3 Local development

| Command | What it does |
|---|---|
| `npm run dev` | `tsx watch --env-file .env.local src/server.ts` — hot-reload dev server on port 3000, loads secrets from `.env.local` (`package.json:9`) |
| `npm run ngrok` | Exposes `:3000` on the **fixed** ngrok domain `thymy-unjarring-brande.ngrok-free.dev` (`package.json:10`) |
| `npm run build` | `tsc` → `dist/` |
| `npm start` | `node dist/server.js` (prod-style) |
| `npm run typecheck` | `tsc --noEmit` |

- **Fixed ngrok domain:** because the domain is stable, Twilio webhooks can point
  at it during local dev without reconfiguration each time.
- **Returning to prod:** run `scripts/twilio-restore-prod.sh` to point Twilio
  webhooks back at the production URL when you finish local testing (CLAUDE.md
  gotchas).
- Secrets live in `.env.local` (gitignored) — never commit, log, or print them.

> **What this means (technical successor):** To run it locally: put secrets in
> `.env.local`, `npm run dev` in one terminal, `npm run ngrok` in another, set
> Twilio's voice webhook to the ngrok URL, and call the number. When done, run
> `twilio-restore-prod.sh`.

---

## 4. Configuration / Environment-Variable Inventory (exhaustive)

Every variable the codebase reads via `process.env`, grouped by service. Defaults
are shown where the code provides one. **No real secret values appear here.** This
is the single most important reference for standing the system up in a new
environment — to provision a fresh deploy, set the required vars below in Railway.

### App / Server
| Var | Default | Description | Source |
|---|---|---|---|
| `PORT` | `3000` | HTTP/WebSocket listen port | `server.ts:31` |
| `APP_URL` | `http://localhost:$PORT` | Public base URL; used to build the `wss://.../stream` URL Twilio connects to | `server.ts:32,141` |
| `NODE_ENV` | — | Standard Node environment flag | used across `src/` |
| `ADMIN_KEY` | `fausto2026` | Shared-secret query key guarding `/admin` and `/admin/api/status` — **change this** | `admin.ts:695` |
| `CALL_LOG_DIR` | `/tmp/call-logs` | Where call logs are read from for the dashboard (ephemeral on Railway) | `admin.ts:21` |
| `REVIEW_DIR` | `/tmp/agent-reviews` | Storage dir for the agent-review feature | `agent-review.ts:17` |
| `RAILWAY_VOLUME_MOUNT_PATH` | — | Set by Railway when a volume is attached; used as the default durable storage dir for SMS consent and LLA notify state | `sms-consent.ts:46`, `lla-reconcile.ts:154` |

### Twilio (telephony + SMS)
| Var | Default | Description | Source |
|---|---|---|---|
| `TWILIO_ACCOUNT_SID` | — | Twilio Account SID (call recording, admin balance check) | `server.ts:144`, `admin.ts:25` |
| `TWILIO_AUTH_TOKEN` | — | Twilio auth token | `server.ts:145`, `admin.ts:26` |
| `TWILIO_SID` | — | Legacy alias for Account SID (fallback) | `server.ts:144` |
| `TWILIO_TOKEN` | — | Legacy alias for auth token (fallback) | `server.ts:145` |
| `TWILIO_PHONE_NUMBER` | — | "From" number for outbound SMS, e.g. `+1305…` | `sms.ts:35` |
| `TWILIO_MESSAGING_SERVICE_SID` | — | Alternative SMS sender (Messaging Service); one of this or the phone number must be set | `sms.ts:40` |

### Deepgram (STT + TTS)
| Var | Default | Description | Source |
|---|---|---|---|
| `DEEPGRAM_API_KEY` | — | Deepgram API key for streaming STT and TTS | `admin.ts:28`, `stt-flux.ts`, `tts.ts` |
| `STT_MODEL` | `flux` | STT model selector — `flux` (default) or `nova` | `call-handler.ts:35,108` |

### Claude / Anthropic
| Var | Default | Description | Source |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | — | Claude API key for the streaming conversation engine and the admin health-check ping | `admin.ts:29`, `claude.ts` |

### ElevenLabs (legacy TTS / admin panel only)
| Var | Default | Description | Source |
|---|---|---|---|
| `ELEVENLABS_API_KEY` | — | Consumed only by the admin dashboard's ElevenLabs health/credit check; live TTS now uses Deepgram | `admin.ts:27` |

### Salesforce
| Var | Default | Description | Source |
|---|---|---|---|
| `SF_LOGIN_URL` | `https://login.salesforce.com` | Org login/custom-domain URL (should be the org's `*.my.salesforce.com`) | `salesforce.ts:82` |
| `SF_CLIENT_ID` | — | Connected App consumer key (OAuth client credentials) | `salesforce.ts:83` |
| `SF_CLIENT_SECRET` | — | Connected App consumer secret | `salesforce.ts:84` |
| `SF_LIGHTNING_BASE_URL` | — | Override for the Lightning host used in LLA review links (vs the API host) | `lla-reconcile.ts:192` |
| `SF_WEBHOOK_SECRET` | — | Shared secret expected in `X-SF-Webhook-Secret` for the prod SF→WP webhook | `webhooks/salesforce.ts:54` |
| `SF_DEV_WEBHOOK_SECRET` | — | Same, for the dev org | `webhooks/salesforce.ts:55` |
| `MAKE_WEBHOOK_URL` | `''` | Optional/legacy Make.com webhook fallback for lead creation | `salesforce.ts:85` |

### WordPress
| Var | Default | Description | Source |
|---|---|---|---|
| `WP_SITE_URL` | `https://faustocommercial.com` | WordPress site base for REST listing data | `integrations/wordpress.ts:28` |
| `WP_USER` | — | WordPress user for REST auth | `integrations/wordpress.ts:29` |
| `WP_APP_PASSWORD` | — | WordPress application password | `integrations/wordpress.ts:30` |

### Campaign Monitor
| Var | Default | Description | Source |
|---|---|---|---|
| `CM_API_KEY` | — | Campaign Monitor account API key for email-list sync | `campaign-monitor.ts` |

### Resend / Email
| Var | Default | Description | Source |
|---|---|---|---|
| `RESEND_API_KEY` | — | Resend API key for transactional email (flyer/listing delivery, LLA digest) | `integrations/resend.ts` |
| `EMAIL_FROM` | `listings@faustocommercial.com` | Verified sender address | `integrations/resend.ts:22` |
| `EMAIL_FROM_NAME` | `Fausto Commercial` | Sender display name (optional) | `integrations/resend.ts:23` |
| `EMAIL_ENABLED` | `false` (must equal `'true'`) | Master switch for the email-send feature | `admin.ts:31` |

### Flyer / PDF
| Var | Default | Description | Source |
|---|---|---|---|
| `PDFSHIFT_API_KEY` | — | PDFShift SaaS key for HTML→PDF flyer rendering (no Chromium needed) | `integrations/flyer.ts:245` |
| `FLYER_SHARED_SECRET` | — | Shared secret guarding the flyer route | `handlers/flyer.ts:29` |

### SMS feature flags / A2P consent
| Var | Default | Description | Source |
|---|---|---|---|
| `SMS_ENABLED` | `true` (unless `'false'`) | Master switch for SMS sending | `admin.ts:30` |
| `CONSENT_STORE_DIR` | falls back to volume → `data/` | Override dir for persisted A2P consent records | `sms-consent.ts:45` |

### LLA automation (Salesforce Lead-List-Assignment scheduler)
| Var | Default | Description | Source |
|---|---|---|---|
| `LLA_RECONCILE_ENABLED` | off | Enables the `Lead.Group__c` → LLA auto-create reconcile job | `lla-reconcile.ts` |
| `LLA_RECONCILE_INTERVAL_MIN` | `10` | Minutes between reconcile runs | `lla-reconcile.ts:384` |
| `LLA_NOTIFY_ENABLED` | off | Enables the admin email digest of new Pending LLAs (via Resend) | `lla-reconcile.ts` |
| `LLA_NOTIFY_EMAIL` | `na@faustocommercial.com` | Recipient for the Pending-LLA digest | `lla-reconcile.ts:226` |
| `LLA_NOTIFY_STORE_DIR` | falls back to volume → local | Dir for notify de-dupe state (so the same Pending isn't emailed twice) | `lla-reconcile.ts:153` |

### Cloudflare R2 / B2 backups (`scripts/backup/`)
| Var | Default | Description | Source |
|---|---|---|---|
| `BACKUP_S3_ENDPOINT` | — | S3-compatible endpoint (Cloudflare R2 / Backblaze B2) | `scripts/backup/sf-backup.ts:90` |
| `BACKUP_S3_REGION` | — | Bucket region | `sf-backup.ts:91` |
| `BACKUP_S3_BUCKET` | — | Target bucket name | `sf-backup.ts:170` |
| `BACKUP_S3_ACCESS_KEY_ID` | — | S3 access key | `sf-backup.ts:93` |
| `BACKUP_S3_SECRET_ACCESS_KEY` | — | S3 secret key | `sf-backup.ts:94` |
| `BACKUP_KEEP_DAILY` | `30` | Daily backups to retain (current tier) | `sf-backup.ts:59` |
| `BACKUP_KEEP_MONTHLY` | `12` | Monthly backups to retain | `sf-backup.ts:58` |

### Other / misc
| Var | Default | Description | Source |
|---|---|---|---|
| `FILLER_ENABLED` | `true` (unless `'false'`) | Toggle conversational "filler" phrases while tools run | `call-handler.ts:41` |
| `HOME` | OS-provided | Used for default local paths in some scripts | scripts |

> **Note:** Several `SF_*`, `WP_*`, and `BACKUP_S3_*` vars are also read by
> one-off scripts under `scripts/migrations/` and `scripts/backup/` — they share
> the same names as the server, so one set of credentials covers both.

---

## 5. Key Files & Functions (quick reference)

| What | Where |
|---|---|
| Server entry / startup | `src/server.ts:42` (`main`) |
| Plugin + route registration | `src/server.ts:48-67` |
| Process-level error guards | `src/server.ts:35-40` |
| Twilio answer webhook + recording | `src/server.ts:134` |
| Twilio status webhook | `src/server.ts:176` |
| Media-stream WebSocket | `src/server.ts:187` |
| Health check | `src/server.ts:72` |
| Debug dump | `src/server.ts:79` |
| Admin route registration + key gate | `src/admin.ts:689` |
| Admin status payload | `src/admin.ts:460` (`getStatusData`) |
| Service health checks | `src/admin.ts:188` (`checkServices`) |
| Call-log ingestion | `src/admin.ts:79` / `:106` / `:139` |
| Dashboard HTML/CSS/JS | `src/admin.ts:502` (`renderHtml`) |
| Phone masking | `src/admin.ts:493` |
| LLA scheduler kickoff | `src/server.ts:204` → `src/integrations/lla-reconcile.ts` |
| Deploy config | `railway.json` |
| Scripts | `package.json:5-11` |

---

## 6. Gotchas & Maintenance Notes

1. **`ADMIN_KEY` default is public.** It defaults to `'fausto2026'`
   (`src/admin.ts:695`). Set a strong value in Railway; the key rides in the URL
   (logs/history exposure). Wrong key → `404`, not `401`.
2. **`/debug` is unauthenticated** (`src/server.ts:79`) and exposes lead +
   listing data. Lock it down or remove before relying on the public URL.
3. **Call logs are ephemeral.** `/tmp/call-logs` is wiped on every Railway
   deploy/restart; the dashboard's "Recent Calls" is a rolling 100-item,
   in-memory view. For durable history, mount a Railway volume and set
   `CALL_LOG_DIR`.
4. **ElevenLabs is legacy in the call path** but still polled by the dashboard;
   `ELEVENLABS_API_KEY` only feeds the admin panel. Live TTS is Deepgram.
5. **Salesforce init is non-blocking** (`src/server.ts:198`). If SF is down the
   server still boots on fallback listings — check the dashboard's Salesforce
   panel / `/debug` `usingSource` field to confirm which source is live.
6. **Service checks are cached 5 min** (`src/admin.ts:22,189`). A green dot can be
   up to 5 minutes stale; an outage may not show immediately.
7. **Feature switches are env-driven and default differently:** `SMS_ENABLED`
   and `FILLER_ENABLED` are **on unless** set to `'false'`; `EMAIL_ENABLED`,
   `LLA_RECONCILE_ENABLED`, `LLA_NOTIFY_ENABLED` are **off unless** explicitly
   enabled. Know the polarity before toggling.
8. **Restart policy retries only 3 times** (`railway.json`). A crash loop beyond
   3 attempts leaves the service down — watch Railway alerts.
9. **Local dev rewires Twilio.** After pointing Twilio webhooks at the ngrok
   domain, run `scripts/twilio-restore-prod.sh` to restore prod, or live calls
   will hit your laptop.
10. **Adding a route = one module + one line.** Follow the `register*Routes`
    pattern and add the call in `src/server.ts` — don't bypass it with ad-hoc
    `app.get` calls scattered elsewhere.
11. **Salesforce is Professional Edition — no custom Apex.** Anything that would
    normally be a record-triggered Flow/trigger (like LLA auto-create + Pending
    notify) runs **server-side in this Node process** via the scheduler
    (`src/server.ts:204`). Keep that constraint in mind before "moving logic to
    Salesforce."
