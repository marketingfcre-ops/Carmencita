/**
 * SpeechAnalyzer v3 — No intent classification.
 *
 * Philosophy: Claude is the brain, we are just the ears.
 *
 * What we handle:
 *   1. Language detection → which TTS voice to use
 *   2. Noise filtering   → confidence + word count based discard
 *   3. Filler selection   → keyword presence (search vs generic), NOT intent
 *   4. Fast-trigger       → punctuation + word count, NOT intent
 *
 * What we DON'T do (Claude handles these):
 *   - Farewell detection — Claude has the end_call tool
 *   - Intent classification — every word-to-intent regex was a source of false positives
 *   - Context overrides (bye→buy) — handled by transcript correction in respond()
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PendingQuestionType =
  | 'buy_or_lease'
  | 'property_type'
  | 'location'
  | 'size'
  | 'budget'
  | 'name'
  | 'yes_no'
  | 'open';

interface PendingQuestion {
  type: PendingQuestionType;
  askedAt: number;
  expiresAt: number;
}

export type FillerKey = 'en_search' | 'en_generic' | 'es_search' | 'es_generic';

export interface SpeechDecision {
  action: 'respond' | 'discard';
  audioConfidence: number;
  isNoise: boolean;
  filler: FillerKey | null;
  cleanedText: string;
  lang: 'en' | 'es';
  debug: string;
}

export interface DeepgramWord {
  word: string;
  start: number;
  end: number;
  confidence: number;
  punctuated_word?: string;
}

export interface FinalSegment {
  text: string;
  words: DeepgramWord[];
  segmentConfidence: number;
}

// ---------------------------------------------------------------------------
// Filler phrases — just two per language: search and generic
// ---------------------------------------------------------------------------

export const FILLER_PHRASES: Record<FillerKey, string> = {
  en_search: 'Let me check what we have.',
  es_search: 'Déjeme ver qué tenemos.',
  en_generic: 'One moment please.',
  es_generic: 'Un momento, por favor.',
};

// ---------------------------------------------------------------------------
// Noise threshold
// ---------------------------------------------------------------------------
const NOISE_THRESHOLD = 0.55;

// ---------------------------------------------------------------------------
// CRE vocabulary — known words get a lower single-word confidence threshold
// ---------------------------------------------------------------------------
const CRE_KNOWN_WORDS = new Set([
  // Cities / neighborhoods
  'miami',
  'doral',
  'hialeah',
  'brickell',
  'wynwood',
  'kendall',
  'homestead',
  'medley',
  'hollywood',
  'hallandale',
  'miramar',
  'davie',
  'pompano',
  'lauderdale',
  'opalocka',
  'gables',
  'pinecrest',
  'palmetto',
  'sweetwater',
  'edgewater',
  'midtown',
  'flagami',
  'allapattah',
  'overtown',
  // Property types
  'warehouse',
  'retail',
  'office',
  'industrial',
  'multifamily',
  'commercial',
  'residential',
  'medical',
  'land',
  // CRE terms
  'nnn',
  'cam',
  'noi',
  'lease',
  'sale',
  'sqft',
  'zoning',
  // Transaction terms
  'buy',
  'purchase',
  'rent',
  'comprar',
  'alquilar',
  'rentar',
  // Company
  'fausto',
  // Spanish CRE
  'bodega',
  'almacen',
  'oficina',
  'terreno',
  'local',
  'propiedad',
]);

// ---------------------------------------------------------------------------
// Keyword checks for filler selection (NOT intent classification)
// These answer ONE question: "Will Claude likely call search_properties?"
// ---------------------------------------------------------------------------

const LOCATION_KEYWORDS =
  /\b(miami|doral|hialeah|homestead|hollywood|brickell|wynwood|kendall|medley|gables|fort lauderdale|allapattah|cutler|palmetto|opalocka|sweetwater|flagami|pinecrest|edgewater|hallandale|pompano|miramar|davie|north miami|US-1|dixie|biscayne)\b/i;

const PROPERTY_TYPE_KEYWORDS =
  /\b(warehouse|retail|office|industrial|multifamily|multi-family|land|commercial|medical|bodega|almacen|oficina|terreno|propiedad)\b/i;

const SEARCH_VERB_KEYWORDS =
  /\b(looking for|look for|find|search|show me|what do you have|have any|available|busco|buscando|tiene|hay|muéstrame|qué tienen)\b/i;

// ---------------------------------------------------------------------------
// Language detection
// ---------------------------------------------------------------------------

const SPANISH_INDICATORS =
  /\b(hola|estoy|llamando|quiero|busco|tiene|puede|necesito|por favor|gracias|bueno|bien|dónde|cuánto|cómo|cerca|cuesta|español|buscando|tengo|puedo|quería|quisiera|alquilar|comprar|vender|propiedad|propiedades|buscar|buenos|buenas|también|número|teléfono|correo|dirección|acabo|creo|aquí|sí|ese|esa|esos|esas|cuál|cuáles|está|están|voy|pero|porque|entonces|donde|cuando|algo|nada|mucho|poco|otro|otra|esto|mira|dime|oye|dale|claro|verdad|mismo|pequeño|grande|calle|letrero|déjame|listo|perfecto|ese mismo)\b/gi;

// ===========================================================================
// SpeechAnalyzer v3
// ===========================================================================

export class SpeechAnalyzer {
  private segments: FinalSegment[] = [];
  private allText = '';
  private allWords: DeepgramWord[] = [];
  private detectedLang: 'en' | 'es' = 'en';
  private callSid: string;
  private pendingQuestion: PendingQuestion | null = null;

  constructor(callSid: string) {
    this.callSid = callSid;
  }

  // ---------------------------------------------------------------------------
  // PendingQuestion — persists across reset(), expires after 30 seconds
  // ---------------------------------------------------------------------------

  setPendingQuestion(type: PendingQuestionType): void {
    this.pendingQuestion = {
      type,
      askedAt: Date.now(),
      expiresAt: Date.now() + 30_000,
    };
    console.log(`❓ [${this.callSid}] Pending question set: ${type}`);
  }

  hasPendingQuestion(): boolean {
    if (!this.pendingQuestion) return false;
    if (Date.now() > this.pendingQuestion.expiresAt) {
      this.pendingQuestion = null;
      return false;
    }
    return true;
  }

  getPendingQuestionType(): PendingQuestionType | null {
    return this.hasPendingQuestion() ? this.pendingQuestion!.type : null;
  }

  clearPendingQuestion(): void {
    this.pendingQuestion = null;
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /** Feed an interim transcript — only used for early language detection. */
  onInterim(text: string): void {
    const combined = [...this.segments.map((s) => s.text), text.trim()]
      .filter(Boolean)
      .join(' ');
    this.detectLanguage(combined);
  }

  /** Feed a finalized segment with word-level confidence. */
  onFinal(segment: FinalSegment): void {
    this.segments.push(segment);
    this.allWords.push(...segment.words);
    this.allText = this.segments.map((s) => s.text).join(' ');
    this.detectLanguage(this.allText);

    const avgConf = this.avgConfidence();
    const lowWords = segment.words
      .filter((w) => w.confidence < NOISE_THRESHOLD)
      .map((w) => `${w.word}(${w.confidence.toFixed(2)})`);
    console.log(
      `🔬 [${this.callSid}] Conf: avg=${avgConf.toFixed(2)} ` +
        `seg=${segment.segmentConfidence.toFixed(2)} words=${segment.words.length}` +
        (lowWords.length ? ` low=[${lowWords.join(', ')}]` : ' all-clear')
    );
  }

  /** Get accumulated text. */
  getText(): string {
    return this.allText.trim();
  }

  /** Get detected language. */
  getLang(): 'en' | 'es' {
    return this.detectedLang;
  }

  /**
   * THE DECISION — called when UtteranceEnd fires.
   *
   * Pure confidence + word count. No intent classification.
   * Claude handles all the intelligence.
   */
  public getDecision(): SpeechDecision {
    const text = this.getText();
    if (!text || text === this.lastTriggeredText) {
      return this.build('discard', 0, true, '', 'already_handled');
    }

    const audioConf = this.avgConfidence();

    // SINGLE-WORD GATE: Require higher confidence for unknown single words.
    // Known CRE terms (e.g. "Miami") pass at 0.50; unknown words need 0.75.
    const wordList = text.split(/\s+/);
    if (wordList.length === 1) {
      const word = wordList[0].toLowerCase().replace(/[.,!?]/g, '');
      if (CRE_KNOWN_WORDS.has(word)) {
        if (audioConf < 0.5) {
          return this.build('discard', audioConf, true, '', 'single_known_low');
        }
      } else {
        if (audioConf < 0.75) {
          return this.build('discard', audioConf, true, '', 'single_unknown');
        }
      }
    }

    // NOISE GATE: Low confidence + short = likely background noise.
    if (audioConf < 0.55 && wordList.length < 4) {
      return this.build('discard', audioConf, true, '', 'noise_gate');
    }

    this.lastTriggeredText = text;
    const filler = this.pickFiller();
    return this.build('respond', audioConf, false, text, 'valid', filler);
  }

  /** Reset for next utterance. Language persists. */
  reset(): void {
    this.segments = [];
    this.allText = '';
    this.allWords = [];
  }

  // ---------------------------------------------------------------------------
  // Language detection
  // ---------------------------------------------------------------------------

  private detectLanguage(text: string): void {
    if (/[¿¡]/.test(text)) {
      this.detectedLang = 'es';
      return;
    }
    const matches = text.match(SPANISH_INDICATORS);
    const wordCount = text.split(/\s+/).length;
    if (matches && matches.length >= 2 && wordCount > 2) {
      this.detectedLang = 'es';
    }
  }

  // ---------------------------------------------------------------------------
  // Confidence
  // ---------------------------------------------------------------------------

  private avgConfidence(): number {
    if (this.allWords.length === 0) return 0.5;
    return (
      this.allWords.reduce((sum, w) => sum + w.confidence, 0) /
      this.allWords.length
    );
  }

  // ---------------------------------------------------------------------------
  // Filler — keyword-based, NOT intent-based
  //
  // Answers ONE question: "Will Claude likely call search_properties?"
  // If yes → search filler ("Let me check what we have")
  // If no  → generic filler ("One moment please")
  // ---------------------------------------------------------------------------

  /**
   * Context-aware filler selection.
   *
   * Returns null (NO filler) for most turns — short confirmations, names,
   * farewells, yes/no answers. Claude responds in <1s for these; a filler
   * would sound unnatural.
   *
   * Returns a filler ONLY when the response is expected to be slow:
   *   - search_properties tool call (~3-4s) — location, property type, or search verb detected
   *   - Long/complex questions (8+ words) — likely need more processing
   */
  private pickFiller(): FillerKey | null {
    const p = this.detectedLang === 'es' ? 'es' : 'en';
    const wordCount = this.allText.trim().split(/\s+/).length;

    // Keep the 1-2 word "no-filler" rule for "Yes", "No", "Buy"
    if (wordCount <= 2) return null;

    // If it's a search, definitely use search filler
    if (
      LOCATION_KEYWORDS.test(this.allText) ||
      SEARCH_VERB_KEYWORDS.test(this.allText)
    ) {
      return `${p}_search` as FillerKey;
    }

    // For everything else (3+ words), allow a GENERIC reactive filler.
    // Because it's REACTIVE, it still won't play if Claude is fast (<1.5s).
    return `${p}_generic` as FillerKey;
  }

  // ---------------------------------------------------------------------------
  // Builder
  // ---------------------------------------------------------------------------

  private build(
    action: 'respond' | 'discard',
    audioConf: number,
    isNoise: boolean,
    cleanedText: string,
    debug: string,
    filler: FillerKey | null = null
  ): SpeechDecision {
    return {
      action,
      audioConfidence: audioConf,
      isNoise,
      filler,
      cleanedText,
      lang: this.detectedLang,
      debug,
    };
  }

  /**
   * Fast-trigger: is the current text a complete thought?
   * Pure punctuation + word count. No intent classification.
   */
  private lastTriggeredText = '';

  public isThoughtComplete(): boolean {
    const text = this.getText().toLowerCase();
    if (text === this.lastTriggeredText) return false;

    const words = text.split(/\s+/);
    const wordCount = words.length;
    if (wordCount < 2 || text.length < 5) return false;

    const audioConf = this.avgConfidence();
    if (audioConf < 0.55 && wordCount < 5) return false;

    // Don't trigger if the caller is mid-sentence (last word is a bridge word)
    const lastWord = words[words.length - 1].replace(/[.!?]/g, '');
    const bridgeWords = [
      'a',
      'the',
      'and',
      'or',
      'but',
      'if',
      'with',
      'im',
      'wanna',
      'que',
      'para',
      'y',
      'de',
      'la',
    ];
    if (bridgeWords.includes(lastWord)) return false;

    const hasTerminalPunctuation = /[.!?]$/.test(text);

    // 3+ words with terminal punctuation → complete thought
    if (hasTerminalPunctuation && wordCount >= 3) return true;

    // 6+ words without bridge ending → likely complete
    if (wordCount >= 6) return true;

    return false;
  }
}
