/**
 * Claude integration — OPTIMIZED for latency.
 *
 * Key changes from v1:
 * 1. Pre-baked greeting — no Claude call needed
 * 2. Single streaming call with tool handling (was: 2 calls per turn!)
 * 3. Uses Haiku for speed — Sonnet is overkill for a phone attendant
 * 4. Shorter system prompt — less tokens = faster first token
 */

import Anthropic from '@anthropic-ai/sdk';
import {
  getListingSummary,
  searchPropertiesWithMeta,
  formatResultsForClaude,
  getSearchGeographyContext,
  isShareableListingUrl,
  type SearchFilters,
} from './listings';
import { createLead, getProperties } from './salesforce';
import { requestPropertyConfirmation, requestFlyerByEmail } from './sms';
import { isConfirmed, isOptedOut } from './sms-consent';

const SMS_ENABLED = process.env.SMS_ENABLED !== 'false'; // default: true, set SMS_ENABLED=false to disable
const EMAIL_ENABLED = process.env.EMAIL_ENABLED === 'true'; // default: false (Resend pending), set EMAIL_ENABLED=true to enable
// Filler phrases no longer needed in Claude — fillers are handled by call-handler
// based on the onToolCall callback.

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string | Anthropic.Messages.ContentBlockParam[];
}

export interface LeadData {
  callerName?: string;
  callerPhone: string;
  propertyId?: string;
  propertyAddress?: string;
  interest?: string;
  notes?: string;
  timestamp: string;
}

// ---------------------------------------------------------------------------
// In-memory stores
// ---------------------------------------------------------------------------

const conversations = new Map<string, Anthropic.Messages.MessageParam[]>();
const leads: LeadData[] = [];
const loggedLeadsPerCall = new Map<string, Set<string>>();

export function getConversation(
  callSid: string
): Anthropic.Messages.MessageParam[] {
  if (!conversations.has(callSid)) {
    conversations.set(callSid, []);
  }
  return conversations.get(callSid)!;
}

export function clearConversation(callSid: string): void {
  conversations.delete(callSid);
  loggedLeadsPerCall.delete(callSid);
}

export function getLeads(): LeadData[] {
  return leads;
}

function deduplicateLead(callSid: string, lead: LeadData): boolean {
  const key = `${lead.callerPhone}:${lead.propertyId || 'general'}`;
  if (!loggedLeadsPerCall.has(callSid)) {
    loggedLeadsPerCall.set(callSid, new Set());
  }
  const loggedSet = loggedLeadsPerCall.get(callSid)!;
  if (loggedSet.has(key)) {
    const existingIdx = leads.findIndex(
      (l) =>
        l.callerPhone === lead.callerPhone && l.propertyId === lead.propertyId
    );
    if (existingIdx >= 0) {
      const existing = leads[existingIdx];
      if (
        lead.notes &&
        (!existing.notes || lead.notes.length > existing.notes.length)
      ) {
        existing.notes = lead.notes;
      }
      if (lead.callerName && !existing.callerName) {
        existing.callerName = lead.callerName;
      }
    }
    return true;
  }
  loggedSet.add(key);
  return false;
}

// ---------------------------------------------------------------------------
// System prompt — SHORTER for faster processing
// ---------------------------------------------------------------------------

const SYSTEM_PROMPT = `You are the AI phone attendant for Fausto Commercial Real Estate, a boutique commercial real estate brokerage in South Florida founded in 2013. You answer incoming phone calls professionally and helpfully.

YOUR ROLE:
- Help callers find commercial properties (retail, warehouse, office, industrial, land)
- Use the search_properties tool to find matching listings — DO NOT guess or make up properties
- Refer callers to the listing agent for that property when one is provided in the search results
- Collect caller information for follow-up
- Answer general questions about Fausto Commercial

GREETING:
- A pre-baked greeting plays first: "Thank you for calling Fausto Commercial — how can I help?" (in English) or the Spanish equivalent. You do NOT need to re-greet on your first turn.
- Do NOT say "Fausto Commercial Real Estate" — just "Fausto Commercial".
- Let the caller open the conversation however they want. Do not force a "specific or general" fork.

BILINGUAL SUPPORT:
- You are fully bilingual in English and Spanish
- If the caller speaks Spanish, switch entirely to Spanish for the rest of the conversation
- If the caller mixes English and Spanish (Spanglish), match their style naturally
- If unsure what language the caller prefers, continue in whatever they're speaking
- When speaking Spanish, use natural Latin American / Miami Spanish — not overly formal Castilian

CONVERSATION STYLE:
- Speak naturally and conversationally — your responses will be read aloud via text-to-speech
- KEEP RESPONSES SHORT — 1-2 sentences max. This is a phone call. If you catch yourself writing 3+ sentences, stop and cut it down
- ALWAYS PRESENT PROPERTIES when search returns results. NEVER say "I found several options" without listing at least the top 2-3 with address, type, and price. The caller called to hear about specific properties, not vague summaries.
- After search results come back, your FIRST response must include actual property details. You can ask a follow-up question AFTER presenting properties, not INSTEAD of presenting them.
- GENERAL QUERIES — when the caller says "what do you have?" with no location or property type: narrow first by asking one question at a time in this order: property type → buy or lease → city/area → size → budget
- SKIP "buy or lease?" entirely when the property type is one that is almost never leased whole: multi-family / apartment buildings (5+ units), land, development sites, hotels, motels, assemblages, industrial land. Default to For Sale and proceed. Do not ask. The system also defaults listingType to For Sale server-side for these types.
- These casual phrasings ALL count as sale-only — skip buy/lease for any of them:
  * "X acre site/lot/parcel", "X-acre site", "vacant lot", "vacant land" → LAND
  * "X unit apartment building", "X unit building", "X-unit multifamily", "X-plex" where X ≥ 5 → MULTIFAMILY
  * "land development site", "development site", "dev site", "assemblage" → LAND/DEV
  * "hotel", "motel", "boutique hotel" → HOSPITALITY
- If the caller's wording fits any of these, do NOT ask buy or lease — search directly.
- If the caller's wording already implies intent ("I want to buy a warehouse", "I'm leasing retail space"), DO NOT ask buy or lease again — you already know.
- This applies to the property you JUST PRESENTED, not only the caller's query: if the listing you found is land, a development site, a multi-family/apartment building (5+ units), a hotel/motel, or an assemblage, it is FOR SALE — NEVER ask the caller "buy or lease" about it. (e.g. a "land development site" is for sale; do not ask.)
- After 2 unanswered qualifying questions in a row, STOP asking. Search with whatever info you have and present the closest matches.
- When presenting results: address, type, and price in a brief phrase per property. If more than 3 match, present top 3 and mention how many total
- After listing results: "We have over 400 exclusively listed commercial properties, I can keep narrowing these down for you."
- Never ask the same question twice. If you already asked "buy or lease?" and got no clear answer, move on and present what you have. Check the conversation history before asking any qualifying question.
- NO MATCH HANDLING — When the search returns nothing, do NOT ask "are you flexible on size/budget?" or "would you go larger or smaller?" — these interrogations frustrate callers. The system automatically broadens the search; when you see the "[No exact matches — broadened search by X]" hint in tool results, present the broadened results with a brief framing like: "I don't have exactly that, but here are the closest options:" then list them. Only ask a clarifying question if even the broadened search returns nothing.
- Don't repeat information the caller already told you
- Use simple language, avoid jargon
- Don't use bullet points, numbered lists, or any formatting — this is a phone call
- Don't say things like "according to our listings" — just speak naturally
- If you're not sure about a match, describe what you found and ask if it sounds right
- Always try to collect the caller's name and what they're looking for
- Once you have the caller's name and interest, log the lead and wrap up efficiently

FILLER AWARENESS:
- The system plays a short acknowledgment phrase (like "Let me check on that") BEFORE your response when the caller asks for a property search
- Because of this, NEVER start your response with filler phrases like "Let me search for that", "Let me look that up", "Sure, let me check", "I'll search for that"
- Jump straight into the answer: "I found a six unit property at..." or "We have several options in that area..."
- Sometimes before your response plays, a short filler phrase was already spoken to fill silence. When a filler phrase is noted in context, do not open your response with similar sentiment — it would sound repetitive. Flow directly into your answer as if continuing naturally from what was already said
- Never narrate what you're about to do: don't say "Let me search", "I'll look that up", "Let me find that for you". Just present the results directly

NOISY CALLS:
- Callers may be in cars, offices, or noisy environments
- You may receive garbled or nonsensical text mixed in with real requests — this is background noise picked up by the microphone
- Focus on extracting the actual request and ignore fragments that don't make sense in context
- If the transcript is mostly noise with no clear request, ask the caller to repeat: "I didn't catch that clearly — what are you looking for?"
- Never respond to obvious background chatter as if the caller said it to you

STT ERROR AWARENESS:
- All caller input comes through phone speech-to-text and may contain transcription errors. Before responding, check if a word fits the context or if it is likely a mishearing. Common errors:
  * "just one / just 1 / just won" → US-1 / Dixie Highway
  * "dubai / the buy" → "to buy" (purchase intent)
  * "bye" immediately after asking buy or lease → "buy"
  * "alla parra / alapara" → Allapattah
  * "coral cable / coral cables" → Coral Gables
  * "repito / repeat" when asking for a name → caller wants you to repeat yourself
  * "please" after buy or lease question → likely "lease"
  * "fine" after buy or lease question → filler word, ask again
  * "square inch" → square feet
- Use the most contextually logical interpretation like a human receptionist would. Only ask for clarification if the word genuinely could mean two different things in context

TTS FORMATTING — IMPORTANT:
- Your responses are read aloud by a text-to-speech engine. Write everything as spoken words, never abbreviations.
- For ADDRESSES: Break the street number into pairs and read each pair as a number. NEVER read it as a single thousands number. Pattern:
  * 4-digit numbers: split into two pairs. 1805 → "eighteen oh five". 3040 → "thirty forty". 1028 → "ten twenty-eight". 2432 → "twenty-four thirty-two". 4831 → "forty-eight thirty-one". NOT "one thousand eight hundred five" or "eighteen hundred five".
  * 3-digit numbers: read as one number, OR digit-by-digit when the middle digit is 0. 807 → "eight oh seven". 537 → "five thirty-seven". 250 → "two fifty".
  * 5-digit numbers: split first 2 + last 3, or first 3 + last 2 — whichever flows better. 14100 → "fourteen one hundred". 21500 → "twenty-one five hundred". 11620 → "one one six two zero" or "eleven six twenty".
  * When in doubt, read each digit individually rather than as a thousands number — that always works.
  * The phrase "one thousand X" or "X thousand Y" is FORBIDDEN for street numbers. Nobody says "I live at one thousand eight hundred five Ponce de Leon".
  * Same rule in Spanish: 1805 → "dieciocho cero cinco", NOT "mil ochocientos cinco". 3040 → "treinta cuarenta".
- For MONEY: Always say "dollars" or "per square foot" (e.g., "thirty-two dollars per square foot" not "$32/sqft").
- For MEASUREMENTS: Always say "square feet" (e.g., "one thousand four hundred square feet" not "1400 sq ft").
- Spell out street types and directions fully: "West Dixie Highway" not "W Dixie Hwy", "Northwest" not "NW".
- Never use the "#" symbol; say the word "Unit" or "Number".

ABOUT FAUSTO COMMERCIAL:
- Owner/Broker: Carlos Fausto
- Founded: 2013
- Specializes in commercial real estate in Miami-Dade and Broward counties
- Services: Leasing, Sales, Tenant Representation, Property Management
- Office hours: Monday-Friday 9am-6pm, Saturday by appointment
- Website: faustocommercial.com

AVAILABLE INVENTORY:
${getListingSummary()}

TOOL USAGE:
- Use search_properties to find listings matching the caller's needs. Search by city, property type, listing type, price range, size, or keywords.
- LOT SIZE — When the caller says "acres" (e.g. "5 acre site"), convert to sqft: 1 acre = 43,560 sqft. Pass as minLotSqft. So "5 acres" → minLotSqft: 217800. When the caller says sqft for a lot, pass minLotSqft / maxLotSqft directly.
- CHEAPEST / PRICE PER DOOR — When the caller asks for "cheapest", "best price per door", "lowest per unit" on multifamily, set sortBy: "price_per_door_asc". For absolute cheapest by total price set sortBy: "price_asc".
- When you've identified a caller's name, phone number, and property interest, use the log_lead tool to record it
- You don't need to ask for their phone number — Twilio provides it automatically
- IMPORTANT: Only call log_lead ONCE per property per call. Do not re-log the same lead when confirming details or saying goodbye. If you already logged it, do not call the tool again.
- Wait until you have gathered the caller's name and specific interest before logging — don't log too early with incomplete info

CONVERSATION FLOW (follow this order):
1. Search for properties matching the caller's request
2. Present the property details verbally
3. Ask for the caller's name to log their interest
4. Log the lead (name + property + interest)
${SMS_ENABLED ? `5. THEN you MUST offer to get the caller the info — NEVER end with only an agent referral.
   - If the chosen property's search-result line does NOT carry "| No shareable URL": offer to text it — "Would you like me to text you the property details and a link?"
   - If it DOES carry "| No shareable URL" (not published on the website yet, only the chosen property's tag matters): NEVER say "we don't have a link" or "it's not on our website." ${EMAIL_ENABLED ? 'PROACTIVELY offer to email the flyer — "I can email you the flyer; I\'ll text you and you just reply with your email" — and call the text_for_email tool for that property ON YOUR OWN, before wrapping up, even if you also mention the listing agent. Only if text_for_email reports there is no flyer do you fall back to an agent reaching out.' : 'briefly say an agent will reach out with the details using the number they called from.'} The caller's number is on file — do NOT ask for it. Phrase it in your own words.
6. If they say yes (or already asked to be texted), you MUST call the send_property_sms tool for that property. Do NOT skip this step — logging the lead does NOT send a text.
7. The tool result will tell you what happened. Two cases:
   a) The result starts with "Text sent" — the caller has previously confirmed consent. Say: "I just sent you a text with the details."
   b) The result starts with "Confirmation text sent" — this is a first-time caller. Say something like: "I just sent you a quick text — reply YES to that message and I'll send the property details right after." Do NOT say the property details are already on the way; the YES reply is required by texting regulations.
- CRITICAL — NO PHANTOM SENDS: You have NOT sent a text unless you called send_property_sms and got a result in THIS turn. NEVER say "I sent you a text" / "I just texted you" if you did not call the tool — that misleads the caller. Logging a lead is NOT sending a text. If you are about to confirm a text you did not actually send, call send_property_sms now instead.
- Only send SMS once per property per call
${EMAIL_ENABLED ? `- WHEN THE CALLER WANTS SEVERAL PROPERTIES: prefer EMAIL over text. One email carries every flyer and link cleanly; multiple links by SMS are clunky. Use SMS for a single property's link; switch to email once they want two or more.` : ''}
${EMAIL_ENABLED ? `- EMAIL — A LISTING WITH NO WEBSITE LINK IS NOT A DEAD END: if it has a flyer you can still EMAIL it. Whenever a property the caller wants has no shareable link, offer to email the flyer (text_for_email) — do NOT jump to "an agent will reach out." Agent follow-up is only the fallback when text_for_email reports there's no flyer. Callers can get the property flyer by email. DEFAULT method is the text_for_email tool — it texts the caller and they reply with their email; do NOT ask them to spell their address out loud on the call. (Use send_email ONLY if the caller insists on saying the address verbally — then read it back to confirm.) When you use text_for_email, tell the caller you've sent them a text and to reply to it with their email. For SEVERAL properties, call text_for_email for each — they're collected into ONE email (all flyers + links) sent when the caller replies. Don't promise email for a property that has neither a flyer nor a web page.` : '- We do NOT offer email yet. If a caller asks to receive info by email, do not promise email — offer to text them the listing link or have an agent follow up instead.'}
- IF THE CALLER PROACTIVELY ASKS FOR A TEXT before you've gathered their name ("can you text me?" / "¿me puede mandar un texto?"), check the search-result line for the chosen listing FIRST.
   • If that line does NOT carry "No shareable URL": acknowledge YES — say something like "Sure — what's your name and I'll send that text right after." Then gather name, log the lead, and call send_property_sms.
   • If that line DOES carry "No shareable URL": do NOT offer to text a link and do NOT say "no link" or "not on our website." ${EMAIL_ENABLED ? 'Instead, offer to EMAIL the flyer — "I can email you the flyer; I\'ll text you a quick message and you just reply with your email." Gather their name, log the lead, and call text_for_email for this property. (Only if text_for_email reports there is no flyer does an agent reach out instead.)' : 'Say an agent will reach out with the full info using the number they called from, and end without calling send_property_sms.'}` : '5. Ask if there is anything else you can help with'}

ADDRESS SEARCHES:
- When a caller asks about a specific street address and search returns no results, DO NOT immediately say it's not in our listings
- Instead, retry the search with just the street name without the street number (e.g., if "3040 NW 40th" returns nothing, search again with keyword "40th Street")
- IMPORTANT: Our address database uses full direction names (Northwest, not NW). When searching by keyword, spell out directions fully: "Northwest 40th" not "NW 40th"
- If the retry finds a nearby listing on the same street, say: "I don't have that exact address, but we do have a listing at [address] — could that be the one you're looking for?"
- Only say we don't have listings at that location if the broader street search also returns nothing
- SPANISH NUMBER ADDRESSES — When a Spanish-speaking caller speaks the street number as words, ALWAYS convert to digits BEFORE searching. Examples:
  * "dieciocho cero cinco Ponce de León" → search for "1805 Ponce de Leon"
  * "mil ochocientos cinco" → "1805"
  * "tres mil cuarenta Northwest cuarenta" → "3040 NW 40th"
  * "diez veintiocho Southwest novena" → "1028 SW 9th"
  Map Spanish digit-by-digit (uno=1, dos=2, tres=3, cuatro=4, cinco=5, seis=6, siete=7, ocho=8, nueve=9, cero=0, diez=10, once=11, doce=12, trece=13, catorce=14, quince=15, dieciseis=16, diecisiete=17, dieciocho=18, diecinueve=19, veinte=20, treinta=30, cuarenta=40, cincuenta=50, sesenta=60, setenta=70, ochenta=80, noventa=90, cien=100, mil=1000) and Spanish ordinals (primera=1st, segunda=2nd, tercera=3rd, cuarta=4th, quinta=5th, sexta=6th, séptima=7th, octava=8th, novena=9th, décima=10th).

SOUTH FLORIDA GEOGRAPHY:
- When a caller references a location, recognize these South Florida aliases:
  * US-1, US 1, Route 1, just one, Highway 1 = S Dixie Hwy = Dixie Highway
  * 836 = Dolphin Expressway
  * 826 = Palmetto Expressway
  * 874 = Don Shula Expressway
  * Turnpike = Florida Turnpike = SR-91
  * I-95 = 95
  * Biscayne = Biscayne Blvd
- Miami-Dade is a grid starting from Flagler Street (east-west) and Miami Avenue (north-south). Numbers grow away from downtown in NW/SW/NE/SE quadrants
- Street numbers above 180th are far South Miami-Dade (Cutler Bay, Homestead, Palmetto Bay)
- When searching by highway, try alias variants — "US-1 and 215th Street" should search "Dixie Hwy" near "21500" or "Cutler Bay"

AGENT REFERRALS:
- Each property has a listing agent. When a caller is interested in a property, tell them the listing agent's name will call them back.
- Example: "The listing agent for that property is Yuniel De Varona, he'll give you a call to set up a showing."
- If no agent is listed for a property, say "one of our agents" will follow up.
- Do NOT say "Maria" or "Carlos" will call — it's the listing agent who handles showings and follow-up.
- If the caller asks a general question not about a specific property, say "our team" will reach out.

FOLLOW-UP YES/NO PROMPTS:
- When you ask "anything else?" / "any more questions?" / similar, and the caller just says "yes" / "yeah" / "sí" / "uh-huh", do NOT ask "what question do you have?" — that creates a race where the caller is already speaking their question. Instead, give a tiny acknowledgment ("Sure.") or stay quiet and wait. The caller's next utterance will be the actual question.

SHORT RESPONSES:
- When the caller gives a one or two word answer, ALWAYS interpret it as a response to your most recent question first
- CRITICAL: "Buy", "bye", and "goodbye" sound identical or very similar on phone calls. If you JUST asked "buy or lease?" and the very next thing the caller says is "bye", "goodbye", or any farewell-sounding word — they are answering "buy", NOT saying goodbye. Nobody calls a real estate company, asks about a property, gets asked "buy or lease?", and immediately hangs up. Always interpret it as "buy" in that context.
- If you just asked a question with clear options (buy or lease, yes or no, English or Spanish), the next short reply is ALWAYS answering that question — never a farewell
- Only treat farewells as actual farewells when: the conversation has reached a natural conclusion, you've already helped them, AND there is no pending unanswered question

ENDING CALLS:
- Use the end_call tool to hang up the phone when the conversation is clearly finished
- Call end_call AFTER saying your farewell — say goodbye first, then use the tool
- Use it when: the caller says a clear farewell with no pending question, the caller asks you to hang up, or you've completed the interaction and exchanged farewells
- Do NOT use it prematurely — only after mutual farewell or explicit request to end
- Do NOT use it just because you said "have a great day" — wait for the caller to also say goodbye

IMPORTANT RULES:
- If asked about properties you don't have, offer to have the team follow up with other options
- If someone wants to schedule a showing, let them know the listing agent will call them back to arrange it
- Never make up properties or details — always use search_properties to find real listings`;

const tools: Anthropic.Messages.Tool[] = [
  {
    name: 'search_properties',
    description:
      'Search available property listings. Use this whenever a caller asks about properties. Returns top matching results with details.',
    input_schema: {
      type: 'object' as const,
      properties: {
        city: {
          type: 'string',
          description:
            'City name (e.g. Miami, Hialeah, Hollywood, Fort Lauderdale, Doral)',
        },
        propertyType: {
          type: 'string',
          description:
            'Property type: Retail, Industrial, Multi-Family, Office, Land, Commercial, Medical, Hotel',
        },
        listingType: { type: 'string', description: 'For Sale or For Lease' },
        minPrice: { type: 'number', description: 'Minimum price' },
        maxPrice: { type: 'number', description: 'Maximum price' },
        minSqft: {
          type: 'number',
          description: 'Minimum building size in sqft',
        },
        maxSqft: {
          type: 'number',
          description: 'Maximum building size in sqft',
        },
        minLotSqft: {
          type: 'number',
          description:
            'Minimum lot size in sqft. When caller says acres, convert: 1 acre = 43,560 sqft (e.g. "5 acres" → 217800).',
        },
        maxLotSqft: {
          type: 'number',
          description: 'Maximum lot size in sqft (1 acre = 43,560 sqft).',
        },
        keyword: {
          type: 'string',
          description:
            'Free text search — address, neighborhood, zoning, tags, description',
        },
        sortBy: {
          type: 'string',
          enum: ['relevance', 'price_asc', 'price_desc', 'price_per_door_asc'],
          description:
            'Sort order. Use "price_per_door_asc" when the caller asks for cheapest per door / per unit on multifamily. Use "price_asc" when caller asks for the absolute cheapest. Defaults to "relevance".',
        },
      },
      required: [],
    },
  },
  {
    name: 'log_lead',
    description:
      'Log a lead when caller gives their name and interest. Call ONCE per property. Include asset type, city, and intent for lead categorization.',
    input_schema: {
      type: 'object' as const,
      properties: {
        caller_name: { type: 'string', description: "Caller's name" },
        property_id: { type: 'string', description: 'Salesforce Property ID' },
        property_address: { type: 'string', description: 'Property address' },
        interest: { type: 'string', description: 'What they want' },
        notes: { type: 'string', description: 'Extra notes' },
        property_type: {
          type: 'string',
          description:
            'Asset type: Multi-Family, Retail, Industrial, Office, Land, Commercial, Medical, Hotel',
        },
        city: {
          type: 'string',
          description: 'City the caller is interested in (e.g. Miami, Fort Lauderdale, Jacksonville)',
        },
        intent: {
          type: 'string',
          enum: ['buy', 'lease'],
          description: 'Whether the caller wants to buy or lease',
        },
      },
      required: ['interest'],
    },
  },
  {
    name: 'end_call',
    description:
      "End the phone call. Use this AFTER saying your final farewell when the conversation is clearly over. Signs the call is done: you've said goodbye, the caller has said goodbye, or the caller has asked you to hang up. Always say your farewell message BEFORE calling this tool.",
    input_schema: {
      type: 'object' as const,
      properties: {
        reason: {
          type: 'string',
          description:
            "Brief reason for ending: 'farewell', 'caller_requested', 'conversation_complete'",
        },
      },
      required: ['reason'],
    },
  },
  ...(SMS_ENABLED
    ? [
        {
          name: 'send_property_sms' as const,
          description:
            'Send a text message to the caller with property details and a link. Use when the caller wants to receive property information via text. Only send once per property per call.',
          input_schema: {
            type: 'object' as const,
            properties: {
              property_id: {
                type: 'string',
                description: 'Salesforce Property ID. Copy it EXACTLY from the search-result line — it appears as "[id:a0R...]" right after the result number. Do NOT invent or guess; the wrong id breaks the SMS.',
              },
              property_name: {
                type: 'string',
                description: 'Property name or marketing name',
              },
              property_address: {
                type: 'string',
                description: 'Full property address',
              },
            },
            required: ['property_id', 'property_address'],
          },
        },
      ]
    : []),
  ...(EMAIL_ENABLED
    ? [
        {
          name: 'send_email' as const,
          description:
            "Email the caller a property flyer (PDF) and listing link. Use when the caller asks to receive property info by email AND has given their email address. Read the address back to confirm spelling before calling. Only send once per property per call.",
          input_schema: {
            type: 'object' as const,
            properties: {
              email: {
                type: 'string',
                description: "The caller's email address, confirmed by reading it back to them.",
              },
              property_id: {
                type: 'string',
                description: 'Salesforce Property ID. Copy it EXACTLY from the search-result line — it appears as "[id:a0R...]". Do NOT invent or guess.',
              },
              property_address: {
                type: 'string',
                description: 'Full property address',
              },
            },
            required: ['email', 'property_address'],
          },
        },
        {
          name: 'text_for_email' as const,
          description:
            "Text the caller asking them to reply with their email, then email them the flyer(s) when they reply. Use when the caller wants the flyer by email but does NOT want to spell their address out loud — especially when there's no website link to text (the listing isn't published yet) but there is a flyer. Their phone number is already known. Call it once per property the caller wants emailed: the first call texts them, the rest are added — all the flyers arrive in ONE email when they reply.",
          input_schema: {
            type: 'object' as const,
            properties: {
              property_id: {
                type: 'string',
                description: 'Salesforce Property ID. Copy it EXACTLY from the search-result line — "[id:a0R...]". Do NOT guess.',
              },
              property_address: {
                type: 'string',
                description: 'Full property address',
              },
            },
            required: ['property_address'],
          },
        },
      ]
    : []),
];

// ---------------------------------------------------------------------------
// Claude client
// ---------------------------------------------------------------------------

const client = new Anthropic();

// Use Haiku for speed — it's more than smart enough for a phone attendant
const MODEL = 'claude-haiku-4-5-20251001';

async function processToolUse(
  callSid: string,
  callerPhone: string,
  block: Anthropic.Messages.ToolUseBlock
): Promise<Anthropic.Messages.ToolResultBlockParam> {
  if (block.name === 'search_properties') {
    const input = block.input as SearchFilters;
    console.log(`🔍 [${callSid}] Search: ${JSON.stringify(input)}`);
    const { properties: results, fallbackReason } = searchPropertiesWithMeta(input, 15);
    const formatted = formatResultsForClaude(results, {
      showPricePerDoor: input.sortBy === 'price_per_door_asc',
      showLotSize:
        input.minLotSqft != null ||
        input.maxLotSqft != null ||
        /\b(land|lot|acre|sqft|square\s*feet)\b/i.test(input.keyword || ''),
    });
    console.log(
      `🔍 [${callSid}] Found ${results.length} matches${
        fallbackReason ? ` (broadened: ${fallbackReason})` : ''
      }`
    );
    // Surface canText flags so we can tell why the AI may skip the SMS offer.
    if (results.length) {
      console.log(
        `🔍 [${callSid}] canText flags: ${results
          .slice(0, 5)
          .map((p) => `${p.id}=${p.canText === false ? 'NO' : 'yes'}`)
          .join(' ')}`
      );
    }

    let content = formatted;
    if (fallbackReason) {
      content += `\n\n[No exact matches — broadened search by ${fallbackReason}. Tell the caller: "I don't have exactly that, but here are the closest options."]`;
    }

    // When results are sparse, add geography context so Claude can suggest alternatives
    if (results.length < 2 && input.keyword) {
      const geoContext = getSearchGeographyContext(input.keyword);
      if (geoContext) {
        content += `\n\n[Geography context: ${geoContext}]`;
      }
    }

    return {
      type: 'tool_result',
      tool_use_id: block.id,
      content,
    };
  }

  if (block.name === 'log_lead') {
    const input = block.input as {
      caller_name?: string;
      property_id?: string;
      property_address?: string;
      interest?: string;
      notes?: string;
      property_type?: string;
      city?: string;
      intent?: string;
    };

    const lead: LeadData = {
      callerName: input.caller_name,
      callerPhone,
      propertyId: input.property_id,
      propertyAddress: input.property_address,
      interest: input.interest,
      notes: input.notes,
      timestamp: new Date().toISOString(),
    };

    const isDuplicate = deduplicateLead(callSid, lead);
    if (!isDuplicate) {
      leads.push(lead);
      console.log('📋 Lead logged:', JSON.stringify(lead, null, 2));

      // Fire-and-forget to Salesforce (falls back to Make.com if SF unavailable)
      const nameParts = (input.caller_name || '').trim().split(/\s+/);
      createLead({
        firstName: nameParts.slice(0, -1).join(' ') || undefined,
        lastName: nameParts[nameParts.length - 1] || 'Unknown',
        phone: callerPhone,
        propertyId: input.property_id,
        propertyName: input.property_address,
        interest: input.interest,
        notes: input.notes,
        leadSource: 'AI Phone Attendant',
        propertyType: input.property_type,
        city: input.city,
        intent: input.intent,
      }).catch(() => {}); // Never block the call
    }

    let content = isDuplicate
      ? 'Already logged. Do NOT call again. Just continue talking.'
      : 'Lead saved. Do NOT log again. Continue the conversation.';

    // Deterministic nudge: the prompt alone wasn't reliably offering the flyer on
    // draft listings, so inject the instruction at the exact moment we log the
    // lead. If this property has no public web page, tell the assistant to offer
    // the flyer by email right now (text_for_email checks for an actual flyer).
    if (!isDuplicate) {
      const sfProps = getProperties();
      let p = input.property_id ? sfProps.find((x) => x.id === input.property_id) : undefined;
      if (!p && input.property_address) {
        const needle = input.property_address.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 20);
        if (needle.length >= 5) {
          p = sfProps.find((x) =>
            `${x.address || ''} ${x.name || ''}`.toLowerCase().replace(/[^a-z0-9]+/g, ' ').includes(needle)
          );
        }
      }
      if (p && isShareableListingUrl(p.publicUrl)) {
        // Symmetric to the email nudge below: the SMS path was relying on the
        // prompt alone, so the model would log the lead and then FALSELY claim
        // it texted the caller without ever calling send_property_sms. Nudge it
        // to actually send, at the exact moment it logs.
        content +=
          ' NEXT, RIGHT NOW: this listing HAS a public website page. If the caller wants it (they asked to be texted, or you offered), you MUST call the send_property_sms tool for THIS property before you say anything about a text. You have NOT sent a text unless send_property_sms returns a result this turn — never say "I sent you a text" otherwise.';
      } else if (p && EMAIL_ENABLED && !isShareableListingUrl(p.publicUrl)) {
        content +=
          ' NEXT, RIGHT NOW: this listing has NO public website page. Do NOT just refer the caller to an agent and wrap up — proactively tell them you can email the flyer and call the text_for_email tool for this property. Never mention a missing link.';
      }
    }

    return { type: 'tool_result', tool_use_id: block.id, content };
  }

  if (block.name === 'send_property_sms') {
    const input = block.input as {
      property_id?: string;
      property_name?: string;
      property_address?: string;
    };

    // Look up the SF property for publicUrl. Prefer id, fall back to address
    // matching when the AI passes an empty / hallucinated id (it sometimes does
    // when it can't see the id in search results).
    const sfProps = getProperties();
    let sfProp = input.property_id
      ? sfProps.find((p) => p.id === input.property_id)
      : undefined;
    let matchedBy: 'id' | 'address' | 'none' = sfProp ? 'id' : 'none';
    if (!sfProp && input.property_address) {
      const needle = input.property_address.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 20);
      if (needle.length >= 5) {
        sfProp = sfProps.find((p) => {
          const hay = `${p.address || ''} ${p.name || ''}`.toLowerCase().replace(/[^a-z0-9]+/g, ' ');
          return hay.includes(needle);
        });
        if (sfProp) matchedBy = 'address';
      }
    }
    console.log(
      `📱 [${callSid}] send_property_sms lookup: id="${input.property_id || ''}" addr="${input.property_address || ''}" → matched=${matchedBy}${sfProp ? ` (${sfProp.id})` : ''}`
    );
    const publicUrl = sfProp?.publicUrl || null;
    const name =
      input.property_name ||
      sfProp?.marketingName ||
      sfProp?.name ||
      'Property';
    const address = input.property_address || sfProp?.address || '';

    // No shareable URL → a text would either contain just a name + address
    // (useless) or a draft-style ?p=<id> URL (404 for the recipient).
    if (!isShareableListingUrl(publicUrl)) {
      const reason = publicUrl ? 'draft / non-public URL' : 'no listing page';
      console.log(`📱 [${callSid}] SMS skipped — ${reason} for ${name}`);
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: EMAIL_ENABLED
          ? 'REFUSED — this listing has no public web page, so NO text/link was sent. Do NOT say "I sent you a text" or mention a missing link. Instead, OFFER TO EMAIL THE FLYER: tell the caller you can email them the flyer and you\'ll text them to reply with their email — then call the text_for_email tool for this property. Only fall back to an agent if text_for_email reports no flyer.'
          : 'REFUSED — this property has no shareable web page. NO TEXT WAS SENT. Do NOT say "I sent you a text", "reply YES", or any phrasing that implies a message went out. Instead: briefly tell the caller the listing isn\'t on the website yet so a text wouldn\'t have the details, and you can have an agent reach out with the full info using the number they called from. Confirm the number is fine, then wrap up.',
      };
    }

    if (isOptedOut(callerPhone)) {
      console.log(`📱 [${callSid}] SMS skipped — caller has opted out`);
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: EMAIL_ENABLED
          ? 'This caller previously opted out of text messages. Do NOT promise to text them. Offer to email or have an agent call instead.'
          : 'This caller previously opted out of text messages. Do NOT promise to text them. Offer to have an agent call them instead.',
      };
    }

    const alreadyConfirmed = isConfirmed(callerPhone);
    console.log(
      `📱 [${callSid}] Property SMS request for ${callerPhone}: ${name} @ ${address} (already_confirmed=${alreadyConfirmed})`
    );

    const outcome = await requestPropertyConfirmation(callerPhone, {
      propertyId: sfProp?.id || input.property_id || '',
      propertyName: name,
      propertyAddress: address,
      publicUrl,
    }).catch((err) => {
      console.warn(`📱 [${callSid}] requestPropertyConfirmation failed:`, err?.message);
      return 'failed' as const;
    });
    console.log(`📱 [${callSid}] requestPropertyConfirmation: ${outcome}`);

    let content: string;
    switch (outcome) {
      case 'sent_immediately':
        content = 'Text sent with the property details. Tell the caller it is on its way.';
        break;
      case 'confirmation_sent':
        content =
          'Confirmation text sent: the caller will get a "Reply YES to confirm" message. Tell them to reply YES to receive the property details (and any other properties you queue go out together on that YES). They get nothing until they reply YES.';
        break;
      case 'queued':
        content = `Added ${name} to the same batch — it goes out with the others when the caller replies YES. Do NOT ask them to reply YES again (you already did); just say you've added it.`;
        break;
      case 'opted_out':
        content = 'This caller opted out of texts — do NOT promise a text. Offer to email or have an agent follow up.';
        break;
      default:
        content = "The text didn't go through. NO TEXT WAS SENT. Offer to email the caller or have an agent follow up.";
    }

    return {
      type: 'tool_result',
      tool_use_id: block.id,
      content,
    };
  }

  if (block.name === 'send_email') {
    const input = block.input as {
      email?: string;
      property_id?: string;
      property_address?: string;
    };

    const email = (input.email || '').trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: 'The email address looks invalid. NO EMAIL WAS SENT. Ask the caller to repeat it slowly and try again.',
      };
    }

    // Resolve the SF property — prefer id, fall back to address (same as SMS).
    const sfProps = getProperties();
    let sfProp = input.property_id ? sfProps.find((p) => p.id === input.property_id) : undefined;
    if (!sfProp && input.property_address) {
      const needle = input.property_address.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 20);
      if (needle.length >= 5) {
        sfProp = sfProps.find((p) => {
          const hay = `${p.address || ''} ${p.name || ''}`.toLowerCase().replace(/[^a-z0-9]+/g, ' ');
          return hay.includes(needle);
        });
      }
    }
    const propId = sfProp?.id || input.property_id || '';
    const name = sfProp?.marketingName || sfProp?.name || input.property_address || 'the property';
    const hasUrl = isShareableListingUrl(sfProp?.publicUrl || null);

    // Viability: a flyer OR a public listing page. Cheap existence check (no download).
    let hasFlyer = false;
    if (propId) {
      try {
        const { propertyHasFlyer } = await import('./integrations/sf-files');
        hasFlyer = await propertyHasFlyer(propId);
      } catch (err) {
        console.warn(`[${callSid}] propertyHasFlyer failed:`, (err as Error)?.message);
      }
    }

    if (!hasFlyer && !hasUrl) {
      console.log(`📧 [${callSid}] email skipped — no flyer and no listing page for ${name}`);
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content:
          'REFUSED — this property has no flyer on file and no public web page. NO EMAIL WAS SENT. Do NOT say you emailed anything. Instead, tell the caller you\'ll have an agent reach out with the details using the number they called from, then wrap up.',
      };
    }

    // Fire-and-forget — never block the call.
    console.log(`📧 [${callSid}] Emailing ${name} to ${email} (flyer=${hasFlyer}, url=${hasUrl})`);
    if (propId) {
      import('./handlers/email')
        .then(({ emailListingToLead }) => emailListingToLead(propId, email))
        .then((r) => console.log(`📧 [${callSid}] email result: ok=${r.ok} flyer=${r.hadFlyer} url=${r.hadUrl}${r.error ? ` err=${r.error}` : ''}`))
        .catch((err) => console.warn(`📧 [${callSid}] email send failed:`, err?.message));
    }

    return {
      type: 'tool_result',
      tool_use_id: block.id,
      content: `Email is on its way to ${email}${hasFlyer ? ' with the property flyer attached' : ' with the listing link'}. Tell the caller to check their inbox (and spam folder) in a couple of minutes. Do NOT send again for this property.`,
    };
  }

  if (block.name === 'text_for_email') {
    const input = block.input as { property_id?: string; property_address?: string };

    if (isOptedOut(callerPhone)) {
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: 'This caller opted out of texts — do NOT promise a text. Offer to take their email out loud to send it, or have an agent follow up.',
      };
    }

    // Resolve the SF property — prefer id, fall back to address (same as send_email).
    const sfProps = getProperties();
    let sfProp = input.property_id ? sfProps.find((p) => p.id === input.property_id) : undefined;
    if (!sfProp && input.property_address) {
      const needle = input.property_address.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 20);
      if (needle.length >= 5) {
        sfProp = sfProps.find((p) => {
          const hay = `${p.address || ''} ${p.name || ''}`.toLowerCase().replace(/[^a-z0-9]+/g, ' ');
          return hay.includes(needle);
        });
      }
    }
    const propId = sfProp?.id || input.property_id || '';
    const name = sfProp?.marketingName || sfProp?.name || input.property_address || 'the property';
    const hasUrl = isShareableListingUrl(sfProp?.publicUrl || null);

    if (!propId) {
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: 'Could not identify which property. Ask the caller to confirm the listing, then try again.',
      };
    }

    let hasFlyer = false;
    try {
      const { propertyHasFlyer } = await import('./integrations/sf-files');
      hasFlyer = await propertyHasFlyer(propId);
    } catch (err) {
      console.warn(`[${callSid}] propertyHasFlyer failed:`, (err as Error)?.message);
    }
    if (!hasFlyer && !hasUrl) {
      return {
        type: 'tool_result',
        tool_use_id: block.id,
        content: 'REFUSED — this property has no flyer on file and no public page, so there is nothing to email. NO TEXT WAS SENT. Offer to have an agent follow up instead.',
      };
    }

    console.log(`📧 [${callSid}] text_for_email ${name} → ${callerPhone} (flyer=${hasFlyer}, url=${hasUrl})`);
    const outcome = await requestFlyerByEmail(callerPhone, { propertyId: propId, propertyName: name }).catch((err) => {
      console.warn(`📧 [${callSid}] requestFlyerByEmail failed:`, err?.message);
      return 'failed' as const;
    });
    console.log(`📧 [${callSid}] requestFlyerByEmail: ${outcome}`);

    if (outcome === 'opted_out') {
      return { type: 'tool_result', tool_use_id: block.id, content: 'This caller opted out of texts — do NOT promise a text. Offer to take their email out loud, or have an agent follow up.' };
    }
    if (outcome === 'failed') {
      return { type: 'tool_result', tool_use_id: block.id, content: "The text didn't go through. NO TEXT WAS SENT. Offer to take the caller's email out loud instead, or have an agent follow up." };
    }
    if (outcome === 'added') {
      return { type: 'tool_result', tool_use_id: block.id, content: `Added ${name} to the same email — when the caller replies with their email, it arrives together with the others. Tell them you've added it; do NOT ask them to spell their email, and do NOT call this again for this property.` };
    }
    return {
      type: 'tool_result',
      tool_use_id: block.id,
      content: `Texting the caller now — tell them to reply to that text with their email and we'll send the ${name} flyer (plus any others they ask about). Do NOT ask them to spell the email out loud, and do NOT call this again for this property.`,
    };
  }

  if (block.name === 'end_call') {
    const input = block.input as { reason?: string };
    console.log(
      `📴 [${callSid}] End call requested: ${input.reason || 'no reason'}`
    );
    return {
      type: 'tool_result',
      tool_use_id: block.id,
      content: 'CALL_ENDED',
    };
  }

  return {
    type: 'tool_result',
    tool_use_id: block.id,
    content: 'Unknown tool.',
  };
}

// ---------------------------------------------------------------------------
// Streaming chat — SINGLE call (was two calls before!)
// ---------------------------------------------------------------------------

/**
 * Stream a response from Claude. Uses a single API call that handles
 * both tool use and text generation.
 *
 * If Claude calls a tool, we handle it and make ONE more streaming call
 * for the follow-up text. Total: 1-2 calls instead of always 2.
 */
export interface ChatResult {
  text: string;
  shouldEndCall: boolean;
}

export async function chatStream(
  callSid: string,
  callerPhone: string,
  userMessage: string,
  onTextChunk: (chunk: string) => void,
  onToolCall?: (toolName: string) => void,
): Promise<ChatResult> {
  const history = getConversation(callSid);
  history.push({ role: 'user', content: userMessage });

  let messages = [...history];
  let fullText = '';
  let rounds = 0;
  let shouldEndCall = false;

  while (rounds < 3) {
    rounds++;

    // Stream the response
    const stream = client.messages.stream({
      model: MODEL,
      max_tokens: 250,
      system: [
        {
          type: 'text',
          text: SYSTEM_PROMPT,
          cache_control: { type: 'ephemeral' },
        },
      ],
      tools,
      messages,
    });

    let hasToolUse = false;
    const toolUseBlocks: Anthropic.Messages.ToolUseBlock[] = [];
    let currentToolUse: { id: string; name: string; inputJson: string } | null =
      null;

    for await (const event of stream) {
      switch (event.type) {
        case 'content_block_start':
          if (event.content_block.type === 'tool_use') {
            hasToolUse = true;
            currentToolUse = {
              id: event.content_block.id,
              name: event.content_block.name,
              inputJson: '',
            };
            // Notify caller immediately — this is the moment to play a filler
            onToolCall?.(event.content_block.name);
          }
          break;

        case 'content_block_delta':
          if (event.delta.type === 'text_delta') {
            fullText += event.delta.text;
            onTextChunk(event.delta.text);
          } else if (
            event.delta.type === 'input_json_delta' &&
            currentToolUse
          ) {
            currentToolUse.inputJson += event.delta.partial_json;
          }
          break;

        case 'content_block_stop':
          if (currentToolUse) {
            try {
              const input = JSON.parse(currentToolUse.inputJson);
              toolUseBlocks.push({
                type: 'tool_use',
                id: currentToolUse.id,
                name: currentToolUse.name,
                input,
              });
            } catch {}
            currentToolUse = null;
          }
          break;
      }
    }

    if (!hasToolUse || toolUseBlocks.length === 0) break;

    // Check if end_call was used
    if (toolUseBlocks.some((b) => b.name === 'end_call')) {
      shouldEndCall = true;
    }

    // Handle tool use — process and loop for follow-up text
    const assistantContent: Anthropic.Messages.ContentBlockParam[] = [];

    // Add any text that came before the tool call
    if (fullText) {
      assistantContent.push({ type: 'text', text: fullText });
    }
    for (const block of toolUseBlocks) {
      assistantContent.push(block);
    }

    const toolResults: Anthropic.Messages.ToolResultBlockParam[] =
      await Promise.all(
        toolUseBlocks.map((block) => processToolUse(callSid, callerPhone, block))
      );

    // Save tool exchange to HISTORY so future turns have correct context
    history.push({ role: 'assistant' as const, content: assistantContent });
    history.push({ role: 'user' as const, content: toolResults });

    messages = [...history];

    // If end_call was used, don't loop for follow-up text
    if (shouldEndCall) break;

    // Reset fullText for the follow-up response
    fullText = '';
  }

  if (fullText) {
    history.push({ role: 'assistant', content: fullText });
  }

  return { text: fullText, shouldEndCall };
}

// ---------------------------------------------------------------------------
// Pre-baked greeting — NO Claude call!
// ---------------------------------------------------------------------------

// Recording disclosure is baked into the greeting: Florida is a two-party
// (all-party) consent state and every call is recorded (dual-channel) for QA.
// Disclosing up front in the first utterance keeps us compliant.
const GREETINGS = {
  en: 'Thank you for calling Fausto Commercial. This call may be recorded for quality. How can I help?',
  es: 'Gracias por llamar a Fausto Commercial. Esta llamada puede ser grabada para fines de calidad. ¿En qué le puedo ayudar?',
};

/**
 * Return a pre-baked greeting — no API call needed.
 * Saves 7-11 seconds on every call!
 */
export function getGreeting(callSid: string, lang: 'en' | 'es' = 'en'): string {
  const greeting = GREETINGS[lang];
  const history = getConversation(callSid);
  history.push({ role: 'user', content: '[Call connected]' });
  history.push({ role: 'assistant', content: greeting });
  return greeting;
}
