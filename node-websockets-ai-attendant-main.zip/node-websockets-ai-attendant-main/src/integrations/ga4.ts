/**
 * Google Analytics 4 — Data API client (read-only, for the marketing report).
 *
 * Zero-dependency: authenticates a Google service account by signing a JWT with
 * node:crypto and exchanging it for an OAuth access token, then calls the
 * Analytics Data API `runReport` endpoint directly. Matches this repo's raw
 * `fetch` style (no googleapis SDK).
 *
 * Auth: service account with **Viewer** on the GA4 property.
 * Env vars:
 *   GA4_PROPERTY_ID    — numeric property id (default 433530724)
 *   GA4_SA_JSON        — the full service-account JSON key, as one string
 *                        (preferred; paste the downloaded key verbatim)
 *   — or, as separate vars —
 *   GA4_SA_EMAIL       — service account client_email
 *   GA4_SA_PRIVATE_KEY — service account private_key (PEM; literal "\n" ok)
 *
 * If credentials are absent, `isGa4Configured()` returns false and the report
 * renders the traffic section as "manual / pending" instead of failing.
 */

import { createSign } from 'crypto';

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const GA4_PROPERTY_ID = process.env.GA4_PROPERTY_ID || '433530724';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/analytics.readonly';
const DATA_API = 'https://analyticsdata.googleapis.com/v1beta';
const TOKEN_TTL_SEC = 3600;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Raw metric totals for a single date range. */
export interface GA4Metrics {
  activeUsers: number;
  newUsers: number;
  sessions: number;
  screenPageViews: number;
  /** GA4's "key events" (formerly conversions). */
  keyEvents: number;
  /** Total user-engagement seconds across the range. */
  userEngagementDuration: number;
  /** Derived: engagement seconds per active user (GA4's "avg engagement time"). */
  avgEngagementPerUserSec: number;
}

/** Both windows the report compares. */
export interface GA4Report {
  propertyId: string;
  current: GA4Metrics;
  prior: GA4Metrics;
}

interface ServiceAccount {
  clientEmail: string;
  privateKey: string;
}

// ---------------------------------------------------------------------------
// Credential resolution
// ---------------------------------------------------------------------------

function resolveServiceAccount(): ServiceAccount | null {
  const raw = process.env.GA4_SA_JSON;
  if (raw) {
    try {
      const j = JSON.parse(raw) as { client_email?: string; private_key?: string };
      if (j.client_email && j.private_key) {
        return { clientEmail: j.client_email, privateKey: normalizeKey(j.private_key) };
      }
    } catch {
      console.warn('⚠️ GA4_SA_JSON is set but not valid JSON — ignoring');
    }
  }
  const email = process.env.GA4_SA_EMAIL;
  const key = process.env.GA4_SA_PRIVATE_KEY;
  if (email && key) {
    return { clientEmail: email, privateKey: normalizeKey(key) };
  }
  return null;
}

/** Env vars often store PEM newlines as the two-char sequence "\n". */
function normalizeKey(key: string): string {
  return key.includes('\\n') ? key.replace(/\\n/g, '\n') : key;
}

export function isGa4Configured(): boolean {
  return resolveServiceAccount() !== null;
}

// ---------------------------------------------------------------------------
// OAuth — signed-JWT (service account) grant, with a short-lived token cache
// ---------------------------------------------------------------------------

let cachedToken = '';
let cachedTokenExp = 0;

function base64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

async function getAccessToken(sa: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cachedToken && now < cachedTokenExp - 60) return cachedToken;

  const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claims = base64url(
    JSON.stringify({
      iss: sa.clientEmail,
      scope: SCOPE,
      aud: TOKEN_URL,
      iat: now,
      exp: now + TOKEN_TTL_SEC,
    })
  );
  const signingInput = `${header}.${claims}`;
  const signature = base64url(
    createSign('RSA-SHA256').update(signingInput).sign(sa.privateKey)
  );
  const assertion = `${signingInput}.${signature}`;

  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
    }).toString(),
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) {
    throw new Error(`GA4 token exchange failed: ${res.status} ${await res.text()}`);
  }
  const data = (await res.json()) as { access_token: string; expires_in: number };
  cachedToken = data.access_token;
  cachedTokenExp = now + (data.expires_in || TOKEN_TTL_SEC);
  return cachedToken;
}

// ---------------------------------------------------------------------------
// runReport
// ---------------------------------------------------------------------------

const METRIC_NAMES = [
  'activeUsers',
  'newUsers',
  'sessions',
  'screenPageViews',
  'keyEvents',
  'userEngagementDuration',
] as const;

async function runReport(
  token: string,
  startDate: string,
  endDate: string
): Promise<GA4Metrics> {
  const res = await fetch(
    `${DATA_API}/properties/${GA4_PROPERTY_ID}:runReport`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        dateRanges: [{ startDate, endDate }],
        metrics: METRIC_NAMES.map((name) => ({ name })),
      }),
      signal: AbortSignal.timeout(15000),
    }
  );
  if (!res.ok) {
    throw new Error(`GA4 runReport failed: ${res.status} ${await res.text()}`);
  }
  const data = (await res.json()) as {
    rows?: { metricValues: { value: string }[] }[];
  };
  const values = data.rows?.[0]?.metricValues?.map((m) => Number(m.value) || 0) ?? [];
  const [
    activeUsers = 0,
    newUsers = 0,
    sessions = 0,
    screenPageViews = 0,
    keyEvents = 0,
    userEngagementDuration = 0,
  ] = values;

  return {
    activeUsers,
    newUsers,
    sessions,
    screenPageViews,
    keyEvents,
    userEngagementDuration,
    avgEngagementPerUserSec: activeUsers
      ? Math.round(userEngagementDuration / activeUsers)
      : 0,
  };
}

/**
 * Fetch GA4 metrics for the current and prior reporting windows.
 * Dates are `YYYY-MM-DD` in the property's timezone.
 * Returns null when GA4 is not configured (caller renders "manual/pending").
 */
export async function getGa4Report(
  current: { start: string; end: string },
  prior: { start: string; end: string }
): Promise<GA4Report | null> {
  const sa = resolveServiceAccount();
  if (!sa) return null;

  const token = await getAccessToken(sa);
  const [cur, pri] = await Promise.all([
    runReport(token, current.start, current.end),
    runReport(token, prior.start, prior.end),
  ]);
  return { propertyId: GA4_PROPERTY_ID, current: cur, prior: pri };
}
