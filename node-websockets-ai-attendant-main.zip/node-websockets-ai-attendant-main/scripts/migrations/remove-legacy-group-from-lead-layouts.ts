/**
 * Remove the legacy free-text Group fields (Group_old2__c and Group_Old__c)
 * from the Lead page layouts. Tooling-API metadata PATCH.
 *
 * Why: agents keep typing into the legacy text field when creating new leads,
 * causing every new lead to be born orphaned (Group__c null) which the access
 * Flow then blocks them from editing. Removing the field from the layouts
 * stops the bleed at the source.
 *
 * Idempotent (the PATCH simply re-saves what's already missing).
 * Dry-run by default. Pass --apply.
 *
 *   npx tsx --env-file .env.local scripts/migrations/remove-legacy-group-from-lead-layouts.ts
 *   npx tsx --env-file .env.local scripts/migrations/remove-legacy-group-from-lead-layouts.ts --apply
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const FIELDS_TO_REMOVE = new Set(['Group_old2__c', 'Group_Old__c']);

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  const layouts: any[] = await sf.toolingQuery(
    `SELECT Id, Name FROM Layout WHERE EntityDefinition.QualifiedApiName = 'Lead'`
  );
  console.log(`Lead layouts found: ${layouts.length}`);

  for (const l of layouts) {
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);
    const full: any = await toolingGet(sf, 'Layout', l.Id);
    const meta = full.Metadata || {};
    const sections = (meta.layoutSections || []) as any[];

    let removed = 0;
    const newSections = sections.map((s: any) => ({
      ...s,
      layoutColumns: (s.layoutColumns || []).map((col: any) => ({
        ...col,
        layoutItems: (col.layoutItems || []).filter((item: any) => {
          if (item.field && FIELDS_TO_REMOVE.has(item.field)) {
            console.log(`  Removing "${item.field}" (behavior=${item.behavior}) from section "${s.label}"`);
            removed++;
            return false;
          }
          return true;
        }),
      })),
    }));

    if (!removed) {
      console.log(`  Already clean — no legacy group fields present.`);
      continue;
    }

    if (DRY) {
      console.log(`  Would remove ${removed} item(s). Re-run with --apply.`);
      continue;
    }

    // Tooling API chokes on round-tripped platformActionList (actionListContext
    // serializes as a string on GET but PATCH expects a complexvalue). Send
    // only the modified layoutSections; Layout PATCH treats Metadata as a
    // partial update for top-level keys.
    await toolingPatch(sf, 'Layout', l.Id, { Metadata: { layoutSections: newSections } });
    console.log(`  ✓ PATCH succeeded — ${removed} item(s) removed.`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
