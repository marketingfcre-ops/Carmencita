/**
 * Backfill WP_Post_ID__c on Property__c for properties that already have
 * a Public_URL__c pointing to an existing WordPress page.
 *
 * For each candidate:
 *   1. Parse the slug from Public_URL__c
 *   2. Look up the WP property post by slug
 *   3. Write WP_Post_ID__c back to SF
 *
 * Safe to re-run — only touches properties where WP_Post_ID__c is currently null.
 *
 * Run: tsx --env-file .env.local scripts/backfill-wp-post-ids.ts [--dry-run]
 */

import { initSalesforce, updatePropertyField } from '../../src/salesforce';
import {
  findPropertyIdBySlug,
  extractSlugFromPublicUrl,
} from '../../src/integrations/wordpress';

interface Candidate {
  Id: string;
  Name: string;
  Public_URL__c: string;
}

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 100; // gentle on the WP API

async function querySfDirect<T>(soql: string): Promise<T[]> {
  const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
  const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
  const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

  // Get token directly (initSalesforce will also do this — we duplicate just to query)
  const authRes = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await authRes.json()) as {
    access_token: string;
    instance_url: string;
  };

  const url = `${instance_url}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${access_token}` },
  });
  if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
  const body = (await res.json()) as { records: T[] };
  return body.records;
}

async function main() {
  console.log(`\n🔄 Backfill WP_Post_ID__c${DRY_RUN ? ' (DRY RUN)' : ''}\n`);

  console.log('Initializing Salesforce client...');
  await initSalesforce();

  const soql = `
    SELECT Id, Name, Public_URL__c
    FROM Property__c
    WHERE WP_Post_ID__c = null
      AND Public_URL__c != null
    ORDER BY LastModifiedDate DESC
  `.trim();

  console.log('Querying candidates...');
  const candidates = await querySfDirect<Candidate>(soql);
  console.log(`   Found ${candidates.length} properties to backfill\n`);

  const stats = {
    matched: 0,
    no_slug: 0,
    not_in_wp: 0,
    write_failed: 0,
    skipped_non_http: 0,
  };
  const unmatched: Array<{ id: string; name: string; url: string; reason: string }> = [];

  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i];
    const url = c.Public_URL__c?.trim() || '';

    if (!url.startsWith('http')) {
      stats.skipped_non_http++;
      continue;
    }

    const slug = extractSlugFromPublicUrl(url);
    if (!slug) {
      stats.no_slug++;
      unmatched.push({ id: c.Id, name: c.Name, url, reason: 'no /property/<slug>/ in URL' });
      continue;
    }

    const wpId = await findPropertyIdBySlug(slug);
    if (!wpId) {
      stats.not_in_wp++;
      unmatched.push({ id: c.Id, name: c.Name, url, reason: `slug "${slug}" not found in WP` });
      continue;
    }

    if (DRY_RUN) {
      console.log(`[${i + 1}/${candidates.length}] ${c.Id} → wp:${wpId} (${slug})`);
    } else {
      const ok = await updatePropertyField(c.Id, { WP_Post_ID__c: wpId });
      if (ok) {
        stats.matched++;
        if ((i + 1) % 25 === 0 || i === candidates.length - 1) {
          console.log(
            `[${i + 1}/${candidates.length}] matched=${stats.matched} not_in_wp=${stats.not_in_wp} no_slug=${stats.no_slug}`
          );
        }
      } else {
        stats.write_failed++;
        unmatched.push({ id: c.Id, name: c.Name, url, reason: `SF write failed for wp:${wpId}` });
      }
    }

    // Be nice to the WP API
    await new Promise((r) => setTimeout(r, REQUEST_DELAY_MS));
  }

  console.log('\n=== Summary ===');
  console.log(`Total candidates:       ${candidates.length}`);
  console.log(`✅ Matched + written:   ${DRY_RUN ? '(skipped — dry run)' : stats.matched}`);
  console.log(`⚠️  No slug in URL:      ${stats.no_slug}`);
  console.log(`⚠️  Slug not in WP:      ${stats.not_in_wp}`);
  console.log(`⚠️  Non-HTTP URL:        ${stats.skipped_non_http}`);
  console.log(`❌ SF write failed:     ${stats.write_failed}`);

  if (unmatched.length > 0) {
    console.log(`\n=== Unmatched (first 15) ===`);
    for (const u of unmatched.slice(0, 15)) {
      console.log(`  ${u.id} | ${u.name?.slice(0, 30)?.padEnd(30)} | ${u.reason}`);
      console.log(`    ${u.url}`);
    }
    if (unmatched.length > 15) {
      console.log(`  ...and ${unmatched.length - 15} more`);
    }
  }

  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Backfill crashed:', err);
  process.exit(1);
});
