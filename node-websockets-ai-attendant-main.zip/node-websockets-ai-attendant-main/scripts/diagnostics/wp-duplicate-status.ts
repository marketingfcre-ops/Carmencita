/**
 * Read-only: report status of every WP post with "[DUPLICATE" in its title.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-duplicate-status.ts
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
}

async function fetchAll(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

async function main() {
  const all = await fetchAll();
  const dupes = all.filter((p) => p.title.includes('[DUPLICATE'));
  dupes.sort((a, b) => a.status.localeCompare(b.status) || a.date.localeCompare(b.date));

  console.log(`\n🔍 ${dupes.length} posts with [DUPLICATE in title\n`);

  const byStatus = new Map<string, number>();
  for (const p of dupes) byStatus.set(p.status, (byStatus.get(p.status) || 0) + 1);
  console.log('── By status ──');
  for (const [s, n] of byStatus.entries()) console.log(`   ${s.padEnd(10)} ${n}`);

  const stillPublished = dupes.filter((p) => p.status === 'publish');
  if (stillPublished.length > 0) {
    console.log(`\n⚠️  ${stillPublished.length} are STILL published — these need fixing:\n`);
    for (const p of stillPublished) {
      console.log(`   wp:${p.id}  ${p.date.slice(0, 10)}  "${p.title.slice(0, 80)}"`);
    }
  } else {
    console.log('\n✅ All [DUPLICATE] posts are correctly in draft status.');
  }
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
