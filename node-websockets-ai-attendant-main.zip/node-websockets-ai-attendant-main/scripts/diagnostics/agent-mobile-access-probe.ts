/**
 * Why can't "Account for Agents" users log into the Salesforce mobile app /
 * PhoneBurner / any API-based client? Read-only. Print the load-bearing facts.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-mobile-access-probe.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

const AGENT_PROFILE = 'Account for Agents';

async function safe<T>(p: Promise<T>, label: string): Promise<T | null> {
  try { return await p; } catch (e: any) {
    console.log(`  (${label} failed: ${String(e.message || e).slice(0, 100)})`);
    return null;
  }
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Profile-level flags that gate mobile / API.
  console.log('=== "Account for Agents" profile flags ===');
  const prof: any[] = (await safe(sf.soql(
    `SELECT Id, Name, UserType, PermissionsApiEnabled, UserLicenseId FROM Profile WHERE Name = '${AGENT_PROFILE}'`
  ), 'profile flags')) || [];
  for (const p of prof) {
    console.log(`  ${p.Name}  userType=${p.UserType}  apiEnabled=${p.PermissionsApiEnabled}  licenseId=${p.UserLicenseId}`);
  }
  const profileId = prof[0]?.Id;
  const userLicenseId = prof[0]?.UserLicenseId;

  // 2. Underlying user license — limits what's grantable via permission set.
  if (userLicenseId) {
    console.log('\n=== Underlying user license ===');
    const lic: any[] = (await safe(sf.toolingQuery(
      `SELECT Name, MasterLabel, Status FROM UserLicense WHERE Id = '${userLicenseId}'`
    ), 'user license')) || [];
    for (const l of lic) console.log(`  ${l.MasterLabel} (${l.Name})  status=${l.Status}`);
  }

  // 3. Profile login IP ranges — silent mobile-login blocker even if API is on.
  if (profileId) {
    console.log('\n=== Profile login IP ranges ===');
    const ips: any[] = (await safe(sf.toolingQuery(
      `SELECT StartAddress, EndAddress, Description FROM LoginIpRange WHERE ParentId = '${profileId}'`
    ), 'login IP')) || [];
    if (!ips.length) console.log('  (none — no IP restriction on the profile)');
    for (const ip of ips) console.log(`  ${ip.StartAddress} → ${ip.EndAddress}  "${ip.Description || ''}"`);

    console.log('\n=== Profile login hours ===');
    const hrs: any[] = (await safe(sf.toolingQuery(
      `SELECT MondayStart, MondayEnd, SundayStart, SundayEnd FROM ProfileLoginHours WHERE ProfileId = '${profileId}'`
    ), 'login hours')) || [];
    if (!hrs.length) console.log('  (none — 24/7 login allowed)');
    for (const h of hrs) console.log(`  Mon ${h.MondayStart}-${h.MondayEnd}  Sun ${h.SundayStart}-${h.SundayEnd}`);
  }

  // 4. Permission sets currently granting API Enabled (any candidate to assign?)
  console.log('\n=== Permission sets that grant API Enabled ===');
  const ps: any[] = (await safe(sf.soql(
    `SELECT Id, Name, Label, IsCustom FROM PermissionSet WHERE PermissionsApiEnabled = true ORDER BY IsCustom DESC, Label`
  ), 'permission sets with API')) || [];
  if (!ps.length) console.log('  (none — would have to create one and assign it)');
  for (const p of ps) console.log(`  ${p.IsCustom ? 'custom' : 'managed'}  ${p.Label}  (${p.Name})`);

  // 5. Are any of those permission sets actually assigned to agent users today?
  if (ps.length && profileId) {
    const psIds = ps.map((p) => `'${p.Id}'`).join(',');
    console.log('\n=== Agent users currently assigned an API-granting permission set ===');
    const psas: any[] = (await safe(sf.soql(
      `SELECT PermissionSet.Label, COUNT(Id) c
         FROM PermissionSetAssignment
         WHERE PermissionSetId IN (${psIds})
           AND Assignee.ProfileId = '${profileId}'
         GROUP BY PermissionSet.Label`
    ), 'PSAs')) || [];
    if (!psas.length) console.log('  (zero agents currently have an API-granting permission set)');
    for (const r of psas) console.log(`  ${String(r.c).padStart(3)}  ${r['PermissionSet']?.Label || r.Label}`);
  }

  // 6. Was API enabled recently flipped on this profile? SetupAuditTrail tells us when.
  console.log('\n=== Recent setup audit trail entries mentioning "API" or the agent profile ===');
  const audit: any[] = (await safe(sf.toolingQuery(
    `SELECT CreatedDate, CreatedBy.Name, Action, Display
       FROM SetupAuditTrail
       WHERE (Display LIKE '%API Enabled%'
              OR Display LIKE '%${AGENT_PROFILE}%'
              OR Action LIKE '%profile%')
       ORDER BY CreatedDate DESC LIMIT 40`
  ), 'audit trail')) || [];
  if (!audit.length) console.log('  (no matching audit entries — or SetupAuditTrail not queryable in this org)');
  for (const a of audit) console.log(`  ${a.CreatedDate}  ${a['CreatedBy']?.Name}  ${a.Action}  "${(a.Display || '').slice(0, 80)}"`);

  // 7. Sample of agent users — so we can hand the names to admin for permission-set assignment.
  console.log('\n=== Sample agent users (first 10 active) ===');
  if (profileId) {
    const us: any[] = (await safe(sf.soql(
      `SELECT Name, Username, IsActive, LastLoginDate FROM User WHERE ProfileId = '${profileId}' AND IsActive = true ORDER BY LastLoginDate DESC NULLS LAST LIMIT 10`
    ), 'sample users')) || [];
    for (const u of us) console.log(`  ${u.Name.padEnd(28)}  ${u.Username.padEnd(40)}  lastLogin=${u.LastLoginDate || '(never)'}`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
