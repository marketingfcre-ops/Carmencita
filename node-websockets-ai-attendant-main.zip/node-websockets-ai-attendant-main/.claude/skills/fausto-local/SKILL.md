---
name: fausto-local
description: Use to run the Fausto attendant locally for development or testing — starts the dev server, exposes it via the fixed ngrok domain, and verifies health. Use when asked to run/start Fausto locally, test a call flow, or expose the local server for Twilio.
---

# Running Fausto locally

Boots the streaming attendant locally and (optionally) exposes it for Twilio.

## Steps
1. **Start the dev server** (auto-reload, loads `.env.local`, port 3000):
   ```bash
   npm run dev
   ```
   Run it in the background so you can keep working; watch for the startup log.
2. **Verify health:**
   ```bash
   curl -sf http://localhost:3000/health
   ```
3. **Expose via ngrok** (fixed domain) only if you need Twilio/webhooks to reach
   the local server:
   ```bash
   npm run ngrok    # → https://thymy-unjarring-brande.ngrok-free.dev
   ```
   Verify: `curl -sf https://thymy-unjarring-brande.ngrok-free.dev/health`

## Pointing Twilio at local (only when explicitly asked)
Pointing Twilio webhooks at the ngrok URL is a config change to a live number —
**gate it.** When finished, restore prod webhooks:
```bash
bash scripts/twilio-restore-prod.sh
```

## Notes
- `/debug` (GET) shows current leads + listings.
- Tear down with `pkill -f "tsx watch"` when done.
- Never expose `.env.local` contents in logs or output.
