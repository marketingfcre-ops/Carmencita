/**
 * Read-only diagnostic: full state of WP property posts.
 *
 * Run:
 *   tsx --env-file .env.local scripts/diagnostics/wp-state-report.ts
 *
 * Prints:
 *   - Totals by status
 *   - Posts published in each month (publish date)
 *   - Of published posts: how many have a featured image vs none
 *   - The full list of "published in May 2026 with no photo" — the bucket we're worried about
 *   - A best-effort guess at "did this post jump from draft → publish during the bug window"
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;         // publish date (or last status change for some flows)
  date_gmt: string;
  modified: string;     // last modified
  modified_gmt: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function fetchAll(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,date_gmt,modified,modified_gmt,status,title,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          date_gmt: p.date_gmt || '',
          modified: p.modified || '',
          modified_gmt: p.modified_gmt || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function monthKey(iso: string): string {
  return iso ? iso.slice(0, 7) : 'unknown';
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP_USER or WP_APP_PASSWORD env vars.');
    process.exit(1);
  }

  console.log('\n📊 WordPress property posts — full state report\n');
  console.log(`→ Fetching from ${WP_SITE_URL}...`);
  const posts = await fetchAll();
  console.log(`   Total posts: ${posts.length}\n`);

  // ---------------------------------------------------------------------------
  // 1. Totals by status
  // ---------------------------------------------------------------------------
  const byStatus = new Map<string, number>();
  for (const p of posts) byStatus.set(p.status, (byStatus.get(p.status) || 0) + 1);
  console.log('── Totals by status ──');
  for (const [status, n] of [...byStatus.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`   ${status.padEnd(10)} ${n}`);
  }

  // ---------------------------------------------------------------------------
  // 2. Publish-date distribution by month
  // ---------------------------------------------------------------------------
  const published = posts.filter((p) => p.status === 'publish');
  const byMonth = new Map<string, number>();
  for (const p of published) {
    const m = monthKey(p.date);
    byMonth.set(m, (byMonth.get(m) || 0) + 1);
  }
  console.log('\n── Published posts by month (date field) ──');
  for (const [m, n] of [...byMonth.entries()].sort()) {
    console.log(`   ${m}   ${n}`);
  }

  // ---------------------------------------------------------------------------
  // 3. Featured image coverage of published posts
  // ---------------------------------------------------------------------------
  const pubWithPhoto = published.filter((p) => p.featured_media > 0).length;
  const pubNoPhoto = published.length - pubWithPhoto;
  console.log(
    `\n── Featured image on published posts ──\n   With photo:    ${pubWithPhoto}\n   Without photo: ${pubNoPhoto}  ← the concerning bucket`
  );

  // ---------------------------------------------------------------------------
  // 4. "Published in May 2026 with no photo" — the suspect bucket
  // ---------------------------------------------------------------------------
  const may = published.filter(
    (p) =>
      p.date.startsWith('2026-05') &&
      p.featured_media === 0 &&
      !p.title.startsWith('[DUPLICATE')
  );
  console.log(
    `\n── Published in May 2026 with NO photo (excluding [DUPLICATE] retires): ${may.length} ──`
  );
  // Sort by date asc for chronology
  may.sort((a, b) => a.date.localeCompare(b.date));
  for (const p of may) {
    const created = p.date.slice(0, 10);
    const modified = p.modified.slice(0, 10);
    const wasModifiedLater = created !== modified;
    const flag = wasModifiedLater ? ' [modified later]' : '';
    console.log(
      `   wp:${p.id}  ${created}${flag}  "${p.title.slice(0, 70)}"`
    );
  }

  // ---------------------------------------------------------------------------
  // 5. Heuristic: posts where date === modified means likely created-and-published
  //    in one shot. Date < modified means a draft was published later OR edits
  //    happened after publish. Useful to spot bulk-publish patterns.
  // ---------------------------------------------------------------------------
  console.log('\n── May 2026 published-no-photo: created same day as last modify? ──');
  const sameDay = may.filter((p) => p.date.slice(0, 10) === p.modified.slice(0, 10));
  const laterEdit = may.length - sameDay.length;
  console.log(
    `   Same-day publish+modify: ${sameDay.length}  (likely fresh-created posts)`
  );
  console.log(
    `   Modified later:          ${laterEdit}  (likely older drafts edited or published later)`
  );

  // ---------------------------------------------------------------------------
  // 6. Cross-check: do these no-photo published posts have addresses?
  //    A post WITHOUT fave_property_address is more suspicious — it suggests
  //    the post was created without proper data ever filled in.
  // ---------------------------------------------------------------------------
  console.log('\n── May no-photo posts: address presence ──');
  const noAddr = may.filter((p) => !p.fave_property_address || !p.fave_property_address.trim()).length;
  console.log(`   With address:    ${may.length - noAddr}`);
  console.log(`   Missing address: ${noAddr}  ← these are essentially empty stubs`);

  // ---------------------------------------------------------------------------
  // 7. Cross-period comparison: same "published with no photo" rate
  //    for posts from APRIL (before the bug) so we know the baseline
  // ---------------------------------------------------------------------------
  const apr = published.filter(
    (p) => p.date.startsWith('2026-04') && p.featured_media === 0 && !p.title.startsWith('[DUPLICATE')
  );
  console.log(
    `\n── Baseline: published in April 2026 with NO photo: ${apr.length} ──`
  );
  console.log('   (For comparison — if this is similar to May, no-photo posts may be a steady-state thing, not a bug-window anomaly.)');

  // ---------------------------------------------------------------------------
  // 8. Earlier-still: posts published BEFORE April that have no photo
  //    (Long-running stubs that pre-date everything we care about.)
  // ---------------------------------------------------------------------------
  const old = published.filter(
    (p) => p.date < '2026-04-01' && p.featured_media === 0 && !p.title.startsWith('[DUPLICATE')
  );
  console.log(
    `\n── Published BEFORE April 2026 with no photo: ${old.length} ──`
  );
  console.log('   (Pre-existing stubs unrelated to the May bug.)');

  // ---------------------------------------------------------------------------
  // 9. Sanity: are there published posts with photos in May too?
  //    Helps confirm the bug didn't touch *everything*.
  // ---------------------------------------------------------------------------
  const mayPubWithPhoto = published.filter(
    (p) => p.date.startsWith('2026-05') && p.featured_media > 0 && !p.title.startsWith('[DUPLICATE')
  ).length;
  console.log(
    `\n── Published in May 2026 WITH photo (sanity check): ${mayPubWithPhoto} ──`
  );

  console.log('\n────────────────────────────────────');
  console.log('Report complete. No changes made.\n');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Report crashed:', err);
  process.exit(1);
});
