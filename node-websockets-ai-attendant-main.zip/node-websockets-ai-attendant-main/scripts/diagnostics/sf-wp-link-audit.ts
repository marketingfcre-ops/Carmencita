/**
 * Critical pre-deletion audit: cross-reference every [DUPLICATE]-tagged WP post
 * with SF.WP_Post_ID__c links, so we know exactly which posts are SAFE to delete
 * and which would leave Salesforce orphaned.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/sf-wp-link-audit.ts
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  return { token: access_token, instance: instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function extractCanonicalRef(title: string): number | null {
  const decoded = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const m = decoded.match(/\[DUPLICATE[\s\S]*?see wp:(\d+)\]/i);
  return m ? parseInt(m[1], 10) : null;
}

function isDuplicateTagged(title: string): boolean {
  return /\[DUPLICATE/i.test(title);
}

async function main() {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET || !WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔐 SF ↔ WP link audit (read-only)\n');

  // Fetch SF records with their WP_Post_ID__c
  const { token, instance } = await sfAuth();
  const sfRecords = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, WP_Post_ID__c
       FROM Property__c
      WHERE WP_Post_ID__c != NULL`
  );
  console.log(`SF records with WP_Post_ID__c: ${sfRecords.length}`);

  // Fetch all WP posts
  const wpPosts = await fetchAllWpPosts();
  const wpById = new Map<number, WpPost>();
  for (const p of wpPosts) wpById.set(p.id, p);
  console.log(`WP property posts: ${wpPosts.length}\n`);

  // Build reverse map: WP_Post_ID__c → SF records (could be multiple)
  const sfByWpId = new Map<number, SfProperty[]>();
  for (const sf of sfRecords) {
    const wpId = sf.WP_Post_ID__c!;
    const arr = sfByWpId.get(wpId) || [];
    arr.push(sf);
    sfByWpId.set(wpId, arr);
  }

  // Find all [DUPLICATE]-tagged WP posts
  const taggedPosts = wpPosts.filter((p) => isDuplicateTagged(p.title));
  console.log(`[DUPLICATE]-tagged WP posts: ${taggedPosts.length}\n`);

  // Categorize each tagged post:
  //   - SAFE TO DELETE: not linked from any SF record
  //   - DANGEROUS: linked from SF — would orphan that SF record
  //   - ORPHANED CANONICAL: the wp:N it points to doesn't exist
  const safe: { post: WpPost; canonical: number | null }[] = [];
  const dangerous: { post: WpPost; canonical: number | null; sfRecords: SfProperty[] }[] = [];

  for (const post of taggedPosts) {
    const canonical = extractCanonicalRef(post.title);
    const linkedSf = sfByWpId.get(post.id) || [];
    if (linkedSf.length > 0) {
      dangerous.push({ post, canonical, sfRecords: linkedSf });
    } else {
      safe.push({ post, canonical });
    }
  }

  console.log('── Summary ──');
  console.log(`   ✅ SAFE to delete (no SF link):         ${safe.length}`);
  console.log(`   ⚠️  DANGEROUS (SF still points at it):  ${dangerous.length}`);
  console.log('');

  if (dangerous.length > 0) {
    console.log('── DANGEROUS: these need SF relinked BEFORE deletion ──\n');
    for (const d of dangerous) {
      const canonicalPost = d.canonical ? wpById.get(d.canonical) : null;
      const canonicalExists = !!canonicalPost;
      const canonicalIsTagged = canonicalPost
        ? isDuplicateTagged(canonicalPost.title)
        : false;
      console.log(`wp:${d.post.id}  status=${d.post.status}`);
      console.log(`   Title: "${d.post.title.replace(/&#8211;/g, '–').slice(0, 75)}"`);
      console.log(
        `   Points to:  wp:${d.canonical}${canonicalExists ? '' : ' ❌ DOES NOT EXIST'}${canonicalIsTagged ? ' ⚠️  also tagged [DUPLICATE]' : ''}`
      );
      if (canonicalExists) {
        console.log(
          `      → "${canonicalPost!.title.replace(/&#8211;/g, '–').slice(0, 70)}"  (status=${canonicalPost!.status})`
        );
      }
      console.log(`   Linked from SF:`);
      for (const sf of d.sfRecords) {
        console.log(`      ${sf.Id}  ${sf.Name || '(no name)'}  ${sf.Address__c || ''}`);
      }
      console.log('');
    }
  }

  // Also surface a sanity check: SF records pointing at WP IDs that don't exist
  const sfPointingAtMissing: SfProperty[] = [];
  for (const sf of sfRecords) {
    if (!wpById.has(sf.WP_Post_ID__c!)) sfPointingAtMissing.push(sf);
  }
  if (sfPointingAtMissing.length > 0) {
    console.log(`── ${sfPointingAtMissing.length} SF records point at WP IDs that don't exist ──`);
    for (const sf of sfPointingAtMissing.slice(0, 20)) {
      console.log(`   ${sf.Id}  WP_Post_ID__c=${sf.WP_Post_ID__c}  ${sf.Address__c || ''}`);
    }
    if (sfPointingAtMissing.length > 20)
      console.log(`   ... and ${sfPointingAtMissing.length - 20} more`);
    console.log('');
  }

  console.log('── Recommendation ──');
  if (dangerous.length === 0) {
    console.log(`✅ All ${taggedPosts.length} [DUPLICATE]-tagged posts are safe to delete — no SF record points at them.`);
  } else {
    console.log(
      `⚠️  ${dangerous.length} of ${taggedPosts.length} tagged posts have SF still pointing at them.\n   Do NOT delete those until SF.WP_Post_ID__c is repointed at the canonical (wp:<see wp:N> in their title).\n   The ${safe.length} SAFE posts can be deleted now.`
    );
  }
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
