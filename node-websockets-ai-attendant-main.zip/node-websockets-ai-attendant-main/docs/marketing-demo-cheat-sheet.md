# Marketing Phase-1 Demo — Cheat Sheet

Audience: **Fausto's wife (marketing director) + marketing team**
Goal: confirm the SF → WordPress sync works on production data, hand off the
flyer template integration plan, preview Phase 1.5 (Campaign Monitor email
triggers).

> Security/agent demo with Fausto + agents is a **separate meeting**.

---

## Before the meeting

```bash
# 1. Confirm Railway server is up (after PR merge + deploy)
curl -sf https://fausto-ai-attendant.up.railway.app/health && echo " prod up"

# 2. Pick a low-stakes property for the demo (no live agents marketing it)
#    Note: this fires on PROD now. Pick a Pending or Draft property.
```

## Tabs to pre-open

1. **Production SF Property list** (filter: status = "Active"):
   `https://d30000001hp0jeas.lightning.force.com/lightning/o/Property__c/list`

2. **A specific test property** (any Active one with a WP page already linked):
   pick one and load it. Note its `Public_URL__c` — that's what we'll watch refresh.

3. **The WP page for that property** (separate browser, ideally incognito for cache control)

4. **Railway logs tab** (tail of the production webhook log) — visible on screen

5. **WordPress admin → Properties** (to show drafts being created live):
   `https://faustocommercial.com/wp-admin/edit.php?post_type=property`

---

## Demo sequence (~20 min)

### Part 1 — The sync is live (10 min)

| # | Step | What to show |
|---|---|---|
| 1 | "Same data lives in two places — SF for the team, WP for the public" | Show the property list in SF, show the same property on the public site |
| 2 | "When you change SF, the website updates within seconds" | Edit the property's **Description** or **Price** in SF UI, click Save |
| 3 | Watch the Railway log fire | Within 3 seconds: `Property change handled, target: prod` |
| 4 | Refresh the public WP page (or admin) | Field updated. "No double-entry. No copy-paste." |
| 5 | Show Closed Won → Sold | Change Status to **Closed Won**, refresh WP — **Sold** badge appears, page stays browsable |
| 6 | Show Closed Lost → Off Market | Change Status to **Closed Lost**, refresh WP — **Off Market** badge appears, page still browsable (Zillow-style historical record) |
| 7 | Reset to Active | Status = Active. Back to "For Sale" badge. |

### Part 2 — Flyer track + handoff (8 min)

Open `src/integrations/flyer.ts` and walk through:

1. **The skeleton template** — Letter size, brand-styled with a placeholder layout
2. **Merge tags** the marketing template should use — pull up the printed list (next page of this doc)
3. **The endpoint** — `GET /api/flyer/:sfPropertyId` returns HTML or PDF
4. **Live preview** — render a flyer for a real property: open
   `https://fausto-ai-attendant.up.railway.app/api/flyer/<some-prop-id>?secret=<flyer-shared-secret>`
   in a browser, show the rendered HTML

Hand-off ask:
- *"Send me your Illustrator/Canva HTML export. I'll keep all the merge tags
  intact. One file replacement and we're live with your branding."*
- *"Decide: do you want the 'Generate Flyer' link as a hyperlink formula
  field on Property records (agents click it from SF), or surfaced via the
  admin dashboard? Both take an hour to wire."*

### Part 3 — What's next (Phase 1.5) (2 min)

Preview, don't commit:

- **Campaign Monitor integration** — when a Property's price drops, automatically email everyone in the relevant CM segment ("Buyers Industrial," etc.). Skeleton CM client functions are built (`src/campaign-monitor.ts` has `addOrUpdateSubscriber`, `sendSmartEmail`, `listSegments`). Need their input: which segments map to which property types, which Smart Email template to send.
- **Auto-attach the flyer** to new-listing emails (once flyer template lands).

---

## Available merge tags for the flyer

Print this and hand it to your wife — she uses these in the HTML template:

```
{{title}}              {{price}}              {{building_sqft}}
{{address}}            {{price_label}}        {{lot_sqft}}
{{full_address}}       {{property_type}}      {{units}}
{{city}}               {{listing_type}}       {{year_built}}
{{state}}              {{description}}        {{zoning}}
{{zip}}                {{pricing_notes}}      {{generated_date}}
{{brand_name}}         {{brand_phone}}        {{brand_url}}
{{brand_address}}
```

Triple-brace `{{{tag}}}` for raw HTML (use only for fields that contain
intentional markup — rare).

## What's NOT in this demo (separate meeting topics)

- **Agent security restrictions** (group-based edit rule, multi-list
  approvals, audit trail) — agent roundtable, separate meeting.
- **Production deployment of security work** — sequenced after agent
  signoff.

## If something goes wrong

| Symptom | Fix |
|---|---|
| Railway logs don't show the webhook fire | Verify the prod Flow is Active in SF (Setup → Flows). Verify Railway env has `SF_WEBHOOK_SECRET` set. |
| WP page shows old content after edit | Cache — append `?v=N` to the URL or hard-refresh in incognito |
| `target: dev` in logs (wrong org) | The production Flow is using the dev secret. Update its `secret` query param to the prod value. |
| Flyer HTML preview returns 404 | Confirm `FLYER_SHARED_SECRET` is set in Railway and the URL includes `?secret=…` |
