/**
 * Unlock Salesforce Classic for agent users.
 *
 * Cause: UserPreferencesHideS1BrowserUI = true on agent users (likely flipped
 * by Salesforce's Classic phase-out). That preference hides the "Switch to
 * Salesforce Classic" link from the user menu. Setting it false restores it.
 *
 * Scope: all active users on profiles "Account for Agents" and "Etico Agents".
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const TARGET_PROFILES = ['Account for Agents', 'Etico Agents'];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  const profileList = TARGET_PROFILES.map((p) => `'${p}'`).join(',');
  const users: any[] = await sf.soql(
    `SELECT Id, Name, Profile.Name, UserPreferencesHideS1BrowserUI
     FROM User WHERE Profile.Name IN (${profileList}) AND IsActive = true`
  );
  console.log(`Total active users on target profiles: ${users.length}`);
  const needsFix = users.filter((u) => u.UserPreferencesHideS1BrowserUI === true);
  const alreadyOk = users.filter((u) => u.UserPreferencesHideS1BrowserUI === false);
  console.log(`  Already unlocked (HideClassicSwitcher=false): ${alreadyOk.length}`);
  console.log(`  To unlock: ${needsFix.length}\n`);
  for (const u of needsFix) console.log(`  ${u.Id}  ${u.Name}  profile=${u.Profile?.Name}`);

  if (!needsFix.length) { console.log('\nNothing to do.'); return; }
  if (DRY) { console.log(`\nDry-run complete. Re-run with --apply to flip.`); return; }

  // PATCH each user via standard sObject endpoint (no composite needed — small N)
  let ok = 0, fail = 0;
  for (const u of needsFix) {
    const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/User/${u.Id}`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ UserPreferencesHideS1BrowserUI: false }),
    });
    if (res.ok || res.status === 204) { ok++; console.log(`  ✓ ${u.Name}`); }
    else { fail++; const txt = await res.text(); console.log(`  ✗ ${u.Name}: ${res.status} ${txt.slice(0, 200)}`); }
  }
  console.log(`\nUnlocked: ${ok}.  Failed: ${fail}.`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
