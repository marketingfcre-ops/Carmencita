/**
 * Investigate WHY specific WP posts got re-published when they should have
 * stayed as drafts. Pulls:
 *   1. Revision history (WP /revisions endpoint) — who/when changed the post
 *   2. Custom-endpoint return value (/fausto/v1/push/{id}) — tests the
 *      hypothesis that getProperty() returns Houzez status, not WP post status
 *   3. Standard endpoint return value (/wp/v2/properties/{id}?context=edit)
 *      — the source of truth for WP post status
 *
 * Read-only. Doesn't change anything.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-publish-cause.ts
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

// The 5 posts we want to investigate
const SUSPECT_IDS = [49004, 49005, 49006, 49007, 63204];

async function fetchJson(path: string): Promise<{ status: number; body: any }> {
  const res = await fetch(`${WP_SITE_URL}${path}`, {
    headers: { Authorization: WP_AUTH },
  });
  let body: any = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  return { status: res.status, body };
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP creds.');
    process.exit(1);
  }

  for (const id of SUSPECT_IDS) {
    console.log(`\n${'═'.repeat(70)}`);
    console.log(`wp:${id}`);
    console.log('═'.repeat(70));

    // 1. Standard WP endpoint — true post status
    console.log('\n── 1. /wp/v2/properties/' + id + '?context=edit (standard, truth) ──');
    const std = await fetchJson(`/wp-json/wp/v2/properties/${id}?context=edit&_fields=id,date,date_gmt,modified,modified_gmt,status,title,author,featured_media`);
    if (std.status === 200) {
      const p = std.body;
      console.log(`   id:               ${p.id}`);
      console.log(`   date (publish):   ${p.date}`);
      console.log(`   date_gmt:         ${p.date_gmt}`);
      console.log(`   modified:         ${p.modified}`);
      console.log(`   modified_gmt:     ${p.modified_gmt}`);
      console.log(`   status:           ${p.status}    ← WP post status`);
      console.log(`   author:           ${p.author}`);
      console.log(`   featured_media:   ${p.featured_media}`);
      console.log(`   title:            "${(p.title?.rendered || '').slice(0, 75)}"`);
    } else {
      console.log(`   ❌ ${std.status}: ${JSON.stringify(std.body).slice(0, 200)}`);
    }

    // 2. Custom endpoint — what getProperty() actually sees
    console.log('\n── 2. /fausto/v1/push/' + id + ' (custom, what handler reads) ──');
    const custom = await fetchJson(`/wp-json/fausto/v1/push/${id}`);
    if (custom.status === 200) {
      // Print full body so we can see what "status" field looks like
      console.log(JSON.stringify(custom.body, null, 2).slice(0, 1500));
    } else {
      console.log(`   ❌ ${custom.status}: ${JSON.stringify(custom.body).slice(0, 200)}`);
    }

    // 3. Revisions
    console.log('\n── 3. /wp/v2/properties/' + id + '/revisions ──');
    const revs = await fetchJson(`/wp-json/wp/v2/properties/${id}/revisions?context=edit&per_page=20&_fields=id,date,modified,author,title,status,slug`);
    if (revs.status === 200 && Array.isArray(revs.body)) {
      if (revs.body.length === 0) {
        console.log('   (no revisions found)');
      } else {
        for (const r of revs.body) {
          console.log(
            `   rev:${String(r.id).padEnd(6)}  modified:${r.modified}  status:${(r.status || '').padEnd(8)}  author:${r.author}  "${(r.title?.rendered || r.title?.raw || '').slice(0, 55)}"`
          );
        }
      }
    } else if (revs.status === 401 || revs.status === 403) {
      console.log(`   ❌ ${revs.status}: auth issue — WP user may not have permission to read revisions`);
    } else {
      console.log(`   ❌ ${revs.status}: ${JSON.stringify(revs.body).slice(0, 200)}`);
    }
  }

  console.log('\n');
  console.log('═'.repeat(70));
  console.log('Interpretation guide:');
  console.log('═'.repeat(70));
  console.log(`
  - If section 2's "status" field is "publish" or "draft" → getProperty()
    returns WP status correctly → the bug is something else.
  - If section 2's "status" field is "Active" / "For Sale" / "Off Market"
    or missing → getProperty() returns Houzez status, not WP status.
    The handler's draft-check will never fire → every webhook publishes.
    This is the bug.
  - In section 3, look at the "author" of the most recent revision and the
    "modified" timestamp. If author = the WP user our integration uses
    (admin-em) and the timestamp matches when we were running migrations,
    that's smoking gun proof the sync handler did it.
  - If no revisions are returned at all, the custom post type may not have
    revisions enabled — we can still infer from date/modified deltas.
  `);
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
