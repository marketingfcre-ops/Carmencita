/**
 * Grandfather User_Group_Access__c — for every (Owner, Group) pair that
 * currently appears in active Lead data, ensure an Approved
 * User_Group_Access__c row exists. Closes the access gap before the
 * Lead_Group_Access_Check validation Flow gets re-activated.
 *
 * SAFETY:
 *   - Pure inserts. Touches no existing User_Group_Access rows.
 *   - Skips (User, Group) pairs that already have a row (any status).
 *   - Per-batch allOrNone=false so a bad row doesn't fail the batch.
 *   - Before commit, writes an audit log to data/archive/
 *     grandfather-access-<ts>.json with the timestamp + every pair planned.
 *   - Rollback via rollback-grandfather-access.ts (uses the same timestamp).
 *
 * Idempotent. Dry-run by default.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/grandfather-user-group-access.ts
 *   tsx --env-file .env.local scripts/migrations/grandfather-user-group-access.ts --commit
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const TARGET: SfTarget = 'prod';
const COMMIT = process.argv.includes('--commit');
const BATCH = 200;
const API = '59.0';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const ARCHIVE_DIR = path.join(REPO_ROOT, 'data', 'archive');

async function main() {
  console.log(`\n🛡️  Grandfather User_Group_Access__c for current Lead owners`);
  console.log(`   target: ${TARGET}`);
  console.log(`   mode:   ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Pull every active (non-converted) Lead with OwnerId + Group__c
  console.log('Pulling active leads with OwnerId + Group__c...');
  const leads: any[] = await sf.soql(
    `SELECT OwnerId, Group__c FROM Lead WHERE Group__c != null AND IsConverted = false`
  );
  console.log(`  ${leads.length} active leads with Group__c set`);

  // Filter to user-owned only (skip Queues — OwnerId starts with '00G' for queues, '005' for users)
  const userOwned = leads.filter((l) => l.OwnerId?.startsWith('005'));
  console.log(`  ${userOwned.length} user-owned (skipping ${leads.length - userOwned.length} queue-owned)`);

  // 2. Compute distinct (User, Group) pairs needed
  const neededPairs = new Set<string>();
  for (const l of userOwned) neededPairs.add(`${l.OwnerId}|${l.Group__c}`);
  console.log(`\n  ${neededPairs.size} distinct (User, Group) pairs needed total`);

  // 3. Pull existing User_Group_Access pairs (any status)
  console.log('\nPulling existing User_Group_Access__c pairs...');
  const existing: any[] = await sf.soql(`SELECT User__c, Group__c, Status__c FROM User_Group_Access__c`);
  const existingKeys = new Set<string>();
  for (const e of existing) existingKeys.add(`${e.User__c}|${e.Group__c}`);
  console.log(`  ${existing.length} existing rows, ${existingKeys.size} distinct (User, Group) pairs`);

  // 4. Compute the gap — pairs we need to create
  const toCreate: Array<{ user: string; group: string }> = [];
  for (const key of neededPairs) {
    if (!existingKeys.has(key)) {
      const [user, group] = key.split('|');
      toCreate.push({ user, group });
    }
  }
  console.log(`\n  ${toCreate.length} new User_Group_Access__c rows to create`);

  // 5. Pull user names + group names for the audit log
  const userIds = [...new Set(toCreate.map((p) => p.user))];
  const groupIds = [...new Set(toCreate.map((p) => p.group))];
  console.log(`  ${userIds.length} distinct users, ${groupIds.length} distinct groups\n`);

  const userNames = new Map<string, string>();
  for (let i = 0; i < userIds.length; i += 800) {
    const chunk = userIds.slice(i, i + 800).map((id) => `'${id}'`).join(',');
    const us: any[] = await sf.soql(`SELECT Id, Name FROM User WHERE Id IN (${chunk})`);
    for (const u of us) userNames.set(u.Id, u.Name);
  }
  const groupNames = new Map<string, string>();
  for (let i = 0; i < groupIds.length; i += 800) {
    const chunk = groupIds.slice(i, i + 800).map((id) => `'${id}'`).join(',');
    const gs: any[] = await sf.soql(`SELECT Id, Name FROM Group__c WHERE Id IN (${chunk})`);
    for (const g of gs) groupNames.set(g.Id, g.Name);
  }

  // 6. Summary by user
  const byUser = new Map<string, number>();
  for (const p of toCreate) byUser.set(p.user, (byUser.get(p.user) || 0) + 1);
  const sortedByUser = [...byUser.entries()].sort((a, b) => b[1] - a[1]);
  console.log(`=== Top 15 users by new-access rows ===`);
  for (const [uid, n] of sortedByUser.slice(0, 15)) {
    console.log(`  ${userNames.get(uid) || uid}  →  ${n} new group accesses`);
  }

  // 7. Audit log + dry-run exit
  const timestamp = new Date().toISOString();
  const auditLog = {
    timestamp,
    mode: COMMIT ? 'COMMIT' : 'DRY-RUN',
    target: TARGET,
    leadsScanned: leads.length,
    userOwnedScanned: userOwned.length,
    distinctPairsNeeded: neededPairs.size,
    existingPairs: existingKeys.size,
    toCreate: toCreate.length,
    distinctUsers: userIds.length,
    distinctGroups: groupIds.length,
    rollbackHint: COMMIT
      ? `DELETE FROM User_Group_Access__c WHERE CreatedDate >= '${timestamp}' AND CreatedById = <integration user>`
      : null,
    pairs: toCreate.map((p) => ({
      user: userNames.get(p.user) || p.user,
      userId: p.user,
      group: groupNames.get(p.group) || p.group,
      groupId: p.group,
    })),
  };

  if (!fs.existsSync(ARCHIVE_DIR)) fs.mkdirSync(ARCHIVE_DIR, { recursive: true });
  const tsSlug = timestamp.replace(/[:.]/g, '-').slice(0, 19);
  const logPath = path.join(ARCHIVE_DIR, `grandfather-access-${tsSlug}.json`);
  fs.writeFileSync(logPath, JSON.stringify(auditLog, null, 2));
  console.log(`\n📄 Audit log: ${path.relative(REPO_ROOT, logPath)}`);

  if (!COMMIT) {
    console.log(`\n🧪 Dry-run only. Re-run with --commit when ready.`);
    console.log(`   Rollback command after commit:`);
    console.log(`     tsx --env-file .env.local scripts/migrations/rollback-grandfather-access.ts ${tsSlug}`);
    return;
  }

  // ───── COMMIT ─────
  console.log(`\nPhase 2: insert ${toCreate.length} User_Group_Access__c rows in batches of ${BATCH}`);
  console.log(`         ⚠️  AFTER THIS, ROLLBACK COMMAND IS:`);
  console.log(`         tsx --env-file .env.local scripts/migrations/rollback-grandfather-access.ts ${tsSlug}\n`);

  let created = 0, failed = 0;
  for (let off = 0; off < toCreate.length; off += BATCH) {
    const chunk = toCreate.slice(off, off + BATCH);
    const records = chunk.map((p) => ({
      attributes: { type: 'User_Group_Access__c' },
      User__c: p.user,
      Group__c: p.group,
      Status__c: 'Approved',
    }));
    const url = `${sf.instanceUrl}/services/data/v${API}/composite/sobjects`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ allOrNone: false, records }),
    });
    if (!res.ok) {
      console.error(`  batch ${off}: ${res.status} ${await res.text()}`);
      failed += chunk.length;
      continue;
    }
    const results: any[] = await res.json();
    for (const r of results) {
      if (r.success) created++;
      else failed++;
    }
    console.log(`  [${Math.min(off + BATCH, toCreate.length)}/${toCreate.length}] created=${created} failed=${failed}`);
  }

  console.log(`\n✅ Done. Created ${created} grandfather rows. ${failed} failed.`);
  console.log(`   Rollback command: tsx --env-file .env.local scripts/migrations/rollback-grandfather-access.ts ${tsSlug}`);
}

main().catch((e) => { console.error('💀 Crashed:', e); process.exit(1); });
