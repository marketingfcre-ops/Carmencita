/**
 * Email delivery — orchestrates "email this listing + flyer to a lead".
 *
 * Pulls the property + its flyer PDF from Salesforce, composes a branded HTML
 * email, and sends via Resend. This is what the assistant calls when a caller
 * asks to be emailed a flyer/listing (mirrors the SMS path).
 *
 * Product rule (graceful degrade): if there's no confident flyer AND no public
 * listing URL, there's nothing to send — return notSent so the assistant offers
 * a call-back instead.
 *
 * Wiring (NOT done yet — add when ready):
 *   server.ts →  import { registerEmailRoutes } from './handlers/email';
 *                await registerEmailRoutes(app);
 *   claude.ts →  add a `send_email` tool that calls emailListingToLead(...).
 */

import type { FastifyInstance } from 'fastify';
import { sendEmail, isEmailConfigured, type SendEmailResult } from '../integrations/resend';
import { getFlyerForProperty, type FlyerFile } from '../integrations/sf-files';
import { fetchPropertyForSync } from '../salesforce';
import { isShareableListingUrl } from '../listings';

const ADMIN_KEY = process.env.ADMIN_KEY || 'fausto2026';

export interface EmailListingResult extends SendEmailResult {
  hadFlyer: boolean;
  hadUrl: boolean;
  notSent?: boolean;
}

export interface EmailListingsResult extends SendEmailResult {
  notSent?: boolean;
  listings: { propertyId: string; name: string; hadFlyer: boolean; hadUrl: boolean }[];
}

interface ResolvedListing {
  propertyId: string;
  name: string;
  address: string;
  url: string | null;
  flyer: FlyerFile | null;
  agentEmail: string | null;
}

async function resolveListingForEmail(sfPropertyId: string): Promise<ResolvedListing | null> {
  const property = await fetchPropertyForSync(sfPropertyId);
  if (!property) return null;
  const flyer = await getFlyerForProperty(sfPropertyId).catch(() => null);
  const url = isShareableListingUrl(property.publicUrl) ? property.publicUrl! : null;
  const address = [property.address, property.city, property.state, property.zipCode].filter(Boolean).join(', ');
  return {
    propertyId: sfPropertyId,
    name: property.marketingName || property.name || 'Property',
    address,
    url,
    flyer,
    agentEmail: property.listingAgentEmail || null,
  };
}

/**
 * Email one or more listings to a lead in a SINGLE message — every flyer PDF
 * attached, every public link listed. Skips properties with neither a flyer nor
 * a public URL. Reply-to is the listing agent when they all share one.
 */
export async function emailListingsToLead(propertyIds: string[], to: string): Promise<EmailListingsResult> {
  const ids = [...new Set(propertyIds)].filter(Boolean);
  const resolved = (await Promise.all(ids.map(resolveListingForEmail))).filter(Boolean) as ResolvedListing[];
  const usable = resolved.filter((r) => r.flyer || r.url);
  if (usable.length === 0) {
    return { ok: false, notSent: true, error: 'no flyer and no public URL for any property', listings: [] };
  }

  const attachments = usable
    .filter((r) => r.flyer)
    .map((r) => ({ filename: r.flyer!.filename, content: r.flyer!.content, contentType: r.flyer!.contentType }));
  const agentEmails = [...new Set(usable.map((r) => r.agentEmail).filter(Boolean))] as string[];
  const subject =
    usable.length === 1 ? `Fausto Commercial — ${usable[0].name}` : `Fausto Commercial — ${usable.length} properties`;

  const result = await sendEmail({
    to,
    subject,
    html: buildListingsEmailHtml(usable),
    replyTo: agentEmails.length === 1 ? agentEmails[0] : undefined,
    attachments: attachments.length ? attachments : undefined,
  });

  return {
    ...result,
    listings: usable.map((r) => ({ propertyId: r.propertyId, name: r.name, hadFlyer: !!r.flyer, hadUrl: !!r.url })),
  };
}

/** Single-listing convenience wrapper (used by the verbal send_email path). */
export async function emailListingToLead(
  sfPropertyId: string,
  to: string,
  _recipientName?: string
): Promise<EmailListingResult> {
  const r = await emailListingsToLead([sfPropertyId], to);
  const first = r.listings[0];
  return {
    ok: r.ok,
    status: r.status,
    messageId: r.messageId,
    error: r.error,
    skipped: r.skipped,
    notSent: r.notSent,
    hadFlyer: first?.hadFlyer ?? false,
    hadUrl: first?.hadUrl ?? false,
  };
}

function buildListingsEmailHtml(listings: ResolvedListing[]): string {
  const multiple = listings.length > 1;
  const intro = multiple
    ? `Thanks for your interest — here are the ${listings.length} properties we discussed:`
    : `Thanks for your interest in <strong>${esc(listings[0].name)}</strong>.`;

  let bodyBlock: string;
  if (multiple) {
    const items = listings
      .map((l) => {
        const addr = l.address ? `<br><span style="color:#64748b;">${esc(l.address)}</span>` : '';
        const link = l.url ? `<br>View online: <a href="${esc(l.url)}">${esc(l.url)}</a>` : '';
        const flyer = l.flyer ? `<br>Flyer attached (PDF).` : '';
        return `<li style="margin-bottom:12px;"><strong>${esc(l.name)}</strong>${addr}${link}${flyer}</li>`;
      })
      .join('');
    bodyBlock = `<ul style="padding-left:18px;">${items}</ul>`;
  } else {
    const l = listings[0];
    const addr = l.address ? `<p style="color:#64748b;">${esc(l.address)}</p>` : '';
    const link = l.url ? `<p>View the listing online: <a href="${esc(l.url)}">${esc(l.url)}</a></p>` : '';
    const flyer = l.flyer ? `<p>The full property flyer is attached as a PDF.</p>` : '';
    bodyBlock = `${addr}${link}${flyer}`;
  }

  return `<!DOCTYPE html><html><body style="font-family:Arial,Helvetica,sans-serif;color:#1a2332;max-width:560px;margin:0 auto;">
  <div style="border-bottom:3px solid #c9a961;padding-bottom:10px;margin-bottom:16px;">
    <span style="font-family:Georgia,serif;font-size:20px;font-weight:bold;">FAUSTO COMMERCIAL</span>
  </div>
  <p>${intro}</p>
  ${bodyBlock}
  <p>Reply to this email or call <a href="tel:+13054312258">(305) 431-2258</a> and one of our agents will help.</p>
  <p style="color:#64748b;font-size:12px;margin-top:24px;">Fausto Commercial · 1761 W Flagler St, Miami, FL 33135 · FaustoCommercial.com</p>
  </body></html>`;
}

function esc(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Test route: POST /email/test?key=ADMIN_KEY  body { to, propertyId }
 * Lets you verify Resend + flyer fetch end-to-end before wiring the assistant.
 */
export async function registerEmailRoutes(app: FastifyInstance): Promise<void> {
  app.post('/email/test', async (request, reply) => {
    const query = request.query as Record<string, string>;
    if (query.key !== ADMIN_KEY) return reply.code(401).send({ error: 'unauthorized' });
    if (!isEmailConfigured()) return reply.code(503).send({ error: 'Resend not configured' });

    const body = (request.body || {}) as { to?: string; propertyId?: string; name?: string };
    if (!body.to || !body.propertyId) return reply.code(400).send({ error: 'need { to, propertyId }' });

    const result = await emailListingToLead(body.propertyId, body.to, body.name);
    return reply.code(result.ok ? 200 : 502).send(result);
  });
}
