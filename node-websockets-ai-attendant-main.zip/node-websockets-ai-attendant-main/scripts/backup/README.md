# Salesforce backup

Our own SOQL-based export → gzip → S3-compatible storage (Cloudflare R2 or
Backblaze B2), with script-managed retention. We don't use PE's native scheduled
Data Export: it's capped at monthly and the ZIPs aren't cleanly API-fetchable.

| File | What |
|---|---|
| `sf-backup.ts` | The backup job: describe → query every object → gzip → upload → prune |
| `sf-restore.ts` | Download + decompress a backup (restore drill / recovery) |
| `sf-export.ts` | Original local-only spike (no upload) — kept for ad-hoc dumps |
| `../../.github/workflows/sf-backup.yml` | Weekly + monthly schedules |

Measured volume: ~462K records, ~691 MB raw JSON, ~100–130 MB gzipped per backup.
Retention (30 daily + 12 monthly) hard-caps total storage at ~2 GB — well within
R2's 10 GB free tier.

## One-time setup

### 1. Create the bucket (Cloudflare R2 recommended)

1. Cloudflare dashboard → **R2** → **Create bucket** → e.g. `fausto-sf-backups`.
2. R2 → **Manage API Tokens** → **Create API token** → *Object Read & Write* →
   copy the **Access Key ID**, **Secret Access Key**, and your **endpoint**
   (`https://<account-id>.r2.cloudflarestorage.com`).

Backblaze B2 works identically — create a bucket + application key, use the B2 S3
endpoint and region. No code changes.

### 2. Provide the credentials

**GitHub Actions** (where the scheduled backup runs) — repo → Settings → Secrets
and variables → Actions → add:

```
SF_LOGIN_URL, SF_CLIENT_ID, SF_CLIENT_SECRET          # Salesforce read
BACKUP_S3_ENDPOINT, BACKUP_S3_REGION, BACKUP_S3_BUCKET
BACKUP_S3_ACCESS_KEY_ID, BACKUP_S3_SECRET_ACCESS_KEY
```

For R2: `BACKUP_S3_REGION=auto`. For B2: the bucket's region (e.g. `us-west-004`).

**Local testing** — put the same `BACKUP_S3_*` in `.env.local`.

## Running

```bash
# measure only — read-only, no creds, confirms the export works
npx tsx --env-file .env.local scripts/backup/sf-backup.ts --dry-run

# real backup
npx tsx --env-file .env.local scripts/backup/sf-backup.ts --tier daily
npx tsx --env-file .env.local scripts/backup/sf-backup.ts --tier monthly

# one object only (debugging)
npx tsx --env-file .env.local scripts/backup/sf-backup.ts --dry-run --only Lead
```

The GitHub Action runs daily (08:00 UTC) and monthly (1st 09:00 UTC), and
can be triggered manually via **Run workflow**.

## Restore drill — do this once, then quarterly

A backup nobody has restored is theoretical. After the first successful upload:

```bash
npx tsx --env-file .env.local scripts/backup/sf-restore.ts --list
npx tsx --env-file .env.local scripts/backup/sf-restore.ts --get daily/<stamp>
```

This downloads + ungzips every object's JSON into `./restore/<stamp>/`. Spot-check
a few files (record counts vs. the manifest, a known record's fields). Re-import
into Salesforce is intentionally **manual** (jsforce / Data Loader / a targeted
script) — a blind bulk re-insert creates duplicates and is never the right move in
a real incident.

## Scope & notes

- **Salesforce only.** WordPress is covered by Cloudways; Campaign Monitor TBD.
- **No file/attachment bytes** (flyer PDFs) — `ContentVersion` metadata is included
  but not the binaries. Add separately if wanted.
- Objects are selected by global-describe: all queryable `__c` custom objects plus
  the core standard objects in `STANDARD_KEEP`. `__Share/__History/__Feed/...` and
  `address/location/base64` fields are skipped.
- `manifest.json` is uploaded **last**, so its presence marks a complete backup.
- Big objects (Lead ~104K, Task ~254K) currently go through the REST query path
  (paginated). If runtime becomes a problem, switch those two to Bulk API v2.
