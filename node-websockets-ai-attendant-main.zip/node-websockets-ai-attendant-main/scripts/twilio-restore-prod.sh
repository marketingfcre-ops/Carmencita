#!/bin/bash
# Restore Twilio (786) 673-9218 webhooks back to production Railway URLs.
# Run this when you're done testing on ngrok.
# Loads creds from the repo's .env.local (resolved relative to this script).
set -e
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="$REPO_ROOT/.env.local"
[ ! -f "$ENV_FILE" ] && { echo "❌ Could not find $ENV_FILE"; exit 1; }
set -a; source "$ENV_FILE"; set +a
[ -z "$TWILIO_ACCOUNT_SID" ] && { echo "❌ TWILIO_ACCOUNT_SID missing from $ENV_FILE"; exit 1; }

PN_SID="PN3192251cfd58348ede2c4edac657b772"
PROD="https://node-websockets-ai-attendant-production.up.railway.app"

curl -s -u "$TWILIO_ACCOUNT_SID:$TWILIO_AUTH_TOKEN" \
  -X POST "https://api.twilio.com/2010-04-01/Accounts/$TWILIO_ACCOUNT_SID/IncomingPhoneNumbers/$PN_SID.json" \
  --data-urlencode "VoiceUrl=$PROD/voice/answer" \
  --data-urlencode "VoiceMethod=POST" \
  --data-urlencode "StatusCallback=$PROD/voice/status" \
  --data-urlencode "StatusCallbackMethod=POST" \
  --data-urlencode "SmsUrl=$PROD/sms/incoming" \
  --data-urlencode "SmsMethod=POST" > /dev/null
echo "✅ Twilio +1 786 673 9218 restored to prod ($PROD)"
