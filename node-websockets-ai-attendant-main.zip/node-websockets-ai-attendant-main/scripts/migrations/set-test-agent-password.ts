import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  const id = '005Jw00001mIHELIA4';
  const password = 'ClassicTest2026!';
  const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/User/${id}/password`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ NewPassword: password }),
  });
  console.log(`POST ${url} → ${res.status}`);
  console.log(await res.text() || '(empty)');
  if (res.ok || res.status === 204) {
    console.log(`\n✓ Password set.`);
    console.log(`  Username: classic.test.agent@faustocommercial.com.test`);
    console.log(`  Password: ${password}`);
    console.log(`  Login URL: ${sf.instanceUrl}/`);
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
