# 02 — Listing Search & Geographic Intelligence

*This is the "brain" that turns a caller's loose, spoken request — "got any
warehouses near the Palmetto in Hialeah, around five acres?" — into a short,
ranked list of real Fausto Commercial listings, in well under a second, with no
database query and no internet round-trip.*

This subsystem is the part of Carmencita that feels genuinely smart about Miami
real estate. It is three files working together:

| File | Role |
|---|---|
| `src/geography.ts` | A hand-built spatial knowledge base of South Florida — neighborhoods, boundaries, distances, the Miami grid, highway nicknames. |
| `src/search.ts` | A typo-tolerant, multi-strategy scored search engine that ranks listings against a caller's words. |
| `src/listings.ts` | The listing data model, the filter/sort/broaden logic, and the formatting that the AI reads back over the phone. |

---

## 1. Purpose — why this is "smart"

A person calling a brokerage does not talk like a database. They say "the
Gables," not "Coral Gables, FL 33134." They say "five acres," not "217,800
square feet." They mispronounce "Allapattah" three different ways. They ask for
something "near 215th" without naming a city at all. They say "off the Dolphin"
instead of "near State Road 836."

A naive search ("does the address field contain the caller's words?") fails
every one of those. This subsystem was built specifically so that **the messy,
human, Spanish-inflected, error-prone way real Miami callers describe property
still lands on the right listing.** It does this with four layers of
intelligence:

1. **Unit understanding** — acres and square feet are treated as the same thing.
2. **Geographic awareness** — it knows where Miami neighborhoods are, what they're
   called, and what's next to them.
3. **Fuzzy, typo-tolerant matching** — it tolerates misspellings, abbreviations,
   speech-to-text errors, and partial words.
4. **Graceful broadening** — if nothing matches the exact ask, it intelligently
   loosens the search rather than saying "nothing found."

Crucially, all of this runs **in-process, in memory, with zero network latency**
— essential on a live phone call where every 100 ms is audible.

---

## 2. Intelligence features, concretely

### 2.1 Square-feet ↔ acres normalization

Callers mix units constantly: land is quoted in acres, buildings in square feet,
and a single caller will switch between them mid-sentence. The system makes the
two units interchangeable at three points so neither the caller nor the AI ever
has to do the math:

- **At data load**, every listing gets *both* units computed from one source.
  Salesforce only stores lot size in square feet; the loader derives acres:
  `lotAcres = lotSqftRaw / 43_560` (`src/salesforce.ts:246-248`). So a 217,800
  sqft lot automatically carries `lotAcres = 5.0`. The `Property` model
  (`src/listings.ts:35-36`) holds both `lotSqft` and `lotAcres`.
- **At query time**, when a caller says "five acres," the AI converts to the
  canonical unit (square feet) before searching. This instruction lives in the
  Claude tool definition: *"When the caller says 'acres' (e.g. '5 acre site'),
  convert to sqft: 1 acre = 43,560 sqft. Pass as minLotSqft. So '5 acres' →
  minLotSqft: 217800"* (`src/claude.ts:210`, repeated in the tool parameter
  descriptions at `src/claude.ts:322,326`). The filter itself
  (`applyStructuredFilters`, `src/listings.ts:165-170`) only ever compares
  square feet, so there is a single source of truth.
- **At read-back**, results are formatted with *both* units so the AI can answer
  in whichever the caller used: `"5.00 acres / 217,800 lot sqft"`
  (`src/listings.ts:449-452`).

> **Example.** Caller: "Looking for about a 5-acre development site in Doral."
> The AI passes `minLotSqft: 217800`, the engine filters in square feet, and the
> match is read back as "a 5.2-acre site" — the caller never knows a conversion
> happened.

### 2.2 Geographic awareness — the South Florida knowledge base

`src/geography.ts` is a curated, hand-authored map of **19 key areas**
(`AREAS`, `src/geography.ts:51-352`) spanning Miami-Dade, Broward, and into Palm
Beach. Each area entry carries:

- **Aliases** — the nicknames callers actually use. "the Gables," "coral cable,"
  "coral cables" all resolve to `coral gables` (`src/geography.ts:151`). "SoBe,"
  "the beach," "MB" all resolve to `miami beach` (`src/geography.ts:295`).
- **Real boundaries** — north/south/east/west edges as actual streets, e.g.
  Coral Gables is bounded by "SW 22nd St / Coral Way" on the north and "Red Rd /
  SW 57th Ave" on the west (`src/geography.ts:153`).
- **Directional proximity with distances** — for each area, what's north/south/
  east/west and *how far*. Downtown's neighbors include
  `{ name: 'coconut grove', miles: 3 }` to the south and
  `{ name: 'little havana', miles: 1 }` to the west
  (`src/geography.ts:58-63`).
- **Grid bounds** — the range of street and avenue numbers the area covers (see
  2.4 below).

Two functions turn this into intelligence the rest of the system consumes:

- `getNearbyAreas(areaName)` (`src/geography.ts:498-509`) — a flat list of all
  neighbors, used to *expand* a search (a request "in Wynwood" can also surface
  listings in Edgewater and Allapattah next door).
- `getProximityContext(areaName)` (`src/geography.ts:514-529`) and
  `getGeographyContext(query)` (`src/geography.ts:556-593`) — human-readable
  geography fed to Claude so it can *talk* like a local: "Wynwood is the arts
  district north of downtown; nearby you've also got Edgewater, Little Haiti,
  and Allapattah."

### 2.3 The Miami-Dade grid system — turning a number into a neighborhood

The single cleverest piece. Miami-Dade is laid out as a numbered 2-D grid:
**Streets run the N-S axis, Avenues run the E-W axis**, both numbered outward
from the zero-zero origin at **Flagler St × Miami Ave** downtown. A local hears
"215th" and instantly knows you mean deep south Miami-Dade. The system encodes
that intuition.

- **`parseAddressGrid(address)`** (`src/geography.ts:408-463`) reads a raw
  address and extracts grid coordinates. It detects the quadrant (NW/NE/SW/SE),
  figures out whether the road is a street or an avenue, pulls the road number,
  and — cleverly — **derives the cross-street from the building number**: in
  `12101 NW 98th Ave`, the leading `12101` implies the ~121st block, so
  `streetNum ≈ 121` while `aveNum = 98` (`src/geography.ts:433-434`). It special-
  cases the two zero lines: anything on Flagler is `streetNum = 0`, anything on
  Miami Ave is `aveNum = 0` (`src/geography.ts:450-460`).
- **`locateAddress(streetNum, aveNum, quadrant)`** (`src/geography.ts:472-493`)
  does the reverse: given grid coordinates, it returns every neighborhood whose
  `gridBounds` contain that point. Street 215 with no avenue or quadrant resolves
  to Cutler Bay / Homestead, because those are the only areas whose street range
  spans 215 (`src/geography.ts:272,288`).

> **Example.** Caller: "Anything around 125th Street?" `getGeographyContext`
> parses `125`, calls `locateAddress(125, null, null)`, and reports "Street 125
> is in the north miami area" (`src/geography.ts:560-570`) — even though the
> caller never said "North Miami." The AI can now situate the caller correctly.

### 2.4 Highway and road nicknames

Miami drivers refer to highways by name, number, or local slang. `HIGHWAY_ALIASES`
(`src/geography.ts:358-375`) maps all of them together: `826` ⇄ "palmetto" ⇄
"palmetto expressway"; `836` ⇄ "dolphin"; `US-1` ⇄ "dixie" ⇄ "south dixie
highway" ⇄ even "route 1." Note the deliberate inclusion of speech-to-text
mishears like `'just one', 'just 1'` for US-1 (`src/geography.ts:359`) — a real
artifact of phone audio transcription. `expandHighwayAliases(token)`
(`src/geography.ts:548-551`) is what the search engine calls to widen "dolphin"
into "836" so a listing tagged either way still matches.

### 2.5 Fuzzy, typo-tolerant matching and ranking

The engine in `src/search.ts` is a **multi-strategy scored search**, not a
database `LIKE`. The pipeline:

**Bidirectional abbreviation normalization** (`normalizeText`,
`src/search.ts:86-113`). Every field — and every query — is expanded so
abbreviations and full forms both exist in the text. `"S DIXIE HWY"` becomes
`"s south dixie hwy highway"`; `"Dixie Highway"` becomes `"dixie highway hwy"`.
This means "SW" in a query matches "Southwest" in the data and vice-versa,
forever, without case-by-case handling. The abbreviation tables cover directions
(`DIRECTION_ABBREVS`, `src/search.ts:46-49`) and street types
(`STREET_ABBREVS`, `src/search.ts:51-56`), and reverse maps are auto-derived
(`src/search.ts:58-66`).

**Pre-computed weighted index** (`buildSearchIndex`, `src/search.ts:124-140`).
At startup and on every Salesforce refresh, each listing is pre-normalized into
weighted fields so live queries are pure in-memory scoring. Field weights encode
what matters most: **address 3.0 > neighborhood 2.5 > city 2.0 > name/
description/propertyType 1.5 > listingType/tags 1.0 > zoning 0.5**
(`src/search.ts:127-137`).

**Three scoring strategies per token**, best score wins
(`scoreTokenField`, `src/search.ts:203-210`):

1. `wordMatchScore` (`src/search.ts:150-157`) — exact whole-word match, score
   **85**. Highest quality.
2. `substringScore` (`src/search.ts:163-169`) — token appears inside a word,
   score **60-70**, *position-aware* (earlier in the field scores higher).
3. `sequenceScore` (`src/search.ts:175-194`) — the typo-tolerant one. The
   token's characters appear *in order* within the field, even with gaps, scored
   **0-40** by how tightly packed they are (`coverage = len / (gaps + len)`).
   This is what lets "allapata" still find "Allapattah."

**Noise-word stripping** (`NOISE_WORDS`, `src/search.ts:69-75`) removes filler in
both English and Spanish — "looking," "want," "near," plus "el," "la," "los,"
"de," "por" — so Spanish-English code-switching ("quiero algo en Doral") doesn't
dilute the score.

**Coverage bonus** (`src/search.ts:402-405`) — listings matching a higher
fraction of the query's tokens get up to a **1.5×** multiplier, so a result that
hits 4 of 4 words ranks above one that hits 1 of 4.

### 2.6 Query expansion and use-type intelligence

`expandQuery` (`src/search.ts:224-265`) does more than tokenize:

- **Grid-number expansion**: "215th" expands to also include `215` and `21500`
  (`src/search.ts:231-242`), so a spoken street number matches both a street name
  and a building number in the data.
- **Building-number → street inference**: `21500` collapses back to `215`
  (`src/search.ts:245-252`) — the inverse, so an address number in the data
  matches a spoken street number.
- **Highway alias injection** via `expandHighwayAliases` (`src/search.ts:254-261`).

`getGeographyBonusTokens` (`src/search.ts:272-299`) injects **soft** geographic
hints: a spoken street number is run through `locateAddress` to add the implied
area names, and a named area adds its neighbors. These are applied at only
**0.3× weight** against city/neighborhood fields (`src/search.ts:389-399`) so
proximity nudges ranking without overpowering a direct address hit.

`USE_TYPE_ALIASES` (`src/search.ts:308-324`) handles the case where a caller's
*use* ("hotel," "gas station," "auto body," "self storage") isn't in the
structured `propertyType` field but is mentioned in the free-text description or
tags. When one appears in the query, matches in description/tags/propertyType get
a **2.0× boost** (`src/search.ts:372-387`) so the right use-type surfaces.

---

## 3. From spoken words to a matched listing — the flow

```
Caller speaks
   │  "any warehouses near the Palmetto in Hialeah, about 5 acres for sale?"
   ▼
Deepgram STT → Claude (src/claude.ts)
   │  Claude maps the sentence to a search_properties tool call:
   │    { keyword: "warehouse Palmetto Hialeah", propertyType: "Industrial",
   │      listingType: "For Sale", minLotSqft: 217800 }   ← acres→sqft here
   ▼
searchPropertiesWithMeta(filters)            (src/listings.ts:230-286)
   │  1. Default listingType if it's a sale-only type   (src/listings.ts:235-238)
   │  2. runSearchOnce:                                 (src/listings.ts:198-228)
   │       a. applyStructuredFilters — city/type/price/sqft  (:131-172)
   │       b. fuzzySearchProperties(keyword) — fuzzy scoring  (search.ts:339)
   │            • expandQuery + geoBonus + useType aliases
   │            • score every indexed listing, 3 strategies × weighted fields
   │            • coverage bonus, sort desc, take top N
   │       c. intersect fuzzy results with structured filter set  (:218-223)
   │       d. applySort (relevance / price / price-per-door)      (:174-196)
   │  3. If empty → progressive broadening (see §4)    (src/listings.ts:247-283)
   ▼
formatResultsForClaude(results)              (src/listings.ts:416-467)
   │  address abbreviations expanded for TTS, both units shown, price humanized
   ▼
Claude reads the top matches back to the caller over the phone
```

---

## 4. Non-obvious, clever engineering — call-outs

- **Progressive broadening / "never say nothing"** (`searchPropertiesWithMeta`,
  `src/listings.ts:247-283`). If the exact filters return zero, the engine
  retries with one constraint relaxed at a time, **tightest→softest**: budget
  +25%, then min building size ÷2, then min lot size ÷2, then drop city, then
  drop property type. The first retry that yields results wins, and the reason
  ("relaxed budget (+25%)", "any city") is returned as `fallbackReason` so the AI
  can be honest: "Nothing exactly in your budget, but here are a few a little
  above it." This converts dead-end calls into leads.

- **Sale-only type defaulting** (`isSaleOnlyType`, `src/listings.ts:60-75`;
  applied `:235-238`). Multi-family, land, hotels, development sites are almost
  never leased. If the caller names one without saying buy or lease, the system
  silently defaults to "For Sale" and the AI skips an awkward, pointless
  question.

- **Building-number ⇄ street-number duality** — the system reasons in both
  directions (address number → block, spoken block → address number) at
  `src/geography.ts:433-434` and `src/search.ts:231-252`. This is what makes a
  bare number like "around 88th" usefully searchable.

- **Speech-to-text mishears baked into the data.** Alias lists deliberately
  include transcription artifacts: `'just one'/'just 1'` for US-1
  (`src/geography.ts:359`), `'alla parra'/'alapara'` for Allapattah
  (`src/geography.ts:103`), `'coral cable'/'coral cables'` for Coral Gables. The
  knowledge base is tuned to how the phone *actually hears* callers.

- **Bilingual noise filtering** (`src/search.ts:69-75`) — Spanish stop-words are
  stripped alongside English, reflecting Miami's bilingual callers.

- **Tiny prompt, big catalog.** Rather than stuffing ~260 listings into the
  system prompt, Claude gets only a ~150-token summary (`getListingSummary`,
  `src/listings.ts:306-349`) plus the `search_properties` tool. This keeps the
  model fast and cheap on every turn while still having the full catalog
  searchable (`src/listings.ts:7-12`).

- **Zero-latency, zero-network search.** The whole engine is in-memory over a
  pre-built index — no DB query on the call path, which is what keeps responses
  sub-second on a live phone line.

- **TTS-aware formatting** (`expandAddress`, `src/listings.ts:355-405`) — before
  the AI speaks, "NW" → "Northwest," "Blvd" → "Boulevard," "# 1-6" → "Unit 1,"
  and the redundant ", FL 33312" ZIP tail is stripped, so addresses sound natural
  read aloud instead of like an abbreviated mailing label.

---

## 5. Key files & functions (file:line)

**`src/geography.ts`**
- `AREAS` — 19-area knowledge base — `:51-352`
- `HIGHWAY_ALIASES` — highway/road nickname map — `:358-375`
- `parseAddressGrid(address)` — address → grid coords — `:408-463`
- `locateAddress(street, ave, quadrant)` — grid coords → neighborhoods — `:472-493`
- `getNearbyAreas(name)` — flat neighbor list — `:498-509`
- `getProximityContext(name)` — human-readable proximity for Claude — `:514-529`
- `getAreaInfo` / `getAllAreaNames` — lookups — `:534-543`
- `expandHighwayAliases(token)` — `:548-551`
- `getGeographyContext(query)` — geo cues from a free query — `:556-593`

**`src/search.ts`**
- `normalizeText(text)` — bidirectional abbrev expansion — `:86-113`
- `buildSearchIndex(properties)` — weighted pre-index — `:124-140`
- `wordMatchScore` / `substringScore` / `sequenceScore` — 3 strategies — `:150-194`
- `scoreTokenField` — best-of-3 — `:203-210`
- `expandQuery(query)` — grid/highway/number expansion — `:224-265`
- `getGeographyBonusTokens(query)` — soft geo boost tokens — `:272-299`
- `USE_TYPE_ALIASES` / `extractUseTypeAliases` — `:308-329`
- `fuzzySearchProperties(keyword, limit)` — main scorer — `:339-416`

**`src/listings.ts`**
- `Property` interface — data model — `:23-47`
- `isShareableListingUrl` — `:52-55`
- `SALE_ONLY_TYPE_PATTERNS` / `isSaleOnlyType` — `:60-75`
- data load + `setProperties` / `getPropertyList` — `:81-106`
- `applyStructuredFilters` — `:131-172`
- `applySort` (relevance / price / price-per-door) — `:174-196`
- `runSearchOnce` — fuzzy ∩ structured — `:198-228`
- `searchPropertiesWithMeta` — entrypoint + broadening — `:230-286`
- `getListingSummary` — prompt summary — `:306-349`
- `expandAddress` — TTS readability — `:355-405`
- `formatResultsForClaude` — result rendering — `:416-467`

**Related (outside this subsystem, referenced above)**
- `src/salesforce.ts:246-248` — derives `lotAcres` from `lotSqft` (1 acre =
  43,560 sqft).
- `src/claude.ts:210,322,326` — tool-prompt instructions telling the model to
  convert acres → sqft and how to use `search_properties`.

---

## 6. Configuration, data sources, env vars

- **Listing data has two sources.** Primary: a bundled JSON at
  `data/properties.json`, loaded at module init (`src/listings.ts:84-94`). When
  Salesforce is connected, `salesforce.ts` calls `setProperties()`
  (`src/listings.ts:99-102`) to swap in live data and **rebuild the search
  index**. Salesforce is the system of record; the JSON is the offline fallback.
- **The geographic knowledge base is code, not config.** `AREAS` and
  `HIGHWAY_ALIASES` in `src/geography.ts` are hand-authored constants. Adding or
  correcting a neighborhood means editing that file — there is no external data
  file or env var for geography.
- **No env vars are specific to this subsystem.** It has no API keys, no
  endpoints, no feature flags. (Search runs purely in-memory; Salesforce
  connectivity and its credentials are configured in `salesforce.ts`, outside
  this area.)
- **Index lifecycle:** built once at startup and again on every SF refresh
  (`buildSearchIndex`, `src/search.ts:124-140`); a console log
  `🔍 Search index built: N properties` confirms it.

---

## 7. Gotchas & maintenance notes

- **Geography is curated, not computed.** There is no geocoding API and no
  lat/long. Distances, boundaries, and grid bounds in `AREAS` are
  human-estimated. They're good enough for "what's nearby" reasoning but are
  **not** survey-accurate. New neighborhoods Fausto starts listing in must be
  added to `AREAS` by hand or they get no proximity intelligence.
- **Grid bounds overlap on purpose**, so `locateAddress` can return multiple
  areas for one number (e.g. street 215 → both Cutler Bay and Homestead). Callers
  see only the top few; this is expected, not a bug.
- **The grid model is Miami-Dade-specific.** Broward/Palm Beach areas
  (Fort Lauderdale, Hollywood, Pompano) intentionally have **no `gridBounds`**
  (`src/geography.ts:307-351`) because they don't share the numbered grid, so
  street-number → neighborhood inference simply doesn't fire there. Don't "fix"
  this by inventing grid bounds for them.
- **Acres conversion is one-directional from sqft.** `lotAcres` is always derived
  from `lotSqft` at load (`salesforce.ts:248`). If a Salesforce record is missing
  `Lot_Size_sqft__c`, it will have *neither* unit. There is no separate acres
  field to fall back on — fix the sqft value in Salesforce.
- **Acres→sqft on input depends on the LLM following the prompt.** The conversion
  at query time lives in the Claude tool instructions (`src/claude.ts:210`), not
  in the search code. If the model misbehaves on lot-size math, that's a prompt
  fix, not a search-engine fix.
- **`sequenceScore` ignores tokens shorter than 3 chars** (`src/search.ts:176`)
  to avoid garbage matches — very short queries lean on exact/substring matching
  only.
- **Adding a use-type term** the AI should weight (e.g. "car wash") means adding
  it to `USE_TYPE_ALIASES` (`src/search.ts:308-324`); otherwise it's treated as a
  plain keyword with no boost.
- **Field weights are tuning knobs.** If results feel off (e.g. city matches
  drowning out address matches), the weights at `src/search.ts:127-137` and the
  bonus multipliers (use-type 2.0×, geo 0.3×, coverage up to 1.5×) are where you
  tune ranking — change them deliberately and re-test, since they interact.
- **Broadening can surprise callers.** Because zero-result searches auto-broaden
  (`src/listings.ts:247-283`), the AI should always cite `fallbackReason` so the
  caller understands a result is *near* their ask, not an exact match. If results
  ever seem "wrong," check whether a broaden fired.
