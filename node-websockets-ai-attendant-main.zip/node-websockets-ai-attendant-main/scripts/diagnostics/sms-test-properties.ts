/**
 * Pick 3 Active Property__c records — one for each SMS test case. Read-only.
 *   1. publicUrl set       → AI should send SMS with the listing link.
 *   2. publicUrl null      → AI should refuse to send (offer agent follow-up).
 *   3. publicUrl points to a WP draft → AI sends, but the recipient hits a
 *      404/private page (the bug the user wants to see in action).
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/sms-test-properties.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

const WP_BASE = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_PASS = process.env.WP_APP_PASSWORD || '';

async function wpStatus(url: string): Promise<string> {
  const auth = Buffer.from(`${WP_USER}:${WP_PASS}`).toString('base64');
  const headers = { Authorization: `Basic ${auth}` };

  // Form 1: pretty permalink — /property/<slug>
  const mSlug = url.match(/\/property\/([^/?#]+)/);
  // Form 2: query-string — ?p=<id> or ?post_type=...&p=<id>
  const mId = url.match(/[?&]p=(\d+)/);

  if (mId) {
    const res = await fetch(`${WP_BASE}/wp-json/wp/v2/properties/${mId[1]}?status=any&context=edit`, { headers });
    if (!res.ok) return `http-${res.status}`;
    const r = (await res.json()) as any;
    return (r.status as string) || 'unknown';
  }
  if (mSlug) {
    const res = await fetch(
      `${WP_BASE}/wp-json/wp/v2/properties?slug=${encodeURIComponent(mSlug[1])}&status=any`,
      { headers }
    );
    if (!res.ok) return `http-${res.status}`;
    const arr = (await res.json()) as any[];
    if (!arr.length) return 'not-found';
    return arr[0].status as string;
  }
  return 'no-id-or-slug';
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. WITH publicUrl — pick a recognizable, recent one.
  const withUrl: any[] = await sf.soql(
    `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, Public_URL__c
     FROM Property__c
     WHERE Status__c = 'Active' AND Public_URL__c != null
     ORDER BY LastModifiedDate DESC
     LIMIT 5`
  );

  // 2. WITHOUT publicUrl
  const noUrl: any[] = await sf.soql(
    `SELECT Id, Name, Marketing_Name__c, Address__c, City__c
     FROM Property__c
     WHERE Status__c = 'Active' AND Public_URL__c = null
     ORDER BY LastModifiedDate DESC
     LIMIT 5`
  );

  console.log('=== Category 1: Active + Public_URL__c set + WP status = publish (AI should SEND working link) ===');
  if (WP_USER && WP_PASS) {
    let shown = 0;
    const scanPub: any[] = await sf.soql(
      `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, Public_URL__c
       FROM Property__c
       WHERE Status__c = 'Active' AND Public_URL__c != null
       ORDER BY LastModifiedDate DESC
       LIMIT 200`
    );
    for (const p of scanPub) {
      const status = await wpStatus(p.Public_URL__c);
      if (status === 'publish') {
        const display = p.Marketing_Name__c || p.Name;
        console.log(`  ${p.Id}  "${display}"  ${p.Address__c || ''}, ${p.City__c || ''}`);
        console.log(`    URL: ${p.Public_URL__c}`);
        shown++;
        if (shown >= 3) break;
      }
    }
    if (!shown) console.log(`  (none publish-status in last 200)`);
  } else {
    for (const p of withUrl.slice(0, 3)) {
      const display = p.Marketing_Name__c || p.Name;
      console.log(`  ${p.Id}  "${display}"  ${p.Address__c || ''}, ${p.City__c || ''}`);
      console.log(`    URL: ${p.Public_URL__c}  (WP status check skipped — no creds)`);
    }
  }

  console.log('\n=== Category 2: Active + Public_URL__c null (AI should REFUSE; offer agent follow-up) ===');
  for (const p of noUrl.slice(0, 3)) {
    const display = p.Marketing_Name__c || p.Name;
    console.log(`  ${p.Id}  "${display}"  ${p.Address__c || ''}, ${p.City__c || ''}`);
  }

  // 3. WITH URL but WP page is a DRAFT (URL points to a non-public page).
  if (WP_USER && WP_PASS) {
    console.log('\n=== Category 3: Active + URL set but WP page is DRAFT ===');
    let found = 0;
    const scanLimit = 300;
    const scan: any[] = await sf.soql(
      `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, Public_URL__c
       FROM Property__c
       WHERE Status__c = 'Active' AND Public_URL__c != null
       ORDER BY LastModifiedDate DESC
       LIMIT ${scanLimit}`
    );
    for (const p of scan) {
      const status = await wpStatus(p.Public_URL__c);
      if (status === 'draft') {
        const display = p.Marketing_Name__c || p.Name;
        console.log(`  ${p.Id}  "${display}"  ${p.Address__c || ''}, ${p.City__c || ''}`);
        console.log(`    URL: ${p.Public_URL__c}   (WP status: draft)`);
        found++;
        if (found >= 3) break;
      }
    }
    if (!found) console.log(`  (no drafts found in last ${scanLimit} active properties — scan more if needed)`);
  } else {
    console.log('\n(Skipping draft scan — WP_USER / WP_APP_PASSWORD not in env)');
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
