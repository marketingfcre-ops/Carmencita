# Salesforce MFA Setup — Administrators (Passkey / Security Key)

**Who:** the 5 Salesforce admins — Carlos Fausto Miranda, Nathalie Aguirre,
Elizabeth, Eleni, Tony.
**Deadline:** **July 1, 2026.**
**Method required:** a **phishing-resistant** method — a **passkey** (Face ID,
Touch ID, Windows Hello) or a **hardware security key** (e.g. YubiKey).

> ⚠️ Important: for admins, an authenticator app or SMS code is **not** enough.
> Salesforce requires a phishing-resistant method for admin accounts. Passkeys
> are free and built into modern phones and laptops.

## Option A — Passkey (recommended, free)

Use this if you have a modern phone or laptop (Face ID, Touch ID, fingerprint,
or Windows Hello).

1. Log in to Salesforce on the device you want to use.
2. Click your **avatar** (top right) → **Settings**.
3. In the left menu: **My Personal Information → Advanced User Details**, or search
   **"Security"** in Quick Find → **Connected Apps / Authentication**.
4. Find **Register → Passkey** (or **"Add Passkey / Security Key"**).
5. When prompted, confirm with **Face ID / Touch ID / fingerprint / device PIN**.
6. Done — next login will prompt for that biometric.

## Option B — Hardware security key (YubiKey)

Use this if you prefer a physical key (works across all your devices).

1. Same path as above → **Register → Security Key**.
2. Insert the YubiKey (USB) or tap it (NFC) when prompted.
3. Touch the key's button to confirm.
4. Done.

## Tips

- **Register two methods** if you can (e.g. phone passkey + laptop passkey, or a
  passkey + a backup YubiKey) so you're never locked out if a device is lost.
- A passkey is tied to the device — register one on each device you use to log in.
- Lost all methods? An admin can reset MFA for you in Setup → Users.

## Questions

Contact Jesus or Nathalie. We'll run a short walkthrough before July 1.
