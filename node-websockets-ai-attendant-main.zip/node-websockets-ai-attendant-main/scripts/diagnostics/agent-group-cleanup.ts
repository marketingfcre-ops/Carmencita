/**
 * Apply the cleanup decisions from orphan-matcher.ts to Salesforce.
 *
 * Reads:
 *   data/archive/orphan-matches-2026-05-24.json
 *
 * One destructive operation class (MERGE) + one read-only side-output:
 *   MERGE: For each SF duplicate cluster, reassign Leads from the dups to the
 *          canonical row, then delete the dup Group__c rows.
 *   EXCEL-UPDATE-REPORT: For each HIGH-confidence orphan match (and explicit
 *          medium-confidence promotions), tell Fausto what to change in his
 *          spreadsheet so it matches the SF name. We don't rename SF — the SF
 *          names are clearer/longer; Fausto's Excel uses abbreviations that
 *          would be cryptic in the database.
 *
 * Modes:
 *   default       → DRY-RUN. Prints every operation it WOULD do. No writes.
 *   --commit      → Actually perform the merges.
 *   --target dev|prod  (default prod)
 *
 * Safety:
 *   - DRY-RUN is the default and prints lead counts before each delete.
 *   - Writes a rollback log to data/archive/agent-group-cleanup-rollback-YYYY-MM-DD.json
 *     containing every reassign-and-delete with the reverse operation. Lets us
 *     undo if needed (delete victim re-created, leads moved back).
 *   - Confirms before --commit if running interactively.
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-cleanup.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-cleanup.ts --commit
 */

import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const INPUT = path.join(
  REPO_ROOT,
  'data',
  'archive',
  'orphan-matches-2026-05-24.json'
);
const TODAY = new Date().toISOString().slice(0, 10);
const ROLLBACK_LOG = path.join(
  REPO_ROOT,
  'data',
  'archive',
  `agent-group-cleanup-rollback-${TODAY}.json`
);
const EXCEL_UPDATE_REPORT = path.join(
  REPO_ROOT,
  'data',
  'archive',
  `excel-updates-for-fausto-${TODAY}.txt`
);

// ---------------------------------------------------------------------------
// Promotions from MEDIUM bucket — picked by the user during review.
// These pairs are considered as confidently mapping Excel → SF as the HIGH
// bucket. Used only to enrich the Excel-update report (we don't rename SF).
// ---------------------------------------------------------------------------
const MEDIUM_PROMOTIONS: Array<{ excelName: string; sfName: string }> = [
  { excelName: 'VicentePRolodex', sfName: 'VicenteRolodex' },
  { excelName: 'SouthMiamiOffices', sfName: 'MiamiOfficesSouth' },
  { excelName: 'HiaGarden Warehouse', sfName: 'HiaGardenWare' },
];

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface MatcherOutput {
  generated_at: string;
  summary: Record<string, number>;
  orphan_matches: Array<{
    excelName: string;
    agents: string[];
    candidates: Array<{
      sfId: string;
      sfName: string;
      leads: number;
      score: number;
      reasons: string[];
    }>;
    bestScore: number;
    bucket: 'HIGH' | 'MEDIUM' | 'LOW';
  }>;
  cluster_picks: Array<{
    normKey: string;
    inExcel: boolean;
    canonical: { id: string; name: string; leads: number };
    toMerge: Array<{ id: string; name: string; leads: number }>;
    totalLeads: number;
  }>;
}

interface RollbackEntry {
  ts: string;
  op: 'reassign' | 'delete-group';
  // Forward operation
  forward: Record<string, unknown>;
  // Reverse instruction — enough info to undo
  reverse: Record<string, unknown>;
}

/**
 * Custom-object references to `Group__c` that block deletion in SF.
 * Discovered via the describe() child-relationship list. Standard SF
 * infrastructure (Attachments, Notes, ContentDocumentLink, etc.) cascades
 * automatically and is not listed here.
 *
 * If a new custom object adds a Group__c lookup, add it here.
 */
const GROUP_REFS: Array<{ sobject: string; field: string }> = [
  { sobject: 'Lead', field: 'Group__c' },
  { sobject: 'Property__c', field: 'Group__c' },
  { sobject: 'Account', field: 'Group__c' },
];

// ---------------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------------

function parseArgs(argv: string[]) {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        out[key] = next;
        i++;
      } else {
        out[key] = true;
      }
    }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';
const COMMIT = args.commit === true;

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  if (!fs.existsSync(INPUT)) {
    console.error(`❌ Missing input: ${INPUT}`);
    console.error(`   Run scripts/diagnostics/orphan-matcher.ts first.`);
    process.exit(1);
  }
  const data: MatcherOutput = JSON.parse(fs.readFileSync(INPUT, 'utf8'));

  console.log(`\n🧹 Agent-group cleanup`);
  console.log(`   target:   ${TARGET}`);
  console.log(`   mode:     ${COMMIT ? '🔥 COMMIT — will write to Salesforce' : '🧪 DRY-RUN — no writes'}`);
  console.log(`   input:    ${path.basename(INPUT)}\n`);

  // Excel-update suggestions (always written — read-only side-output)
  writeExcelUpdateReport(data);

  // Merge ops = ALL clusters (each cluster collapses its dups into canonical)
  const mergeOps = data.cluster_picks;

  // Summary up-front
  const totalLeadsToMove = mergeOps.reduce(
    (s, c) => s + c.toMerge.reduce((ss, r) => ss + r.leads, 0),
    0
  );
  const totalRowsToDelete = mergeOps.reduce((s, c) => s + c.toMerge.length, 0);
  console.log(`Planned MERGE operations:`);
  console.log(`  ${mergeOps.length} clusters → ${totalLeadsToMove} Leads reassigned, ${totalRowsToDelete} Group__c rows deleted`);
  console.log(`Excel-update report (for Fausto): ${path.relative(REPO_ROOT, EXCEL_UPDATE_REPORT)}`);
  console.log();

  if (COMMIT) {
    // Confirm interactively
    if (stdin.isTTY) {
      const rl = readline.createInterface({ input: stdin, output: stdout });
      const ans = await rl.question(
        `⚠️  About to commit to ${TARGET}. Type "yes" to proceed: `
      );
      rl.close();
      if (ans.trim().toLowerCase() !== 'yes') {
        console.log('Aborted.');
        process.exit(0);
      }
    }
  }

  const sf = await sfClient(TARGET);
  console.log(`Connected to ${sf.instance}\n`);

  const rollback: RollbackEntry[] = [];

  // Up-front: which dup IDs still exist in SF? Lets us skip ones that were
  // already deleted in a previous (interrupted) run.
  let existingDupIds = new Set<string>();
  if (COMMIT) {
    const allDupIds = mergeOps.flatMap((c) => c.toMerge.map((d) => d.id));
    if (allDupIds.length > 0) {
      // Batch in chunks of 200 (SOQL IN-clause practical limit)
      for (let off = 0; off < allDupIds.length; off += 200) {
        const chunk = allDupIds.slice(off, off + 200);
        const ids = chunk.map((i) => `'${i}'`).join(',');
        const rows = await sf.soql<{ Id: string }>(
          `SELECT Id FROM Group__c WHERE Id IN (${ids})`
        );
        for (const r of rows) existingDupIds.add(r.Id);
      }
      const skipping = allDupIds.length - existingDupIds.size;
      if (skipping > 0) {
        console.log(`ℹ️  ${skipping} dups already deleted in a previous run — will skip those.\n`);
      }
    }
  }

  // === MERGES ===
  console.log(`═══ MERGES (${mergeOps.length}) ═══\n`);
  for (let i = 0; i < mergeOps.length; i++) {
    const cluster = mergeOps[i];
    const { canonical, toMerge, totalLeads } = cluster;
    console.log(
      `[${i + 1}/${mergeOps.length}] cluster "${cluster.normKey}" (totalLeads=${totalLeads})`
    );
    console.log(`  KEEP    ${canonical.id} "${canonical.name}" (${canonical.leads} leads)`);
    for (const dup of toMerge) {
      // Skip dups already deleted (resume support)
      if (COMMIT && !existingDupIds.has(dup.id)) {
        console.log(`  SKIP    ${dup.id} "${dup.name}" — already deleted`);
        continue;
      }
      console.log(`  MERGE → ${dup.id} "${dup.name}" (${dup.leads} leads expected)`);

      // 1. For each known custom-object reference, find rows pointing at the
      //    dup and reassign them to the canonical. This includes Lead,
      //    Property__c, and Account — all of which have Group__c lookups.
      for (const ref of GROUP_REFS) {
        if (COMMIT) {
          const safeId = dup.id.replace(/'/g, "\\'");
          const rows = await sf.soql<{ Id: string }>(
            `SELECT Id FROM ${ref.sobject} WHERE ${ref.field} = '${safeId}'`
          );
          if (rows.length === 0) continue;
          console.log(`     reassigning ${rows.length} ${ref.sobject} → ${canonical.id}`);
          for (const row of rows) {
            await sf.update(ref.sobject, row.Id, { [ref.field]: canonical.id });
            rollback.push({
              ts: new Date().toISOString(),
              op: 'reassign',
              forward: {
                sobject: ref.sobject,
                id: row.Id,
                field: ref.field,
                from: dup.id,
                to: canonical.id,
              },
              reverse: {
                sobject: ref.sobject,
                id: row.Id,
                field: ref.field,
                from: canonical.id,
                to: dup.id,
              },
            });
            // Flush rollback after every destructive op so a crash leaves us
            // with a complete audit trail.
            writeRollback(rollback);
          }
        }
      }

      // 2. Delete the dup
      if (COMMIT) {
        try {
          await sf.delete('Group__c', dup.id);
          existingDupIds.delete(dup.id);
          rollback.push({
            ts: new Date().toISOString(),
            op: 'delete-group',
            forward: { groupId: dup.id, name: dup.name },
            reverse: {
              recreate: { sobject: 'Group__c', fields: { Name: dup.name } },
              note: 'Will get new Id; references already reassigned to canonical.',
            },
          });
          writeRollback(rollback);
        } catch (err: any) {
          // If SF still refuses (new ref type we don't know about), surface and
          // continue with the next dup so a single bad row doesn't halt 90 others.
          console.error(`  ❌ DELETE failed for ${dup.id}: ${err.message?.slice(0, 200)}`);
          console.error('     → leaving this row in place. Add the blocking sobject to GROUP_REFS and re-run.');
        }
      } else {
        console.log(`     [dry-run] would reassign all refs and delete Group__c ${dup.id}`);
      }
    }
    console.log();
  }

  // Final rollback log
  if (COMMIT) {
    writeRollback(rollback);
    console.log(`\n📝 Rollback log: ${path.relative(REPO_ROOT, ROLLBACK_LOG)}`);
    console.log(`   ${rollback.length} reversible operations recorded`);
  } else {
    console.log(`\n🧪 DRY-RUN complete. Re-run with --commit to apply.`);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Generate a human-readable list of Excel-side edits Fausto should make so his
 * spreadsheet matches the canonical SF names. This is the OPPOSITE direction
 * of renaming SF — we keep the SF names (they're already attached to leads and
 * are clearer than the abbreviated Excel forms) and ask Fausto to fix his
 * spreadsheet.
 */
function writeExcelUpdateReport(data: MatcherOutput): void {
  interface ExcelEdit {
    bucket: 'HIGH' | 'MEDIUM-PROMOTED';
    excelCurrent: string;
    excelShouldBe: string; // the SF canonical name
    agents: string[];
    leads: number;
    sfId: string;
  }

  const edits: ExcelEdit[] = [];

  for (const m of data.orphan_matches) {
    if (m.bucket !== 'HIGH') continue;
    const best = m.candidates[0];
    if (!best || best.sfName === m.excelName) continue;
    edits.push({
      bucket: 'HIGH',
      excelCurrent: m.excelName,
      excelShouldBe: best.sfName,
      agents: m.agents,
      leads: best.leads,
      sfId: best.sfId,
    });
  }

  for (const promo of MEDIUM_PROMOTIONS) {
    const m = data.orphan_matches.find((x) => x.excelName === promo.excelName);
    if (!m) continue;
    const c = m.candidates.find((x) => x.sfName === promo.sfName);
    if (!c) continue;
    edits.push({
      bucket: 'MEDIUM-PROMOTED',
      excelCurrent: promo.excelName,
      excelShouldBe: promo.sfName,
      agents: m.agents,
      leads: c.leads,
      sfId: c.sfId,
    });
  }

  // Sort by impact (leads) desc
  edits.sort((a, b) => b.leads - a.leads);

  // LOW-bucket orphans: no good SF match. Either these are real new groups
  // (we should create empty Group__c rows in SF) or Excel typos (Fausto fixes
  // the spreadsheet). Surface them so Fausto can decide per row.
  const newOrUnknown = data.orphan_matches
    .filter((m) => m.bucket === 'LOW')
    .map((m) => ({
      excelName: m.excelName,
      agents: m.agents,
      closestSfGuess: m.candidates[0]?.sfName ?? null,
      closestScore: m.candidates[0]?.score ?? 0,
    }));

  const lines: string[] = [];
  lines.push('EXCEL UPDATE RECOMMENDATIONS — for Fausto');
  lines.push(`Generated: ${new Date().toISOString()}`);
  lines.push('');
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`PART 1 — Fix the Excel to match Salesforce names (${edits.length})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(
    'These pairs are the same group; the Excel uses one name and Salesforce uses'
  );
  lines.push(
    'another. Salesforce already has the leads attached — please update the Excel'
  );
  lines.push('cell to match the SF name. Sorted by lead count desc.');
  lines.push('');
  for (const e of edits) {
    lines.push(`"${e.excelCurrent}"   →   "${e.excelShouldBe}"`);
    lines.push(`   bucket: ${e.bucket}   leads: ${e.leads}   agents: ${e.agents.join(', ')}`);
    lines.push(`   SF Group__c.Id: ${e.sfId}`);
    lines.push('');
  }
  if (edits.length === 0) lines.push('(no edits suggested)\n');

  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(`PART 2 — Confirm: real new groups, or Excel typos? (${newOrUnknown.length})`);
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push(
    'These Excel groups have no good Salesforce match. For each, please mark:'
  );
  lines.push('  [NEW]  if the group really should exist — we will create an empty');
  lines.push('         Group__c record in SF for it.');
  lines.push('  [TYPO] if this is a misspelling of an existing group — tell us the');
  lines.push('         correct name and we will fix the Excel.');
  lines.push('');
  for (const n of newOrUnknown) {
    lines.push(`"${n.excelName}"`);
    lines.push(`   agents: ${n.agents.join(', ')}`);
    if (n.closestSfGuess && n.closestScore > 0.3) {
      lines.push(
        `   (closest existing SF group: "${n.closestSfGuess}" — score ${n.closestScore.toFixed(2)}. Probably unrelated.)`
      );
    }
    lines.push('   [ ] NEW  /  [ ] TYPO  →  ____________________');
    lines.push('');
  }

  fs.writeFileSync(EXCEL_UPDATE_REPORT, lines.join('\n'));
  console.log(`📝 Excel-update report: ${path.relative(REPO_ROOT, EXCEL_UPDATE_REPORT)}`);
  console.log(
    `   ${edits.length} same-group renames + ${newOrUnknown.length} unknowns to confirm\n`
  );
}

function writeRollback(entries: RollbackEntry[]) {
  fs.writeFileSync(
    ROLLBACK_LOG,
    JSON.stringify(
      {
        generated_at: new Date().toISOString(),
        target: TARGET,
        count: entries.length,
        entries,
      },
      null,
      2
    )
  );
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
