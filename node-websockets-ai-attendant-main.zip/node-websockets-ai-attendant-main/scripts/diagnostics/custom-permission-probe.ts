/**
 * Probe Custom Permission capability in this org. Read-only.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/custom-permission-probe.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log('instance:', sf.instanceUrl);

  const org: any[] = await sf.soql(
    `SELECT OrganizationType, InstanceName, IsSandbox FROM Organization`
  );
  console.log('Org:', org[0]);

  const cps: any[] = await sf
    .toolingQuery(
      `SELECT Id, DeveloperName, MasterLabel, NamespacePrefix FROM CustomPermission ORDER BY MasterLabel`
    )
    .catch((e: any) => {
      console.log('CustomPermission query err:', (e.message || '').slice(0, 200));
      return [];
    });
  console.log(`\nExisting CustomPermission records: ${cps.length}`);
  for (const c of cps.slice(0, 30))
    console.log(`  ${c.NamespacePrefix || '(local)'}  ${c.DeveloperName}  "${c.MasterLabel}"`);

  // System Administrator profile flags
  const sysAdmin: any[] = await sf.soql(
    `SELECT Id, Name, PermissionsCustomizeApplication, PermissionsManageCustomPermissions
     FROM Profile WHERE Name = 'System Administrator'`
  );
  console.log('\nSystem Administrator profile:');
  for (const p of sysAdmin) {
    console.log(`  customizeApp=${p.PermissionsCustomizeApplication}  manageCustomPerms=${p.PermissionsManageCustomPermissions}`);
  }

  // Whoever runs the integration is who we can test as
  const me: any[] = await sf.soql(
    `SELECT Id, Name, Username, Email, Profile.Name FROM User WHERE Email = 'jesus.wmr@gmail.com' OR Username LIKE 'jesus%' LIMIT 5`
  );
  console.log('\nJesus user candidates:');
  for (const u of me) {
    console.log(`  ${u.Id}  ${u.Name}  ${u.Username}  ${u.Email}  profile=${u.Profile?.Name}`);
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
