import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // Try ProfileApplicationVisibility / SetupEntityAccess
  for (const obj of ['SetupEntityAccess', 'ProfileApplicationVisibility']) {
    console.log(`\n=== ${obj} ===`);
    try {
      const r: any[] = await sf.toolingQuery(`SELECT Id FROM ${obj} LIMIT 1`);
      console.log(`  queryable (${r.length})`);
    } catch (e:any) { console.log(`  ${e.message?.slice(0,150)}`); }
  }
  // SetupEntityAccess on the Account for Agents PPS
  console.log('\n=== SetupEntityAccess on AfA PPS for ApplicationDefinition ===');
  try {
    const r: any[] = await sf.toolingQuery(
      `SELECT Id, ParentId, SetupEntityId, SetupEntityType FROM SetupEntityAccess WHERE ParentId IN ('0PSJw000000502bOAA','0PS300000001KGfGAM')`
    );
    console.log(`  ${r.length} rows`);
    for (const x of r.slice(0, 30)) console.log(`    ${x.SetupEntityType.padEnd(20)} ${x.SetupEntityId}  parent=${x.ParentId}`);
  } catch (e:any) { console.log(`  ${e.message?.slice(0,200)}`); }

  // Get apps Markos was in (the second one)
  console.log('\n=== Resolve unknown AppDefinitions ===');
  for (const id of ['06mJw000003u9LRIAY', '06m0c000001CPaYAAW']) {
    try {
      const r: any[] = await sf.toolingQuery(`SELECT Id, DurableId, DeveloperName, Label, NavType FROM AppDefinition WHERE DurableId = '${id}'`);
      for (const a of r) console.log(`  ${id}  →  ${a.Label}  (${a.DeveloperName})  navType=${a.NavType}`);
    } catch (e:any) {
      try {
        const r: any[] = await sf.soql(`SELECT Id, DurableId, DeveloperName, Label, NavType FROM AppDefinition WHERE DurableId = '${id}'`);
        for (const a of r) console.log(`  ${id}  →  ${a.Label}  (${a.DeveloperName})  navType=${a.NavType}`);
      } catch (e2:any) { console.log(`  ${id}  →  query failed`); }
    }
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
