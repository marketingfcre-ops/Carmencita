import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  const layouts: any[] = await sf.toolingQuery(
    `SELECT Id, Name FROM Layout WHERE EntityDefinition.QualifiedApiName = 'User_Group_Access__c'`
  );
  for (const l of layouts) {
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);
    const url = `${sf.instanceUrl}/services/data/v59.0/tooling/sobjects/Layout/${l.Id}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
    const lo: any = await res.json();
    for (const s of lo.Metadata?.layoutSections || []) {
      console.log(`  Section: "${s.label}"`);
      for (const c of s.layoutColumns || []) for (const it of c.layoutItems || []) {
        if (it.field) console.log(`    ${it.field}  behavior=${it.behavior}`);
      }
    }
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
