/**
 * Call handler with:
 * - Deepgram Flux (English) or Nova-3 (Spanish/multi) for STT
 * - ElevenLabs WebSockets for ultra-low latency TTS streaming
 * - Tool-aware fillers: play the instant Claude calls a tool (search, log_lead)
 * - Generation ID for barge-in cancellation
 * - Language-aware TTS voice selection
 * - Mid-call STT switch: Flux → Nova-3 when Spanish detected
 */

import { WebSocket } from 'ws';
import { createClient, LiveTranscriptionEvents } from '@deepgram/sdk';
import {
  chatStream,
  getGreeting,
  getConversation,
  clearConversation,
  getLeads,
  type ChatResult,
} from './claude';
import { ElevenLabsStream, detectLanguage } from './tts';
import {
  SpeechAnalyzer,
  FILLER_PHRASES,
  type FillerKey,
  type FinalSegment,
} from './speech-analyzer';
import { FluxConnection, applyReplacements } from './stt-flux';
import { CallLogger } from './call-logger';

const DEEPGRAM_API_KEY = process.env.DEEPGRAM_API_KEY!;

// STT model: "flux" (default) uses Flux for English with auto-switch to Nova-3 for Spanish.
// "nova-3" uses Nova-3 multi-language only (previous behavior, for comparison).
const STT_MODEL = process.env.STT_MODEL || 'flux';

// Feature flag: set FILLER_ENABLED=false to disable filler phrases entirely.
// When off, the caller hears silence while Claude processes tools (~2-4s).
// When on (default), a filler plays the INSTANT Claude calls a tool (search, log_lead).
// Zero prediction, zero timers — only real tool calls trigger fillers.
const FILLER_ENABLED = process.env.FILLER_ENABLED !== 'false'; // default: ON

// Standalone affirmative tokens — used to detect when the caller's first reply
// to a yes/no follow-up is just acknowledgment with more to come.
function isAffirmative(text: string): boolean {
  const norm = text.trim().toLowerCase().replace(/[.,!?]/g, '');
  return [
    'yes',
    'yeah',
    'yep',
    'yup',
    'sure',
    'ok',
    'okay',
    'uh-huh',
    'uhuh',
    'mhm',
    'mm-hmm',
    'mmhmm',
    'sí',
    'si',
    'claro',
    'dale',
  ].includes(norm);
}

interface TwilioMediaMessage {
  event: string;
  sequenceNumber?: string;
  media?: { track: string; chunk: string; timestamp: string; payload: string };
  start?: {
    streamSid: string;
    callSid: string;
    customParameters: Record<string, string>;
  };
  streamSid?: string;
  stop?: { callSid: string };
  dtmf?: { digit: string };
  mark?: { name: string };
}

interface LogEntry {
  timestamp: string;
  speaker: 'caller' | 'ai' | 'system';
  text: string;
}

export class CallHandler {
  private ws: WebSocket;
  private streamSid = '';
  private callSid = '';
  private callerPhone = '';
  private deepgramLive: any = null;
  private conversationLog: LogEntry[] = [];

  private isProcessing = false;
  private generationId = 0;
  private finalTranscripts: string[] = [];
  private pendingTranscripts: string[] = []; // Queued during cooldown, processed when cooldown ends

  private callerLang: 'en' | 'es' = 'en';
  private currentTTSStream: ElevenLabsStream | null = null;

  // The brain — language detection, noise filtering, pending questions
  private analyzer!: SpeechAnalyzer;

  // Flux STT — native turn detection for English
  private sttMode: 'flux' | 'nova' = STT_MODEL === 'flux' ? 'flux' : 'nova';
  private fluxConnection: FluxConnection | null = null;
  private eagerResponsePending = false; // True when EagerEndOfTurn triggered a speculative Claude call

  // Structured timeline logger for debugging call quality
  private logger!: CallLogger;

  // Track when filler started so we don't cut it mid-sentence
  private fillerStartTime = 0;
  private fillerStream: ElevenLabsStream | null = null;

  // Twilio mark events — know exactly when the caller heard the audio
  private markResolvers = new Map<string, () => void>();
  private markTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private pendingHangup = false;

  constructor(ws: WebSocket) {
    this.ws = ws;
    this.setup();
  }

  private log(who: 'caller' | 'ai' | 'system', text: string): void {
    this.conversationLog.push({
      timestamp: new Date().toISOString(),
      speaker: who,
      text,
    });
    const icon = who === 'caller' ? '🎤' : who === 'ai' ? '🤖' : '⚙️';
    console.log(`${icon} [${this.callSid}] ${who}: ${text}`);
  }

  private setup(): void {
    this.ws.on('message', (data: Buffer) => {
      try {
        this.onTwilioMsg(JSON.parse(data.toString()));
      } catch (err) {
        console.error(
          `❌ [${this.callSid || 'init'}] Message parse error:`,
          err
        );
      }
    });
    this.ws.on('close', (code: number, reason: Buffer) => {
      console.log(
        `🔌 [${this.callSid}] Twilio WS CLOSED — code: ${code}, reason: "${reason?.toString() || 'none'}"`
      );
      this.log('system', `Call ended (ws close code: ${code})`);
      this.printSummary();
      this.logger?.flush().catch(() => {}); // Save call timeline
      this.cleanup();
    });
    this.ws.on('error', (err: Error) => {
      console.error(`❌ [${this.callSid}] Twilio WS ERROR:`, err.message);
      this.cleanup();
    });
  }

  private async onTwilioMsg(msg: TwilioMediaMessage): Promise<void> {
    switch (msg.event) {
      case 'connected':
        console.log('🔌 Twilio connected');
        break;
      case 'start':
        this.streamSid = msg.start!.streamSid;
        this.callSid = msg.start!.callSid;
        this.callerPhone =
          msg.start!.customParameters?.callerPhone || 'unknown';
        this.analyzer = new SpeechAnalyzer(this.callSid);
        this.logger = new CallLogger(this.callSid, this.callerPhone);
        this.log('system', `Call from ${this.callerPhone}`);
        await this.greet();
        this.startSTT();
        break;
      case 'media':
        if (msg.media?.payload) {
          const buf = Buffer.from(msg.media.payload, 'base64');
          if (this.sttMode === 'flux' && this.fluxConnection) {
            this.fluxConnection.send(buf);
          } else if (this.deepgramLive) {
            this.deepgramLive.send(buf);
          }
        }
        break;
      case 'mark':
        if (msg.mark?.name) {
          const resolver = this.markResolvers.get(msg.mark.name);
          if (resolver) {
            console.log(
              `🏁 [${this.callSid}] Mark confirmed: ${msg.mark.name}`
            );
            this.logger?.twilioMarkConfirmed(msg.mark.name);
            resolver();
            this.markResolvers.delete(msg.mark.name);
          }
        }
        break;
      case 'stop':
        this.log('system', 'Stream stopped');
        this.cleanup();
        break;
    }
  }

  // ---------------------------------------------------------------------------
  // Greeting
  // ---------------------------------------------------------------------------

  private async greet(): Promise<void> {
    try {
      this.isProcessing = true;
      const text = getGreeting(this.callSid, this.callerLang);
      this.log('ai', text);
      this.streamToTTS(text);
    } catch (err) {
      console.error('Greeting error:', err);
      this.isProcessing = false;
    }
  }

  // ---------------------------------------------------------------------------
  // Filler — plays the instant Claude starts a tool call (search, log_lead).
  // Triggered by the onToolCall callback from chatStream, not by prediction.
  // The main response will clear Twilio's audio buffer before playing.
  // ---------------------------------------------------------------------------

  private sendFiller(fillerKey: FillerKey): void {
    const phrase = FILLER_PHRASES[fillerKey];
    const lang = fillerKey.startsWith('es') ? 'es' : 'en';

    this.fillerStream = new ElevenLabsStream(
      (base64Audio) => this.sendBase64Audio(base64Audio),
      () => {},
      (err) => console.error(`Filler TTS error:`, err),
      { lang }
    );

    this.fillerStream.pushText(phrase);
    // Remove this.fillerStream.finish() from here if it causes resets,
    // or wrap it in a short setImmediate
    setImmediate(() => this.fillerStream?.finish());
  }

  // ---------------------------------------------------------------------------
  // STT — Flux (English, native turn detection) or Nova-3 (multi-language)
  // ---------------------------------------------------------------------------

  // Shared keyterms for both Flux and Nova-3
  private static readonly KEYTERMS = [
    // CRE property types
    'warehouse:2', 'industrial:1.5', 'multifamily:2', 'retail:1.5',
    'office:1.5', 'flex:1.5', 'storefront:1.5',
    // CRE terms
    'NNN:2', 'CAM:2', 'NOI:2', 'cap rate:2', 'triple net:2',
    'leasable:1.5', 'buildout:2', 'turnkey:2', 'value add:2',
    'dock high:2', 'grade level:1.5', 'clear height:1.5',
    // Transaction terms
    'buy:2.5', 'to buy:2.5', 'lease:2', 'to lease:2', 'sale:1.5',
    'purchase:2', 'rent:1.5', 'for sale:2', 'for lease:2',
    // Size
    'square feet:1.5', 'square footage:1.5', 'acreage:1.5',
    // Miami neighborhoods
    'Miami:2', 'Doral:2', 'Hialeah:2', 'Brickell:1.5', 'Wynwood:1.5',
    'Coral Gables:2', 'Kendall:1.5', 'Homestead:1.5', 'Medley:2',
    'Opa-locka:2', 'Hallandale:1.5', 'Miramar:1.5', 'Sweetwater:1.5',
    'Allapattah:2', 'Edgewater:1.5', 'Flagami:1.5', 'Pinecrest:1.5',
    'Palmetto Bay:1.5', 'Little Havana:1.5', 'Cutler Bay:2', 'Goulds:1.5',
    'North Miami Beach:1.5', 'Little Haiti:1.5', 'Little River:1.5',
    'Coconut Grove:1.5',
    // Company
    'Fausto:2', 'Fausto Commercial:2',
  ];

  private startSTT(): void {
    if (this.sttMode === 'flux') {
      this.startFluxSTT();
    } else {
      this.startNovaSTT();
    }
  }

  // ---------------------------------------------------------------------------
  // Flux STT — native turn detection, multilingual (English + Spanish)
  // ---------------------------------------------------------------------------

  private startFluxSTT(): void {
    this.sttMode = 'flux';
    console.log(`🎤 [${this.callSid}] Starting Flux STT (multilingual EN/ES)`);

    this.fluxConnection = new FluxConnection(
      DEEPGRAM_API_KEY,
      {
        encoding: 'mulaw',
        sampleRate: 8000,
        eotThreshold: 0.7,
        eagerEotThreshold: 0.5,
        eotTimeoutMs: 3000,
        keyterms: CallHandler.KEYTERMS,
        model: 'flux-general-multi',
        languageHints: ['en', 'es'],
      },
      {
        onOpen: () => this.log('system', 'Flux STT connected'),

        // Partial transcript — feed analyzer (kept for noise/STT-error logic).
        // Spanish detection here is no longer needed; Flux Multilingual decodes
        // ES audio natively and reports the language in TurnInfo.languages.
        onUpdate: (transcript, words) => {
          if (!transcript.trim()) return;
          this.analyzer.onInterim(transcript);
        },

        // Fast-trigger — model thinks caller might be done (replaces isThoughtComplete)
        onEagerEndOfTurn: (transcript, words, confidence, languages) => {
          if (!transcript.trim()) return;
          const text = transcript.trim();
          console.log(
            `⚡ [${this.callSid}] Flux EagerEndOfTurn (${confidence.toFixed(2)}): "${text}"${
              languages?.length ? ` [lang: ${languages.join(',')}]` : ''
            }`
          );
          this.logger?.sttFinal(text, confidence, words.length);
          this.logger?.analyzerFastTrigger();

          // Adopt Flux's language detection so TTS picks the right voice.
          this.adoptFluxLanguage(languages);

          // Feed analyzer (kept for noise/STT-error logic).
          const segment = this.fluxWordsToSegment(text, words);
          this.analyzer.onFinal(segment);

          if (this.isProcessing) {
            // Barge-in: Flux says caller started a new thought while AI is talking
            const wordCount = text.split(/\s+/).length;
            if (wordCount <= 3) {
              this.pendingTranscripts.push(text);
              console.log(
                `📦 [${this.callSid}] Stashed during processing (${wordCount}w): "${text}"`
              );
              this.logger?.bargeInStash(text, `flux_eager_${wordCount}w`);
            } else {
              console.log(
                `🛑 [${this.callSid}] Barge-in via EagerEndOfTurn (${wordCount}w): "${text}"`
              );
              this.logger?.bargeIn(text, wordCount);
              this.cancel();
              this.analyzer.reset();
              this.analyzer.onFinal(segment);
              this.finalTranscripts = [text];
              this.eagerResponsePending = true;
              this.flushAndRespond();
            }
            return;
          }

          // Short low-confidence guard — when caller hasn't really said much yet
          // (≤2 words, confidence below 0.7), do NOT fire a speculative Claude call.
          // The bot saying "I didn't catch that" on top of "See." / "I'll" makes the
          // call feel rushed. Hold for the definitive EndOfTurn instead.
          const wordCount = text.split(/\s+/).length;
          if (wordCount <= 2 && confidence < 0.7) {
            console.log(
              `🕒 [${this.callSid}] Holding eager trigger — short/low-conf (${wordCount}w, conf ${confidence.toFixed(2)})`
            );
            return;
          }

          // Yes/no follow-up guard — when bot just asked a yes/no follow-up ("any
          // more questions?") and caller answers with a single affirmative, the
          // real question is almost always still coming. Hold the eager response
          // so we don't race the caller's next utterance with "what question?".
          if (
            this.analyzer.getPendingQuestionType() === 'yes_no' &&
            isAffirmative(text)
          ) {
            console.log(
              `🕒 [${this.callSid}] Holding eager trigger — affirmative to yes/no, expecting follow-up`
            );
            return;
          }

          // Start speculative Claude call
          this.finalTranscripts = [text];
          this.eagerResponsePending = true;
          this.flushAndRespond();
        },

        // Caller continued after eager trigger — cancel speculative response
        onTurnResumed: () => {
          if (this.eagerResponsePending) {
            console.log(
              `🔄 [${this.callSid}] Flux TurnResumed — cancelling speculative response`
            );
            this.eagerResponsePending = false;
            this.cancel();
          }
        },

        // Definitive end of turn — respond if not already processing
        onEndOfTurn: (transcript, words, confidence, languages) => {
          if (!transcript.trim()) return;
          const text = transcript.trim();
          console.log(
            `🔚 [${this.callSid}] Flux EndOfTurn (${confidence.toFixed(2)}): "${text}"${
              languages?.length ? ` [lang: ${languages.join(',')}]` : ''
            }`
          );
          this.logger?.sttFinal(text, confidence, words.length);
          this.logger?.sttUtteranceEnd();

          // Adopt Flux's language detection so TTS picks the right voice.
          this.adoptFluxLanguage(languages);

          // Feed analyzer (kept for noise/STT-error logic).
          const segment = this.fluxWordsToSegment(text, words);
          this.analyzer.onFinal(segment);

          // If EagerEndOfTurn already started processing and wasn't cancelled, skip
          if (this.eagerResponsePending && this.isProcessing) {
            console.log(
              `✅ [${this.callSid}] EndOfTurn confirms eager response (already processing)`
            );
            this.eagerResponsePending = false;
            this.analyzer.reset();
            return;
          }
          this.eagerResponsePending = false;

          // If already processing from another source, stash
          if (this.isProcessing) {
            if (text) {
              this.pendingTranscripts.push(text);
              console.log(
                `📦 [${this.callSid}] Stashed EndOfTurn during processing: "${text}"`
              );
            }
            this.analyzer.reset();
            return;
          }

          // Normal respond — callerLang was set by adoptFluxLanguage above.
          this.finalTranscripts = [text];
          this.flushAndRespond();
        },

        // Barge-in signal — caller started speaking while AI is talking
        onStartOfTurn: () => {
          if (this.isProcessing) {
            console.log(
              `🛑 [${this.callSid}] Flux StartOfTurn — barge-in signal`
            );
            // Don't cancel immediately on StartOfTurn — wait for the actual transcript
            // in EagerEndOfTurn or EndOfTurn to decide (could be a noise burst).
            // But if we have a filler playing, note it.
          }
        },

        onError: (err) => {
          console.error(`Flux STT error (${this.callSid}):`, err.message);
        },

        onClose: () => {
          this.log('system', 'Flux STT closed');
        },
      },
    );
  }

  /**
   * Apply Flux Multilingual's per-turn language detection to callerLang so TTS
   * picks the right voice. We only flip on a clear primary signal — short or
   * ambiguous turns leave the existing language sticky.
   */
  private adoptFluxLanguage(languages?: string[]): void {
    if (!languages || languages.length === 0) return;
    const primary = languages[0].toLowerCase().split('-')[0];
    const next = primary === 'es' ? 'es' : 'en';
    if (next !== this.callerLang) {
      console.log(`🌐 [${this.callSid}] Flux language switch: ${this.callerLang} → ${next}`);
      this.callerLang = next;
    }
  }

  /** Convert Flux word array to a FinalSegment for the SpeechAnalyzer. */
  private fluxWordsToSegment(text: string, words: { word: string; confidence: number }[]): FinalSegment {
    const avgConf = words.length > 0
      ? words.reduce((sum, w) => sum + w.confidence, 0) / words.length
      : 0.9;
    return {
      text,
      words: words.map((w) => ({
        word: w.word,
        start: 0,
        end: 0,
        confidence: w.confidence,
      })),
      segmentConfidence: avgConf,
    };
  }

  // ---------------------------------------------------------------------------
  // Mid-call switch: Flux → Nova-3 (when Spanish detected)
  // ---------------------------------------------------------------------------

  private switchToNova(): void {
    console.log(`🔄 [${this.callSid}] Switching STT: Flux → Nova-3 (multi-language)`);

    // Cancel any in-flight response — garbled English transcription of Spanish is useless.
    // The caller will naturally repeat themselves and Nova-3 will pick it up cleanly.
    if (this.isProcessing) {
      console.log(`🗑️ [${this.callSid}] Cancelling garbled response before language switch`);
      this.cancel();
    }

    // Close Flux
    if (this.fluxConnection) {
      this.fluxConnection.close();
      this.fluxConnection = null;
    }

    // Start Nova-3
    this.callerLang = 'es';
    this.startNovaSTT();
  }

  // ---------------------------------------------------------------------------
  // Nova-3 STT — multi-language with custom endpointing (original architecture)
  // ---------------------------------------------------------------------------

  private startNovaSTT(): void {
    this.sttMode = 'nova';
    console.log(`🎤 [${this.callSid}] Starting Nova-3 STT (multi-language)`);

    const dg = createClient(DEEPGRAM_API_KEY);
    this.deepgramLive = dg.listen.live({
      model: 'nova-3',
      language: 'multi',
      encoding: 'mulaw',
      sample_rate: 8000,
      channels: 1,
      punctuate: true,
      smart_format: true,
      endpointing: 600,
      utterance_end_ms: 1800,
      interim_results: true,
      replace: [
        'dubai:to buy',
        'do buy:to buy',
        'the buy:to buy',
        'do by:to buy',
        'just one:US-1',
        'just won:US-1',
        'alla parra:Allapattah',
        'alapara:Allapattah',
        'coral cable:Coral Gables',
        'coral cables:Coral Gables',
      ],
      keyterms: CallHandler.KEYTERMS,
    });

    this.deepgramLive.on(LiveTranscriptionEvents.Open, () =>
      this.log('system', 'Nova-3 STT connected')
    );

    this.deepgramLive.on(LiveTranscriptionEvents.Transcript, (data: any) => {
      const alt = data.channel?.alternatives?.[0];
      const transcript = alt?.transcript;
      if (!transcript || !transcript.trim()) return;

      if (data.is_final) {
        const text = transcript.trim();
        const words = (alt.words || []).map((w: any) => ({
          word: w.word,
          start: w.start,
          end: w.end,
          confidence: w.confidence,
          punctuated_word: w.punctuated_word,
        }));
        const segment: FinalSegment = {
          text,
          words,
          segmentConfidence: alt.confidence,
        };

        // 1. Feed analyzer
        this.analyzer.onFinal(segment);
        this.logger?.sttFinal(text, alt.confidence, words.length);

        // 2. ASSERTION: Fast-trigger if the thought is complete
        if (!this.isProcessing && this.analyzer.isThoughtComplete()) {
          console.log(
            `⚡ [${this.callSid}] Intent asserted: Fast-triggering response.`
          );
          this.logger?.analyzerFastTrigger();
          const decision = this.analyzer.getDecision();
          if (decision.cleanedText) {
            this.finalTranscripts = [decision.cleanedText];
          } else {
            this.finalTranscripts.push(text);
          }
          this.flushAndRespond();
          return;
        }

        // 3. Barge-in: word-count based
        if (this.isProcessing) {
          const wordCount = text.split(/\s+/).length;

          if (this.fillerStream) {
            console.log(
              `📦 [${this.callSid}] Stashed during filler phase: "${text}"`
            );
            this.logger?.bargeInStash(text, 'filler_phase');
            return;
          }

          if (wordCount <= 2) {
            // Don't stash ultra-low confidence short transcripts — likely noise
            // or garbled partial words (e.g. "Es" at 0.48 during Spanish speech)
            if (alt.confidence < 0.55) {
              console.log(
                `🗑️ [${this.callSid}] Skipped low-conf stash (${alt.confidence.toFixed(2)}): "${text}"`
              );
              return;
            }
            this.pendingTranscripts.push(text);
            console.log(
              `📦 [${this.callSid}] Stashed (short, ${wordCount}w): "${text}"`
            );
            this.logger?.bargeInStash(text, `short_${wordCount}w`);
            return;
          }

          if (wordCount === 3) {
            this.pendingTranscripts.push(text);
            console.log(`📦 [${this.callSid}] Stashed (medium, 3w): "${text}"`);
            this.logger?.bargeInStash(text, 'medium_3w');
            return;
          }

          console.log(
            `🛑 [${this.callSid}] Barge-in (${wordCount}w): "${text}"`
          );
          this.logger?.bargeIn(text, wordCount);
          this.cancel();
          this.analyzer.reset();
          this.analyzer.onFinal(segment);
          this.finalTranscripts = [text];
          return;
        }

        this.finalTranscripts.push(text);
      }
    });

    this.deepgramLive.on(LiveTranscriptionEvents.UtteranceEnd, () => {
      this.logger?.sttUtteranceEnd();
      if (this.isProcessing) {
        if (this.finalTranscripts.length > 0) {
          this.pendingTranscripts.push(...this.finalTranscripts);
          console.log(
            `📦 [${this.callSid}] Stashed ${this.finalTranscripts.length} transcript(s) for after cooldown: "${this.finalTranscripts.join(' ')}"`
          );
          this.finalTranscripts = [];
        }
        this.analyzer.reset();
        return;
      }

      if (this.finalTranscripts.length === 0) return;

      const decision = this.analyzer.getDecision();
      this.callerLang = decision.lang;
      this.logger?.analyzerDecision(
        decision.action,
        decision.debug,
        decision.filler
      );

      if (decision.action === 'respond') {
        console.log(
          `🔚 [${this.callSid}] UtteranceEnd safety-trigger: responding.`
        );
        if (decision.cleanedText) {
          this.finalTranscripts = [decision.cleanedText];
        }
        this.flushAndRespond();
      } else {
        console.log(
          `🗑️ [${this.callSid}] Discarded as noise: "${this.finalTranscripts.join(' ')}"`
        );
        this.finalTranscripts = [];
        this.analyzer.reset();
      }
    });

    this.deepgramLive.on(LiveTranscriptionEvents.Error, (err: any) =>
      console.error(`STT error (${this.callSid}):`, err)
    );
    this.deepgramLive.on(LiveTranscriptionEvents.Close, () =>
      this.log('system', 'STT closed')
    );
  }

  // ---------------------------------------------------------------------------
  // Flush and respond
  // ---------------------------------------------------------------------------

  private flushAndRespond(): void {
    if (this.finalTranscripts.length === 0) return;

    const combined = this.finalTranscripts.join(' ');
    this.finalTranscripts = [];

    // Reset the analyzer COMPLETELY for the next turn
    this.analyzer.reset();

    if (combined.trim().length < 2) return;

    this.log('caller', combined);
    this.respond(combined);
  }

  // ---------------------------------------------------------------------------
  // Cancel
  // ---------------------------------------------------------------------------

  private cancel(): void {
    this.generationId++;
    this.logger?.setGen(this.generationId);

    // Capture barge-in context BEFORE killing TTS —
    // uses ElevenLabs alignment data to know exactly what was spoken
    if (this.currentTTSStream && this.lastResponseText) {
      const spokenText = this.currentTTSStream.getSpokenText();
      if (spokenText) {
        const unspokenText = this.computeUnspokenText(
          this.lastResponseText,
          spokenText
        );
        if (unspokenText) {
          this.updateHistoryForBargeIn(spokenText, unspokenText);
        }
      }
    }
    this.lastResponseText = '';

    this.clearAudio();
    this.isProcessing = false;
    this.finalTranscripts = [];
    this.pendingTranscripts = [];
    this.fillerStartTime = 0;
    this.pendingHangup = false;
    this.eagerResponsePending = false;

    // Cancel any pending mark resolvers AND their timers — stale playback confirmations
    for (const timer of this.markTimers.values()) clearTimeout(timer);
    this.markTimers.clear();
    this.markResolvers.clear();

    // Kill the TTS stream instantly on barge-in
    if (this.currentTTSStream) {
      this.currentTTSStream.abort();
      this.currentTTSStream = null;
    }
    if (this.fillerStream) {
      this.fillerStream.abort();
      this.fillerStream = null;
    }
    this.log('system', `Cancelled (gen ${this.generationId})`);
  }

  private lastProcessedTranscript = '';
  private lastResponseText = ''; // Full Claude text for barge-in context tracking

  // ---------------------------------------------------------------------------
  // Respond — stream Claude text directly into ElevenLabs TTS
  // ---------------------------------------------------------------------------

  private async respond(transcript: string): Promise<void> {
    // ASSERTION: If we just finished talking about this exact thing, ignore it.
    if (transcript === this.lastProcessedTranscript) return;
    this.lastProcessedTranscript = transcript;

    if (this.isProcessing) return;

    this.isProcessing = true;
    const gen = ++this.generationId;
    this.logger?.setGen(gen);
    this.logger?.lockAcquired('respond');
    const t0 = Date.now();
    let firstChunkReceived = false;
    let toolFillerFired = false;

    // Add pending question context so Claude knows about STT error patterns
    let enrichedTranscript = transcript;
    if (this.analyzer.hasPendingQuestion()) {
      const qType = this.analyzer.getPendingQuestionType();
      if (qType === 'buy_or_lease') {
        const lower = transcript.toLowerCase().trim();
        // Correct known STT errors at the transcript level
        if (/\b(dubai|do buy|the buy|do by)\b/i.test(lower)) {
          enrichedTranscript = 'To buy.';
          console.log(
            `🔄 [${this.callSid}] Transcript corrected: "${transcript}" → "${enrichedTranscript}" (pending: ${qType})`
          );
          this.logger?.transcriptCorrection(
            transcript,
            enrichedTranscript,
            `pending: ${qType}`
          );
        }
        // "Lease" misheard as "Liz", "Lis", "Liss", "Less" on phone audio
        else if (/^(liz|lis|liss|less|leez|lisa)[.!?,\s]*$/i.test(lower)) {
          enrichedTranscript = 'To lease.';
          console.log(
            `🔄 [${this.callSid}] Transcript corrected: "${transcript}" → "${enrichedTranscript}" (pending: ${qType})`
          );
          this.logger?.transcriptCorrection(
            transcript,
            enrichedTranscript,
            `pending: ${qType}`
          );
        }
        // HARD OVERRIDE: When buy_or_lease is pending, ANY short farewell-sounding
        // response MUST be interpreted as "buy". Claude's Haiku model repeatedly
        // ignores the system prompt instruction and ends the call instead.
        // This is not optional — it's a business-critical correction.
        else {
          const farewell = /^(bye|goodbye|good bye|goodnight|adios|adiós|see ya|later|peace|take care)[.!?,\s]*$/i;
          if (farewell.test(lower)) {
            enrichedTranscript = 'To buy.';
            console.log(
              `🔄 [${this.callSid}] HARD OVERRIDE: "${transcript}" → "${enrichedTranscript}" (buy_or_lease pending — farewell impossible here)`
            );
            this.logger?.transcriptCorrection(
              transcript,
              enrichedTranscript,
              `HARD OVERRIDE: buy_or_lease pending`
            );
          }
        }
      }
      this.analyzer.clearPendingQuestion();
    }

    try {
      let fullText = '';
      let preToolText = ''; // Backup of text before tool call (restored if no post-tool text)
      let shouldEndCall = false;

      // Decide filler language from the actual transcript the caller just spoke,
      // not just `callerLang`. Flux Multilingual occasionally omits the
      // `languages` array on short or ambiguous utterances, which leaves
      // `callerLang` stuck on its default 'en' even when the caller is clearly
      // speaking Spanish. Use two complementary detectors and prefer 'es' if
      // either is confident — an English filler on a Spanish call is jarring,
      // while a Spanish filler on an English call basically never happens
      // because both detectors are conservative about Spanish.
      const turnLang: 'en' | 'es' =
        this.callerLang === 'es' ||
        detectLanguage(enrichedTranscript) === 'es' ||
        this.analyzer.getLang() === 'es'
          ? 'es'
          : 'en';
      if (turnLang !== this.callerLang) {
        console.log(
          `🌐 [${this.callSid}] Language from transcript: ${this.callerLang} → ${turnLang}`
        );
        this.callerLang = turnLang;
      }

      // Tool-aware filler map: when Claude calls a tool, play the right filler.
      // This fires the INSTANT Claude decides to use a tool — zero guessing.
      const TOOL_FILLERS: Record<string, FillerKey> = {
        search_properties: turnLang === 'es' ? 'es_search' : 'en_search',
        log_lead: turnLang === 'es' ? 'es_generic' : 'en_generic',
        send_property_sms: turnLang === 'es' ? 'es_generic' : 'en_generic',
      };

      this.logger?.claudeCall(enrichedTranscript);
      const result = await chatStream(
        this.callSid,
        this.callerPhone,
        enrichedTranscript,
        (chunk: string) => {
          if (gen !== this.generationId) return;
          if (!firstChunkReceived) {
            const ttft = Date.now() - t0;
            console.log(`⏱️ [${this.callSid}] Claude First Token: ${ttft}ms`);
            this.logger?.claudeFirstToken(ttft);
            firstChunkReceived = true;
          }
          fullText += chunk;
        },
        // Tool callback: fires immediately when Claude starts a tool call
        (toolName: string) => {
          if (gen !== this.generationId) return;
          if (toolFillerFired) return; // Only one filler per turn

          // Save pre-tool text as backup. If Claude produces post-tool text, we
          // discard this (preamble like "Let me search..." is redundant with the filler).
          // If Claude produces NO post-tool text (e.g. log_lead with all text before
          // the tool), we restore it so the caller isn't left in silence.
          if (fullText.trim()) {
            preToolText = fullText;
            console.log(
              `🗑️ [${this.callSid}] Stripped pre-tool preamble: "${fullText.trim().substring(0, 80)}${fullText.length > 80 ? '...' : ''}"`
            );
            fullText = '';
          }

          const fillerKey = FILLER_ENABLED ? TOOL_FILLERS[toolName] : null;
          if (fillerKey) {
            toolFillerFired = true;
            console.log(`💭 [${this.callSid}] Tool filler: ${toolName} → ${fillerKey}`);
            this.sendFiller(fillerKey);
          }
        },
      );

      shouldEndCall = result.shouldEndCall;

      if (gen !== this.generationId) {
        console.log(
          `🗑️ [${this.callSid}] Stale (gen ${gen} vs ${this.generationId})`
        );
        return;
      }

      // If pre-tool text was stripped but Claude produced NO post-tool text,
      // restore the pre-tool text so the caller isn't left in silence.
      // (e.g. Claude says "Got it, Jesus!" then calls log_lead with no follow-up)
      if (!fullText?.trim() && preToolText.trim()) {
        console.log(
          `🔄 [${this.callSid}] Restored pre-tool text (no post-tool text): "${preToolText.trim().substring(0, 80)}"`
        );
        fullText = preToolText;
      }

      // If Claude used end_call tool with no text (tool-only response),
      // still schedule the hangup — don't let the empty text skip it.
      if (!fullText?.trim()) {
        if (shouldEndCall) {
          console.log(
            `📴 [${this.callSid}] Claude used end_call (no text). Scheduling hangup.`
          );
          this.logger?.hangup('end_call_no_text');
          this.scheduleHangup();
          // Wait for any reactive filler to finish, then hang up
          if (this.fillerStream) {
            await this.fillerStream.waitForCompletion();
            await this.waitForPlayback(`filler_${gen}`, 5000);
            this.fillerStream = null;
          }
          // 8s timeout: enough for any buffered audio to finish playing
          this.waitForPlayback(`hangup_${gen}`, 8000).then(() => {
            if (gen === this.generationId && this.pendingHangup) {
              this.pendingHangup = false;
              this.hangupCall();
            }
          });
        } else {
          this.isProcessing = false;
        }
        return;
      }

      // Wait for tool filler to finish playing (if it fired)
      if (toolFillerFired && this.fillerStream) {
        await this.fillerStream.waitForCompletion();
        await this.waitForPlayback(`filler_${gen}`, 5000);
        this.fillerStream = null;
      }

      // 2. ASSERTION: Wait for ANY current audio (filler OR previous response)
      // to finish playing before moving to the next turn.
      if (this.currentTTSStream) {
        console.log(`⏳ [${this.callSid}] Waiting for playback assertion...`);
        await this.currentTTSStream.waitForCompletion();
      }

      this.fillerStartTime = 0;

      // Track the full response text for barge-in context
      this.lastResponseText = fullText;

      // 3. Clear Twilio buffer ONLY after assertion is complete
      this.clearAudio();
      this.logger?.twilioAudioClear();

      const lang = this.callerLang === 'es' ? 'es' : detectLanguage(fullText);

      // 4. Create NEW stream for the full response
      this.logger?.ttsStart(fullText, lang);
      let ttsFirstChunkLogged = false;
      this.currentTTSStream = new ElevenLabsStream(
        (base64Audio) => {
          if (gen === this.generationId) {
            if (!ttsFirstChunkLogged) {
              this.logger?.ttsFirstChunk();
              ttsFirstChunkLogged = true;
            }
            this.sendBase64Audio(base64Audio);
          }
        },
        () => {
          // Wait for Twilio to confirm the caller actually heard the audio.
          // Timeout scales with response length — TTS reads ~2.5 words/sec on phone.
          const wordCount = fullText.split(/\s+/).length;
          const estimatedPlaybackMs = Math.max(
            10_000,
            (wordCount / 2.5) * 1000 + 5000
          );
          this.waitForPlayback(`resp_${gen}`, estimatedPlaybackMs).then(() => {
            if (gen !== this.generationId) return;

            this.isProcessing = false;
            this.lastResponseText = ''; // Response fully delivered
            console.log(
              `🔓 [${this.callSid}] AI Lock released (playback confirmed)`
            );
            this.logger?.lockReleased('playback_confirmed');
            this.logger?.ttsComplete();

            // If farewell was spoken, hang up now that the caller heard it
            if (this.pendingHangup) {
              this.pendingHangup = false;
              this.logger?.hangup('farewell_confirmed');
              this.hangupCall();
              return;
            }

            // Process any transcripts that were stashed during playback
            if (this.pendingTranscripts.length > 0) {
              const combined = this.pendingTranscripts.join(' ');
              this.pendingTranscripts = [];

              // Skip stashed text that's a duplicate/subset of the previous turn.
              // This catches late-arriving STT segments from the same utterance
              // that triggered a barge-in (e.g. "The first one." arriving after
              // "The the first one. I like the first one. I that's the one I want."
              // was already sent).
              const normStash = combined.toLowerCase().replace(/[.!?,]/g, '').trim();
              const normPrev = this.lastProcessedTranscript.toLowerCase().replace(/[.!?,]/g, '').trim();
              if (normStash && normPrev && normPrev.includes(normStash)) {
                console.log(
                  `🗑️ [${this.callSid}] Skipped stashed duplicate: "${combined}" (subset of prev turn)`
                );
              } else {
                console.log(
                  `📬 [${this.callSid}] Processing stashed transcripts: "${combined}"`
                );
                this.logger?.stashProcessed(combined);

                // Feed the stashed text through the analyzer
                this.analyzer.reset();
                this.analyzer.onFinal({
                  text: combined,
                  words: combined.split(/\s+/).map((w) => ({
                    word: w,
                    start: 0,
                    end: 0,
                    confidence: 0.85, // Reasonable default for stashed transcripts
                  })),
                  segmentConfidence: 0.85,
                });

                const decision = this.analyzer.getDecision();
                if (decision.action === 'respond' && decision.cleanedText) {
                  this.finalTranscripts = [decision.cleanedText];
                  this.flushAndRespond();
                } else if (combined.trim().length >= 2) {
                  // Even if analyzer says discard, if there's meaningful text, respond
                  this.finalTranscripts = [combined];
                  this.flushAndRespond();
                }
              }
            }
          });
        },
        (err) => {
          console.error(`TTS Error:`, err);
          if (gen === this.generationId) this.isProcessing = false;
        },
        { lang }
      );

      this.currentTTSStream.pushText(fullText);
      this.currentTTSStream.finish();

      const totalMs = Date.now() - t0;
      console.log(`⏱️ [${this.callSid}] Claude total: ${totalMs}ms`);
      this.logger?.claudeComplete(totalMs, fullText);
      this.log('ai', fullText);

      // Analyze AI output for pending questions
      this.detectPendingQuestion(fullText);

      if (shouldEndCall) {
        console.log(`📴 [${this.callSid}] Claude used end_call tool.`);
        this.scheduleHangup();
      }
    } catch (err) {
      if (gen !== this.generationId) return;
      console.error(`Response error:`, err);
      this.isProcessing = false;
      this.streamToTTS('Disculpe, hubo un error. ¿Puede repetir?');
    }
  }

  // ---------------------------------------------------------------------------
  // One-shot TTS — for greeting, DTMF switch, error messages
  // ---------------------------------------------------------------------------

  private streamToTTS(text: string): void {
    const gen = ++this.generationId;
    this.isProcessing = true;

    const lang = this.callerLang === 'es' ? 'es' : detectLanguage(text);

    this.currentTTSStream = new ElevenLabsStream(
      (base64Audio) => {
        if (gen === this.generationId) this.sendBase64Audio(base64Audio);
      },
      () => {
        // Wait for the caller to actually hear the audio before unlocking
        this.waitForPlayback(`tts_${gen}`).then(() => {
          if (gen === this.generationId) {
            console.log('✅ TTS playback confirmed - Unlocking AI');
            this.isProcessing = false;
          }
        });
      },
      (err) => {
        console.error(`TTS Error:`, err);
        if (gen === this.generationId) this.isProcessing = false;
      },
      { lang }
    );

    this.currentTTSStream.pushText(text);
    this.currentTTSStream.finish();
  }

  // ---------------------------------------------------------------------------
  // Hangup — end the call after farewell audio plays
  // ---------------------------------------------------------------------------

  private scheduleHangup(): void {
    // Don't hang up on a fixed timer — wait for the farewell audio to finish
    // playing. The TTS onComplete callback checks pendingHangup after the
    // Twilio mark confirms the caller heard the farewell.
    this.pendingHangup = true;
  }

  private async hangupCall(): Promise<void> {
    const accountSid =
      process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_SID || '';
    const authToken =
      process.env.TWILIO_AUTH_TOKEN || process.env.TWILIO_TOKEN || '';

    if (!accountSid || !authToken) {
      console.warn(
        `⚠️ [${this.callSid}] Cannot hang up — TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN env vars not set`
      );
      console.warn(`   Set these in Railway to enable automatic call hangup`);
      return;
    }

    try {
      console.log(`📴 [${this.callSid}] Hanging up call via Twilio API`);
      const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Calls/${this.callSid}.json`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization:
            'Basic ' +
            Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'Status=completed',
      });

      if (res.ok) {
        console.log(`✅ [${this.callSid}] Call terminated successfully`);
      } else {
        const errText = await res.text();
        console.error(
          `❌ [${this.callSid}] Hangup failed: ${res.status} ${errText}`
        );
      }
    } catch (err) {
      console.error(`❌ [${this.callSid}] Hangup error:`, err);
    }
  }

  // ---------------------------------------------------------------------------
  // Audio
  // ---------------------------------------------------------------------------

  private sendBase64Audio(base64Payload: string): void {
    if (this.ws.readyState !== WebSocket.OPEN) {
      console.warn(
        `⚠️ [${this.callSid}] Tried to send audio but WS state: ${this.ws.readyState}`
      );
      return;
    }
    try {
      this.ws.send(
        JSON.stringify({
          event: 'media',
          streamSid: this.streamSid,
          media: { payload: base64Payload },
        })
      );
    } catch (err: any) {
      console.error(`❌ [${this.callSid}] WS send error:`, err.message);
    }
  }

  private clearAudio(): void {
    if (this.ws.readyState !== WebSocket.OPEN) return;
    try {
      this.ws.send(
        JSON.stringify({ event: 'clear', streamSid: this.streamSid })
      );
    } catch (err: any) {
      console.error(`❌ [${this.callSid}] WS clear error:`, err.message);
    }
  }

  /**
   * Send a Twilio mark and wait for playback confirmation.
   * Returns when the caller has actually heard all audio up to this point.
   * Falls back to a timeout if Twilio never sends the mark back (e.g., caller hung up).
   */
  private waitForPlayback(markName: string, timeoutMs = 10_000): Promise<void> {
    return new Promise((resolve) => {
      // Fallback timeout — if mark never comes back (caller hung up, etc.)
      const timer = setTimeout(() => {
        this.markResolvers.delete(markName);
        this.markTimers.delete(markName);
        console.log(
          `⏰ [${this.callSid}] Mark timeout: ${markName} (${timeoutMs}ms)`
        );
        this.logger?.twilioMarkTimeout(markName, timeoutMs);
        resolve();
      }, timeoutMs);

      // Store timer reference so cancel() can clear it
      this.markTimers.set(markName, timer);

      this.markResolvers.set(markName, () => {
        clearTimeout(timer);
        this.markTimers.delete(markName);
        resolve();
      });

      if (this.ws.readyState === WebSocket.OPEN) {
        try {
          this.ws.send(
            JSON.stringify({
              event: 'mark',
              streamSid: this.streamSid,
              mark: { name: markName },
            })
          );
        } catch {
          clearTimeout(timer);
          this.markTimers.delete(markName);
          this.markResolvers.delete(markName);
          resolve();
        }
      } else {
        clearTimeout(timer);
        this.markTimers.delete(markName);
        this.markResolvers.delete(markName);
        resolve();
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Summary and cleanup
  // ---------------------------------------------------------------------------

  private printSummary(): void {
    const turns = this.conversationLog.filter((e) => e.speaker !== 'system');
    if (!turns.length) return;

    console.log(`\n${'='.repeat(60)}`);
    console.log(
      `📋 TRANSCRIPT: ${this.callSid} | From: ${this.callerPhone} | Turns: ${turns.length}`
    );
    console.log(`${'='.repeat(60)}`);
    for (const e of turns) {
      const t = new Date(e.timestamp).toLocaleTimeString();
      console.log(
        `  [${t}] ${e.speaker === 'caller' ? 'CALLER' : 'AI    '}: ${e.text}`
      );
    }

    const leads = getLeads().filter((l) => l.callerPhone === this.callerPhone);
    if (leads.length) {
      console.log(`\n  📋 LEADS:`);
      for (const l of leads) {
        console.log(
          `     ${l.callerName || '?'} → ${l.propertyAddress || l.interest}`
        );
        if (l.notes) console.log(`     Notes: ${l.notes}`);
      }
    }
    console.log(`${'='.repeat(60)}\n`);
  }

  private cleanup(): void {
    if (this.fluxConnection) {
      this.fluxConnection.close();
      this.fluxConnection = null;
    }
    if (this.deepgramLive) {
      try {
        this.deepgramLive.finish();
      } catch {}
      this.deepgramLive = null;
    }
    if (this.currentTTSStream) {
      this.currentTTSStream.abort();
      this.currentTTSStream = null;
    }
    for (const timer of this.markTimers.values()) clearTimeout(timer);
    this.markTimers.clear();
    this.markResolvers.clear();
    this.pendingTranscripts = [];
    if (this.callSid) clearConversation(this.callSid);
  }

  // ---------------------------------------------------------------------------
  // Barge-in context — track what was actually spoken vs interrupted
  // ---------------------------------------------------------------------------

  /**
   * Compute what text wasn't spoken based on ElevenLabs alignment data.
   * Uses word-count matching for robustness against whitespace/char differences.
   */
  private computeUnspokenText(fullText: string, spokenText: string): string {
    const spoken = spokenText.trim();
    if (!spoken) return fullText;

    const spokenWordCount = spoken.split(/\s+/).filter(Boolean).length;
    const fullWords = fullText.split(/\s+/).filter(Boolean);

    if (spokenWordCount >= fullWords.length) return ''; // Everything was spoken
    return fullWords.slice(spokenWordCount).join(' ');
  }

  /**
   * Update Claude's conversation history after barge-in.
   * Replaces the last assistant message with only what was actually spoken,
   * plus context about what was interrupted so Claude can recover naturally.
   */
  private updateHistoryForBargeIn(
    spokenText: string,
    unspokenText: string
  ): void {
    const history = getConversation(this.callSid);

    // Find the last assistant message (string content, not tool blocks)
    for (let i = history.length - 1; i >= 0; i--) {
      if (
        history[i].role === 'assistant' &&
        typeof history[i].content === 'string'
      ) {
        // Replace with only what was spoken + interruption context
        history[i].content =
          spokenText.trim() +
          `\n[INTERRUPTED — the caller started speaking here and did not hear the rest. You were going to say: "${unspokenText.trim()}" — work this information into your next response naturally if still relevant.]`;

        const spokenWc = spokenText.trim().split(/\s+/).length;
        const unspokenWc = unspokenText.trim().split(/\s+/).length;
        console.log(
          `✂️ [${this.callSid}] Barge-in context: spoken ${spokenWc} words, unspoken ${unspokenWc} words`
        );
        console.log(
          `✂️ [${this.callSid}]   Spoken: "${spokenText.trim().substring(0, 100)}${spokenText.length > 100 ? '...' : ''}"`
        );
        console.log(
          `✂️ [${this.callSid}]   Unspoken: "${unspokenText.trim().substring(0, 100)}${unspokenText.length > 100 ? '...' : ''}"`
        );
        this.logger?.bargeInContext(spokenWc, unspokenWc, spokenText.trim());
        break;
      }
    }

    // Clear pending question if the question wasn't in the spoken part
    if (!spokenText.includes('?') && unspokenText.includes('?')) {
      this.analyzer.clearPendingQuestion();
      console.log(
        `🔄 [${this.callSid}] Cleared pending question (question was in unspoken portion)`
      );
    }
  }

  // ---------------------------------------------------------------------------
  // AI output analysis — detect pending questions
  // ---------------------------------------------------------------------------

  private detectPendingQuestion(aiText: string): void {
    const lower = aiText.toLowerCase();
    let detected: string | null = null;

    if (
      /buy or lease|comprar o alquilar|sale or lease|for sale or for lease|buying or leasing|purchase or lease/i.test(
        lower
      )
    ) {
      detected = 'buy_or_lease';
    } else if (
      /what type|property type|qué tipo|tipo de propiedad/i.test(lower)
    ) {
      detected = 'property_type';
    } else if (
      /what city|which city|which area|what area|qué ciudad|en qué zona|qué área/i.test(
        lower
      )
    ) {
      detected = 'location';
    } else if (
      /how big|how large|what size|how many square|cuántos pies|qué tamaño/i.test(
        lower
      )
    ) {
      detected = 'size';
    } else if (
      /budget|price range|how much|what.*budget|presupuesto|cuánto/i.test(lower)
    ) {
      detected = 'budget';
    } else if (
      /your name|what.*name|may i.*name|cómo se llama|su nombre/i.test(lower)
    ) {
      detected = 'name';
    } else if (/\?$/.test(aiText.trim())) {
      detected = 'open';
    }

    if (detected) {
      this.analyzer.setPendingQuestion(detected as any);
      this.logger?.pendingQuestion(detected);
    }
    // If no question detected, clear any pending question since the AI has moved on
  }
}
