# Security Track — Design Doc

Working spec for the security work approved at $1,500 / 2 weeks. Everything
below ships in a Salesforce sandbox first (Dev Edition org), then is promoted
to production after the agent roundtable validation at the 2-week mark.

---

## 1. Group-based edit restriction

> "Agents can only edit leads in their own group. Admins can edit everything."

### Approach: Validation Rule + multi-list junction object

A Lead can belong to **multiple lists** (per Fausto's approval of Option 1).
A new junction object — `Lead_List_Assignment__c` — connects Leads to Groups
many-to-many. Each assignment has a `Status__c` of "Pending" or "Approved".

```
Lead  ←──  Lead_List_Assignment__c (junction)  ──→  Group__c
                  │
                  ├─ Status__c (picklist: Pending / Approved)
                  ├─ Created_By  (system)
                  └─ Approved_By (User lookup, populated when approved)
```

**Why a junction, not a multi-select picklist on Lead:**
- Approval workflow needs per-assignment metadata (who approved, when)
- Reportable
- Future-proof for buyer-pool features (Stage 2 of the larger migration)

### Validation Rule (Lead object)

Blocks an edit by an agent when the edited Lead has no Approved Lead_List_Assignment
matching one of the agent's group memberships. Admins bypass via profile.

**Pseudocode (formula):**
```
AND(
  $Profile.Name <> 'System Administrator',
  $Profile.Name <> 'Account Manager',           /* admin variants */
  NOT(
    /* The agent has at least one approved assignment to a list this Lead is on */
    EXISTS_IN_AGENT_LISTS_AND_LEAD_LISTS()
  )
)
```

The actual formula will use a hidden helper roll-up summary or a formula field
on the Lead that summarizes "is current user in any approved list of this lead".
Specific formula draft to be finalized in Dev org once we can test against
real picklists.

### Approval workflow

When an agent adds a new `Lead_List_Assignment__c`:
- `Status__c` defaults to `Pending`
- Email alert fires to Fausto + assistant ("Approve or reject this assignment")
- They can approve from a simple Lightning page (or in bulk via list view)
- On approval, `Status__c → Approved` and `Approved_By` is stamped
- On rejection, the assignment is deleted

Admins can create directly in `Approved` state, skipping the workflow.

### What this does NOT do (intentional)

- **Does not** restrict viewing — agents see all leads (Fausto's stated preference)
- **Does not** block editing of "their own group's" leads even if they're also
  on someone else's list — overlap is allowed and intentional
- **Does not** prevent ownership changes — handled separately (see §3)

---

## 2. Sensitive field lockdown

**STATUS: DROPPED** per Fausto's email reply ("agents must be able to edit their
leads in case they attain better info"). No work needed. Recovery (§5) and
Field History Tracking (§4) cover the integrity concern that motivated this.

---

## 3. Export & API lockdown

> "Only you and your assistant can export leads. Agents lose export and API access."

### Profile-level removals (from "Account for Agents" profile)

| System Permission | Current | Target |
|---|---|---|
| Export Reports | ✅ enabled | ❌ removed |
| API Enabled | ✅ enabled | ❌ removed |
| Manage Public Reports | varies | ❌ removed |
| Run Reports | ✅ enabled | ✅ keep (needed for normal workflow) |
| View Setup and Configuration | varies | ❌ removed |

### Permission set: "Lead Data Export"

Created and assigned to:
- Fausto (cfm@faustocommercial.com)
- Nathalie (na@faustocommercial.com)
- Elizabeth (em@faustocommercial.com — also the integration user)

Grants:
- Export Reports
- API Enabled
- Weekly Data Export (already covered by admin profile)

### What this closes

- Reports → Export button → CSV download (the Nathalie-flagged exposure path)
- Data Loader and any third-party tool that uses the API user-identity
- Salesforce mobile app data export
- "Print" button is NOT covered — that's a screen-render path. We accept this.

---

## 4. Field History Tracking

> Already approved via Setup UI (separate task). 18-month retention, 20 fields:
> Owner, Status, Source, Name, Email, Phone, Mobile, Company, Address, City,
> State, Zip, Title, Owner Entity, Group, Lead Intent, Etico Status, Etico
> Substatus, Property, Owning Entity (LLC Name), Last Disposition (PhoneBurner).

No additional work — reports are queryable via the `LeadHistory` object.

### Reports we'll build

1. **"Lead Edits — last 7 days"** — every change with who/when/old/new
2. **"Owner Changes Audit"** — every Lead OwnerId change (theft signal)
3. **"Bulk Edit Detector"** — users with >50 lead edits in 24 hrs (anomaly)

Reports go in a private folder, accessible only to Fausto + assistant.

---

## 5. Weekly Data Export & Recovery Runbook

### Setup

Setup → Data Management → **Data Export** → Schedule Export
- Frequency: Weekly
- Day: Sunday
- Include all data
- Include images, documents, attachments: yes
- Include Chatter files: yes
- Notification email: Fausto + assistant

This is GUI-only, can't be scripted. Fausto or admin clicks once.

### Recovery Runbook (short doc to give Fausto)

```
INCIDENT: Suspected mass-edit / data vandalism

1. Identify scope
   - Open report "Bulk Edit Detector" — check users with abnormal counts
   - Open LeadHistory for the affected user/timeframe
   - Note record IDs, fields touched, timestamps

2. Export current state
   - Run Data Loader query for affected records → save as before-restore.csv
   - This preserves any legitimate concurrent edits

3. Restore from backup
   - Download last weekly export ZIP from Setup → Data Export
   - Extract Lead.csv
   - Filter to the affected record IDs
   - Use Data Loader UPDATE to restore those rows from backup

4. Replay legitimate edits
   - Compare before-restore.csv against backup → find edits we want to keep
   - Manually reconcile or skip if too noisy

5. Document
   - Who, what, when, scope, what was restored
   - File in /docs/incidents/
```

---

## 6. Multi-list junction (Option 1 from Fausto's email)

> "Leads can be on more than one list, agent adds, admin needs to approve"

### Schema

**New custom object: `Lead_List_Assignment__c`**

| Field | Type | Notes |
|---|---|---|
| Lead__c | Master-Detail(Lead) | Cascade delete if Lead is deleted |
| Group__c | Lookup(Group__c) | The list this assignment is for |
| Status__c | Picklist | Pending / Approved (default: Pending) |
| Approved_By__c | Lookup(User) | Stamped on approval |
| Approved_Date__c | DateTime | Stamped on approval |

**Page Layout**: minimal, mostly used as a related list on Lead.

### Migration of existing data

Currently every Lead has at most one `Group__c` (lookup). To migrate:
1. For every Lead with `Group__c` set, create a `Lead_List_Assignment__c`
   record with `Status__c = Approved` (legacy data is grandfathered).
2. Keep `Lead.Group__c` populated for backwards compatibility for now
   (the AI agent reads from it). Eventually deprecate.

### UI affordances

- New related list "Group Assignments" on the Lead page layout (default)
- Agent action: "Add to another group" → quick-create form → submits as Pending
- Admin action: list view "Pending Assignments" → bulk approve

---

## Order of deployment in Dev org

1. Create `Lead_List_Assignment__c` object + fields
2. Migrate existing `Lead.Group__c` values into junction records (script)
3. Build validation rule for group-based editing
4. Create permission set "Lead Data Export" + assign
5. Remove relevant permissions from "Account for Agents" profile
6. Build the 3 admin reports (LeadHistory queries)
7. Smoke test with a test agent user
8. Schedule Weekly Data Export
9. Document recovery runbook in /docs/

After 2-week roundtable validation: promote to production.

---

## Open questions (before deploying in Dev)

1. **What admin users should bypass the validation rule?** Currently only
   `System Administrator` profile. Are there other admin variants like
   "Etico Agents" that need bypass?
2. **Approval queue UI**: build a simple Lightning page, or leverage the
   built-in Approval Process feature? (Approval Processes are PE-supported.)
3. **Lead deletion**: should agents be allowed to delete? Currently profile
   probably allows it. Worth removing from "Account for Agents".
4. **Reports section exposure** (Nathalie's screenshot): we believe API +
   Export removal closes it, but worth verifying with the specific report
   path she flagged once we're in the Dev org.
