/**
 * Take a targeted backup of every SF record whose Group__c value could be
 * affected by the junction migration + security deploy.
 *
 * Scope:
 *   - Group__c        (full table — post-cleanup canonical state)
 *   - Lead            (Id, Group__c, OwnerId — junction reads from Group__c)
 *   - Property__c     (Id, Group__c — reassigned in this morning's cleanup)
 *   - Account         (Id, Group__c — reassigned in this morning's cleanup)
 *
 * Read-only. Standing approval per memory.
 *
 * If a deploy goes sideways:
 *   - For any Lead/Property/Account: look up its Id in this snapshot to find
 *     the Group__c value it had pre-deploy, and PATCH it back.
 *   - The Group__c snapshot is the full canonical 236-row table — we can
 *     diff later to spot any unintended renames or deletions.
 *
 * SF's native Data Export (Setup → Data Export) is the broader safety net;
 * this snapshot is the targeted one for THIS deploy specifically.
 *
 * Run:
 *   tsx --env-file .env.local scripts/diagnostics/snapshot-pre-junction-deploy.ts
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const OUT_PATH = path.join(
  REPO_ROOT,
  'data',
  'archive',
  `pre-junction-deploy-snapshot-${new Date().toISOString().slice(0, 10)}.json`
);

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}\n`);

  console.log('Pulling Group__c (full table)...');
  const groups = await sf.soql<any>(
    `SELECT Id, Name, CreatedDate, LastModifiedDate FROM Group__c ORDER BY Name`
  );
  console.log(`  ${groups.length} Group__c records`);

  console.log('Pulling Lead.Group__c values (only leads with a group set)...');
  const leadsWithGroup = await sf.soql<any>(
    `SELECT Id, Group__c, OwnerId FROM Lead WHERE Group__c != null`
  );
  console.log(`  ${leadsWithGroup.length} Leads with Group__c set`);

  console.log('Pulling Property__c.Group__c values...');
  const propsWithGroup = await sf.soql<any>(
    `SELECT Id, Name, Group__c FROM Property__c WHERE Group__c != null`
  );
  console.log(`  ${propsWithGroup.length} Properties with Group__c set`);

  console.log('Pulling Account.Group__c values...');
  const accountsWithGroup = await sf.soql<any>(
    `SELECT Id, Name, Group__c FROM Account WHERE Group__c != null`
  );
  console.log(`  ${accountsWithGroup.length} Accounts with Group__c set`);

  const snapshot = {
    generated_at: new Date().toISOString(),
    target: 'prod',
    purpose: 'pre-junction-deploy backup',
    counts: {
      groups: groups.length,
      leads_with_group: leadsWithGroup.length,
      properties_with_group: propsWithGroup.length,
      accounts_with_group: accountsWithGroup.length,
    },
    groups,
    leads_with_group: leadsWithGroup,
    properties_with_group: propsWithGroup,
    accounts_with_group: accountsWithGroup,
  };

  fs.writeFileSync(OUT_PATH, JSON.stringify(snapshot, null, 2));
  console.log(`\n📦 Snapshot saved: ${path.relative(REPO_ROOT, OUT_PATH)}`);
  console.log(`   Size: ${(fs.statSync(OUT_PATH).size / 1024).toFixed(0)} KB`);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
