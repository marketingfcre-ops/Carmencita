/**
 * Read-only audit of duplicate-group state across all WP property posts.
 *
 * For every address that has 2+ posts, shows:
 *   - All posts at that address (id, status, date, [DUPLICATE] tag, points-to id)
 *   - Whether the group is well-formed:
 *       ✅ exactly 1 canonical (no [DUPLICATE] prefix) + rest tagged & in draft
 *       ⚠️ all tagged [DUPLICATE] (pointing at each other) — needs fixing
 *       ⚠️ multiple posts NOT tagged (no clear canonical) — needs fixing
 *       ⚠️ canonical itself is in draft (unusual but maybe intentional)
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-duplicate-pairs-audit.ts
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function fetchAll(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function normalizeAddress(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().split(',')[0];
  a = a.replace(/[#.]/g, ' ');
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

// Extract the wp:<id> reference from a [DUPLICATE - see wp:NNN] title prefix.
// Handles both the literal "–" en-dash and the &#8211; HTML entity form WP returns.
function extractCanonicalRef(title: string): number | null {
  // Strip HTML entities to literal characters for regex matching
  const t = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const m = t.match(/\[DUPLICATE[\s\S]*?see wp:(\d+)\]/i);
  return m ? parseInt(m[1], 10) : null;
}

function isDuplicateTagged(title: string): boolean {
  return /\[DUPLICATE/i.test(title);
}

interface Group {
  address: string;
  posts: WpPost[];
}

async function main() {
  if (!WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing WP creds.');
    process.exit(1);
  }

  console.log('\n🔍 Duplicate group audit\n');

  const all = await fetchAll();
  console.log(`Total posts fetched: ${all.length}\n`);

  // Group by normalized address
  const byAddr = new Map<string, WpPost[]>();
  for (const p of all) {
    const key = normalizeAddress(p.fave_property_address);
    if (!key) continue;
    const arr = byAddr.get(key) || [];
    arr.push(p);
    byAddr.set(key, arr);
  }

  // Only groups with 2+
  const groups: Group[] = [];
  for (const [addr, posts] of byAddr.entries()) {
    if (posts.length > 1) groups.push({ address: addr, posts });
  }

  console.log(`Address groups with 2+ posts: ${groups.length}\n`);

  let wellFormed = 0;
  let allTagged = 0;
  let noClearCanonical = 0;
  let otherWeirdness = 0;
  const problems: Group[] = [];

  for (const g of groups) {
    const tagged = g.posts.filter((p) => isDuplicateTagged(p.title));
    const untagged = g.posts.filter((p) => !isDuplicateTagged(p.title));

    if (untagged.length === 1 && tagged.length === g.posts.length - 1) {
      // Ideal: one canonical, rest tagged
      // Also check that all tagged are drafts
      const taggedNotDraft = tagged.filter((p) => p.status !== 'draft');
      if (taggedNotDraft.length === 0) {
        wellFormed++;
        continue;
      } else {
        otherWeirdness++;
        problems.push(g);
        continue;
      }
    }
    if (untagged.length === 0) {
      // All posts tagged [DUPLICATE] — the "both pointing at each other" case
      allTagged++;
      problems.push(g);
      continue;
    }
    if (untagged.length > 1) {
      // Multiple posts without [DUPLICATE] — no clear canonical
      noClearCanonical++;
      problems.push(g);
      continue;
    }
    otherWeirdness++;
    problems.push(g);
  }

  console.log('── Group health summary ──');
  console.log(`   ✅ Well-formed (1 canonical, rest tagged drafts):  ${wellFormed}`);
  console.log(`   ⚠️  All tagged [DUPLICATE] (cycle):                 ${allTagged}`);
  console.log(`   ⚠️  Multiple untagged (no clear canonical):         ${noClearCanonical}`);
  console.log(`   ⚠️  Other (tagged but not draft, etc.):             ${otherWeirdness}`);
  console.log(`   ── Total problem groups: ${problems.length} ──`);

  if (problems.length === 0) {
    console.log('\n✅ Everything looks well-formed.\n');
    process.exit(0);
  }

  console.log('\n── Problem groups in detail ──\n');
  for (const g of problems) {
    console.log(`Address: "${g.address}"`);
    for (const p of g.posts.sort((a, b) => a.date.localeCompare(b.date))) {
      const tag = isDuplicateTagged(p.title) ? `[DUP→wp:${extractCanonicalRef(p.title)}]` : '[CANONICAL?]';
      const photo = p.featured_media > 0 ? '📷' : '🚫';
      console.log(
        `   wp:${p.id.toString().padEnd(6)} ${p.status.padEnd(8)} ${p.date.slice(0, 10)} ${photo} ${tag}  "${p.title.replace(/&#8211;/g, '–').slice(0, 70)}"`
      );
    }
    console.log('');
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
