/**
 * Fuzzy property search engine.
 *
 * Multi-strategy scored search adapted from breed fuzzy search pattern:
 * 1. Bidirectional normalization (abbreviations ↔ full forms)
 * 2. Token-based scoring with 3 strategies (word match, substring, sequence)
 * 3. Field weighting (address > neighborhood > city > name > description)
 * 4. Geography-aware proximity boosting via geography.ts
 * 5. Pre-computed index for fast queries
 */

import type { Property } from './listings';
import {
  expandHighwayAliases,
  getNearbyAreas,
  locateAddress,
  parseAddressGrid,
  getAllAreaNames,
  getAreaInfo,
} from './geography';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface IndexedProperty {
  property: Property;
  fields: IndexedField[];
}

interface IndexedField {
  name: string;
  normalized: string; // lowercased + abbreviation-expanded text
  weight: number;
}

interface ScoredResult {
  property: Property;
  score: number;
}

// ---------------------------------------------------------------------------
// Abbreviation tables — bidirectional normalization
// ---------------------------------------------------------------------------

const DIRECTION_ABBREVS: Record<string, string> = {
  'nw': 'northwest', 'ne': 'northeast', 'sw': 'southwest', 'se': 'southeast',
  'n': 'north', 's': 'south', 'e': 'east', 'w': 'west',
};

const STREET_ABBREVS: Record<string, string> = {
  'st': 'street', 'ave': 'avenue', 'blvd': 'boulevard', 'rd': 'road',
  'dr': 'drive', 'ct': 'court', 'ln': 'lane', 'ter': 'terrace',
  'pl': 'place', 'pkwy': 'parkway', 'hwy': 'highway', 'cir': 'circle',
  'expy': 'expressway',
};

const REVERSE_DIRECTIONS: Record<string, string> = {};
for (const [abbr, full] of Object.entries(DIRECTION_ABBREVS)) {
  REVERSE_DIRECTIONS[full] = abbr;
}

const REVERSE_STREETS: Record<string, string> = {};
for (const [abbr, full] of Object.entries(STREET_ABBREVS)) {
  REVERSE_STREETS[full] = abbr;
}

// Noise words to strip from queries
const NOISE_WORDS = new Set([
  'the', 'a', 'an', 'in', 'on', 'at', 'near', 'by', 'around', 'of', 'for',
  'and', 'or', 'with', 'to', 'from', 'is', 'are', 'i', 'we', 'me',
  'looking', 'want', 'need', 'find', 'search', 'show', 'have', 'any',
  'do', 'you', 'something', 'anything', 'properties', 'property', 'listings',
  'el', 'la', 'los', 'las', 'en', 'de', 'del', 'por', 'un', 'una',
]);

// ---------------------------------------------------------------------------
// Normalization — bidirectional abbreviation expansion
// ---------------------------------------------------------------------------

/**
 * Normalize text by appending both abbreviated and expanded forms.
 * "S DIXIE HWY" → "s south dixie hwy highway"
 * "Dixie Highway" → "dixie highway hwy"
 */
function normalizeText(text: string): string {
  if (!text) return '';
  const lower = text.toLowerCase();
  const words = lower.split(/[\s,/;]+/).filter(Boolean);
  const expanded: string[] = [];

  for (const word of words) {
    expanded.push(word);

    // Expand abbreviations → full
    if (DIRECTION_ABBREVS[word]) {
      expanded.push(DIRECTION_ABBREVS[word]);
    }
    if (STREET_ABBREVS[word]) {
      expanded.push(STREET_ABBREVS[word]);
    }

    // Contract full → abbreviation
    if (REVERSE_DIRECTIONS[word]) {
      expanded.push(REVERSE_DIRECTIONS[word]);
    }
    if (REVERSE_STREETS[word]) {
      expanded.push(REVERSE_STREETS[word]);
    }
  }

  return expanded.join(' ');
}

// ---------------------------------------------------------------------------
// Search index — pre-computed at startup / Salesforce refresh
// ---------------------------------------------------------------------------

let searchIndex: IndexedProperty[] = [];

/**
 * Build the search index. Called once at startup and on each SF refresh.
 */
export function buildSearchIndex(properties: Property[]): void {
  searchIndex = properties.map((p) => ({
    property: p,
    fields: [
      { name: 'address', normalized: normalizeText(p.address), weight: 3.0 },
      { name: 'neighborhood', normalized: normalizeText(p.neighborhood || ''), weight: 2.5 },
      { name: 'city', normalized: normalizeText(p.city), weight: 2.0 },
      { name: 'name', normalized: normalizeText(p.name), weight: 1.5 },
      { name: 'description', normalized: normalizeText(p.description || ''), weight: 1.5 },
      { name: 'tags', normalized: normalizeText(p.tags || ''), weight: 1.0 },
      { name: 'zoning', normalized: normalizeText(p.zoning || ''), weight: 0.5 },
      { name: 'propertyType', normalized: normalizeText(p.propertyType), weight: 1.5 },
      { name: 'listingType', normalized: normalizeText(p.listingType), weight: 1.0 },
    ],
  }));
  console.log(`🔍 Search index built: ${searchIndex.length} properties`);
}

// ---------------------------------------------------------------------------
// Scoring strategies
// ---------------------------------------------------------------------------

/**
 * Strategy 1: Word boundary match — highest quality.
 * Checks if token appears as a complete word in the field.
 */
function wordMatchScore(token: string, field: string): number {
  try {
    const re = new RegExp(`\\b${escapeRegex(token)}\\b`, 'i');
    return re.test(field) ? 85 : 0;
  } catch {
    return 0;
  }
}

/**
 * Strategy 2: Substring match — position-aware.
 * Earlier position in the string scores higher.
 */
function substringScore(token: string, field: string): number {
  const idx = field.indexOf(token);
  if (idx === -1) return 0;
  // Score 60-70 based on position (earlier = better)
  const positionBonus = Math.max(0, 10 - Math.floor(idx / 20));
  return 60 + positionBonus;
}

/**
 * Strategy 3: Character sequence match — handles typos.
 * Characters of token appear in order within field.
 */
function sequenceScore(token: string, field: string): number {
  if (token.length < 3) return 0; // Too short for sequence matching

  let ti = 0;
  let gaps = 0;
  let lastMatchIdx = -1;

  for (let fi = 0; fi < field.length && ti < token.length; fi++) {
    if (field[fi] === token[ti]) {
      if (lastMatchIdx >= 0) gaps += fi - lastMatchIdx - 1;
      lastMatchIdx = fi;
      ti++;
    }
  }

  if (ti < token.length) return 0; // Not all chars found

  const coverage = token.length / (gaps + token.length);
  return Math.floor(40 * coverage); // 0-40 score
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Score a single token against a single field (best of 3 strategies).
 */
function scoreTokenField(token: string, field: string): number {
  if (!token || !field) return 0;
  return Math.max(
    wordMatchScore(token, field),
    substringScore(token, field),
    sequenceScore(token, field)
  );
}

// ---------------------------------------------------------------------------
// Query expansion
// ---------------------------------------------------------------------------

/**
 * Expand a query into search tokens:
 * 1. Normalize text
 * 2. Tokenize and filter noise
 * 3. Expand grid addresses ("215th" → also "21500", "215")
 * 4. Expand highway aliases ("us-1" → "dixie", "dixie hwy", ...)
 * 5. Inject geography proximity tokens
 */
function expandQuery(query: string): string[] {
  const normalized = normalizeText(query);
  const rawTokens = normalized.split(/\s+/).filter((t) => t.length > 0 && !NOISE_WORDS.has(t));

  const tokens = new Set<string>(rawTokens);

  for (const token of rawTokens) {
    // Grid address expansion: "215th" → "21500", "215"
    const gridMatch = token.match(/^(\d{1,3})(th|st|nd|rd)?$/);
    if (gridMatch) {
      const num = parseInt(gridMatch[1], 10);
      if (num >= 1 && num <= 350) {
        tokens.add(String(num));
        tokens.add(String(num * 100));     // 215 → 21500
        tokens.add(String(num * 100 + 0)); // redundant but clear
        // Also try with trailing zeros for block matching
        if (num < 10) tokens.add(String(num * 100));
      }
    }

    // Large building number → possible street reference: "21500" → "215"
    const buildingMatch = token.match(/^(\d{4,6})$/);
    if (buildingMatch) {
      const num = parseInt(buildingMatch[1], 10);
      const streetRef = Math.floor(num / 100);
      if (streetRef > 0 && streetRef < 400) {
        tokens.add(String(streetRef));
      }
    }

    // Highway alias expansion
    const aliases = expandHighwayAliases(token);
    for (const alias of aliases) {
      // Multi-word aliases get split into tokens
      for (const part of alias.split(/\s+/)) {
        tokens.add(part);
      }
    }
  }

  return [...tokens];
}

/**
 * Extract geography bonus tokens from a query.
 * When someone says "near 215th" we inject area names like "cutler bay", "homestead"
 * as soft-boost tokens (lower weight so they don't overpower direct matches).
 */
function getGeographyBonusTokens(query: string): string[] {
  const lower = query.toLowerCase();
  const bonusTokens: string[] = [];

  // Extract street number for geographic positioning
  const streetMatch = lower.match(/\b(\d{1,3})\s*(?:th|st|nd|rd)?\b/);
  if (streetMatch) {
    const num = parseInt(streetMatch[1], 10);
    if (num > 0 && num < 350) {
      const areas = locateAddress(num, null, null);
      for (const area of areas) {
        bonusTokens.push(area);
      }
    }
  }

  // Check for named areas and add their neighbors
  const allNames = getAllAreaNames();
  for (const name of allNames) {
    if (name.length > 2 && lower.includes(name)) {
      const nearby = getNearbyAreas(name);
      bonusTokens.push(...nearby);
      break; // Only match the first area
    }
  }

  return [...new Set(bonusTokens)];
}

// ---------------------------------------------------------------------------
// Use-type aliases
// ---------------------------------------------------------------------------

// Use-type terms callers say that are often present only in description/tags,
// not in the structured propertyType field. When one of these appears in a
// query, we boost description/tags matches so the relevant listing surfaces.
const USE_TYPE_ALIASES = [
  'hotel',
  'motel',
  'hospitality',
  'gas station',
  'auto body',
  'body shop',
  'medical',
  'church',
  'school',
  'daycare',
  'restaurant',
  'bar',
  'warehouse',
  'self storage',
  'storage',
];

function extractUseTypeAliases(query: string): string[] {
  const lower = query.toLowerCase();
  return USE_TYPE_ALIASES.filter((a) => lower.includes(a));
}

// ---------------------------------------------------------------------------
// Main search function
// ---------------------------------------------------------------------------

/**
 * Fuzzy search properties by keyword.
 * Returns scored results sorted by relevance.
 */
export function fuzzySearchProperties(keyword: string, limit = 15): ScoredResult[] {
  if (!keyword || !keyword.trim() || searchIndex.length === 0) return [];

  const tokens = expandQuery(keyword);
  const geoBonus = getGeographyBonusTokens(keyword);
  const useTypeAliases = extractUseTypeAliases(keyword);

  if (tokens.length === 0) return [];

  const results: ScoredResult[] = [];

  for (const entry of searchIndex) {
    let totalScore = 0;
    let tokensMatched = 0;

    // Score main tokens against all fields
    for (const token of tokens) {
      let bestTokenScore = 0;

      for (const field of entry.fields) {
        const raw = scoreTokenField(token, field.normalized);
        const weighted = raw * field.weight;
        if (weighted > bestTokenScore) {
          bestTokenScore = weighted;
        }
      }

      if (bestTokenScore > 0) {
        totalScore += bestTokenScore;
        tokensMatched++;
      }
    }

    // Use-type alias bonus — when caller says "hotel", reward strong matches
    // in description/tags/propertyType so the use-type drives the result.
    for (const alias of useTypeAliases) {
      for (const field of entry.fields) {
        if (
          field.name === 'description' ||
          field.name === 'tags' ||
          field.name === 'propertyType'
        ) {
          const raw = scoreTokenField(alias, field.normalized);
          if (raw > 0) {
            totalScore += raw * 2.0;
          }
        }
      }
    }

    // Geography bonus — softer boost (0.3x weight) for area proximity
    for (const geoToken of geoBonus) {
      for (const field of entry.fields) {
        if (field.name === 'city' || field.name === 'neighborhood') {
          const raw = wordMatchScore(geoToken, field.normalized);
          if (raw > 0) {
            totalScore += raw * field.weight * 0.3;
          }
        }
      }
    }

    // Coverage bonus: matching more query tokens = significantly better
    if (tokens.length > 1 && tokensMatched > 0) {
      const coverage = tokensMatched / tokens.length;
      totalScore *= 1 + coverage * 0.5; // Up to 1.5x multiplier
    }

    if (totalScore > 0) {
      results.push({ property: entry.property, score: totalScore });
    }
  }

  // Sort by score descending
  results.sort((a, b) => b.score - a.score);

  return results.slice(0, limit);
}
