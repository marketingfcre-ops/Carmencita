/**
 * Migration: Fausto's Excel (agent → groups) → User_Group_Access__c (junction)
 *
 * Reads:
 *   data/archive/agent-groups-fausto-2026-05-20.json
 *     (the May 20 Excel snapshot — list of {agent, group} assignments)
 *   data/archive/orphan-matches-2026-05-24.json
 *     (HIGH-confidence + promoted-MEDIUM matches from the orphan matcher —
 *      these tell us "Excel group X is actually SF Group__c with name Y")
 *
 * For each (agent, group) pair in the Excel:
 *   1. Find the matching SF User by Name (47/47 verified to match)
 *   2. Find the matching SF Group__c by name (using exact + fuzzy via the
 *      orphan matcher output)
 *   3. Create one User_Group_Access__c record with Status='Approved'
 *      (existing assignments are grandfathered as Approved — agents won't
 *      need re-approval for groups they're already on)
 *
 * Idempotent — checks for existing (User, Group) pair before insert.
 *
 * Excel orphans that have no SF Group__c match (LOW bucket from the orphan
 * matcher — Tony's TS-prefixed groups, Bobby's per-county gas stations, etc.)
 * are SKIPPED with a warning. They'll be picked up once Fausto returns Part 2
 * of the Excel update report and we create the missing groups.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/migrate-agents-to-group-access.ts --target prod [--dry-run] [--limit 50]
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const EXCEL_SNAPSHOT = path.join(
  REPO_ROOT,
  'data',
  'archive',
  'agent-groups-fausto-2026-05-20.json'
);
const MATCHER_OUTPUT = path.join(
  REPO_ROOT,
  'data',
  'archive',
  'orphan-matches-2026-05-24.json'
);

interface ExcelAssignment {
  agent: string;
  group: string;
}

interface ExcelSnapshot {
  assignments: ExcelAssignment[];
  agents_without_groups: string[];
}

interface MatcherResult {
  orphan_matches: Array<{
    excelName: string;
    bucket: 'HIGH' | 'MEDIUM' | 'LOW';
    candidates: Array<{ sfId: string; sfName: string; score: number }>;
  }>;
}

// Same MEDIUM promotions used in the cleanup script — keep in sync
const MEDIUM_PROMOTIONS: Array<{ excelName: string; sfName: string }> = [
  { excelName: 'VicentePRolodex', sfName: 'VicenteRolodex' },
  { excelName: 'SouthMiamiOffices', sfName: 'MiamiOfficesSouth' },
  { excelName: 'HiaGarden Warehouse', sfName: 'HiaGardenWare' },
];

// ---------------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------------

function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        out[key] = next;
        i++;
      } else out[key] = true;
    }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';
const DRY_RUN = args['dry-run'] === true || !args.commit;
const LIMIT = args.limit ? parseInt(String(args.limit), 10) : null;

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  console.log(`\n🔗 User → Group Access migration`);
  console.log(`   target:  ${TARGET}`);
  console.log(`   mode:    ${DRY_RUN ? '🧪 DRY-RUN' : '🔥 COMMIT'}`);
  if (LIMIT) console.log(`   limit:   ${LIMIT}`);
  console.log();

  if (!fs.existsSync(EXCEL_SNAPSHOT)) {
    console.error(`❌ Missing: ${EXCEL_SNAPSHOT}`);
    process.exit(1);
  }
  if (!fs.existsSync(MATCHER_OUTPUT)) {
    console.error(`❌ Missing: ${MATCHER_OUTPUT}`);
    process.exit(1);
  }

  const snapshot: ExcelSnapshot = JSON.parse(fs.readFileSync(EXCEL_SNAPSHOT, 'utf8'));
  const matcher: MatcherResult = JSON.parse(fs.readFileSync(MATCHER_OUTPUT, 'utf8'));

  console.log(`Loaded ${snapshot.assignments.length} (agent, group) pairs from Excel`);

  const sf = await sfClient(TARGET);
  console.log(`Connected to ${sf.instance}`);

  // 1. Verify User_Group_Access__c exists
  try {
    await sf.describe('User_Group_Access__c');
  } catch {
    console.error(`❌ User_Group_Access__c not found in ${TARGET}. Run seed-prod-junctions.ts first.`);
    process.exit(1);
  }

  // 2. Build agent name → User Id map
  const allUsers = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM User WHERE IsActive = true`
  );
  const userByName = new Map<string, string>();
  for (const u of allUsers) {
    if (u.Name) userByName.set(u.Name.toLowerCase().trim(), u.Id);
  }

  // 3. Build group name → Group__c Id map.
  //    For HIGH and MEDIUM-PROMOTED orphan matches, also map the Excel-side
  //    name to the SF canonical Id so "LitHavApt" → "LittleHavanaApt" Id.
  const allGroups = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c`
  );
  const groupByName = new Map<string, string>();
  for (const g of allGroups) groupByName.set(g.Name, g.Id);

  // Add HIGH-confidence orphan name → SF Id resolutions
  for (const m of matcher.orphan_matches) {
    if (m.bucket !== 'HIGH') continue;
    const best = m.candidates[0];
    if (!best) continue;
    if (!groupByName.has(m.excelName)) {
      groupByName.set(m.excelName, best.sfId);
    }
  }

  // Add MEDIUM-promoted ones (manually approved by reviewer)
  for (const p of MEDIUM_PROMOTIONS) {
    const m = matcher.orphan_matches.find((x) => x.excelName === p.excelName);
    if (!m) continue;
    const c = m.candidates.find((x) => x.sfName === p.sfName);
    if (!c) continue;
    if (!groupByName.has(m.excelName)) {
      groupByName.set(m.excelName, c.sfId);
    }
  }

  // Also: a normalized lookup so "Miami Beach" matches "MiamiBeach" etc.
  // (Excel often has casing/spacing variants of the 49 exact matches too.)
  const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const groupByNorm = new Map<string, string>();
  for (const g of allGroups) {
    const k = normalize(g.Name);
    if (!groupByNorm.has(k)) groupByNorm.set(k, g.Id);
  }

  // 4. Pull existing User_Group_Access__c so we can be idempotent
  const existing = await sf.soql<{ User__c: string; Group__c: string }>(
    `SELECT User__c, Group__c FROM User_Group_Access__c`
  );
  const existingKey = new Set(existing.map((r) => `${r.User__c}|${r.Group__c}`));
  console.log(`Existing User_Group_Access__c records: ${existing.length}`);

  // 5. Process every Excel (agent, group) pair
  let toCreate = 0;
  let skippedExisting = 0;
  let skippedMissingUser = 0;
  let skippedMissingGroup = 0;
  const missingUsers = new Set<string>();
  const missingGroups = new Set<string>();
  let processed = 0;
  let created = 0;

  for (const pair of snapshot.assignments) {
    if (LIMIT && processed >= LIMIT) break;
    processed++;

    const userId = userByName.get(pair.agent.toLowerCase().trim());
    if (!userId) {
      skippedMissingUser++;
      missingUsers.add(pair.agent);
      continue;
    }

    const groupId =
      groupByName.get(pair.group) ?? groupByNorm.get(normalize(pair.group));
    if (!groupId) {
      skippedMissingGroup++;
      missingGroups.add(pair.group);
      continue;
    }

    const key = `${userId}|${groupId}`;
    if (existingKey.has(key)) {
      skippedExisting++;
      continue;
    }

    toCreate++;
    if (!DRY_RUN) {
      try {
        await sf.create('User_Group_Access__c', {
          User__c: userId,
          Group__c: groupId,
          Status__c: 'Approved',
          Approved_Date__c: new Date().toISOString(),
        });
        existingKey.add(key);
        created++;
        if (created % 25 === 0) console.log(`  ... ${created} created so far`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        console.error(`  ✗ insert failed (${pair.agent} → ${pair.group}): ${msg.slice(0, 150)}`);
      }
    }
  }

  console.log(`\n=== Summary ===`);
  console.log(`  Processed pairs:      ${processed}`);
  console.log(`  Existing (skipped):   ${skippedExisting}`);
  console.log(`  ${DRY_RUN ? 'Would create' : 'Created'}:         ${DRY_RUN ? toCreate : created}`);
  console.log(`  Skipped (no SF User): ${skippedMissingUser}`);
  console.log(`  Skipped (no SF Group): ${skippedMissingGroup}`);

  if (missingUsers.size > 0) {
    console.log(`\n⚠️  Excel agents with no active SF User (${missingUsers.size}):`);
    for (const u of missingUsers) console.log(`    - ${u}`);
  }
  if (missingGroups.size > 0) {
    console.log(`\n⚠️  Excel groups with no SF Group__c (${missingGroups.size}) — these are the LOW-bucket orphans awaiting Fausto's Part 2 confirmation:`);
    for (const g of [...missingGroups].sort()) console.log(`    - ${g}`);
    console.log(`\n   When Fausto returns Part 2, create the missing Group__c records and re-run this script — it's idempotent.`);
  }

  if (DRY_RUN) {
    console.log(`\n🧪 DRY-RUN complete. Re-run with --commit to actually write.`);
  }
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
