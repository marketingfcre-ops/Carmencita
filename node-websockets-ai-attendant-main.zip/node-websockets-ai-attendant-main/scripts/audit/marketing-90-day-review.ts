/**
 * Fausto 90-Day Review — listing & marketing-material analytics.
 *
 * Pulls all Property__c records created since 2026-01-07 from PROD Salesforce,
 * inspects every PDF attached via ContentDocumentLink → ContentVersion,
 * classifies each PDF as OM or Flyer (filename keywords first, then size
 * fallback at 1.5 MB), and prints a markdown report to stdout.
 *
 * Two periods are compared:
 *   - Baseline:  2026-01-07 → 2026-01-12  (initial post-upload activity)
 *   - Optimized: 2026-01-13 → today
 *
 * Listings created on Jan 5 / Jan 6 are excluded (bulk data load).
 *
 * Read-only — only sf.soql() is called.
 *
 * Run: tsx --env-file .env.local scripts/marketing-90-day-review.ts > review.md
 */

import { sfClient, SfClient } from '../../src/integrations/sf-client';

// ---------------------------------------------------------------------------
// Tunables
// ---------------------------------------------------------------------------

const ANALYSIS_START = '2026-01-07T00:00:00Z';
const BASELINE_END_EXCLUSIVE = '2026-01-13T00:00:00Z';
const OPTIMIZED_START = '2026-01-13T00:00:00Z';
const SINCE_JAN_12 = '2026-01-12T00:00:00Z';

const OM_SIZE_THRESHOLD_BYTES = 1.5 * 1024 * 1024;
const SOQL_ID_CHUNK = 200;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface PropertyRow {
  Id: string;
  Name: string;
  Marketing_Name__c: string | null;
  Address__c: string | null;
  City__c: string | null;
  State__c: string | null;
  CreatedDate: string;
  LastModifiedDate: string;
  Status__c: string | null;
  Listing_Type__c: string | null;
}

interface LinkRow {
  ContentDocumentId: string;
  LinkedEntityId: string;
}

interface ContentVersionRow {
  ContentDocumentId: string;
  Title: string;
  FileType: string;
  ContentSize: number;
  CreatedDate: string;
}

type Classification = 'OM' | 'Flyer';

interface ClassifiedPdf {
  title: string;
  sizeBytes: number;
  createdAt: string;
  classification: Classification;
}

interface ListingMetrics {
  id: string;
  name: string;
  marketingName: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  createdAt: string;
  pdfs: ClassifiedPdf[];
  firstFlyerAt: string | null;
  firstOmAt: string | null;
  flyerCount: number;
  omCount: number;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const sf = await sfClient('prod');

  const properties = await fetchProperties(sf);
  const propIds = properties.map((p) => p.Id);

  const links = await fetchLinks(sf, propIds);
  const docIds = unique(links.map((l) => l.ContentDocumentId));
  const versions = await fetchPdfVersions(sf, docIds);

  const pdfsByProperty = groupPdfsByProperty(properties, links, versions);

  const sinceJan12 = Date.parse(SINCE_JAN_12);
  const modifiedSinceJan12 = properties.filter(
    (p) => Date.parse(p.LastModifiedDate) >= sinceJan12
  ).length;

  const listings: ListingMetrics[] = properties.map((p) => {
    const pdfs = pdfsByProperty.get(p.Id) ?? [];
    const flyers = pdfs.filter((x) => x.classification === 'Flyer');
    const oms = pdfs.filter((x) => x.classification === 'OM');
    return {
      id: p.Id,
      name: p.Name,
      marketingName: p.Marketing_Name__c,
      address: p.Address__c,
      city: p.City__c,
      state: p.State__c,
      createdAt: p.CreatedDate,
      pdfs,
      firstFlyerAt: minDate(flyers.map((x) => x.createdAt)),
      firstOmAt: minDate(oms.map((x) => x.createdAt)),
      flyerCount: flyers.length,
      omCount: oms.length,
    };
  });

  const report = renderMarkdown(listings, modifiedSinceJan12);
  process.stdout.write(report);
}

// ---------------------------------------------------------------------------
// SOQL fetches
// ---------------------------------------------------------------------------

async function fetchProperties(sf: SfClient): Promise<PropertyRow[]> {
  // The WHERE clause already excludes Jan 5–6, but the spec calls them out.
  const q = `
    SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c,
           CreatedDate, LastModifiedDate, Status__c, Listing_Type__c
    FROM Property__c
    WHERE CreatedDate >= ${ANALYSIS_START}
    ORDER BY CreatedDate ASC
  `.replace(/\s+/g, ' ').trim();
  return sf.soql<PropertyRow>(q);
}

async function fetchLinks(sf: SfClient, propertyIds: string[]): Promise<LinkRow[]> {
  const out: LinkRow[] = [];
  for (const chunk of chunks(propertyIds, SOQL_ID_CHUNK)) {
    const idList = chunk.map((id) => `'${id}'`).join(',');
    const q = `SELECT ContentDocumentId, LinkedEntityId FROM ContentDocumentLink WHERE LinkedEntityId IN (${idList})`;
    const rows = await sf.soql<LinkRow>(q);
    out.push(...rows);
  }
  return out;
}

async function fetchPdfVersions(sf: SfClient, docIds: string[]): Promise<ContentVersionRow[]> {
  if (docIds.length === 0) return [];
  const out: ContentVersionRow[] = [];
  for (const chunk of chunks(docIds, SOQL_ID_CHUNK)) {
    const idList = chunk.map((id) => `'${id}'`).join(',');
    const q = `SELECT ContentDocumentId, Title, FileType, ContentSize, CreatedDate FROM ContentVersion WHERE ContentDocumentId IN (${idList}) AND IsLatest = true AND FileType = 'PDF'`;
    const rows = await sf.soql<ContentVersionRow>(q);
    out.push(...rows);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Joining + classification
// ---------------------------------------------------------------------------

function groupPdfsByProperty(
  properties: PropertyRow[],
  links: LinkRow[],
  versions: ContentVersionRow[]
): Map<string, ClassifiedPdf[]> {
  const versionsByDoc = new Map<string, ContentVersionRow>();
  for (const v of versions) versionsByDoc.set(v.ContentDocumentId, v);

  const propIdSet = new Set(properties.map((p) => p.Id));
  const result = new Map<string, ClassifiedPdf[]>();
  for (const id of propIdSet) result.set(id, []);

  for (const link of links) {
    if (!propIdSet.has(link.LinkedEntityId)) continue;
    const v = versionsByDoc.get(link.ContentDocumentId);
    if (!v) continue;
    result.get(link.LinkedEntityId)!.push({
      title: v.Title,
      sizeBytes: v.ContentSize,
      createdAt: v.CreatedDate,
      classification: classify(v.Title, v.ContentSize),
    });
  }
  return result;
}

function classify(title: string, sizeBytes: number): Classification {
  const t = (title || '').toLowerCase();
  if (/\bom\b|offering\s*memorandum/.test(t)) return 'OM';
  if (/flyer/.test(t)) return 'Flyer';
  return sizeBytes >= OM_SIZE_THRESHOLD_BYTES ? 'OM' : 'Flyer';
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

interface PeriodStats {
  n: number;
  anyPdfMeanHours: number | null;
  anyPdfMedianHours: number | null;
  flyerMeanHours: number | null;
  flyerMedianHours: number | null;
  omMeanHours: number | null;
  omMedianHours: number | null;
}

function computePeriod(
  listings: ListingMetrics[],
  startInclusive: string,
  endExclusive: string | null,
  opts: { requireOm: boolean }
): PeriodStats {
  const start = Date.parse(startInclusive);
  const end = endExclusive ? Date.parse(endExclusive) : Number.POSITIVE_INFINITY;

  const eligible = listings.filter((l) => {
    const t = Date.parse(l.createdAt);
    if (t < start || t >= end) return false;
    if (l.pdfs.length === 0) return false;
    if (opts.requireOm && l.omCount === 0) return false;
    return true;
  });

  const anyPdfHours: number[] = [];
  const flyerHours: number[] = [];
  const omHours: number[] = [];
  for (const l of eligible) {
    const created = Date.parse(l.createdAt);
    const firstAny = minDate(l.pdfs.map((p) => p.createdAt));
    if (firstAny) {
      anyPdfHours.push((Date.parse(firstAny) - created) / 3_600_000);
    }
    if (l.firstFlyerAt) {
      flyerHours.push((Date.parse(l.firstFlyerAt) - created) / 3_600_000);
    }
    if (l.firstOmAt) {
      omHours.push((Date.parse(l.firstOmAt) - created) / 3_600_000);
    }
  }

  return {
    n: eligible.length,
    anyPdfMeanHours: mean(anyPdfHours),
    anyPdfMedianHours: median(anyPdfHours),
    flyerMeanHours: mean(flyerHours),
    flyerMedianHours: median(flyerHours),
    omMeanHours: mean(omHours),
    omMedianHours: median(omHours),
  };
}

function mean(xs: number[]): number | null {
  if (xs.length === 0) return null;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function median(xs: number[]): number | null {
  if (xs.length === 0) return null;
  const sorted = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

function pctImprovement(baseline: number | null, optimized: number | null): number | null {
  if (baseline === null || optimized === null || baseline === 0) return null;
  return ((baseline - optimized) / baseline) * 100;
}

// ---------------------------------------------------------------------------
// Markdown rendering
// ---------------------------------------------------------------------------

function renderMarkdown(listings: ListingMetrics[], modifiedSinceJan12: number): string {
  const sinceJan12 = Date.parse(SINCE_JAN_12);
  const createdSinceJan12 = listings.filter((l) => Date.parse(l.createdAt) >= sinceJan12).length;

  const totalPdfs = listings.reduce((sum, l) => sum + l.pdfs.length, 0);
  const totalOms = listings.reduce((sum, l) => sum + l.omCount, 0);
  const totalFlyers = listings.reduce((sum, l) => sum + l.flyerCount, 0);

  const dist = pdfDistribution(listings);

  const baselineStrict = computePeriod(listings, ANALYSIS_START, BASELINE_END_EXCLUSIVE, { requireOm: true });
  const optimizedStrict = computePeriod(listings, OPTIMIZED_START, null, { requireOm: true });
  const baselineRelaxed = computePeriod(listings, ANALYSIS_START, BASELINE_END_EXCLUSIVE, { requireOm: false });
  const optimizedRelaxed = computePeriod(listings, OPTIMIZED_START, null, { requireOm: false });

  const flyerMeanImp = pctImprovement(baselineStrict.flyerMeanHours, optimizedStrict.flyerMeanHours);
  const flyerMedImp = pctImprovement(baselineStrict.flyerMedianHours, optimizedStrict.flyerMedianHours);
  const omMeanImp = pctImprovement(baselineStrict.omMeanHours, optimizedStrict.omMeanHours);
  const omMedImp = pctImprovement(baselineStrict.omMedianHours, optimizedStrict.omMedianHours);

  const anyPdfMeanImp = pctImprovement(baselineRelaxed.anyPdfMeanHours, optimizedRelaxed.anyPdfMeanHours);
  const anyPdfMedImp = pctImprovement(baselineRelaxed.anyPdfMedianHours, optimizedRelaxed.anyPdfMedianHours);

  const smallSampleCaveat = baselineStrict.n < 5
    ? `\n> ⚠️ **Strict baseline sample is small (n=${baselineStrict.n}).** Treat the strict % change as directional, not statistically significant. The relaxed view (any PDF, no OM required) below has a larger n.\n`
    : '';

  const runAt = new Date().toISOString();

  return `# Fausto Marketing — 90-Day Review Snapshot

_Generated ${runAt} from production Salesforce. All times UTC._

---

## Headline numbers (since 2026-01-12)

| Metric | Count |
| --- | ---: |
| Listings **created** since Jan 12 | ${createdSinceJan12} |
| Listings **modified** since Jan 12 | ${modifiedSinceJan12} |
| Total PDFs attached (analysis window) | ${totalPdfs} |
| &nbsp;&nbsp;↳ classified as OM | ${totalOms} |
| &nbsp;&nbsp;↳ classified as Flyer | ${totalFlyers} |
| Listings tracked in window (Jan 7+) | ${listings.length} |

---

## PDFs per listing — distribution

| PDFs attached | # of listings |
| --- | ---: |
| 0 | ${dist[0]} |
| 1 | ${dist[1]} |
| 2 | ${dist[2]} |
| 3 | ${dist[3]} |
| 4+ | ${dist[4]} |

---

## Time-to-market — Strict view (≥ 1 PDF AND ≥ 1 OM required)

| Metric | Baseline (Jan 7–12) | Optimized (Jan 13+) | Improvement |
| --- | ---: | ---: | ---: |
| Sample size (n) | ${baselineStrict.n} | ${optimizedStrict.n} | — |
| Avg time → first **Flyer** | ${fmtHours(baselineStrict.flyerMeanHours)} | ${fmtHours(optimizedStrict.flyerMeanHours)} | ${fmtPct(flyerMeanImp)} |
| Median time → first Flyer | ${fmtHours(baselineStrict.flyerMedianHours)} | ${fmtHours(optimizedStrict.flyerMedianHours)} | ${fmtPct(flyerMedImp)} |
| Avg time → first **OM** | ${fmtHours(baselineStrict.omMeanHours)} | ${fmtHours(optimizedStrict.omMeanHours)} | ${fmtPct(omMeanImp)} |
| Median time → first OM | ${fmtHours(baselineStrict.omMedianHours)} | ${fmtHours(optimizedStrict.omMedianHours)} | ${fmtPct(omMedImp)} |
${smallSampleCaveat}
---

## Time-to-market — Relaxed view (≥ 1 PDF of any type)

Drops the OM-required filter so the baseline period actually has a population to compare against. Useful when the question is "how fast does *any* marketing material land on a new listing."

| Metric | Baseline (Jan 7–12) | Optimized (Jan 13+) | Improvement |
| --- | ---: | ---: | ---: |
| Sample size (n) | ${baselineRelaxed.n} | ${optimizedRelaxed.n} | — |
| Avg time → first PDF (any) | ${fmtHours(baselineRelaxed.anyPdfMeanHours)} | ${fmtHours(optimizedRelaxed.anyPdfMeanHours)} | ${fmtPct(anyPdfMeanImp)} |
| Median time → first PDF (any) | ${fmtHours(baselineRelaxed.anyPdfMedianHours)} | ${fmtHours(optimizedRelaxed.anyPdfMedianHours)} | ${fmtPct(anyPdfMedImp)} |

---

${renderWeeklyTimeline(listings)}

---

## Methodology

- **Source:** Production Salesforce \`Property__c\` + \`ContentDocumentLink\` + \`ContentVersion\` (latest versions, FileType = PDF).
- **Window:** Listings with \`CreatedDate >= 2026-01-07\`. Listings created on Jan 5–6 are excluded (bulk data load).
- **Time-to-market filters:** Listing must have ≥ 1 PDF and ≥ 1 OM attached. No filter on PDF upload timing.
- **OM vs Flyer classification:**
  1. If the file title matches \`OM\` or \`Offering Memorandum\` → OM.
  2. Else if the file title matches \`Flyer\` → Flyer.
  3. Else fall back to file size: ≥ 1.5 MB → OM, otherwise Flyer.
- **Periods:**
  - Baseline: \`2026-01-07T00:00:00Z\` ≤ CreatedDate < \`2026-01-13T00:00:00Z\`
  - Optimized: CreatedDate ≥ \`2026-01-13T00:00:00Z\`
- **% improvement:** \`(baseline − optimized) / baseline × 100\`. Positive = faster.
`;
}

function renderWeeklyTimeline(listings: ListingMetrics[]): string {
  // Bucket listings created on/after Jan 12 into Mon–Sun weeks. Jan 12 2026 is a Monday.
  const start = Date.parse(SINCE_JAN_12);
  const eligible = listings
    .filter((l) => Date.parse(l.createdAt) >= start)
    .sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));

  const buckets = new Map<string, ListingMetrics[]>();
  for (const l of eligible) {
    const key = weekKey(l.createdAt);
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key)!.push(l);
  }

  const lines: string[] = ['## Weekly timeline — listings created since Jan 12', ''];
  for (const [weekStart, items] of buckets) {
    const weekEnd = addDaysISO(weekStart, 6);
    lines.push(`### Week of ${weekStart} – ${weekEnd}  (${items.length} listing${items.length === 1 ? '' : 's'})`);
    lines.push('');
    lines.push('| Created | Listing | Address | OM | Flyer | PDFs |');
    lines.push('| --- | --- | --- | :---: | :---: | ---: |');
    for (const l of items) {
      const created = l.createdAt.slice(0, 10);
      const ref = l.marketingName?.trim() || l.name;
      const addr = [l.address, l.city, l.state].filter(Boolean).join(', ') || '—';
      const om = l.omCount > 0 ? `✅ ${l.omCount}` : '—';
      const flyer = l.flyerCount > 0 ? `✅ ${l.flyerCount}` : '—';
      lines.push(`| ${created} | ${escapeMd(ref)} | ${escapeMd(addr)} | ${om} | ${flyer} | ${l.pdfs.length} |`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

function weekKey(iso: string): string {
  // Returns YYYY-MM-DD for the Monday of the week containing `iso` (UTC).
  const d = new Date(iso);
  const day = d.getUTCDay(); // 0=Sun..6=Sat
  const offsetToMonday = (day + 6) % 7;
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - offsetToMonday));
  return monday.toISOString().slice(0, 10);
}

function addDaysISO(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function escapeMd(s: string): string {
  return s.replace(/\s*\n+\s*/g, ' / ').replace(/\|/g, '\\|').trim();
}

function pdfDistribution(listings: ListingMetrics[]): [number, number, number, number, number] {
  const buckets: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  for (const l of listings) {
    const n = l.pdfs.length;
    if (n >= 4) buckets[4]++;
    else buckets[n]++;
  }
  return buckets;
}

function fmtHours(h: number | null): string {
  if (h === null) return '—';
  if (h < 0) return `${h.toFixed(1)}h (negative — file predates listing)`;
  if (h < 1) return `${(h * 60).toFixed(0)}m`;
  if (h < 48) return `${h.toFixed(1)}h`;
  const days = Math.floor(h / 24);
  const rem = Math.round(h - days * 24);
  return `${days}d ${rem}h`;
}

function fmtPct(p: number | null): string {
  if (p === null) return '—';
  const sign = p >= 0 ? '+' : '';
  return `${sign}${p.toFixed(1)}%`;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function* chunks<T>(arr: T[], size: number): Generator<T[]> {
  for (let i = 0; i < arr.length; i += size) yield arr.slice(i, i + size);
}

function unique<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}

function minDate(dates: string[]): string | null {
  if (dates.length === 0) return null;
  return dates.reduce((a, b) => (Date.parse(a) <= Date.parse(b) ? a : b));
}

main().catch((err) => {
  console.error('💀 Review script crashed:', err);
  process.exit(1);
});
