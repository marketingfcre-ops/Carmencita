/**
 * Mark SF Property__c records as Closed Won based on the closings spreadsheet.
 *
 * Reads /tmp/closings-mark-sf-sold-confident.json (produced by
 * scripts/diagnostics/closings-vs-sf-wp-audit.ts).
 *
 * For each closing → SF match (where SF is still "Active"):
 *   1. PATCH SF.Status__c = 'Closed Won'
 *   2. SF Flow webhook fires automatically. The deployed
 *      sf-property-changed handler maps 'Closed Won' →
 *      { postStatus: 'publish', listingStatusKey: 'sold' } and:
 *      - Tags the linked WP post with the "Sold" property_status taxonomy
 *      - Preserves WP post status (draft stays draft, publish stays publish)
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/closings-mark-sf-sold.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/closings-mark-sf-sold.ts
 */

import { readFileSync } from 'fs';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 300;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface ConfidentRow {
  sfId: string;
  sfAddress: string | null;
  currentStatus: string | null;
  targetStatus: string;
  listingAgent: string | null;
  listingType: string | null;
  wpId: number | null;
  closingPrice: number | string | null;
  closingAgents: string | null;
  closingAddress: string;
  closingTimestamp: string;
  closingNotes: string | null;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true } as const;
  return { ok: false as const, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true } as const;
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false as const, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false as const, error: lastError };
  }
  return { ok: false as const, error: lastError };
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID) {
    console.error('❌ Missing SF env vars.');
    process.exit(1);
  }

  const rows: ConfidentRow[] = JSON.parse(
    readFileSync('/tmp/closings-mark-sf-sold-confident.json', 'utf-8')
  );

  console.log(`\n🏁 Mark ${rows.length} SF records as Closed Won ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();

  // Safety: verify each SF record is still Active before flipping, and grab
  // current Notes_for_Marketing__c so we can APPEND an audit note (rather
  // than overwrite — same pattern as agent reviews).
  const ids = rows.map((r) => r.sfId);
  const sfNow = await sfQuery<{
    Id: string;
    Status__c: string | null;
    Notes_for_Marketing__c: string | null;
  }>(
    token,
    instance,
    `SELECT Id, Status__c, Notes_for_Marketing__c FROM Property__c WHERE Id IN ('${ids.join("','")}')`
  );
  const sfById = new Map(sfNow.map((r) => [r.Id, r]));

  let driftCount = 0;
  for (const row of rows) {
    const cur = sfById.get(row.sfId);
    if (!cur) {
      console.warn(`   ⚠️  ${row.sfId} not found in SF`);
      driftCount++;
      continue;
    }
    if ((cur.Status__c || '').toLowerCase() !== 'active') {
      console.warn(
        `   ⚠️  ${row.sfId} no longer Active (current: ${cur.Status__c}) — will skip`
      );
      driftCount++;
    }
  }
  if (driftCount > 0) {
    console.log(
      `\n   ${driftCount} drift detection(s). The script will only update records currently Active.\n`
    );
  }

  console.log('── Plan ──\n');
  for (const row of rows) {
    const cur = sfById.get(row.sfId);
    const stillActive = cur && (cur.Status__c || '').toLowerCase() === 'active';
    const skipMark = !stillActive ? ' [SKIP — no longer Active]' : '';
    const price = typeof row.closingPrice === 'number' ? '$' + row.closingPrice.toLocaleString() : row.closingPrice;
    console.log(`SF ${row.sfId}${skipMark}`);
    console.log(`   Address:        ${row.sfAddress}`);
    console.log(`   Listing agent:  ${row.listingAgent || '—'}  / ${row.listingType || '—'}`);
    console.log(`   WP:             wp:${row.wpId || '—'}`);
    console.log(`   Status:         ${row.currentStatus}  →  Closed Won`);
    console.log(`   Closing:        ${price}  / agents: ${row.closingAgents}`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('── Executing ──\n');
  const today = new Date().toISOString().slice(0, 10);
  let ok = 0;
  let skipped = 0;
  let err = 0;
  for (const row of rows) {
    const cur = sfById.get(row.sfId);
    if (!cur || (cur.Status__c || '').toLowerCase() !== 'active') {
      console.log(`   ⏭️  ${row.sfId} skipped (drift — no longer Active)`);
      skipped++;
      continue;
    }

    // Build the audit note — same convention as agent reviews so a regex
    // sweep of `[Closing Audit \d{4}-\d{2}-\d{2}]` will surface every
    // record this batch touched.
    const priceStr =
      typeof row.closingPrice === 'number'
        ? '$' + row.closingPrice.toLocaleString()
        : row.closingPrice || '(no price)';
    const auditNote = `[Closing Audit ${today}] Marked Closed Won via closing spreadsheet: ${priceStr}${row.closingAgents ? ` — agents: ${row.closingAgents}` : ''}`;
    const existingNotes = (cur.Notes_for_Marketing__c || '').trim();
    const combinedNotes = existingNotes ? `${existingNotes}\n${auditNote}` : auditNote;

    const result = await sfUpdateWithRetry(token, instance, row.sfId, {
      Status__c: 'Closed Won',
      Notes_for_Marketing__c: combinedNotes.slice(0, 30000), // SF text field cap
    });
    if (result.ok) {
      console.log(`   ✓ ${row.sfId} → Closed Won (+ audit note appended)`);
      ok++;
    } else {
      console.warn(`   ❌ ${row.sfId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Marked Closed Won:  ${ok}`);
  console.log(`Skipped (drift):    ${skipped}`);
  console.log(`Failures:           ${err}`);
  console.log('');
  console.log('Next: SF Flow will fire webhooks for each updated record.');
  console.log('The deployed handler will tag each linked WP post with "Sold"');
  console.log('property_status. Give it 1-2 min and check WP admin → Properties.');
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
