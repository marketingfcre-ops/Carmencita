/**
 * Create CustomTabs for User_Group_Access__c and Lead_List_Assignment__c so
 * they show up in the App Launcher. Tooling API.
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

// CustomTab API name = object API name (without __c) + Tab.
// Motif 'Custom32: Magnifying Glass' is a safe generic icon (works in PE).
const TABS = [
  {
    objectApi: 'User_Group_Access__c',
    fullName: 'User_Group_Access__c',
    label: 'User Group Access',
    motif: 'Custom32: Magnifying Glass',
  },
  {
    objectApi: 'Lead_List_Assignment__c',
    fullName: 'Lead_List_Assignment__c',
    label: 'Lead Group Assignments',
    motif: 'Custom32: Magnifying Glass',
  },
];

async function toolingCreate(sf: SfClient, sobject: string, body: any) {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`POST ${sobject} → ${res.status}: ${text.slice(0, 600)}`);
  return JSON.parse(text);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  for (const t of TABS) {
    console.log(`\n=== ${t.label} (${t.objectApi}) ===`);
    // Check if tab already exists by sobject
    const exists: any[] = await sf
      .toolingQuery(
        `SELECT DurableId, Name, Label FROM TabDefinition WHERE SobjectName = '${t.objectApi}'`
      )
      .catch(() => []);
    if (exists.length) {
      console.log(`  ✓ Tab already exists: ${exists[0].Name} (label="${exists[0].Label}")`);
      continue;
    }
    if (DRY) {
      console.log(`  Would CREATE CustomTab "${t.label}" for ${t.objectApi}`);
      continue;
    }
    try {
      const body = {
        Metadata: {
          label: t.label,
          motif: t.motif,
          customObject: true,
        },
        FullName: t.fullName,
      };
      const result = await toolingCreate(sf as any, 'CustomTab', body);
      console.log(`  ✓ Created: ${JSON.stringify(result)}`);
    } catch (e: any) {
      console.log(`  ✗ Create failed: ${e.message?.slice(0, 400)}`);
    }
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
