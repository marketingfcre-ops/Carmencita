/**
 * Resend email transport.
 *
 * Swapped in for SendGrid (which is now trial-only). Same exported surface, so
 * nothing downstream (handlers/email.ts, the send_email tool, sf-files.ts) changes.
 * No SDK dependency — raw fetch against the Resend API, matching the codebase style.
 *
 * Env:
 *   RESEND_API_KEY  — Resend API key (starts with "re_")
 *   EMAIL_FROM      — verified sender, e.g. listings@faustocommercial.com
 *                     (for the FIRST smoke test before domain verification, use
 *                      onboarding@resend.dev — Resend only allows that to your own
 *                      account email until you verify a domain.)
 *   EMAIL_FROM_NAME — display name, e.g. "Fausto Commercial" (optional)
 *   EMAIL_ENABLED   — set "true" to enable sending (default off)
 *
 * Production deliverability: verify faustocommercial.com in Resend (adds SPF/DKIM
 * DNS records) before sending from that domain to real leads.
 */

const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const EMAIL_FROM = process.env.EMAIL_FROM || 'listings@faustocommercial.com';
const EMAIL_FROM_NAME = process.env.EMAIL_FROM_NAME || 'Fausto Commercial';
const EMAIL_ENABLED = process.env.EMAIL_ENABLED === 'true'; // default off; matches claude.ts/admin.ts

const SEND_URL = 'https://api.resend.com/emails';

export interface EmailAttachment {
  filename: string;
  /** Raw file bytes. Base64-encoded before send. */
  content: Buffer;
  /** MIME type (unused by Resend — it infers from filename — kept for interface parity). */
  contentType?: string;
}

export interface SendEmailInput {
  to: string;
  subject: string;
  html: string;
  text?: string;
  attachments?: EmailAttachment[];
  replyTo?: string;
}

export interface SendEmailResult {
  ok: boolean;
  status?: number;
  /** Resend message id, when available. */
  messageId?: string;
  error?: string;
  skipped?: boolean;
}

export function isEmailConfigured(): boolean {
  return Boolean(RESEND_API_KEY && EMAIL_FROM);
}

function htmlToText(html: string): string {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Send one email via Resend. Returns {ok:false} on any failure — callers must
 * treat a failed send as "not delivered" and fall back, never as success.
 */
export async function sendEmail(input: SendEmailInput): Promise<SendEmailResult> {
  if (!EMAIL_ENABLED) return { ok: false, skipped: true, error: 'EMAIL_ENABLED!=true' };
  if (!isEmailConfigured()) return { ok: false, error: 'Resend not configured (RESEND_API_KEY / EMAIL_FROM)' };

  const body: Record<string, unknown> = {
    from: EMAIL_FROM_NAME ? `${EMAIL_FROM_NAME} <${EMAIL_FROM}>` : EMAIL_FROM,
    to: [input.to],
    subject: input.subject,
    html: input.html,
    text: input.text || htmlToText(input.html),
  };
  if (input.replyTo) body.reply_to = input.replyTo;
  if (input.attachments?.length) {
    body.attachments = input.attachments.map((a) => ({
      filename: a.filename,
      content: a.content.toString('base64'),
    }));
  }

  try {
    const res = await fetch(SEND_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    if (res.ok) {
      const data = (await res.json().catch(() => ({}))) as { id?: string };
      return { ok: true, status: res.status, messageId: data.id };
    }
    const err = await res.text();
    return { ok: false, status: res.status, error: `Resend ${res.status}: ${err.slice(0, 300)}` };
  } catch (e: any) {
    return { ok: false, error: `Resend request failed: ${e?.message || e}` };
  }
}
