/**
 * Import LoopNet email-leads CSV into Salesforce as Lead records.
 *
 *   --csv <path>       required
 *   (default = dry-run)  writes a preview CSV, hits zero SF writes
 *   --live             actually create Leads via Composite sObjects API
 *
 * Matching & enrichment:
 *   - Looks up Property__c by LoopNet ID; if found, sets Listing__c (reference)
 *     and uses the property's marketing name as Company.
 *   - Dedupe: skips a row if a Lead with the same (Email, Listing__c) already
 *     exists. Unmatched rows (no SF property) always create.
 *   - LeadSource = "Loopnet"; Lead_Intent__c = Buyer Lead / Owner Lease Lead.
 *   - Description prefixed with the LoopNet inquiry date + property + ID.
 *   - Asset type NOT written — accessible via Listing__r.Property_Type__c.
 */

import { readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';

const API_VERSION = 'v59.0';
const OUTPUT_DIR = join(process.cwd(), 'data', 'sf_import');
const COMPOSITE_BATCH_SIZE = 200;

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
function parseArgs(): { csv: string; live: boolean } {
  const a = process.argv.slice(2);
  let csv = '';
  let live = false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--csv') csv = a[++i] || '';
    else if (a[i] === '--live') live = true;
  }
  if (!csv) {
    console.error('Usage: --csv <path> [--live]');
    process.exit(1);
  }
  return { csv, live };
}

// ---------------------------------------------------------------------------
// CSV parsing (quote-aware, handles embedded newlines)
// ---------------------------------------------------------------------------
function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = []; let f = ''; let q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; }
      else f += c;
    } else {
      if (c === '"') q = true;
      else if (c === ',') { row.push(f); f = ''; }
      else if (c === '\n') { row.push(f); rows.push(row); row = []; f = ''; }
      else if (c !== '\r') f += c;
    }
  }
  if (f.length || row.length) { row.push(f); rows.push(row); }
  if (!rows.length) return [];
  const h = rows[0];
  return rows.slice(1).filter((r) => r.some((v) => v.trim())).map((r) => {
    const o: Record<string, string> = {};
    h.forEach((k, i) => { o[k] = r[i] ?? ''; });
    return o;
  });
}

interface CsvLead {
  date: string;          // "4/21/2026"
  listing_id: string;
  listing_type: string;  // "For Sale" | "For Lease"
  first: string;
  last: string;
  phone: string;
  email: string;
  address: string;       // Lead Subject = street address
  message: string;
}

function readLeads(csvPath: string): CsvLead[] {
  const text = readFileSync(csvPath, 'utf-8').replace(/^\uFEFF/, '');
  const rows = parseCsv(text);
  const out: CsvLead[] = [];
  for (const r of rows) {
    const email = (r['Sender Email'] || '').trim().toLowerCase();
    const listing_id = (r['Listing ID'] || '').trim();
    if (!email || !listing_id) continue;
    out.push({
      date:         (r['Date Submitted'] || '').trim(),
      listing_id,
      listing_type: (r['Listing Type'] || '').trim(),
      first:        (r['Sender First Name'] || '').trim(),
      last:         (r['Sender Last Name'] || '').trim(),
      phone:        (r['Sender Phone Number'] || '').trim(),
      email,
      address:      (r['Lead Subject'] || '').trim(),
      message:      (r['Sender Message'] || '').trim(),
    });
  }
  return out;
}

/** Keep the most recent row per (email, listing_id) pair. */
function dedupeCsv(rows: CsvLead[]): CsvLead[] {
  const best = new Map<string, CsvLead>();
  const parseDate = (s: string) => {
    // "M/D/YYYY" → sortable string
    const [m, d, y] = s.split('/').map((x) => x.padStart(2, '0'));
    return `${y}${m}${d}`;
  };
  for (const r of rows) {
    const key = `${r.email}|${r.listing_id}`;
    const prev = best.get(key);
    if (!prev || parseDate(r.date) > parseDate(prev.date)) best.set(key, r);
  }
  return [...best.values()];
}

// ---------------------------------------------------------------------------
// Salesforce helpers
// ---------------------------------------------------------------------------
async function sfAuth() {
  const p = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: (process.env.SF_CLIENT_ID || '').trim(),
    client_secret: (process.env.SF_CLIENT_SECRET || '').trim(),
  });
  const r = await fetch(`${process.env.SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: p.toString(),
  });
  if (!r.ok) throw new Error(`SF auth ${r.status}: ${await r.text()}`);
  return (await r.json()) as { access_token: string; instance_url: string };
}

async function soqlAll<T = any>(instance: string, tok: string, q: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/${API_VERSION}/query?q=${encodeURIComponent(q)}`;
  const out: T[] = [];
  while (url) {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${tok}` } });
    if (!r.ok) throw new Error(`SOQL ${r.status}: ${await r.text()}`);
    const d = (await r.json()) as any;
    out.push(...(d.records || []));
    url = d.nextRecordsUrl ? `${instance}${d.nextRecordsUrl}` : null;
  }
  return out;
}

interface SFProp {
  id: string;
  name: string;
  marketingName: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  propertyType: string;
  listingType: string;
}

async function fetchPropertiesByLoopnet(
  instance: string, tok: string, loopnetIds: string[]
): Promise<Map<string, SFProp>> {
  const out = new Map<string, SFProp>();
  const ids = [...new Set(loopnetIds.filter(Boolean))];
  const CHUNK = 300;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const chunk = ids.slice(i, i + CHUNK);
    const inClause = chunk.map((v) => `'${v}'`).join(',');
    const soql =
      `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c, ` +
      `Zip_Code__c, Property_Type__c, Listing_Type__c, Loopnet_ID__c ` +
      `FROM Property__c WHERE Loopnet_ID__c IN (${inClause})`;
    const rows = await soqlAll<any>(instance, tok, soql);
    for (const r of rows) {
      if (!r.Loopnet_ID__c) continue;
      out.set(r.Loopnet_ID__c, {
        id: r.Id, name: r.Name || '',
        marketingName: r.Marketing_Name__c || '',
        address: r.Address__c || '', city: r.City__c || '',
        state: r.State__c || '', zipCode: r.Zip_Code__c || '',
        propertyType: r.Property_Type__c || '',
        listingType: r.Listing_Type__c || '',
      });
    }
  }
  return out;
}

/** Existing (Email, Listing__c) pairs for dedupe. Keeps only matching emails. */
async function fetchExistingLeadKeys(
  instance: string, tok: string, emails: string[]
): Promise<Set<string>> {
  const set = new Set<string>();
  const CHUNK = 200;
  for (let i = 0; i < emails.length; i += CHUNK) {
    const chunk = emails.slice(i, i + CHUNK);
    const inClause = chunk.map((e) => `'${e.replace(/'/g, "\\'")}'`).join(',');
    const rows = await soqlAll<{ Email: string; Listing__c: string | null }>(
      instance, tok,
      `SELECT Email, Listing__c FROM Lead WHERE Email IN (${inClause})`
    );
    for (const r of rows) {
      const email = (r.Email || '').toLowerCase();
      if (!email) continue;
      set.add(`${email}|${r.Listing__c || ''}`);
    }
  }
  return set;
}

// ---------------------------------------------------------------------------
// Lead payload
// ---------------------------------------------------------------------------
const CITY_MAP: Record<string, 'MIA' | 'JAX'> = {
  miami: 'MIA', hialeah: 'MIA', doral: 'MIA', 'coral gables': 'MIA',
  hollywood: 'MIA', 'fort lauderdale': 'MIA', 'pompano beach': 'MIA',
  homestead: 'MIA', 'miami beach': 'MIA', medley: 'MIA',
  jacksonville: 'JAX',
};

function normalizeState(s: string): string {
  const v = s.trim().toLowerCase();
  if (v === 'florida' || v === 'fl') return 'FL';
  if (v === 'georgia' || v === 'ga') return 'GA';
  return s;
}

function formatPropertyText(prop: SFProp | null, fallbackStreet: string): string {
  if (prop && prop.address) {
    const state = prop.state ? normalizeState(prop.state) : '';
    const cityPart = prop.city && state ? `${prop.city}, ${state}` : prop.city || '';
    const zip = prop.zipCode ? ` ${prop.zipCode}` : '';
    return cityPart ? `${prop.address} | ${cityPart}${zip}` : prop.address;
  }
  return fallbackStreet;
}

function parseIntent(listingType: string): 'sale' | 'lease' | null {
  const s = listingType.toLowerCase();
  if (s.includes('sale')) return 'sale';
  if (s.includes('lease')) return 'lease';
  return null;
}

function buildLead(csv: CsvLead, prop: SFProp | null): Record<string, unknown> {
  const intent = parseIntent(csv.listing_type);
  const propertyText = formatPropertyText(prop, csv.address);
  const displayName = prop?.marketingName || prop?.name || csv.address || 'LoopNet Inquiry';

  const descriptionLines = [
    `LoopNet Inquiry — ${csv.date}`,
    `Property: ${displayName}`,
    `LoopNet ID: ${csv.listing_id}`,
    '',
    csv.message,
  ];

  const lead: Record<string, unknown> = {
    LastName: csv.last || 'Unknown',
    Email: csv.email,
    Phone: csv.phone || undefined,
    Company: displayName,
    LeadSource: 'Loopnet',
    Description: descriptionLines.join('\n').slice(0, 32000),
    Property__c: propertyText,
  };
  if (csv.first) lead.FirstName = csv.first;
  if (prop) lead.Listing__c = prop.id;
  if (intent === 'sale')  lead.Lead_Intent__c = 'Buyer Lead';
  if (intent === 'lease') lead.Lead_Intent__c = 'Owner Lease Lead';

  if (prop?.city) {
    const code = CITY_MAP[prop.city.trim().toLowerCase()];
    if (code) lead.Interested_City__c = code;
  }

  // Prune undefineds so they don't hit the API.
  for (const k of Object.keys(lead)) if (lead[k] === undefined) delete lead[k];
  return lead;
}

// ---------------------------------------------------------------------------
// Composite create
// ---------------------------------------------------------------------------
interface CompositeResult {
  id?: string;
  success: boolean;
  errors?: Array<{ statusCode: string; message: string; fields?: string[] }>;
}

async function createLeadsBatch(
  instance: string, tok: string, leads: Record<string, unknown>[]
): Promise<CompositeResult[]> {
  const results: CompositeResult[] = [];
  for (let i = 0; i < leads.length; i += COMPOSITE_BATCH_SIZE) {
    const batch = leads.slice(i, i + COMPOSITE_BATCH_SIZE);
    const body = {
      allOrNone: false,
      records: batch.map((l) => ({ attributes: { type: 'Lead' }, ...l })),
    };
    const r = await fetch(
      `${instance}/services/data/${API_VERSION}/composite/sobjects`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      }
    );
    if (!r.ok) throw new Error(`Composite create ${r.status}: ${await r.text()}`);
    const chunkResults = (await r.json()) as CompositeResult[];
    results.push(...chunkResults);
    process.stdout.write(`\r  created ${Math.min(i + COMPOSITE_BATCH_SIZE, leads.length)}/${leads.length}`);
  }
  process.stdout.write('\n');
  return results;
}

// ---------------------------------------------------------------------------
// Output
// ---------------------------------------------------------------------------
function writeCsv(path: string, rows: Record<string, string>[]) {
  if (!rows.length) return;
  const fields = Object.keys(rows[0]);
  const esc = (v: string) => `"${(v || '').replace(/"/g, '""')}"`;
  const lines = [fields.join(',')];
  for (const r of rows) lines.push(fields.map((f) => esc(String(r[f] ?? ''))).join(','));
  writeFileSync(path, lines.join('\n'));
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
  const args = parseArgs();

  console.log(`Reading ${args.csv}…`);
  const rawRows = readLeads(args.csv);
  console.log(`  ${rawRows.length} raw rows with email+listing_id`);
  const csvRows = dedupeCsv(rawRows);
  console.log(`  ${csvRows.length} unique (email, listing_id) pairs after dedupe`);

  const sf = await sfAuth();
  const tok = sf.access_token, iurl = sf.instance_url;

  console.log('Looking up SF Property__c by LoopNet ID…');
  const loopnetIds = [...new Set(csvRows.map((r) => r.listing_id))];
  const propByLoopnet = await fetchPropertiesByLoopnet(iurl, tok, loopnetIds);
  console.log(`  matched ${propByLoopnet.size} / ${loopnetIds.length} LoopNet IDs`);

  console.log('Fetching existing SF Leads by email (dedupe check)…');
  const uniqueEmails = [...new Set(csvRows.map((r) => r.email))];
  const existingKeys = await fetchExistingLeadKeys(iurl, tok, uniqueEmails);
  console.log(`  ${existingKeys.size} existing (email, Listing__c) pairs`);

  // Build Lead payloads, skipping exact (email, Listing__c) dupes.
  const toCreate: { csv: CsvLead; prop: SFProp | null; lead: Record<string, unknown> }[] = [];
  const skipped: CsvLead[] = [];
  for (const csv of csvRows) {
    const prop = propByLoopnet.get(csv.listing_id) || null;
    const key = `${csv.email}|${prop?.id || ''}`;
    if (existingKeys.has(key)) { skipped.push(csv); continue; }
    const lead = buildLead(csv, prop);
    toCreate.push({ csv, prop, lead });
  }

  const matched = toCreate.filter((t) => t.prop).length;
  const unmatched = toCreate.length - matched;
  console.log(`\nPlan:`);
  console.log(`  ${toCreate.length} Leads to create`);
  console.log(`    ${matched} matched to SF Property__c (Listing__c set)`);
  console.log(`    ${unmatched} unmatched (Listing__c null)`);
  console.log(`  ${skipped.length} skipped (duplicate email+property)`);

  mkdirSync(OUTPUT_DIR, { recursive: true });
  writeCsv(
    join(OUTPUT_DIR, 'preview.csv'),
    toCreate.map((t) => ({
      email: t.csv.email,
      last: t.csv.last,
      first: t.csv.first,
      phone: t.csv.phone,
      listing_id: t.csv.listing_id,
      listing_type: t.csv.listing_type,
      date: t.csv.date,
      sf_property_id: t.prop?.id || '',
      sf_property_name: t.prop?.marketingName || t.prop?.name || '',
      company: String(t.lead.Company || ''),
      intent: String(t.lead.Lead_Intent__c || ''),
      interested_city: String(t.lead.Interested_City__c || ''),
      property_text: String(t.lead.Property__c || ''),
    }))
  );
  writeCsv(
    join(OUTPUT_DIR, 'skipped.csv'),
    skipped.map((s) => ({
      email: s.email, last: s.last, first: s.first,
      listing_id: s.listing_id, date: s.date,
    }))
  );
  console.log(`  preview → ${OUTPUT_DIR}/preview.csv`);
  if (skipped.length) console.log(`  skipped → ${OUTPUT_DIR}/skipped.csv`);

  if (!args.live) {
    console.log('\nDry-run complete. Re-run with --live to create Leads.');
    return;
  }

  console.log('\n--- LIVE --- creating Leads via Composite API…');
  const results = await createLeadsBatch(iurl, tok, toCreate.map((t) => t.lead));
  let ok = 0, fail = 0;
  const failures: Array<Record<string, string>> = [];
  results.forEach((r, i) => {
    if (r.success) ok++;
    else {
      fail++;
      const csv = toCreate[i].csv;
      failures.push({
        email: csv.email, last: csv.last, listing_id: csv.listing_id,
        errors: JSON.stringify(r.errors || []).slice(0, 800),
      });
    }
  });
  console.log(`\nCreated: ${ok}  Failed: ${fail}`);
  if (failures.length) {
    writeCsv(join(OUTPUT_DIR, 'failures.csv'), failures);
    console.log(`  failures → ${OUTPUT_DIR}/failures.csv`);
  }
  console.log('Done.');
}

main().catch((e) => { console.error(e); process.exit(1); });
