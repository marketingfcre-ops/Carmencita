# Groups, the new way — a 5-minute walkthrough for Nathalie

A summary of how Lead → Group assignments work after the cleanup, plus
what to do about the old text field. Hand this to Nathalie or paraphrase
into an email.

---

## TL;DR

- Every Lead can now be on **more than one Group** at the same time.
- Two new tables track this: **Lead Group Assignments** (Lead ↔ Group) and **User Group Access** (User ↔ Group).
- A Lead's "primary" Group still lives on `Lead.Group__c` (the lookup field). The AI receptionist and existing reports read from there.
- Multi-group membership lives in the new junction table.
- A Salesforce Flow blocks edits when the editor doesn't have access to the Lead's groups. **System Admins** + three named admin assistants (**Erick, Pedro, Nathalie**) bypass that check.
- The old free-text Group field (`Group_old2`) was reconciled to canonical groups during cleanup. Recommend keeping the field in the database but removing it from agent page layouts.

---

## How the new model works (with a worked example)

Say a Lead — call him **Mike's 1234 NW 7th St** — needs to be on both
**LitHavApt** (Little Havana Apartments) and **FlagamiApts** (Flagami
Apartments) because the property is on the border and two pods own
overlapping lists.

### Before the cleanup

- `Lead.Group__c` would be set to one of them, say **LitHavApt**.
- The agent who owned **FlagamiApts** had no clean way to see this lead. They'd either type "LitHavApt, FlagamiApts" into the `Group_old2` free-text field (which created data hygiene problems) or just lose track.

### After the cleanup

- `Lead.Group__c` is still **LitHavApt** (the primary).
- A new **Lead Group Assignment** record exists with `Lead = Mike's 1234 NW 7th St`, `Group = FlagamiApts`, `Status = Approved`.
- Both pods can now find this lead in their list views.

For multi-group leads, agents add a new Lead Group Assignment via a related list on the Lead page. The new row defaults to `Status = Pending` until an admin approves it.

### The two new tables

1. **Lead Group Assignment** (`Lead_List_Assignment__c`) — one row per (Lead, Group) pair. Status: `Pending` or `Approved`.
2. **User Group Access** (`User_Group_Access__c`) — one row per (User, Group) pair. Status: `Pending` or `Approved`. This is what controls whether an agent is *allowed* to edit a Lead in that group.

### The access check (the Flow)

When anyone hits **Save** on a Lead, a Before-Save Flow checks:

> Does this user have an Approved `User_Group_Access` row for at least one Group that this Lead has an Approved `Lead_List_Assignment` to?

- **Yes** → save proceeds normally.
- **No** → save is blocked with: *"You can only edit leads assigned to a group you have approved access to. Ask an admin to approve a User Group Access record for you, or request that this lead be added to one of your groups."*

### Who bypasses the check

- **System Administrator** profile (Carlos, Eleni, Elizabeth, Tony)
- Anyone with a `User_Group_Access` "wildcard" row (`All_Groups = true`, `Group` blank, `Status = Approved`). Currently three users: **Erick Moretti, Pedro Galindo, Nathalie Aguirre**.

Wildcard rows mean those three can edit any Lead regardless of its Group, without being granted access to every group individually. Future admin-assistant additions: just create one wildcard row per user, no Flow change needed.

---

## What to do about the old `Group_old2` field

Reconciliation moved the legacy free-text values into canonical
`Lead.Group__c` lookups. So `Group_old2` is now largely redundant for
day-to-day use. The question is whether to delete it or keep it.

### Recommendation: **keep the field, hide it from agents**

| | Why |
|---|---|
| **Don't delete the field** | If we ever need to audit "what did the agent originally type for this lead?", the field is our only record. Reconciliation isn't perfect — a small number of `Group__c` assignments were inferred from context and could be wrong. `Group_old2` is the ground truth. |
| **Remove from agent page layouts** | Agents shouldn't see two Group fields side by side — it's confusing and invites them to keep editing the wrong one. |
| **Keep visible on admin layouts** | You and Carlos still want to see it for debugging individual leads ("why is this lead in BrowardMulti when their old text says HiaApts?"). |
| **Optional: rename the label** | Change the field's Label to **"Group (legacy text, do not edit)"** so even when it shows up in admin views, the intent is clear. |

### How to do it (5 minutes)

1. Setup → Object Manager → **Lead** → **Page Layouts**.
2. Open every layout used by `Account for Agents` (typically the **Lead Layout** and **Etico Lead Layout**) → drag `Group_old2` off the layout into the gray field palette → **Save**.
3. (Optional rename) Setup → Object Manager → **Lead** → **Fields & Relationships** → click `Group_old2` → **Edit** → change Label to **"Group (legacy text, do not edit)"** → **Save**. The API name stays `Group_old2__c`, so no scripts break.

### What about `Lead.Group__c` (the lookup)?

**Keep it. Don't touch.** This field is:

- read by the AI receptionist
- read by existing list views and reports
- the "primary group" semantic ("which list does this lead live on first")
- the field the Flow looks at via the junction

The junction (`Lead_List_Assignment__c`) is **additive** — it supplements
`Lead.Group__c` with multi-group support. Both coexist by design.

---

## What's open vs. done (so Nathalie knows where we are)

### ✅ Done

- Junction objects built and populated (100,599 assignments, 1,031 user accesses, 866 grandfathered to ownership so nobody is blocked when the Flow turns on).
- `Lead_Group_Access_Check` Flow is **Active** in prod (v3, as of 2026-06-05). System Admins and the three wildcard users (Erick, Pedro, Nathalie) bypass.
- "Lead Data Export" permission set granting Export + API: assigned to Carlos, Nathalie, Elizabeth. Agents no longer have export or API at the profile level.
- Field History Tracking on Lead (18 months, ~20 fields).

### 🟡 To verify / smoke-test

- Erick, Pedro, Nathalie should each log in once and try editing a Lead in a group they don't normally own — confirms the wildcard bypass works on their accounts. (PE has no "Login As" so I can't verify on their behalf.)

### 🟡 Still to build (small stuff)

- 3 admin LeadHistory reports (Lead Edits — last 7 days; Owner Changes Audit; Bulk Edit Detector).
- Approval queue for Pending Lead Group Assignments. Two paths in `docs/group-assignment-approval-process.md` — pick one.
- Recovery runbook should be extracted from `security-track-design.md` into its own file.
- Weekly Data Export scheduled in Setup → Data Management → Data Export (one-time GUI click).

### ❌ Won't ship

- Sensitive field lockdown — Fausto vetoed early on (agents need to be able to edit lead details).
- Custom Permission as the bypass mechanism — Professional Edition doesn't expose Custom Permissions in this org. We used the wildcard `User_Group_Access` row pattern instead. Same effect.

---

## What you can tell agents in one paragraph

> We tightened access so each agent edits leads in the groups they own, with full audit trail. Most of you won't notice — your normal leads work exactly the same. If you try to edit a lead in a group you don't have, you'll see a "you don't have access to this group" error and can ask an admin to add you. Multi-group leads are now supported through a new related list on the Lead page; submit a new entry there as Pending and Nathalie will approve. Old "Group" text field is being retired — use the Group lookup going forward.
