/**
 * Re-map mislabeled leads to the group their old-text actually indicates.
 *
 * During reconciliation a small set of leads (~0.5%) got their Group__c set to a
 * different group than their Group_old2__c text implies (e.g. old text "Wynwood
 * Norte" but filed under JRLitHaitiWynAPT). This blocks agents who have the
 * CORRECT group from editing them.
 *
 * Fix: for each such lead, move it to the DOMINANT home of its old-text (the
 * group where the majority of that old-text's leads live). Updates BOTH:
 *   - Lead.Group__c   (display / Property lookups)
 *   - Lead_List_Assignment__c.Group__c  (what the access Flow actually checks)
 *
 * Excludes junk old-texts (na/n/a/Other/blank) and the "Alberto" judgment call.
 *
 * Dry-run by default.
 *   npx tsx --env-file .env.local scripts/migrations/remap-mislabeled-group-leads.ts
 *   npx tsx --env-file .env.local scripts/migrations/remap-mislabeled-group-leads.ts --commit
 */
import fs from 'node:fs';
import path from 'node:path';
import { sfClient } from '../../src/integrations/sf-client';

const API = '59.0';
const COMMIT = process.argv.includes('--commit');
const norm = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

const JUNK_GROUP = new Set(['other', 'open', 'na', 'n/a', 'none', 'buyer', 'seller', 'lead', 'delete', 'group']);
const skipOldText = (t: string) => {
  const k = norm(t);
  if (!k) return true;
  if (['na', 'n/a', 'none', 'other'].includes(k)) return true;
  if (/alberto/i.test(t)) return true;       // judgment call — leave for human
  return false;
};

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`\nRe-map mislabeled group leads — ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const names = new Map<string, string>((await sf.soql(`SELECT Id, Name FROM Group__c`)).map((g: any) => [g.Id, g.Name]));

  // dominant home per normalized old-text
  const cross: any[] = await sf.soql(
    `SELECT Group_old2__c t, Group__c gid, COUNT(Id) c FROM Lead WHERE Group__c!=null AND Group_old2__c!=null AND IsConverted=false GROUP BY Group_old2__c, Group__c`
  );
  const byText = new Map<string, Map<string, number>>();
  for (const r of cross) {
    const k = norm(r.t); if (!k) continue;
    if (!byText.has(k)) byText.set(k, new Map());
    const d = byText.get(k)!; d.set(r.gid, (d.get(r.gid) || 0) + Number(r.c));
  }
  const domOf = new Map<string, string>();
  for (const [k, d] of byText) { const top = [...d.entries()].sort((a, b) => b[1] - a[1])[0]; if (top) domOf.set(k, top[0]); }

  // candidate leads: Group__c != dominant home of old text
  const leads: any[] = await sf.soql(`SELECT Id, Group__c, Group_old2__c FROM Lead WHERE Group__c!=null AND Group_old2__c!=null AND IsConverted=false`);
  type Cand = { id: string; oldGid: string; newGid: string; oldText: string };
  const cands: Cand[] = [];
  for (const l of leads) {
    const dom = domOf.get(norm(l.Group_old2__c));
    if (!dom || dom === l.Group__c) continue;
    if (skipOldText(l.Group_old2__c)) continue;
    if (JUNK_GROUP.has((names.get(dom) || '').toLowerCase())) continue;
    cands.push({ id: l.Id, oldGid: l.Group__c, newGid: dom, oldText: l.Group_old2__c });
  }
  console.log(`Candidate leads to re-map: ${cands.length}`);

  // pull junctions for candidates (chunked IN)
  const candIds = cands.map((c) => c.id);
  const jxByLead = new Map<string, any[]>();
  for (let i = 0; i < candIds.length; i += 200) {
    const chunk = candIds.slice(i, i + 200).map((id) => `'${id}'`).join(',');
    const jx: any[] = await sf.soql(`SELECT Id, Lead__c, Group__c FROM Lead_List_Assignment__c WHERE Lead__c IN (${chunk})`);
    for (const j of jx) { if (!jxByLead.has(j.Lead__c)) jxByLead.set(j.Lead__c, []); jxByLead.get(j.Lead__c)!.push(j); }
  }

  // build ops
  const leadPatches: any[] = [];
  const jxPatches: any[] = [];   // repoint existing junction
  const jxCreates: any[] = [];   // create missing junction
  const jxDeletes: string[] = []; // delete redundant old junction
  const byMove = new Map<string, number>();

  for (const c of cands) {
    leadPatches.push({ attributes: { type: 'Lead' }, Id: c.id, Group__c: c.newGid });
    const jx = jxByLead.get(c.id) || [];
    const hasNew = jx.find((j) => j.Group__c === c.newGid);
    const oldJ = jx.find((j) => j.Group__c === c.oldGid);
    if (hasNew) { if (oldJ) jxDeletes.push(oldJ.Id); }            // already linked to new → drop old
    else if (oldJ) jxPatches.push({ attributes: { type: 'Lead_List_Assignment__c' }, Id: oldJ.Id, Group__c: c.newGid });
    else jxCreates.push({ attributes: { type: 'Lead_List_Assignment__c' }, Lead__c: c.id, Group__c: c.newGid, Status__c: 'Approved' });
    const key = `${names.get(c.oldGid)}  →  ${names.get(c.newGid)}`;
    byMove.set(key, (byMove.get(key) || 0) + 1);
  }

  console.log(`\nPlan: ${leadPatches.length} lead group updates | ${jxPatches.length} junction repoints | ${jxCreates.length} junction creates | ${jxDeletes.length} junction deletes`);
  console.log(`\nTop moves (from → to):`);
  for (const [k, n] of [...byMove.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20)) console.log(`  ${String(n).padStart(4)}  ${k}`);

  if (!COMMIT) { console.log(`\n🧪 Dry-run only. Re-run with --commit to apply.`); return; }

  // archive plan
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const archive = path.resolve(__dirname, '..', '..', 'data', 'archive', `remap-mislabeled-${ts}.json`);
  fs.writeFileSync(archive, JSON.stringify({ cands, jxDeletes }, null, 2));

  const patch = async (records: any[]) => {
    for (let i = 0; i < records.length; i += 200) {
      const res = await fetch(`${sf.instanceUrl}/services/data/v${API}/composite/sobjects`, {
        method: 'PATCH', headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ allOrNone: false, records: records.slice(i, i + 200) }) });
      const j = await res.json(); const f = j.filter((r: any) => !r.success).length;
      console.log(`   patched ${Math.min(i + 200, records.length)}/${records.length}${f ? ` (${f} failed: ${JSON.stringify(j.filter((r:any)=>!r.success).slice(0,1))})` : ''}`);
    }
  };
  const post = async (records: any[]) => {
    for (let i = 0; i < records.length; i += 200) {
      const res = await fetch(`${sf.instanceUrl}/services/data/v${API}/composite/sobjects`, {
        method: 'POST', headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ allOrNone: false, records: records.slice(i, i + 200) }) });
      const j = await res.json(); const f = j.filter((r: any) => !r.success).length;
      console.log(`   created ${Math.min(i + 200, records.length)}/${records.length}${f ? ` (${f} failed)` : ''}`);
    }
  };
  const del = async (ids: string[]) => {
    for (let i = 0; i < ids.length; i += 200) {
      const url = `${sf.instanceUrl}/services/data/v${API}/composite/sobjects?ids=${ids.slice(i, i + 200).join(',')}&allOrNone=false`;
      const res = await fetch(url, { method: 'DELETE', headers: { Authorization: `Bearer ${sf.accessToken}` } });
      console.log(`   deleted ${Math.min(i + 200, ids.length)}/${ids.length}${res.ok ? '' : ' ERR'}`);
    }
  };

  console.log(`\nApplying...`);
  console.log(' Lead group updates:'); await patch(leadPatches);
  console.log(' Junction repoints:'); await patch(jxPatches);
  console.log(' Junction creates:'); await post(jxCreates);
  console.log(' Junction deletes:'); await del(jxDeletes);
  console.log(`\n✅ Done. Archive: ${archive}`);
}
main().catch((e) => { console.error('💀', e); process.exit(1); });
