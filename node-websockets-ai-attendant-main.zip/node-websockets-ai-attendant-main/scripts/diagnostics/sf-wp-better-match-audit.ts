/**
 * Find SF records whose WP_Post_ID__c is suboptimal — there's a BETTER WP
 * post that matches the SF address.
 *
 * Strategy: for each SF record, use WP's native search (?search=...) on
 * the street address. WP's search covers title, content, AND meta — so it
 * catches posts where the address is in the title but not the fave_property_address
 * field, OR vice versa.
 *
 * Reports cases where:
 *   A. SF currently points at a non-existent WP post (orphan)
 *   B. SF points at WP post A, but WP post B exists at the same address and
 *      is OLDER (lower id, predates A) — likely the original canonical
 *   C. SF has no link but a clear WP candidate exists by address
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  City__c: string | null;
  Status__c: string | null;
  WP_Post_ID__c: number | null;
  CreatedDate: string;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  link: string;
  title: string;
  fave_property_address: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllWp(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,link,title,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          link: p.link || '',
          title: (p.title?.rendered || '').toString(),
          fave_property_address: p.fave_property_address || '',
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/**
 * Match an SF address against a WP post — checks address field, title, slug.
 * Looks for HOUSE NUMBER + at least one significant street token in any field.
 */
/**
 * Strict address match. Requires:
 *   1. The FIRST digit sequence in SF address (the house number) appears in
 *      WP's fave_property_address as the FIRST or LEADING token. This means
 *      we match wp_addr "1050 SW 7th St..." or "1050, Southwest 7th, Miami"
 *      but NOT "24,700 SF Light Industrial" or "20 Acres" where the number
 *      is incidental.
 *   2. At least one significant street token from SF also appears in WP.
 *
 * Skips matching on title alone to avoid "Mega Indoor Entertainment" style
 * marketing titles. Will catch true dupes where wp_addr is correctly set.
 *
 * Trade-off: misses cases where wp_addr is empty/wrong but title contains
 * the address. We accept that — those need manual review anyway.
 */
function addressMatches(sfAddress: string, sfCity: string, wp: WpPost): boolean {
  const sfLow = (sfAddress || '').toLowerCase();
  const cityLow = (sfCity || '').toLowerCase();

  // Extract the FIRST house number from SF address
  const houseMatch = sfLow.match(/\b(\d{2,6})\b/);
  if (!houseMatch) return false;
  const houseNum = houseMatch[1];

  // Significant tokens from SF (street name etc.)
  const streetTokens = sfLow.match(/\b[a-z]{3,}\b/g) || [];
  // Filler = NON-identifying words. Directions like "nw"/"sw" are excluded
  // here because they're often just 2 chars (won't pass the {3,} length
  // filter), but full forms like "northwest" should be kept as significant.
  const filler = new Set([
    'the', 'and', 'ave', 'street', 'avenue', 'road', 'drive', 'lane',
    'court', 'place', 'terrace', 'boulevard', 'fl', 'florida',
    'unit', 'building', 'suite', 'ste', 'apt', 'highway',
    'miami', 'hialeah', 'doral', 'hollywood', 'jacksonville',
  ]);
  const significant = streetTokens.filter((t) => !filler.has(t) && t !== cityLow);

  // Check WP address field — house number must appear at start of a comma-segment
  // (i.e., as a standalone street number, not embedded in a larger number)
  const wpAddr = wp.fave_property_address.toLowerCase();
  if (!wpAddr) return false;

  // Match patterns:
  //   "1050 SW 7th St"        — house num at start of address
  //   "1050, Southwest 7th"   — house num at start with comma after (Houzez format)
  //   "Castle Beach Club, 5445, Collins Ave"  — digit chunk after a label
  //
  // Requires the house number to appear at the START of the string or after
  // a comma+whitespace (so the comma is an address separator, not a thousands
  // grouping like "24,700"). Word boundary after handles the standalone case.
  const houseAtStart =
    new RegExp(`(?:^|,\\s+)${houseNum}\\b`, 'i').test(wpAddr);

  if (!houseAtStart) return false;

  // Require at least one significant street token to also match
  if (significant.length === 0) return true; // SF has no street tokens — accept on house num alone
  return significant.some((t) => wpAddr.includes(t));
}

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔍 Smarter SF↔WP match audit\n');

  const { token, instance } = await sfAuth();
  const [sfAll, wpAll] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Name, Address__c, City__c, Status__c, WP_Post_ID__c, CreatedDate
         FROM Property__c
        WHERE Address__c != NULL`
    ),
    fetchAllWp(),
  ]);

  const wpById = new Map<number, WpPost>();
  for (const p of wpAll) wpById.set(p.id, p);

  console.log(`SF records: ${sfAll.length}, WP posts: ${wpAll.length}\n`);

  type Issue = {
    sf: SfProperty;
    currentLink: WpPost | null;
    betterCandidates: WpPost[];
    category: 'A_ORPHAN' | 'B_BETTER_EXISTS' | 'C_UNLINKED_BUT_MATCH';
  };
  const issues: Issue[] = [];

  for (const sf of sfAll) {
    const matches = wpAll.filter((wp) => addressMatches(sf.Address__c!, sf.City__c || '', wp));
    const currentLink = sf.WP_Post_ID__c ? wpById.get(sf.WP_Post_ID__c) || null : null;

    if (sf.WP_Post_ID__c && !currentLink) {
      // Category A: SF points at non-existent WP
      issues.push({ sf, currentLink: null, betterCandidates: matches, category: 'A_ORPHAN' });
      continue;
    }

    if (!sf.WP_Post_ID__c && matches.length > 0) {
      // Category C: SF unlinked but matches exist
      issues.push({ sf, currentLink: null, betterCandidates: matches, category: 'C_UNLINKED_BUT_MATCH' });
      continue;
    }

    if (currentLink && matches.length > 0) {
      // Category B: check if an older/better match exists
      const others = matches.filter((m) => m.id !== currentLink.id);
      if (others.length === 0) continue;
      // Suggest if any candidate is OLDER than the current link AND not [DUPLICATE]-tagged
      const olderCandidates = others.filter(
        (m) => m.id < currentLink.id && !m.title.includes('[DUPLICATE')
      );
      if (olderCandidates.length > 0) {
        issues.push({
          sf,
          currentLink,
          betterCandidates: olderCandidates,
          category: 'B_BETTER_EXISTS',
        });
      }
    }
  }

  // Output by category
  const a = issues.filter((i) => i.category === 'A_ORPHAN');
  const b = issues.filter((i) => i.category === 'B_BETTER_EXISTS');
  const c = issues.filter((i) => i.category === 'C_UNLINKED_BUT_MATCH');

  console.log('═'.repeat(78));
  console.log('SUMMARY');
  console.log('═'.repeat(78));
  console.log(`  A — SF orphans (link points at deleted WP):              ${a.length}`);
  console.log(`  B — SF linked but a BETTER (older) WP candidate exists:  ${b.length}`);
  console.log(`  C — SF unlinked but a matching WP exists:                ${c.length}`);
  console.log('');

  const printCandidate = (wp: WpPost, indent: string = '     ') => {
    console.log(`${indent}wp:${wp.id}  ${wp.status.padEnd(8)} ${wp.date.slice(0, 10)}  "${trunc(wp.title.replace(/&#8211;/g, '–'), 55)}"`);
    console.log(`${indent}  addr: "${trunc(wp.fave_property_address, 90)}"`);
  };

  if (a.length > 0) {
    console.log('── A: ORPHANS ──\n');
    for (const i of a) {
      console.log(`SF ${i.sf.Id}  "${i.sf.Address__c || ''}"  /  ${i.sf.City__c || ''}  /  ${i.sf.Status__c || ''}`);
      console.log(`   Currently points at: wp:${i.sf.WP_Post_ID__c} (DELETED)`);
      if (i.betterCandidates.length === 0) {
        console.log(`   No address-matching WP candidates — null the link or create fresh draft`);
      } else {
        console.log(`   Address-matching WP candidates:`);
        for (const wp of i.betterCandidates) printCandidate(wp);
      }
      console.log('');
    }
  }

  if (b.length > 0) {
    console.log('── B: BETTER CANDIDATE EXISTS (currently linked to a newer post when an older one matches) ──\n');
    for (const i of b) {
      console.log(`SF ${i.sf.Id}  "${i.sf.Address__c || ''}"  /  ${i.sf.City__c || ''}  /  ${i.sf.Status__c || ''}`);
      console.log(`   Currently:`);
      printCandidate(i.currentLink!, '     ');
      console.log(`   Better candidate(s):`);
      for (const wp of i.betterCandidates) printCandidate(wp);
      console.log('');
    }
  }

  if (c.length > 0) {
    console.log('── C: SF UNLINKED, MATCH EXISTS ──\n');
    for (const i of c) {
      console.log(`SF ${i.sf.Id}  "${i.sf.Address__c || ''}"  /  ${i.sf.City__c || ''}  /  ${i.sf.Status__c || ''}`);
      for (const wp of i.betterCandidates) printCandidate(wp, '   ');
      console.log('');
    }
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
