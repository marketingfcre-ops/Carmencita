/**
 * Marketing & Automation Report — data assembly + calculated metrics.
 *
 * Pulls live, read-only data from Salesforce, Campaign Monitor, GA4, and
 * ClickUp, computes week-over-week deltas and the ★ "full-package" flag, and
 * returns a single `ReportData` object the route layer renders (HTML) or serves
 * (JSON). Result is cached ~5 min. No writes anywhere (SOQL SELECT + GETs).
 *
 * ── Windowing (per the Weekly Report Build Rules handoff) ──────────────────
 * The report is a weekly EOD-Friday artifact. Windows are anchored to a
 * "report Friday" (the most recent Friday, or an explicit ?friday=YYYY-MM-DD):
 *   - GA4 + Salesforce  current = Saturday–Friday (7 days, INCLUDES the weekend
 *                                 so weekend listing intakes land in this report)
 *   - Campaign Monitor  current = Monday–Friday (actual send window)
 *   - Prior week (ALL)          = the previous Monday–Friday (5 days)
 * The 7-day-vs-5-day asymmetry is intentional (absolute totals rise); per the
 * framing rules we do NOT flag it as a caveat.
 *
 * Manual inputs (edited weekly, everything else is live):
 *   - AUTOMATION_LOG  — the free-text Automation & Project Work log
 *   - MANUAL_GA4      — GA4 figures read by hand; used only until GA4_SA_JSON is
 *                       set, at which point live data takes over automatically.
 *
 * Env:
 *   CM_API_KEY     — Campaign Monitor key (already used elsewhere)
 *   CM_CLIENT_ID   — (optional) pin the CM client; else resolved by name
 *   GA4_*          — see src/integrations/ga4.ts (optional; falls back to MANUAL_GA4)
 *   CLICKUP_TOKEN  — see src/integrations/clickup.ts (optional)
 *   SF_*           — Salesforce (via src/integrations/sf-client.ts)
 */

import { sfClient } from './integrations/sf-client';
import {
  listClients,
  listSentCampaigns,
  getCampaignSummary,
  type CMSentCampaign,
} from './campaign-monitor';
import { getGa4Report, isGa4Configured, type GA4Metrics } from './integrations/ga4';
import { getClickupBoard, isClickupConfigured, type ClickupBoard } from './integrations/clickup';
import {
  MANUAL_GA4,
  AUTOMATION_LOG,
  type AutomationEntry,
  type AutomationSection,
} from './report-manual';

// Re-export so existing importers of these types from './report' keep working.
export type { AutomationEntry, AutomationSection };

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes
const FULL_PACKAGE_PRICE = 3_000_000; // ★ threshold
const FULL_PACKAGE_AGENT = /elior\s+levi/i; // ★ always, regardless of price

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** current - prior, expressed as a percentage; null when prior is 0. */
export interface Delta {
  pct: number | null;
  direction: 'up' | 'down' | 'flat';
}

export interface Windows {
  generatedAt: string; // ISO
  reportFriday: string; // YYYY-MM-DD the week is anchored to
  /** Mon–Fri labels (header + Campaign Monitor). */
  currentWorkWeekLabel: string; // e.g. "Jun 22 – Jun 26"
  priorWorkWeekLabel: string; // e.g. "Jun 15 – Jun 19"
  /** Sat–Fri label for GA4 + Salesforce current (7 days incl. weekend). */
  trafficCurrentLabel: string; // e.g. "Jun 20 – Jun 26"
}

export type Ga4Source = 'live' | 'manual' | 'pending';

export interface Ga4Section {
  source: Ga4Source;
  propertyId: string;
  current: GA4Metrics | null;
  prior: GA4Metrics | null;
  deltas: {
    activeUsers: Delta;
    newUsers: Delta;
    sessions: Delta;
    screenPageViews: Delta;
    keyEvents: Delta;
  } | null;
  note: string;
}

export interface EmailSection {
  configured: boolean;
  clientName: string;
  clientAmbiguous: boolean; // true → we guessed the CM client; confirm it
  campaignsSent: number;
  priorCampaignsSent: number;
  totalRecipients: number;
  totalUnsubscribes: number;
  priorUnsubscribes: number;
  avgOpenRatePct: number;
  priorAvgOpenRatePct: number;
  avgClickRatePct: number;
  bounceRatePct: number;
  unsubDelta: Delta;
}

export interface IntakeRow {
  id: string;
  name: string;
  agent: string;
  price: number | null;
  priceLabel: string;
  listingType: string;
  createdDate: string; // ISO
  dateLabel: string; // "6/22"
  isFullPackage: boolean;
  isElior: boolean;
}

export interface IntakeSection {
  currentCount: number;
  priorCount: number;
  totalCount: number;
  fullPackageCount: number;
  currentRows: IntakeRow[];
  priorRows: IntakeRow[];
  note: string;
}

export interface ClickupSection {
  configured: boolean;
  board: ClickupBoard | null;
  note: string;
}

export interface ReportData {
  windows: Windows;
  ga4: Ga4Section;
  email: EmailSection;
  intakes: IntakeSection;
  automation: AutomationSection;
  clickup: ClickupSection;
  sources: string;
  /** Any non-fatal problems while assembling (shown to the operator only). */
  warnings: string[];
}

// ---------------------------------------------------------------------------
// Manual inputs — the weekly-editable data (AUTOMATION_LOG, MANUAL_GA4) lives in
// src/report-manual.ts. Everything else here is live/derived. Do not inline
// weekly numbers in this file.
// ---------------------------------------------------------------------------

const SOURCES =
  'Google Analytics 4 (property 433530724) · Campaign Monitor · ' +
  'Salesforce Property__c by Created Date · ClickUp "Listings & Marketing" · manual work log.';

// ---------------------------------------------------------------------------
// Window math — Friday-anchored, per-section (see file header)
// ---------------------------------------------------------------------------

const DAY_MS = 86_400_000;

function ymd(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

function shortLabel(ms: number): string {
  return new Date(ms).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
}

function midnightUtc(d: Date): number {
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

/** Most recent Friday (today if Friday), at UTC midnight. */
function mostRecentFriday(fromMs: number): number {
  const dow = new Date(fromMs).getUTCDay(); // 0 Sun … 5 Fri … 6 Sat
  const daysSinceFri = (dow - 5 + 7) % 7;
  return fromMs - daysSinceFri * DAY_MS;
}

interface Bounds {
  curStart: number;
  curEndExcl: number;
  priStart: number;
  priEndExcl: number;
}

interface ReportWindows {
  windows: Windows;
  ga4Dates: { current: { start: string; end: string }; prior: { start: string; end: string } };
  /** GA4 + Salesforce: current Sat–Fri (7d), prior Mon–Fri (5d). */
  trafficBounds: Bounds;
  /** Campaign Monitor: current + prior both Mon–Fri (5d). */
  cmBounds: Bounds;
}

/**
 * Compute all report windows anchored to a report Friday.
 * @param anchorFriday optional YYYY-MM-DD; snapped back to the most recent Friday.
 */
export function computeReportWindows(now: Date = new Date(), anchorFriday?: string): ReportWindows {
  const baseMs =
    anchorFriday && /^\d{4}-\d{2}-\d{2}$/.test(anchorFriday)
      ? Date.parse(anchorFriday + 'T00:00:00Z')
      : midnightUtc(now);
  const reportFri = mostRecentFriday(baseMs); // Friday 00:00
  const curFriEndExcl = reportFri + DAY_MS; // include all of Friday
  const curMon = reportFri - 4 * DAY_MS; // Monday of the work week
  const curSat = reportFri - 6 * DAY_MS; // Saturday before the work week
  const priFri = reportFri - 7 * DAY_MS; // previous Friday
  const priFriEndExcl = priFri + DAY_MS;
  const priMon = priFri - 4 * DAY_MS; // previous Monday

  return {
    windows: {
      generatedAt: now.toISOString(),
      reportFriday: ymd(reportFri),
      currentWorkWeekLabel: `${shortLabel(curMon)} – ${shortLabel(reportFri)}`,
      priorWorkWeekLabel: `${shortLabel(priMon)} – ${shortLabel(priFri)}`,
      trafficCurrentLabel: `${shortLabel(curSat)} – ${shortLabel(reportFri)}`,
    },
    ga4Dates: {
      current: { start: ymd(curSat), end: ymd(reportFri) },
      prior: { start: ymd(priMon), end: ymd(priFri) },
    },
    trafficBounds: { curStart: curSat, curEndExcl: curFriEndExcl, priStart: priMon, priEndExcl: priFriEndExcl },
    cmBounds: { curStart: curMon, curEndExcl: curFriEndExcl, priStart: priMon, priEndExcl: priFriEndExcl },
  };
}

// ---------------------------------------------------------------------------
// Metric helpers
// ---------------------------------------------------------------------------

function delta(current: number, prior: number): Delta {
  if (prior === 0) {
    return { pct: null, direction: current > 0 ? 'up' : 'flat' };
  }
  const pct = ((current - prior) / prior) * 100;
  return {
    pct: Math.round(pct * 10) / 10,
    direction: pct > 0.05 ? 'up' : pct < -0.05 ? 'down' : 'flat',
  };
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function usd(n: number | null): string {
  if (n == null) return '—';
  return '$' + Math.round(n).toLocaleString('en-US');
}

function ga4Deltas(current: GA4Metrics, prior: GA4Metrics): Ga4Section['deltas'] {
  return {
    activeUsers: delta(current.activeUsers, prior.activeUsers),
    newUsers: delta(current.newUsers, prior.newUsers),
    sessions: delta(current.sessions, prior.sessions),
    screenPageViews: delta(current.screenPageViews, prior.screenPageViews),
    keyEvents: delta(current.keyEvents, prior.keyEvents),
  };
}

// ---------------------------------------------------------------------------
// Salesforce — new listing intakes by Created Date (own SOQL, needs CreatedDate)
// ---------------------------------------------------------------------------

interface RawIntake {
  Id: string;
  Name: string;
  Price__c: number | null;
  Listing_Type__c: string | null;
  Listing_Agent__r?: { Name?: string } | null;
  CreatedDate: string;
}

function toIntakeRow(r: RawIntake): IntakeRow {
  const agent = r.Listing_Agent__r?.Name || '—';
  const price = r.Price__c ?? null;
  const isElior = FULL_PACKAGE_AGENT.test(agent);
  const isFullPackage = isElior || (price != null && price >= FULL_PACKAGE_PRICE);
  return {
    id: r.Id,
    name: r.Name || '(unnamed)',
    agent,
    price,
    priceLabel: usd(price),
    listingType: r.Listing_Type__c || '',
    createdDate: r.CreatedDate,
    dateLabel: new Date(r.CreatedDate).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', timeZone: 'UTC' }),
    isFullPackage,
    isElior,
  };
}

async function assembleIntakes(bounds: Bounds, warnings: string[]): Promise<IntakeSection> {
  const empty: IntakeSection = {
    currentCount: 0, priorCount: 0, totalCount: 0, fullPackageCount: 0,
    currentRows: [], priorRows: [],
    note: '★ = ≥ $3M or Elior Levi listing — full marketing package triggered (OM, flyer, landing page, LoopNet). L = Elior Levi agent.',
  };
  try {
    const sf = await sfClient('prod');
    // Fetch everything created since the start of the prior window, then bucket.
    const sinceIso = new Date(bounds.priStart).toISOString();
    const rows = await sf.soql<RawIntake>(
      `SELECT Id, Name, Price__c, Listing_Type__c, Listing_Agent__r.Name, CreatedDate ` +
        `FROM Property__c WHERE CreatedDate >= ${sinceIso} ORDER BY CreatedDate`
    );

    const current: IntakeRow[] = [];
    const prior: IntakeRow[] = [];
    for (const r of rows) {
      const t = new Date(r.CreatedDate).getTime();
      const row = toIntakeRow(r);
      if (t >= bounds.curStart && t < bounds.curEndExcl) current.push(row);
      else if (t >= bounds.priStart && t < bounds.priEndExcl) prior.push(row);
    }
    const fullPackageCount =
      current.filter((r) => r.isFullPackage).length +
      prior.filter((r) => r.isFullPackage).length;

    return {
      ...empty,
      currentCount: current.length,
      priorCount: prior.length,
      totalCount: current.length + prior.length,
      fullPackageCount,
      currentRows: current,
      priorRows: prior,
    };
  } catch (err: any) {
    warnings.push(`Salesforce intakes unavailable: ${err?.message || err}`);
    return empty;
  }
}

// ---------------------------------------------------------------------------
// Campaign Monitor — sent campaigns (Mon–Fri window both weeks)
// ---------------------------------------------------------------------------

function parseCmDate(s: string): number {
  // CM format "YYYY-MM-DD HH:mm:ss" (account timezone, no offset).
  const t = Date.parse(s.replace(' ', 'T'));
  return Number.isNaN(t) ? 0 : t;
}

async function resolveCmClient(
  apiKey: string
): Promise<{ id: string; name: string; ambiguous: boolean }> {
  const pinned = process.env.CM_CLIENT_ID;
  if (pinned) return { id: pinned, name: '(CM_CLIENT_ID)', ambiguous: false };
  const clients = await listClients(apiKey);
  if (clients.length === 0) throw new Error('no CM clients on this account');
  if (clients.length === 1) {
    return { id: clients[0].ClientID, name: clients[0].Name, ambiguous: false };
  }
  const match = clients.find((c) => /fausto/i.test(c.Name));
  if (match) return { id: match.ClientID, name: match.Name, ambiguous: true };
  return { id: clients[0].ClientID, name: clients[0].Name, ambiguous: true };
}

async function assembleEmail(bounds: Bounds, warnings: string[]): Promise<EmailSection> {
  const base: EmailSection = {
    configured: false, clientName: '', clientAmbiguous: false,
    campaignsSent: 0, priorCampaignsSent: 0, totalRecipients: 0,
    totalUnsubscribes: 0, priorUnsubscribes: 0, avgOpenRatePct: 0,
    priorAvgOpenRatePct: 0, avgClickRatePct: 0, bounceRatePct: 0,
    unsubDelta: { pct: null, direction: 'flat' },
  };
  const apiKey = process.env.CM_API_KEY;
  if (!apiKey) {
    warnings.push('Campaign Monitor: CM_API_KEY not set — email section is empty.');
    return base;
  }

  try {
    const client = await resolveCmClient(apiKey);
    const all = await listSentCampaigns(apiKey, client.id);

    const inWindow = (c: CMSentCampaign, start: number, endExcl: number) => {
      const t = parseCmDate(c.SentDate);
      return t >= start && t < endExcl;
    };
    const currentCampaigns = all.filter((c) => inWindow(c, bounds.curStart, bounds.curEndExcl));
    const priorCampaigns = all.filter((c) => inWindow(c, bounds.priStart, bounds.priEndExcl));

    const curSummaries = await Promise.all(
      currentCampaigns.map((c) => getCampaignSummary(apiKey, c.CampaignID))
    );
    const priSummaries = await Promise.all(
      priorCampaigns.map((c) => getCampaignSummary(apiKey, c.CampaignID))
    );

    const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);
    const recipients = sum(curSummaries.map((s) => s.Recipients));
    const uniqueOpened = sum(curSummaries.map((s) => s.UniqueOpened));
    const clicks = sum(curSummaries.map((s) => s.Clicks));
    const unsub = sum(curSummaries.map((s) => s.Unsubscribed));
    const bounced = sum(curSummaries.map((s) => s.Bounced));

    const priorUnsub = sum(priSummaries.map((s) => s.Unsubscribed));
    const priorRecip = sum(priSummaries.map((s) => s.Recipients));
    const priorUniqueOpened = sum(priSummaries.map((s) => s.UniqueOpened));

    return {
      ...base,
      configured: true,
      clientName: client.name,
      clientAmbiguous: client.ambiguous,
      campaignsSent: currentCampaigns.length,
      priorCampaignsSent: priorCampaigns.length,
      totalRecipients: recipients,
      totalUnsubscribes: unsub,
      priorUnsubscribes: priorUnsub,
      avgOpenRatePct: recipients ? round1((uniqueOpened / recipients) * 100) : 0,
      priorAvgOpenRatePct: priorRecip ? round1((priorUniqueOpened / priorRecip) * 100) : 0,
      avgClickRatePct: recipients ? round1((clicks / recipients) * 100) : 0,
      bounceRatePct: recipients ? round1((bounced / recipients) * 100) : 0,
      unsubDelta: delta(unsub, priorUnsub),
    };
  } catch (err: any) {
    warnings.push(`Campaign Monitor unavailable: ${err?.message || err}`);
    return base;
  }
}

// ---------------------------------------------------------------------------
// GA4 — live if configured, else manual figures, else pending
// ---------------------------------------------------------------------------

async function assembleGa4(
  ga4Dates: ReportWindows['ga4Dates'],
  warnings: string[]
): Promise<Ga4Section> {
  const propertyId = process.env.GA4_PROPERTY_ID || '433530724';
  const pending: Ga4Section = {
    source: 'pending', propertyId, current: null, prior: null, deltas: null,
    note: 'GA4 not configured and no manual figures entered — traffic section pending.',
  };

  // 1) Live API
  if (isGa4Configured()) {
    try {
      const rep = await getGa4Report(ga4Dates.current, ga4Dates.prior);
      if (rep) {
        return {
          source: 'live', propertyId,
          current: rep.current, prior: rep.prior,
          deltas: ga4Deltas(rep.current, rep.prior),
          note: 'Source: GA4 Data API. Engagement is total user-engagement seconds ÷ active users.',
        };
      }
    } catch (err: any) {
      warnings.push(`GA4 live fetch failed (${err?.message || err}) — falling back to manual figures.`);
    }
  }

  // 2) Manual figures
  if (MANUAL_GA4) {
    return {
      source: 'manual', propertyId,
      current: MANUAL_GA4.current, prior: MANUAL_GA4.prior,
      deltas: ga4Deltas(MANUAL_GA4.current, MANUAL_GA4.prior),
      note: 'Manual GA4 read (property 433530724). Auto-switches to live once GA4_SA_JSON is set.',
    };
  }

  // 3) Pending
  return pending;
}

// ---------------------------------------------------------------------------
// ClickUp
// ---------------------------------------------------------------------------

async function assembleClickup(warnings: string[]): Promise<ClickupSection> {
  if (!isClickupConfigured()) {
    return {
      configured: false,
      board: null,
      note: 'ClickUp token not configured — deliverables board pending CLICKUP_TOKEN.',
    };
  }
  try {
    const board = await getClickupBoard();
    return {
      configured: true,
      board,
      note: 'Shipped = completed this week · On Hold = queued / our side done, waiting on Dev · Blocked = broken automations or urgent dev dependencies.',
    };
  } catch (err: any) {
    warnings.push(`ClickUp unavailable: ${err?.message || err}`);
    return { configured: true, board: null, note: 'ClickUp fetch failed — see warnings.' };
  }
}

// ---------------------------------------------------------------------------
// Assembly + cache
// ---------------------------------------------------------------------------

let cache: { data: ReportData; at: number; key: string } | null = null;

/**
 * Assemble the report. `anchorFriday` (YYYY-MM-DD) backfills a specific week;
 * default is the most recent Friday. Cache is keyed by the anchor.
 */
export async function getReportData(force = false, anchorFriday?: string): Promise<ReportData> {
  const key = anchorFriday || 'latest';
  if (!force && cache && cache.key === key && Date.now() - cache.at < CACHE_TTL_MS) {
    return cache.data;
  }

  const rw = computeReportWindows(new Date(), anchorFriday);
  const warnings: string[] = [];

  const [ga4, email, intakes, clickup] = await Promise.all([
    assembleGa4(rw.ga4Dates, warnings),
    assembleEmail(rw.cmBounds, warnings),
    assembleIntakes(rw.trafficBounds, warnings),
    assembleClickup(warnings),
  ]);

  const data: ReportData = {
    windows: rw.windows,
    ga4,
    email,
    intakes,
    automation: AUTOMATION_LOG,
    clickup,
    sources: SOURCES,
    warnings,
  };

  cache = { data, at: Date.now(), key };
  return data;
}

/** Seconds → "2m 22s", or "—" for 0. */
export function fmtDuration(sec: number): string {
  if (!sec) return '—';
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}
