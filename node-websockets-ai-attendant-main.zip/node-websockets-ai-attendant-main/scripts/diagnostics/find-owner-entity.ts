/**
 * Investigate the "Owner Entity LLC" missing field/relationship.
 * Per CFM 2026-05-28: They cannot find owner entity LLC.
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. Look for any custom object with Owner or Entity in name (use EntityDefinition)
  console.log('=== Custom objects with Owner/Entity in name ===');
  const ownerObjs: any[] = await sf.toolingQuery(
    `SELECT QualifiedApiName, Label FROM EntityDefinition WHERE QualifiedApiName LIKE '%Owner%'`
  );
  const entityObjs: any[] = await sf.toolingQuery(
    `SELECT QualifiedApiName, Label FROM EntityDefinition WHERE QualifiedApiName LIKE '%Entity%'`
  );
  const labelObjs: any[] = await sf.toolingQuery(
    `SELECT QualifiedApiName, Label FROM EntityDefinition WHERE Label LIKE '%Owner Entity%'`
  );
  const seen = new Set<string>();
  for (const o of [...ownerObjs, ...entityObjs, ...labelObjs]) {
    const key = o.QualifiedApiName;
    if (seen.has(key)) continue;
    seen.add(key);
    console.log(`  ${key}   "${o.Label}"`);
  }
  if (!seen.size) console.log('  (no objects matched)');

  // 2. Fields on Property with Owner or Entity
  console.log('\n=== Property__c fields with Owner/Entity ===');
  const propDesc = await sf.describe('Property__c');
  const ownerFields = propDesc.fields.filter((f: any) =>
    /owner|entity/i.test(f.name) || /owner|entity/i.test(f.label || '')
  );
  for (const f of ownerFields) {
    console.log(`  ${f.name}  "${f.label}"  type=${f.type}  ${f.referenceTo?.length ? `→ ${f.referenceTo.join(',')}` : ''}`);
  }
  if (!ownerFields.length) console.log('  (no matching fields)');

  // 3. Account record types (LLC could be a record type)
  console.log('\n=== Account record types ===');
  const acctRTs: any[] = await sf.soql(
    `SELECT Id, Name, DeveloperName, IsActive FROM RecordType WHERE SobjectType = 'Account'`
  );
  for (const r of acctRTs) console.log(`  ${r.DeveloperName}   "${r.Name}"   active=${r.IsActive}`);

  // 4. Property record types too — maybe LLC is a Property record type
  console.log('\n=== Property__c record types ===');
  const propRTs: any[] = await sf.soql(
    `SELECT Id, Name, DeveloperName, IsActive FROM RecordType WHERE SobjectType = 'Property__c'`
  );
  for (const r of propRTs) console.log(`  ${r.DeveloperName}   "${r.Name}"   active=${r.IsActive}`);

  // 5. Recent metadata changes (Apex/Object/Layout) — last 7 days
  console.log('\n=== Recently modified metadata (last 14 days, top 30) ===');
  const recent: any[] = await sf.toolingQuery(
    `SELECT Name, Type, LastModifiedDate, LastModifiedBy.Name FROM ApexLog WHERE LastModifiedDate = LAST_N_DAYS:14 ORDER BY LastModifiedDate DESC LIMIT 1`
  ).catch(() => []);

  // 6. Check FieldDefinitions for anything with "Owner Entity" label
  console.log('\n=== FieldDefinitions with label containing "Owner Entity" ===');
  const fields: any[] = await sf.toolingQuery(
    `SELECT EntityDefinition.QualifiedApiName, DeveloperName, Label FROM FieldDefinition WHERE Label LIKE '%Owner Entity%'`
  ).catch((e: any) => { console.log('  (tooling query failed: ' + e.message + ')'); return []; });
  for (const f of fields) console.log(`  ${f.EntityDefinition?.QualifiedApiName}.${f.DeveloperName}   "${f.Label}"`);
  if (!fields.length) console.log('  (no fields with that label)');

  // 7. Lookup fields ON Property that might point to an Owner-Entity-like Account
  console.log('\n=== Lookup fields ON Property pointing to Account ===');
  const acctLookups = propDesc.fields.filter((f: any) => f.referenceTo?.includes('Account'));
  for (const f of acctLookups) console.log(`  ${f.name}  "${f.label}"  → ${f.referenceTo.join(',')}`);

  // 8. Look for Property page layouts to see when they were last modified
  console.log('\n=== Property layouts and their last-modified ===');
  const layouts: any[] = await sf.toolingQuery(
    `SELECT Name, NamespacePrefix, LastModifiedDate, LastModifiedBy.Name FROM Layout WHERE TableEnumOrId LIKE 'Property%'`
  ).catch(() => []);
  for (const l of layouts) console.log(`  ${l.Name}   modified ${l.LastModifiedDate} by ${l.LastModifiedBy?.Name}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
