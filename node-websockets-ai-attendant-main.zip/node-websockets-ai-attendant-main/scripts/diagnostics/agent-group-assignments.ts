/**
 * Agent → group assignment report, from User_Group_Access__c. Read-only.
 *
 * Produces the "who can work which lists" table — the current-state version of
 * the Excel Fausto originally sent. Writes docs/agent-group-assignments.md.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-assignments.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-group-assignments.ts --active-only
 */
import fs from 'node:fs';
import path from 'node:path';
import { sfClient } from '../../src/integrations/sf-client';

const ACTIVE_ONLY = process.argv.includes('--active-only');

// placeholder / junk "groups" that shouldn't appear in a client-facing report
const JUNK = new Set(
  ['other', 'open', 'buyer', 'buyers', 'na', 'n/a', 'none', 'lead', 'delete', 'group',
   'a', 'owner', 'seller', 'lessor', 'leasee', 'tenant', 'tenant ish', 'tenant broker',
   'broker', 'broker buyer', 'broker tenant', 'central', 'land', 'industrial', 'retail',
   'commercial', 'assemblage', 'developers', "ben's buyers", 'shimon', 'cindi', 'omni'].map((s) => s)
);
const isJunk = (name: string) =>
  JUNK.has((name || '').toLowerCase().trim()) || /^\d[\d)\-\s.]*$/.test(name) || /\d{3}[)\-]/.test(name);

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  const rows: any[] = await sf.soql(
    `SELECT User__r.Name, User__r.IsActive, User__r.Profile.Name, Group__r.Name
     FROM User_Group_Access__c
     ORDER BY User__r.Name`
  );

  type Agent = { name: string; active: boolean; profile: string; groups: string[] };
  const byAgent = new Map<string, Agent>();
  for (const r of rows) {
    const name = r.User__r?.Name || '(unknown user)';
    const active = !!r.User__r?.IsActive;
    if (ACTIVE_ONLY && !active) continue;
    const profile = r.User__r?.Profile?.Name || '';
    const grp = r.Group__r?.Name || '(unknown group)';
    if (isJunk(grp)) continue;                       // drop placeholder/junk groups
    if (!byAgent.has(name)) byAgent.set(name, { name, active, profile, groups: [] });
    byAgent.get(name)!.groups.push(grp);
  }

  const agents = [...byAgent.values()].sort((a, b) => a.name.localeCompare(b.name));
  // dedupe doubled group names (duplicate Group__c records surfacing) + sort
  for (const a of agents) a.groups = [...new Set(a.groups)].sort((x, y) => x.localeCompare(y));

  const lines: string[] = [];
  lines.push(`# Agent → Group Assignments — Current State\n`);
  lines.push(`_From Salesforce \`User_Group_Access__c\`. These are the groups each agent is allowed to edit once protection is on._\n`);
  const shownAssignments = agents.reduce((s, a) => s + a.groups.length, 0);
  lines.push(`**${agents.length} agents · ${shownAssignments} assignments${ACTIVE_ONLY ? ' (active agents only)' : ''}.**\n`);
  lines.push(`| Agent | # Groups | Groups |`);
  lines.push(`|---|---:|---|`);
  for (const a of agents) {
    const tag = a.active ? '' : ' _(inactive)_';
    lines.push(`| ${a.name}${tag} | ${a.groups.length} | ${a.groups.join(', ')} |`);
  }

  const outPath = path.resolve(__dirname, '..', '..', 'docs', 'agent-group-assignments.md');
  fs.writeFileSync(outPath, lines.join('\n') + '\n');

  // plain-text version for pasting into email
  const txt: string[] = [];
  txt.push(`AGENT ASSIGNMENTS — who can edit which lists (${agents.length}${ACTIVE_ONLY ? ' active' : ''} agents)`);
  txt.push(``);
  for (const a of agents) {
    const tag = a.active ? '' : ' (inactive)';
    txt.push(`- ${a.name}${tag}  (${a.groups.length}):  ${a.groups.join(', ')}`);
  }
  fs.writeFileSync(outPath.replace(/\.md$/, '.txt'), txt.join('\n') + '\n');

  console.log(`${agents.length} agents, ${rows.length} assignments.`);
  console.log('Top by group count:');
  for (const a of [...agents].sort((x, y) => y.groups.length - x.groups.length).slice(0, 8)) {
    console.log(`  ${a.name.padEnd(26)} ${a.groups.length} groups`);
  }
  console.log(`\nWrote ${outPath}`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
