/**
 * One-time cleanup: dedupe WP property posts and relink SF.
 *
 * Background
 *   The April batch script created WP drafts but never wrote WP_Post_ID__c
 *   back to SF. When SF Flow started firing webhooks (May 5–11), the sync
 *   handler saw SF.WP_Post_ID__c = null, the slug-based backfill found
 *   nothing (the April slugs didn't match Public_URL__c), so it created
 *   a NEW WP post for each affected property. Many got auto-published in
 *   the same window via the publish-on-update bug.
 *
 *   This script:
 *     1. Walks every Property__c that lacks WP_Post_ID__c and tries to
 *        locate an existing WP post by slug OR normalized address.
 *     2. Detects WP duplicate groups (multiple posts for the same
 *        normalized street address). Keeps the OLDEST post as canonical.
 *     3. Writes WP_Post_ID__c back to SF pointing at the canonical post.
 *     4. Moves duplicate WP posts to status='draft' and prefixes their
 *        title with "[DUPLICATE - see wp:<id>]" so a human can verify and
 *        permanently delete later (no destructive deletes from this script).
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/relink-and-cleanup-dupes.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/relink-and-cleanup-dupes.ts
 */

import {
  findPropertyIdBySlug,
  findPropertyIdByAddress,
  extractSlugFromPublicUrl,
  rebuildAddressIndex,
  updatePropertyPost,
} from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 120;

// Only retire duplicate WP posts created within this window — the publish-on-update
// bug landed in early May 2026, so anything before that is likely a legitimate
// older listing (multiple units at the same building, manually curated copies,
// etc.). Conservative by design — better to under-retire than to bury work.
const RETIRE_CREATED_AFTER = new Date('2026-05-01T00:00:00Z');

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  Public_URL__c: string | null;
  WP_Post_ID__c: number | null;
  Status__c: string | null;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth(): Promise<{ token: string; instance: string }> {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  return { token: access_token, instance: instance_url };
}

async function sfQuery<T>(
  token: string,
  instance: string,
  soql: string
): Promise<T[]> {
  let url:
    | string
    | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    }
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function sfUpdate(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(
    `${instance}/services/data/v59.0/sobjects/Property__c/${id}`,
    {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(fields),
    }
  );
  if (res.status === 204) return { ok: true };
  return { ok: false, error: `${res.status} ${(await res.text()).slice(0, 500)}` };
}

// Required-field placeholders — mirrors the logic in src/agent-review.ts.
// The April bulk import left lots of records without these required fields,
// so any PATCH (even one that only sets WP_Post_ID__c) gets rejected by
// SF validation rules. If SF complains, we retry adding placeholder values
// only for the specific fields it flagged as missing.
const FIELD_PLACEHOLDERS: Array<{
  match: RegExp;
  field: string;
  value: unknown;
}> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  {
    match: /Listing_Date__c|Listing Date/i,
    field: 'Listing_Date__c',
    value: new Date().toISOString().slice(0, 10),
  },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  {
    match: /Building Size|Building_Size_sqft__c/i,
    field: 'Building_Size_sqft__c',
    value: 0,
  },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  {
    match: /Lot Size|Lot_Size_sqft__c/i,
    field: 'Lot_Size_sqft__c',
    value: 0,
  },
];

async function sfUpdateWithPlaceholderRetry(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string; retried?: boolean; rounds?: number }> {
  // SF reports validation failures in BATCHES — fixing one set surfaces the next.
  // Accumulate placeholders across rounds until SF stops complaining (or we hit a cap).
  const MAX_ROUNDS = 5;
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  let rounds = 0;

  for (let i = 0; i < MAX_ROUNDS; i++) {
    rounds++;
    const result = await sfUpdate(token, instance, id, {
      ...fields,
      ...accumulated,
    });
    if (result.ok) {
      return { ok: true, retried: rounds > 1, rounds };
    }
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) {
      return { ok: false, error: lastError, retried: rounds > 1, rounds };
    }

    // Find any placeholders that match the latest error and that we haven't
    // added yet — if there are no new ones, we're stuck (retrying would be
    // identical), so give up.
    let addedSomething = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        addedSomething = true;
      }
    }
    if (!addedSomething) {
      return { ok: false, error: lastError, retried: rounds > 1, rounds };
    }
  }
  return {
    ok: false,
    error: `Exhausted ${MAX_ROUNDS} placeholder rounds. Last: ${lastError}`,
    retried: true,
    rounds,
  };
}

function normalizeAddress(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().split(',')[0];
  a = a.replace(/[#.]/g, ' ');
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 10; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title:
            (p.title?.rendered || p.title || '').toString() || '',
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

async function moveToDraft(
  wpId: number,
  canonicalId: number,
  currentTitle: string
): Promise<{ ok: boolean; error?: string }> {
  const newTitle = currentTitle.startsWith('[DUPLICATE')
    ? currentTitle
    : `[DUPLICATE - see wp:${canonicalId}] ${currentTitle}`;
  return updatePropertyPost(wpId, {
    status: 'draft',
    title: newTitle,
  });
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET || !WP_USER || !WP_APP_PASSWORD) {
    console.error('❌ Missing env vars (SF_* or WP_*).');
    process.exit(1);
  }

  console.log(`\n🧹 Relink + dedupe ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  // ---------------------------------------------------------------------------
  // 1. Load both sides
  // ---------------------------------------------------------------------------
  console.log('→ Authenticating with Salesforce...');
  const { token, instance } = await sfAuth();

  console.log('→ Fetching all SF Property__c records...');
  const sfRecords = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, Public_URL__c, WP_Post_ID__c, Status__c
     FROM Property__c`
  );
  console.log(`   ${sfRecords.length} SF properties`);

  console.log('→ Fetching all WP property posts...');
  const wpPosts = await fetchAllWpPosts();
  console.log(`   ${wpPosts.length} WP posts`);

  // ---------------------------------------------------------------------------
  // 2. Group WP posts by normalized address → duplicate detection
  // ---------------------------------------------------------------------------
  const byAddr = new Map<string, WpPost[]>();
  for (const p of wpPosts) {
    const key = normalizeAddress(p.fave_property_address);
    if (!key) continue;
    const arr = byAddr.get(key) || [];
    arr.push(p);
    byAddr.set(key, arr);
  }

  // Canonical post per address = OLDEST one (the original draft from April)
  const canonicalByAddr = new Map<string, WpPost>();
  const duplicateGroups: { address: string; canonical: WpPost; dupes: WpPost[] }[] = [];
  for (const [addr, posts] of byAddr.entries()) {
    const sorted = [...posts].sort((a, b) => a.date.localeCompare(b.date));
    canonicalByAddr.set(addr, sorted[0]);
    if (sorted.length > 1) {
      duplicateGroups.push({
        address: addr,
        canonical: sorted[0],
        dupes: sorted.slice(1),
      });
    }
  }

  console.log(
    `   Duplicate groups (same address, multiple posts): ${duplicateGroups.length}`
  );
  const totalDupes = duplicateGroups.reduce((n, g) => n + g.dupes.length, 0);
  console.log(`   Total duplicate posts to retire: ${totalDupes}`);

  // ---------------------------------------------------------------------------
  // 3. For each SF record without WP_Post_ID__c, find the canonical and link
  //    For each SF record WITH WP_Post_ID__c pointing at a duplicate, redirect to canonical
  // ---------------------------------------------------------------------------
  console.log('\n→ Building WP id → canonical map...');
  const dupeIdToCanonical = new Map<number, number>();
  for (const g of duplicateGroups) {
    for (const d of g.dupes) {
      dupeIdToCanonical.set(d.id, g.canonical.id);
    }
  }

  const sfWrites: { sf: SfProperty; targetWpId: number; reason: string }[] = [];

  for (const sf of sfRecords) {
    const sfAddr = normalizeAddress(sf.Address__c || sf.Name || '');
    const canon = canonicalByAddr.get(sfAddr);

    // Case A: SF.WP_Post_ID__c points at a duplicate → redirect to canonical
    if (sf.WP_Post_ID__c && dupeIdToCanonical.has(sf.WP_Post_ID__c)) {
      const canonicalId = dupeIdToCanonical.get(sf.WP_Post_ID__c)!;
      if (canonicalId !== sf.WP_Post_ID__c) {
        sfWrites.push({
          sf,
          targetWpId: canonicalId,
          reason: `redirect from duplicate wp:${sf.WP_Post_ID__c} → canonical wp:${canonicalId}`,
        });
        continue;
      }
    }

    // Case B: SF.WP_Post_ID__c is null but we found a matching post by address
    if (!sf.WP_Post_ID__c && canon) {
      sfWrites.push({
        sf,
        targetWpId: canon.id,
        reason: `link to existing wp:${canon.id} (matched by address)`,
      });
      continue;
    }

    // Case C: SF.WP_Post_ID__c is null and address didn't match — try slug as last resort
    if (!sf.WP_Post_ID__c && sf.Public_URL__c) {
      const slug = extractSlugFromPublicUrl(sf.Public_URL__c);
      if (slug) {
        const wpId = await findPropertyIdBySlug(slug);
        if (wpId) {
          sfWrites.push({
            sf,
            targetWpId: wpId,
            reason: `link to existing wp:${wpId} (matched by slug "${slug}")`,
          });
        }
      }
    }
  }

  console.log(`   SF records to update: ${sfWrites.length}`);

  // ---------------------------------------------------------------------------
  // 4. Execute SF updates
  // ---------------------------------------------------------------------------
  let sfOk = 0;
  let sfErr = 0;
  let sfRetried = 0;
  for (const w of sfWrites) {
    if (DRY_RUN) {
      console.log(`   [DRY] ${w.sf.Id} ← wp:${w.targetWpId}  (${w.reason})`);
      continue;
    }
    const result = await sfUpdateWithPlaceholderRetry(token, instance, w.sf.Id, {
      WP_Post_ID__c: w.targetWpId,
    });
    if (result.ok) {
      sfOk++;
      if (result.retried) sfRetried++;
      if (sfOk % 25 === 0) {
        console.log(`   ...${sfOk}/${sfWrites.length} SF writes done`);
      }
    } else {
      sfErr++;
      console.warn(`   ❌ SF ${w.sf.Id}: ${result.error}`);
    }
    await sleep(REQUEST_DELAY_MS);
  }

  // ---------------------------------------------------------------------------
  // 5. Retire duplicate WP posts → status=draft + "[DUPLICATE]" prefix
  // ---------------------------------------------------------------------------
  console.log(`\n→ Retiring ${totalDupes} duplicate WP posts...`);
  let wpOk = 0;
  let wpErr = 0;
  let wpSkipped = 0;
  for (const g of duplicateGroups) {
    for (const d of g.dupes) {
      // Only retire posts created in the May bug window — older "duplicates"
      // could be intentional (different units at the same address, etc.).
      const created = new Date(d.date);
      if (created < RETIRE_CREATED_AFTER) {
        wpSkipped++;
        continue;
      }
      // Skip if the duplicate is already a draft AND has a "[DUPLICATE" tag
      if (d.status === 'draft' && d.title.startsWith('[DUPLICATE')) {
        wpSkipped++;
        continue;
      }
      // Skip if the dupe has marketing edits we'd want to keep (featured image
      // present and the canonical doesn't). In that case, swap canonical pick.
      const canonHasImg = g.canonical.featured_media > 0;
      const dupeHasImg = d.featured_media > 0;
      if (dupeHasImg && !canonHasImg) {
        console.log(
          `   ⚠️  wp:${d.id} has photo but canonical wp:${g.canonical.id} does not — skipping retire so a human can decide.`
        );
        wpSkipped++;
        continue;
      }
      if (DRY_RUN) {
        console.log(
          `   [DRY] wp:${d.id} (${d.status}, "${d.title.slice(0, 40)}...") → draft + DUPLICATE prefix, canonical=wp:${g.canonical.id}`
        );
        continue;
      }
      const result = await moveToDraft(d.id, g.canonical.id, d.title);
      if (result.ok) {
        wpOk++;
      } else {
        wpErr++;
        console.warn(`   ❌ wp:${d.id}: ${result.error}`);
      }
      await sleep(REQUEST_DELAY_MS);
    }
  }

  // ---------------------------------------------------------------------------
  // 6. Summary
  // ---------------------------------------------------------------------------
  console.log('\n=== Summary ===');
  console.log(`SF records updated:        ${DRY_RUN ? '(dry run)' : sfOk}`);
  console.log(`  └─ with placeholder fix: ${DRY_RUN ? '(dry run)' : sfRetried}`);
  console.log(`SF write failures:         ${sfErr}`);
  console.log(`WP duplicates retired:     ${DRY_RUN ? '(dry run)' : wpOk}`);
  console.log(`WP retires skipped:        ${wpSkipped} (already-drafted or has photo)`);
  console.log(`WP retire failures:        ${wpErr}`);
  console.log('');

  // Make the address index match the new world so subsequent webhooks behave
  if (!DRY_RUN) {
    await rebuildAddressIndex();
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Cleanup crashed:', err);
  process.exit(1);
});
