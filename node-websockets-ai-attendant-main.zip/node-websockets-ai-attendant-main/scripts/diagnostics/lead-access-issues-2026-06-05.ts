/**
 * Diagnose the four access issues Nathalie reported 2026-06-05. Read-only.
 *
 *   1. Kodiak's lead 00QJw00000VJwBLMA1
 *   2. Lucia Villa's "SAN SANTIAGO LLC" lead (7201 CORAL WAY) — she owns it
 *      but can't edit; Group_old is "Coralway"
 *   3. Giovanni Bertolotti — needs access to libcitycom, littlehaiticorridors
 *      and is working a lead from Ashleen
 *   4. Ben Kunzle — eastside group (can't edit), and LHT Land Robin
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/lead-access-issues-2026-06-05.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // -------------------------------------------------------------------------
  // 1. KODIAK — specific lead 00QJw00000VJwBLMA1
  // -------------------------------------------------------------------------
  console.log('=== 1. Kodiak: Lead 00QJw00000VJwBLMA1 ===');
  const kodiakLead: any[] = await sf.soql(
    `SELECT Id, Name, Status, Owner.Name, Group__c, Group__r.Name, Group_old2__c, CreatedDate
     FROM Lead WHERE Id = '00QJw00000VJwBLMA1'`
  );
  for (const l of kodiakLead) {
    console.log(`  ${l.Id}  Name=${l.Name}  Status=${l.Status}`);
    console.log(`  Owner: ${l.Owner?.Name}`);
    console.log(`  Group__c: ${l.Group__r?.Name || '(null)'}  (id ${l.Group__c || '(null)'})`);
    console.log(`  Group_old2__c: "${l.Group_old2__c || ''}"`);
    console.log(`  CreatedDate: ${l.CreatedDate}`);
  }
  // What approved Lead_List_Assignments does this lead have?
  if (kodiakLead.length) {
    const assigns: any[] = await sf.soql(
      `SELECT Id, Group__r.Name, Status__c FROM Lead_List_Assignment__c WHERE Lead__c = '${kodiakLead[0].Id}'`
    );
    console.log(`  Approved Lead_List_Assignment count: ${assigns.filter((a) => a.Status__c === 'Approved').length}`);
    for (const a of assigns) console.log(`    ${a.Status__c.padEnd(10)} ${a.Group__r?.Name}`);
  }
  // Kodiak's User_Group_Access
  console.log('\n  Kodiak User_Group_Access rows:');
  const kodiakAccess: any[] = await sf.soql(
    `SELECT Id, Group__r.Name, Status__c, All_Groups__c
     FROM User_Group_Access__c WHERE User__r.Name = 'Kodiak Fields' ORDER BY Group__r.Name`
  );
  for (const a of kodiakAccess) console.log(`    ${a.Status__c.padEnd(10)} ${a.All_Groups__c ? '[WILDCARD]' : a.Group__r?.Name}`);

  // -------------------------------------------------------------------------
  // 2. LUCIA — "SAN SANTIAGO LLC" lead, owns it, can't edit, Group_old "Coralway"
  // -------------------------------------------------------------------------
  console.log('\n\n=== 2. Lucia Villa: SAN SANTIAGO LLC / 7201 CORAL WAY ===');
  const luciaLead: any[] = await sf.soql(
    `SELECT Id, Name, Status, Owner.Name, Group__c, Group__r.Name, Group_old2__c
     FROM Lead
     WHERE (Name LIKE '%SAN SANTIAGO%' OR Property__c LIKE '%7201%CORAL%')
       AND Owner.Name = 'Lucia Villa'
     LIMIT 5`
  );
  console.log(`  Found ${luciaLead.length} leads matching her name + 7201 CORAL WAY`);
  for (const l of luciaLead) {
    console.log(`\n  ${l.Id}  Name=${l.Name}`);
    console.log(`    Owner: ${l.Owner?.Name}`);
    console.log(`    Group__c: ${l.Group__r?.Name || '(null)'}  (id ${l.Group__c || '(null)'})`);
    console.log(`    Group_old2__c: "${l.Group_old2__c || ''}"`);
    const a: any[] = await sf.soql(
      `SELECT Group__r.Name, Status__c FROM Lead_List_Assignment__c WHERE Lead__c = '${l.Id}'`
    );
    console.log(`    Approved Lead_List_Assignment count: ${a.filter((x) => x.Status__c === 'Approved').length}`);
    for (const r of a) console.log(`      ${r.Status__c.padEnd(10)} ${r.Group__r?.Name}`);
  }
  // Lucia's User_Group_Access
  console.log('\n  Lucia User_Group_Access rows:');
  const luciaAccess: any[] = await sf.soql(
    `SELECT Group__r.Name, Status__c, All_Groups__c
     FROM User_Group_Access__c WHERE User__r.Name = 'Lucia Villa' ORDER BY Group__r.Name`
  );
  for (const a of luciaAccess) console.log(`    ${a.Status__c.padEnd(10)} ${a.All_Groups__c ? '[WILDCARD]' : a.Group__r?.Name}`);

  // Does "Coralway" exist as a Group__c record?
  console.log('\n  Group__c rows matching "coralway" / "coral way":');
  const coralways: any[] = await sf.soql(
    `SELECT Id, Name FROM Group__c WHERE Name LIKE '%oralway%' OR Name LIKE '%oral Way%' OR Name LIKE '%oralWay%' ORDER BY Name`
  );
  for (const g of coralways) console.log(`    ${g.Id}  "${g.Name}"`);

  // -------------------------------------------------------------------------
  // 3. GIOVANNI — libcitycom, littlehaiticorridors, working a lead from Ashleen
  // -------------------------------------------------------------------------
  console.log('\n\n=== 3. Giovanni Bertolotti ===');
  console.log('  Groups he says he works (do they exist?):');
  const gioGroups: any[] = await sf.soql(
    `SELECT Id, Name FROM Group__c
     WHERE Name LIKE '%ibcityCom%' OR Name LIKE '%ibCityCom%' OR Name LIKE '%LibCity%'
        OR Name LIKE '%ittleHaiti%' OR Name LIKE '%LitHaiti%' OR Name LIKE '%LittleHaitiCorridor%'
        OR Name LIKE '%LHC%'
     ORDER BY Name`
  );
  for (const g of gioGroups) console.log(`    ${g.Id}  "${g.Name}"`);

  console.log('\n  Giovanni User_Group_Access rows:');
  const gioAccess: any[] = await sf.soql(
    `SELECT Group__r.Name, Status__c, All_Groups__c
     FROM User_Group_Access__c WHERE User__r.Name = 'Giovanni Bertolotti' ORDER BY Group__r.Name`
  );
  for (const a of gioAccess) console.log(`    ${a.Status__c.padEnd(10)} ${a.All_Groups__c ? '[WILDCARD]' : a.Group__r?.Name}`);

  // -------------------------------------------------------------------------
  // 4. BEN KUNZLE — eastside group, LHT Land Robin
  // -------------------------------------------------------------------------
  console.log('\n\n=== 4. Ben Kunzle ===');
  console.log('  Groups he needs (do they exist?):');
  const benGroups: any[] = await sf.soql(
    `SELECT Id, Name FROM Group__c
     WHERE Name LIKE '%astside%' OR Name LIKE '%EastSide%' OR Name LIKE '%East Side%'
        OR Name LIKE '%LHT Land%' OR Name LIKE '%LHTLand%' OR Name LIKE '%LHT%Robin%'
     ORDER BY Name`
  );
  for (const g of benGroups) console.log(`    ${g.Id}  "${g.Name}"`);

  console.log('\n  Ben Kunzle User_Group_Access rows:');
  const benAccess: any[] = await sf.soql(
    `SELECT Group__r.Name, Status__c, All_Groups__c
     FROM User_Group_Access__c WHERE User__r.Name = 'Benjamin Kunzle' ORDER BY Group__r.Name`
  );
  for (const a of benAccess) console.log(`    ${a.Status__c.padEnd(10)} ${a.All_Groups__c ? '[WILDCARD]' : a.Group__r?.Name}`);

  // -------------------------------------------------------------------------
  // Summary: how many leads have Group_old2 set but no Approved Lead_List_Assignment?
  // (this is the "owner can't edit" pattern Lucia hit)
  // -------------------------------------------------------------------------
  console.log('\n\n=== Pattern check: leads with Group_old2 but no Approved assignment ===');
  const orphans: any[] = await sf.soql(
    `SELECT COUNT(Id) cnt FROM Lead WHERE Group_old2__c != null AND Group__c = null`
  );
  console.log(`  Leads with Group_old2 set but Group__c = null: ${orphans[0]?.cnt}`);
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
