/**
 * Two cleanups in one pass:
 *
 *   A. Semicolon multi-group: for "JRLitHaitiWyn;WWNAPT" (34) and
 *      "FlagamiApts; WWNAPT" (2), the lead belongs to BOTH groups. Same
 *      pattern as the earlier comma-multi-group fix — primary stays as the
 *      first listed; add a junction to each component.
 *
 *   B. BVM tag: every "X; BVM" / "X, BVM" lead currently links only to its
 *      primary X group. Per Jesús 2026-05-28: BVM is itself a group (used
 *      by the Bertolotti / Miranda / Villasuso pod). Add a BVM
 *      Lead_List_Assignment__c for each tagged lead.
 *
 * Idempotent. Dry-run by default. Won't dupe existing junctions.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/fix-bvm-and-semicolon-multi-leads.ts
 *   tsx --env-file .env.local scripts/migrations/fix-bvm-and-semicolon-multi-leads.ts --commit
 */

import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const TARGET: SfTarget = 'prod';
const COMMIT = process.argv.includes('--commit');
const BATCH = 200;
const API = '59.0';

// A. Semicolon multi-group: literal Group_old2 value → ordered component group Names.
const SEMICOLON_MULTI: Record<string, string[]> = {
  'JRLitHaitiWyn;WWNAPT':   ['JRLitHaitiWyn', 'WWNAPT'],
  'FlagamiApts; WWNAPT':    ['FlagamiApts', 'WWNAPT'],
};

async function main() {
  console.log(`\n🧹 Fix BVM-tagged + semicolon-multi-group leads`);
  console.log(`   target: ${TARGET}`);
  console.log(`   mode:   ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const groupByLowerName = new Map<string, string>();
  for (const g of groups) groupByLowerName.set(g.Name.toLowerCase(), g.Id);

  // ──────────────────────────────────────────────────────────────────────
  // A. Semicolon multi-group
  // ──────────────────────────────────────────────────────────────────────
  console.log('═══ A. Semicolon multi-group leads ═══');
  type SemiRow = { leadId: string; firstId: string; firstName: string; allIds: string[]; allNames: string[]; originalText: string };
  const semiRows: SemiRow[] = [];
  for (const [text, names] of Object.entries(SEMICOLON_MULTI)) {
    const ids: string[] = [];
    const missing: string[] = [];
    for (const n of names) {
      const id = groupByLowerName.get(n.toLowerCase());
      if (id) ids.push(id);
      else missing.push(n);
    }
    if (missing.length) {
      console.warn(`  ⚠ "${text}": missing canonical(s) [${missing.join(', ')}] — skipping`);
      continue;
    }
    const leads: any[] = await sf.soql(
      `SELECT Id FROM Lead WHERE Group_old2__c = '${text.replace(/'/g, "\\'")}'`
    );
    for (const lead of leads) {
      semiRows.push({
        leadId: lead.Id, firstId: ids[0], firstName: names[0],
        allIds: ids, allNames: names, originalText: text,
      });
    }
  }
  console.log(`  ${semiRows.length} leads to re-route to first-component + add junctions`);

  // ──────────────────────────────────────────────────────────────────────
  // B. BVM-tag pattern — add a BVM Lead_List_Assignment for every "X; BVM"
  //    or "X, BVM" tagged lead.
  // ──────────────────────────────────────────────────────────────────────
  console.log('\n═══ B. BVM-tagged leads ═══');
  const bvmId = groupByLowerName.get('bvm');
  if (!bvmId) {
    console.error('  ⚠ BVM Group__c missing — cannot add BVM junctions');
    process.exit(1);
  }
  console.log(`  BVM Group__c.Id: ${bvmId}`);

  const bvmTagged: any[] = await sf.soql(
    `SELECT Id, Group_old2__c FROM Lead WHERE Group_old2__c LIKE '%; BVM%' OR Group_old2__c LIKE '%;BVM%' OR Group_old2__c LIKE '%, BVM%' OR Group_old2__c LIKE '%;  BVM%'`
  );
  console.log(`  ${bvmTagged.length} BVM-tagged leads found`);

  // Skip leads that already have a BVM junction
  let existingBvmJunctions: Set<string>;
  if (bvmTagged.length > 0) {
    const leadIdsChunked: string[][] = [];
    for (let i = 0; i < bvmTagged.length; i += 800) leadIdsChunked.push(bvmTagged.slice(i, i + 800).map((l) => `'${l.Id}'`));
    const existingIds = new Set<string>();
    for (const chunk of leadIdsChunked) {
      const existing: any[] = await sf.soql(
        `SELECT Lead__c FROM Lead_List_Assignment__c WHERE Group__c = '${bvmId}' AND Lead__c IN (${chunk.join(',')})`
      );
      for (const e of existing) existingIds.add(e.Lead__c);
    }
    existingBvmJunctions = existingIds;
    console.log(`  ${existingIds.size} already have a BVM junction (skip)`);
  } else {
    existingBvmJunctions = new Set();
  }

  // ──────────────────────────────────────────────────────────────────────
  // Plan summary
  // ──────────────────────────────────────────────────────────────────────
  const newBvmJunctions = bvmTagged.filter((l) => !existingBvmJunctions.has(l.Id));
  let newSemiPatches = 0;
  let newSemiJunctions = 0;

  // For semi-rows, count what we'd create
  const semiLeadIds = semiRows.map((r) => r.leadId);
  let existingSemiJunctions = new Set<string>();
  if (semiLeadIds.length > 0) {
    const idList = semiLeadIds.map((id) => `'${id}'`).join(',');
    const existing: any[] = await sf.soql(
      `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c WHERE Lead__c IN (${idList})`
    );
    existingSemiJunctions = new Set(existing.map((e) => `${e.Lead__c}|${e.Group__c}`));
  }
  for (const r of semiRows) {
    newSemiPatches++;
    for (const gid of r.allIds) {
      if (!existingSemiJunctions.has(`${r.leadId}|${gid}`)) newSemiJunctions++;
    }
  }

  console.log(`\n═══ Plan ═══`);
  console.log(`  A. Lead.Group__c patches:                ${newSemiPatches}`);
  console.log(`  A. New Lead_List_Assignment (semi):      ${newSemiJunctions}`);
  console.log(`  B. New Lead_List_Assignment (BVM):       ${newBvmJunctions.length}`);
  console.log(`  TOTAL new junction rows:                 ${newSemiJunctions + newBvmJunctions.length}`);

  if (!COMMIT) {
    console.log(`\n🧪 Dry-run only. Re-run with --commit to actually write.`);
    return;
  }

  // ──────────────────────────────────────────────────────────────────────
  // COMMIT — A. patch Lead.Group__c
  // ──────────────────────────────────────────────────────────────────────
  console.log(`\nPhase A1: PATCH Lead.Group__c → first component (${semiRows.length} leads)`);
  for (const r of semiRows) {
    const url = `${sf.instanceUrl}/services/data/v${API}/sobjects/Lead/${r.leadId}`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ Group__c: r.firstId }),
    });
    if (!res.ok) console.error(`  ✗ ${r.leadId}: ${res.status} ${await res.text()}`);
  }
  console.log(`  done.`);

  // ──────────────────────────────────────────────────────────────────────
  // COMMIT — A + B. Create junctions in batches of 200
  // ──────────────────────────────────────────────────────────────────────
  const toCreate: any[] = [];
  for (const r of semiRows) {
    for (let i = 0; i < r.allIds.length; i++) {
      const key = `${r.leadId}|${r.allIds[i]}`;
      if (existingSemiJunctions.has(key)) continue;
      toCreate.push({
        attributes: { type: 'Lead_List_Assignment__c' },
        Lead__c: r.leadId, Group__c: r.allIds[i], Status__c: 'Approved',
      });
    }
  }
  for (const l of newBvmJunctions) {
    toCreate.push({
      attributes: { type: 'Lead_List_Assignment__c' },
      Lead__c: l.Id, Group__c: bvmId, Status__c: 'Approved',
    });
  }
  console.log(`\nPhase 2: create ${toCreate.length} Lead_List_Assignment__c rows in batches of ${BATCH}`);
  let created = 0, failed = 0;
  for (let off = 0; off < toCreate.length; off += BATCH) {
    const chunk = toCreate.slice(off, off + BATCH);
    const url = `${sf.instanceUrl}/services/data/v${API}/composite/sobjects`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ allOrNone: false, records: chunk }),
    });
    if (!res.ok) {
      console.error(`  batch ${off}: ${res.status} ${await res.text()}`);
      failed += chunk.length;
      continue;
    }
    const results: any[] = await res.json();
    for (const r of results) {
      if (r.success) created++;
      else failed++;
    }
    console.log(`  [${Math.min(off + BATCH, toCreate.length)}/${toCreate.length}] created=${created} failed=${failed}`);
  }

  console.log(`\n✅ Done. Created ${created} junctions, ${failed} failed.`);
}

main().catch((e) => { console.error('💀 Crashed:', e); process.exit(1); });
