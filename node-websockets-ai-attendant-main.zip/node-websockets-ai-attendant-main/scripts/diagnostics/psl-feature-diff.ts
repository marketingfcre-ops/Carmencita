import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // PermissionSetLicenseAssign for the 6 users
  const names = ['Martina Smoláková','Ernesto Diaz','Mauricio Villasuso','Markos Bertolotti','Classic Test Agent','Carlos Fausto Miranda'];
  const users: any[] = await sf.soql(
    `SELECT Id, Name FROM User WHERE Name IN (${names.map(n=>`'${n}'`).join(',')})`
  );
  const byName = new Map(users.map((u:any) => [u.Name, u.Id]));
  const ids = users.map((u:any) => u.Id);

  console.log('=== PermissionSetLicenseAssignment ===');
  try {
    const psl: any[] = await sf.soql(
      `SELECT AssigneeId, PermissionSetLicense.MasterLabel, PermissionSetLicense.DeveloperName
       FROM PermissionSetLicenseAssign WHERE AssigneeId IN (${ids.map(i=>`'${i}'`).join(',')})
       ORDER BY AssigneeId`
    );
    console.log(`  ${psl.length} assignments`);
    const byUser = new Map<string, string[]>();
    for (const r of psl) {
      const u = users.find((x:any) => x.Id === r.AssigneeId)?.Name || '?';
      if (!byUser.has(u)) byUser.set(u, []);
      byUser.get(u)!.push(r.PermissionSetLicense?.MasterLabel || r.PermissionSetLicense?.DeveloperName || '?');
    }
    for (const n of names) {
      const list = byUser.get(n) || [];
      console.log(`\n${n}: ${list.length} PSL(s)`);
      for (const x of list) console.log(`  ${x}`);
    }
  } catch (e:any) { console.log(`err: ${e.message?.slice(0,200)}`); }

  // UserFeature / UserPackageLicense
  console.log('\n=== UserPackageLicense ===');
  try {
    const upl: any[] = await sf.soql(
      `SELECT UserId, PackageLicense.NamespacePrefix, PackageLicense.AllowedLicenses, PackageLicense.UsedLicenses
       FROM UserPackageLicense WHERE UserId IN (${ids.map(i=>`'${i}'`).join(',')})`
    );
    const byUser = new Map<string, string[]>();
    for (const r of upl) {
      const u = users.find((x:any) => x.Id === r.UserId)?.Name || '?';
      if (!byUser.has(u)) byUser.set(u, []);
      byUser.get(u)!.push(r.PackageLicense?.NamespacePrefix || '?');
    }
    for (const [u, list] of byUser.entries()) console.log(`  ${u}: ${list.join(', ')}`);
  } catch (e:any) { console.log(`err: ${e.message?.slice(0,200)}`); }
}
main().catch(e=>{console.error(e);process.exit(1);});
