/**
 * LeadGroupAccessRestriction — v2 of the group-based edit restriction.
 *
 * Blocks a non-admin user from editing a Lead unless the user has at least
 * one APPROVED User_Group_Access__c record whose Group__c matches the Lead's
 * Group__c (the lead's "primary" list) OR matches any APPROVED
 * Lead_List_Assignment__c on the same lead (the lead's "additional" lists).
 *
 * Admins bypass entirely (profile == System Administrator).
 *
 * Edge cases:
 *  - Lead with no Group__c and no assignments → allow (unscoped lead)
 *  - User with no User_Group_Access__c records → block any non-admin edit
 *    on a scoped lead
 *
 * The companion test class LeadGroupAccessRestrictionTest enforces 75%+
 * coverage. See it for the full behavior matrix.
 */
trigger LeadGroupAccessRestriction on Lead (before update) {
    // ----- 1. Skip entirely for System Administrators ----------------------
    // Profile lookup is cached per transaction by the platform.
    Id myProfileId = UserInfo.getProfileId();
    Profile myProfile = [SELECT Name FROM Profile WHERE Id = :myProfileId LIMIT 1];
    if (myProfile.Name == 'System Administrator') {
        return;
    }

    // ----- 2. Build the set of groups the current user has access to ------
    Set<Id> userApprovedGroupIds = new Set<Id>();
    for (User_Group_Access__c uga : [
        SELECT Group__c
        FROM User_Group_Access__c
        WHERE User__c = :UserInfo.getUserId()
          AND Status__c = 'Approved'
    ]) {
        if (uga.Group__c != null) userApprovedGroupIds.add(uga.Group__c);
    }

    // ----- 3. Collect lead Ids being updated -----------------------------
    Set<Id> leadIds = Trigger.newMap.keySet();

    // ----- 4. Pre-fetch the approved Lead_List_Assignment__c rows once  ---
    // for all leads in this trigger context (bulk-safe).
    Map<Id, Set<Id>> leadToApprovedGroups = new Map<Id, Set<Id>>();
    for (Lead_List_Assignment__c lla : [
        SELECT Lead__c, Group__c
        FROM Lead_List_Assignment__c
        WHERE Lead__c IN :leadIds
          AND Status__c = 'Approved'
    ]) {
        if (lla.Lead__c == null || lla.Group__c == null) continue;
        Set<Id> set_ = leadToApprovedGroups.get(lla.Lead__c);
        if (set_ == null) {
            set_ = new Set<Id>();
            leadToApprovedGroups.put(lla.Lead__c, set_);
        }
        set_.add(lla.Group__c);
    }

    // ----- 5. For each updated lead, check intersection -------------------
    for (Lead lead : Trigger.new) {
        // Collect every group this lead is on:
        //   (a) the legacy Lead.Group__c lookup ("primary" group)
        //   (b) every approved Lead_List_Assignment__c ("additional" lists)
        Set<Id> leadGroups = new Set<Id>();
        if (lead.Group__c != null) leadGroups.add(lead.Group__c);
        Set<Id> additional = leadToApprovedGroups.get(lead.Id);
        if (additional != null) leadGroups.addAll(additional);

        // Unscoped lead → no restriction
        if (leadGroups.isEmpty()) continue;

        // Compute intersection with the user's approved groups
        Boolean allowed = false;
        for (Id gid : leadGroups) {
            if (userApprovedGroupIds.contains(gid)) {
                allowed = true;
                break;
            }
        }

        if (!allowed) {
            lead.addError(
                'You can only edit leads assigned to a group you have approved access to. ' +
                'Ask an admin to approve a User Group Access record for you, ' +
                'or request that this lead be added to one of your groups.'
            );
        }
    }
}
