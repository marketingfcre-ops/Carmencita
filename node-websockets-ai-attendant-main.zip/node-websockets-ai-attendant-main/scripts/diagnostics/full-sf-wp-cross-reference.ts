/**
 * THE ULTIMATE READ-ONLY DATA INTEGRITY AUDIT.
 *
 * Cross-references every Salesforce Property__c record against its WP post:
 *   - Does WP post exist?
 *   - Does the WP address match SF.Address__c?
 *   - Does Public_URL__c match the actual WP permalink?
 *   - Status alignment (SF Status__c vs WP post status + featured image)
 *
 * Categorizes every SF record and surfaces anything that needs attention.
 * Also lists WP posts with no SF backing.
 *
 * Read-only. No fetches besides standard WP/SF read APIs. No writes.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/full-sf-wp-cross-reference.ts
 *
 * Optional flags:
 *   --details        — print full per-record detail for every category
 *   --status=Active  — filter to just one SF Status__c
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const SHOW_DETAILS = process.argv.includes('--details');
const STATUS_FILTER = process.argv.find((a) => a.startsWith('--status='))?.split('=')[1];

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  City__c: string | null;
  Status__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  Listing_Type__c: string | null;
  Property_Type__c: string | null;
  WP_Post_ID__c: number | null;
  Public_URL__c: string | null;
  Price__c: number | null;
}

interface WpPost {
  id: number;
  date: string;
  modified: string;
  status: string;
  link: string;
  title: string;
  slug: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,modified,status,link,title,slug,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          modified: p.modified || '',
          status: p.status || '',
          link: p.link || '',
          title: (p.title?.rendered || '').toString(),
          slug: p.slug || '',
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/** Strong address normalize — handles both SF-typed and Houzez-geocoded formats. */
function normAddr(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().trim();
  const firstDigit = a.search(/\d/);
  if (firstDigit > 0) a = a.substring(firstDigit);
  const parts = a.split(',').map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) return '';
  let s = parts[0];
  let i = 1;
  while (i < parts.length && /^[\d\s\-#/]+$/.test(s)) {
    s = s + ' ' + parts[i];
    i++;
  }
  s = s.replace(/[#.,/]/g, ' ');
  s = s.replace(/(\d+)[\s\-]+\d+([\s\-]+\d+)*/g, '$1');
  s = s.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  s = s.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  s = s.replace(/\bnorthwesr\b/g, 'nw');
  s = s.replace(/\bnorth\b/g, 'n').replace(/\bsouth\b/g, 's');
  s = s.replace(/\beast\b/g, 'e').replace(/\bwest\b/g, 'w');
  s = s.replace(/\b(street|str)\b/g, 'st');
  s = s.replace(/\b(avenue|av)\b/g, 'ave');
  s = s.replace(/\b(boulevard|boul)\b/g, 'blvd');
  s = s.replace(/\broad\b/g, 'rd');
  s = s.replace(/\bdrive\b/g, 'dr');
  s = s.replace(/\bterrace\b/g, 'ter');
  s = s.replace(/\bcourt\b/g, 'ct');
  s = s.replace(/\bplace\b/g, 'pl');
  s = s.replace(/\bhighway\b/g, 'hwy');
  s = s.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  s = s.replace(
    /\b(miami|miami-dade county|miami dade county|miami-dade|broward county|duval county|florida|fl|united states|hialeah|opa-locka|opalocka|jacksonville|dania beach|hollywood|north miami beach|miami beach|coral gables|miramar|fort lauderdale|lauderdale lakes|pompano beach|pompano|davie|deerfield beach|lake worth beach|west park|pembroke park|pembroke pines|hallandale beach|hallandale|medley|homestead|allapattah|wynwood|little havana|silver court trailer park|strawberry village trailer park|bay heights|san souci estates|north miami)\b/g,
    ''
  );
  s = s.replace(/\b\d{5}(-\d{4})?\b/g, '');
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔬 FULL SF ↔ WP cross-reference audit (read-only)\n');
  console.log('Fetching data from both sides...');

  const { token, instance } = await sfAuth();
  const [sfAll, wpAll] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Name, Address__c, City__c, Status__c,
              Listing_Agent__r.Name, Listing_Type__c, Property_Type__c,
              WP_Post_ID__c, Public_URL__c, Price__c
         FROM Property__c`
    ),
    fetchAllWpPosts(),
  ]);

  const sfRecords = STATUS_FILTER
    ? sfAll.filter((r) => (r.Status__c || '').toLowerCase() === STATUS_FILTER.toLowerCase())
    : sfAll;

  const wpById = new Map<number, WpPost>();
  for (const p of wpAll) wpById.set(p.id, p);

  console.log(`Total SF records:         ${sfAll.length}${STATUS_FILTER ? ` (filtered to "${STATUS_FILTER}": ${sfRecords.length})` : ''}`);
  console.log(`Total WP property posts:  ${wpAll.length}`);
  console.log('');

  // ─────────────────────────────────────────────────────────────────
  // Categorize each SF record
  // ─────────────────────────────────────────────────────────────────
  type Category =
    | 'HEALTHY'
    | 'UNLINKED'
    | 'BROKEN_LINK'
    | 'MISLINKED'
    | 'ADDRESS_MISMATCH_FORMAT'
    | 'URL_STALE'
    | 'NO_ADDRESS_TO_VERIFY';

  interface Diagnosis {
    sf: SfProperty;
    wp: WpPost | null;
    category: Category;
    note: string;
  }

  const diagnoses: Diagnosis[] = [];

  for (const sf of sfRecords) {
    if (sf.WP_Post_ID__c === null) {
      diagnoses.push({ sf, wp: null, category: 'UNLINKED', note: 'No WP_Post_ID__c set' });
      continue;
    }
    const wp = wpById.get(sf.WP_Post_ID__c);
    if (!wp) {
      diagnoses.push({
        sf,
        wp: null,
        category: 'BROKEN_LINK',
        note: `WP_Post_ID__c=${sf.WP_Post_ID__c} does not exist`,
      });
      continue;
    }

    const sfNorm = normAddr(sf.Address__c);
    const wpNorm = normAddr(wp.fave_property_address);

    if (!sfNorm && !wpNorm) {
      diagnoses.push({ sf, wp, category: 'NO_ADDRESS_TO_VERIFY', note: 'Both SF and WP addresses empty' });
      continue;
    }
    if (!sfNorm || !wpNorm) {
      diagnoses.push({
        sf,
        wp,
        category: 'NO_ADDRESS_TO_VERIFY',
        note: !sfNorm ? 'SF.Address__c empty' : 'WP fave_property_address empty',
      });
      continue;
    }

    if (sfNorm === wpNorm) {
      // Address matches. Check URL is current too.
      const expectedUrl = wp.link;
      const sfUrl = (sf.Public_URL__c || '').trim();
      if (sfUrl && expectedUrl && sfUrl !== expectedUrl) {
        diagnoses.push({
          sf,
          wp,
          category: 'URL_STALE',
          note: `Public_URL__c="${sfUrl}" but WP permalink="${expectedUrl}"`,
        });
      } else {
        diagnoses.push({ sf, wp, category: 'HEALTHY', note: '' });
      }
      continue;
    }

    // Addresses don't match — could be MISLINKED (different building) or
    // ADDRESS_MISMATCH_FORMAT (same building, normalize incomplete). Check
    // shared significant tokens (housenum + at least one other word).
    const sfTokens = new Set(sfNorm.split(' ').filter((t) => t.length > 1));
    const wpTokens = new Set(wpNorm.split(' ').filter((t) => t.length > 1));
    const shared = [...sfTokens].filter((t) => wpTokens.has(t));
    const housePresent = [...sfTokens].some((t) => /^\d+$/.test(t) && wpTokens.has(t));

    if (housePresent && shared.length >= 2) {
      diagnoses.push({
        sf,
        wp,
        category: 'ADDRESS_MISMATCH_FORMAT',
        note: `SF:"${sfNorm}" vs WP:"${wpNorm}" (share house+tokens, likely format diff)`,
      });
    } else {
      diagnoses.push({
        sf,
        wp,
        category: 'MISLINKED',
        note: `SF:"${sfNorm}" vs WP:"${wpNorm}" (different buildings)`,
      });
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // Summary
  // ─────────────────────────────────────────────────────────────────
  const byCat = new Map<Category, Diagnosis[]>();
  for (const d of diagnoses) {
    const arr = byCat.get(d.category) || [];
    arr.push(d);
    byCat.set(d.category, arr);
  }

  console.log('═'.repeat(72));
  console.log('SUMMARY — SF records (cross-referenced)');
  console.log('═'.repeat(72));
  const order: { cat: Category; label: string; icon: string }[] = [
    { cat: 'HEALTHY', icon: '✅', label: 'Healthy (link valid, address matches, URL current)' },
    { cat: 'ADDRESS_MISMATCH_FORMAT', icon: '🟨', label: 'Address mismatch — likely format-only (review)' },
    { cat: 'URL_STALE', icon: '🟨', label: 'Public_URL__c stale (URL only, link itself is correct)' },
    { cat: 'NO_ADDRESS_TO_VERIFY', icon: '⚪', label: 'No address to verify (data quality issue)' },
    { cat: 'UNLINKED', icon: '📋', label: 'No WP link (needs WP draft)' },
    { cat: 'BROKEN_LINK', icon: '❌', label: 'BROKEN — WP post does not exist' },
    { cat: 'MISLINKED', icon: '❌', label: 'MISLINKED — points at different building' },
  ];
  for (const o of order) {
    const list = byCat.get(o.cat) || [];
    console.log(`   ${o.icon} ${list.length.toString().padStart(4)}  ${o.label}`);
  }
  console.log(`   ──────`);
  console.log(`        ${diagnoses.length.toString().padStart(4)}  total\n`);

  // ─────────────────────────────────────────────────────────────────
  // Per-status breakdown of SF records
  // ─────────────────────────────────────────────────────────────────
  console.log('── SF Status__c distribution ──');
  const statusCounts = new Map<string, number>();
  for (const r of sfRecords) statusCounts.set(r.Status__c || '(none)', (statusCounts.get(r.Status__c || '(none)') || 0) + 1);
  for (const [s, n] of [...statusCounts.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`   ${s.padEnd(30)} ${n}`);
  }
  console.log('');

  // ─────────────────────────────────────────────────────────────────
  // For each "needs attention" category, dump details
  // ─────────────────────────────────────────────────────────────────
  const detailCats: Category[] = ['BROKEN_LINK', 'MISLINKED', 'ADDRESS_MISMATCH_FORMAT', 'URL_STALE', 'UNLINKED', 'NO_ADDRESS_TO_VERIFY'];
  for (const c of detailCats) {
    const list = byCat.get(c) || [];
    if (list.length === 0) continue;
    const order = detailCats.find((dc) => dc === c);
    if (!order) continue;
    console.log('═'.repeat(72));
    console.log(`${c} — ${list.length} record${list.length === 1 ? '' : 's'}`);
    console.log('═'.repeat(72));

    // Sort by SF status, then address
    list.sort((a, b) =>
      (a.sf.Status__c || '').localeCompare(b.sf.Status__c || '') ||
      (a.sf.Address__c || '').localeCompare(b.sf.Address__c || '')
    );

    for (const d of list) {
      console.log(`SF ${d.sf.Id}   ${d.sf.Status__c || '(no status)'}   ${d.sf.Listing_Agent__r?.Name || '(no agent)'}`);
      console.log(`   ${d.sf.Address__c || '(no SF address)'}   |   ${d.sf.City__c || ''}   |   ${d.sf.Property_Type__c || ''} / ${d.sf.Listing_Type__c || ''}`);
      if (d.wp) {
        const photo = d.wp.featured_media > 0 ? '📷' : '🚫';
        console.log(`   → wp:${d.wp.id}  ${d.wp.status.padEnd(8)} ${photo}   ${d.wp.link}`);
        console.log(`     "${trunc(d.wp.title.replace(/&#8211;/g, '–'), 65)}"`);
        if (d.wp.fave_property_address) console.log(`     wp_addr: "${trunc(d.wp.fave_property_address, 70)}"`);
      } else {
        console.log(`   → ${d.note}`);
      }
      console.log(`   note: ${d.note}`);
      console.log('');
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // HEALTHY records — show counts by status (no details unless --details)
  // ─────────────────────────────────────────────────────────────────
  const healthy = byCat.get('HEALTHY') || [];
  if (healthy.length > 0) {
    console.log('═'.repeat(72));
    console.log(`HEALTHY — ${healthy.length} records (link valid, address matches)`);
    console.log('═'.repeat(72));

    // Break out by SF Status × WP status
    const matrix = new Map<string, number>();
    for (const d of healthy) {
      const key = `${d.sf.Status__c || '(none)'} → ${d.wp?.status || '?'}`;
      matrix.set(key, (matrix.get(key) || 0) + 1);
    }
    console.log('\nBreakdown by SF Status → WP status:');
    for (const [k, v] of [...matrix.entries()].sort((a, b) => b[1] - a[1])) {
      console.log(`   ${k.padEnd(40)} ${v}`);
    }

    // Photo coverage on healthy records
    const withPhoto = healthy.filter((d) => d.wp && d.wp.featured_media > 0).length;
    const noPhoto = healthy.length - withPhoto;
    console.log(`\nFeatured image coverage:`);
    console.log(`   📷 with photo:    ${withPhoto}`);
    console.log(`   🚫 no photo:      ${noPhoto}`);

    if (SHOW_DETAILS) {
      console.log('\nFull list (run without --details to suppress):');
      for (const d of healthy) {
        const photo = d.wp && d.wp.featured_media > 0 ? '📷' : '🚫';
        console.log(
          `   ${d.sf.Id}  ${d.sf.Status__c?.padEnd(10) || ''} ${photo}  ${d.sf.Address__c} → wp:${d.wp?.id} (${d.wp?.status})`
        );
      }
    }
    console.log('');
  }

  // ─────────────────────────────────────────────────────────────────
  // WP posts with no SF backing
  // ─────────────────────────────────────────────────────────────────
  const linkedWpIds = new Set<number>();
  for (const sf of sfAll) if (sf.WP_Post_ID__c) linkedWpIds.add(sf.WP_Post_ID__c);
  const orphanWp = wpAll.filter((p) => !linkedWpIds.has(p.id));

  console.log('═'.repeat(72));
  console.log(`WP posts NOT backed by any SF record: ${orphanWp.length}`);
  console.log('═'.repeat(72));
  console.log('(Could be pre-SF posts, manually-created posts, or duplicates marked for deletion.)\n');

  const orphanByStatus = new Map<string, number>();
  let orphanDuplicate = 0;
  for (const p of orphanWp) {
    orphanByStatus.set(p.status, (orphanByStatus.get(p.status) || 0) + 1);
    if (/\[DUPLICATE/i.test(p.title)) orphanDuplicate++;
  }
  for (const [s, n] of [...orphanByStatus.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`   ${s.padEnd(10)} ${n}`);
  }
  console.log(`   ── of which [DUPLICATE]-tagged: ${orphanDuplicate}`);
  console.log('');

  if (SHOW_DETAILS) {
    for (const p of orphanWp.sort((a, b) => a.date.localeCompare(b.date))) {
      const photo = p.featured_media > 0 ? '📷' : '🚫';
      console.log(`   wp:${p.id} ${p.status.padEnd(8)} ${p.date.slice(0, 10)} ${photo}  "${trunc(p.title.replace(/&#8211;/g, '–'), 55)}"`);
    }
  } else {
    console.log('(re-run with --details to see all)');
  }
  console.log('');

  console.log('═'.repeat(72));
  console.log('AUDIT COMPLETE');
  console.log('═'.repeat(72));
  console.log(`
  Run with --details to see all healthy records + all WP-only posts.
  Run with --status=Active (or Sold, Lost, etc.) to filter the SF side.
  `);
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
