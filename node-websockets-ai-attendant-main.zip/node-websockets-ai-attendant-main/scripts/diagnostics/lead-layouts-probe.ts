/**
 * Probe Lead page layouts to find Group_old2__c references. Read-only.
 *   - List every Layout on Lead
 *   - For each, dump the layoutSections / layoutItems to show where
 *     Group_old2__c (Label "Group_old") lives
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/lead-layouts-probe.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function toolingGet(sf: any, sobject: string, id: string): Promise<any> {
  const url = `${sf.instanceUrl}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`tooling GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json();
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  const layouts: any[] = await sf.toolingQuery(
    `SELECT Id, Name, EntityDefinition.QualifiedApiName
     FROM Layout WHERE EntityDefinition.QualifiedApiName = 'Lead'`
  );
  console.log(`Lead layouts (${layouts.length}):`);
  for (const l of layouts) console.log(`  ${l.Id}  "${l.Name}"`);

  for (const l of layouts) {
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);
    const full: any = await toolingGet(sf, 'Layout', l.Id);
    const meta = full.Metadata || {};
    const sections = meta.layoutSections || [];
    let hits = 0;
    for (const s of sections) {
      for (const col of s.layoutColumns || []) {
        for (const item of col.layoutItems || []) {
          if (item.field === 'Group_old2__c') {
            console.log(`  Section "${s.label}"  →  field ${item.field}  behavior=${item.behavior}`);
            hits++;
          }
        }
      }
    }
    if (!hits) console.log(`  (no Group_old2__c references found)`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
