/**
 * Agent contact audit — lists active agents with their phone/mobile/email,
 * and flags anyone missing a mobile number.
 *
 * Use this before the agent-call-notification feature ships: SMS alerts need a
 * confirmed MobilePhone on each agent. Run it, export the list, have Nathalie
 * circulate it for agents to confirm/correct their numbers.
 *
 * Read-only. Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-contact-audit.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/agent-contact-audit.ts --csv
 */

import { sfClient } from '../../src/integrations/sf-client';

const AGENT_PROFILES = ['Account for Agents', 'Etico Agents'];

interface AgentRow {
  Name: string;
  Username: string;
  Email: string;
  Phone: string | null;
  MobilePhone: string | null;
  IsActive: boolean;
  Profile: { Name: string };
}

async function main() {
  const csv = process.argv.includes('--csv');
  const sf = (await sfClient('prod')) as any;

  const inList = AGENT_PROFILES.map((p) => `'${p}'`).join(', ');
  const rows: AgentRow[] = await sf.soql(
    `SELECT Name, Username, Email, Phone, MobilePhone, IsActive, Profile.Name
     FROM User
     WHERE IsActive = true AND Profile.Name IN (${inList})
     ORDER BY Profile.Name, Name`
  );

  if (csv) {
    console.log('Name,Profile,Email,Phone,MobilePhone,HasMobile');
    for (const r of rows) {
      console.log(
        [r.Name, r.Profile?.Name, r.Email, r.Phone || '', r.MobilePhone || '', r.MobilePhone ? 'yes' : 'NO']
          .map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`)
          .join(',')
      );
    }
    return;
  }

  const missing = rows.filter((r) => !r.MobilePhone);
  console.log(`\n👥 Active agents: ${rows.length}  (profiles: ${AGENT_PROFILES.join(', ')})`);
  console.log(`📱 Missing a mobile number: ${missing.length}\n`);
  for (const r of rows) {
    const flag = r.MobilePhone ? '  ' : '⚠️';
    console.log(
      `${flag} ${r.Name.padEnd(28)} ${(r.MobilePhone || '— no mobile —').padEnd(18)} ${r.Phone || ''}`
    );
  }
  if (missing.length) {
    console.log(`\n⚠️  ${missing.length} agent(s) have no MobilePhone — they can't receive SMS alerts:`);
    for (const r of missing) console.log(`   - ${r.Name} (${r.Email})`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
