# Morning Runbook — Salesforce Desktop Tasks

Do these at the desktop. ~30 min total. **Nothing here is risky — every step is reversible**, and the rollback is at the bottom. Do them in order; Task 1 is a 2‑minute warmup.

---

## TASK 1 — Property upload fix (2 min)
*Stops agents getting stuck on "Owner LLC" when adding a listing. The field was never required — just confusing.*

1. Gear icon (top right) → **Setup**
2. Quick Find → **Object Manager** → click it → find and click **Property**
3. Left menu → **Page Layouts** → click **Property Layout**
4. In the layout, find the **Owning Entity (LLC Name)** field
5. Hover over it → click the **➖ / wrench** to remove it (or drag it up into the gray field palette)
   - *This only removes it from the screen. It does NOT delete the field or any data.*
6. Click **Save** (top-left of the layout editor)

✅ Done. Agents won't see/hit Owner LLC anymore.

---

## TASK 2 — The Flow fix (the big one, ~25 min)
*Three fixes in one: (a) stop blocking the **2,368 ungrouped leads**, (b) let an agent always edit **their own** leads, (c) give Pedro/Erick/Nathalie **edit‑everything** (without export).*

### Part A — Create the "Edit All Leads" bypass (5 min)

1. Setup → Quick Find → **Custom Permissions** → **New**
   - Label: `Edit All Leads`  → Name auto-fills `Edit_All_Leads` → **Save**
2. Setup → Quick Find → **Permission Sets** → **New**
   - Label: `Edit All Leads`
   - **License: --None--** ← important (so it can go on anyone) → **Save**
3. On that permission set → **Custom Permissions** → **Edit** → move **Edit All Leads** to *Enabled* → **Save**
4. Same permission set → **Manage Assignments** → **Add Assignment** → check **Pedro Galindo** + **Erick Moretti** (and **Nathalie Aguirre** if she should edit everything) → **Assign** → **Done**

### Part B — Edit the access Flow (15 min)

1. Setup → Quick Find → **Flows** → click **Lead Group Access Check**
2. Top right → **Save As** → **A New Version** → **Save**
   *(You're editing a new version. The current one stays untouched as your rollback.)*

**Change 1 — skip ungrouped leads (the 2,368):**
3. Click the **Start** element (very top of the flow)
4. Under **Set Entry Conditions** (Condition Requirements), add one condition:
   - Field: **Group** (`Group__c`)  ·  Operator: **Is Null**  ·  Value: **{!$GlobalConstant.False}**
   - *(Plain English: "only run this check when the lead actually has a group." Ungrouped leads will no longer be blocked.)*
5. Make sure **"When to Run the Flow for Updated Records"** = **Every time a record is updated and meets the condition requirements** (not "only when newly meets"). → **Done**

**Change 2 — owner + bypass can always edit:**
6. Find the **Decision** element that leads to the error (it currently checks for "System Administrator").
7. Open it → open the outcome/rule that **allows admins**.
8. Set **Condition Logic** to **OR** (or custom `1 OR 2 OR 3`) and make the conditions:
   1. Profile Name **Equals** `System Administrator`  *(existing — keep it)*
   2. **{!$Record.OwnerId}** **Equals** **{!$User.Id}**   *(owner can edit their own lead)*
   3. **{!$Permission.Edit_All_Leads}** **Equals** **{!$GlobalConstant.True}**   *(Pedro/Erick/Nathalie bypass)*
9. **Done** → **Save**

   *Net effect: admin OR the lead's owner OR anyone with "Edit All Leads" is allowed; everyone else is still checked against their assigned lists, exactly like today.*

### Part C — Test before activating
10. Top right → **Debug**. Run it twice:
    - **Run as** a normal agent, on an **ungrouped** lead's Id → should finish with **no error** ✅
    - **Run as** that same agent, on a lead in a group they're **not** on → should still **hit the error** ✅
    *(If both behave that way, you're good. If not, don't activate — see rollback.)*

### Part D — Activate
11. Top right → **Activate**. The new version goes live; the old one is kept automatically.

---

## After you activate — text me and I'll verify
I'll run a quick check that:
- ungrouped leads are now editable by agents,
- Pedro & Erick can edit everything,
- normal group restrictions still hold.

---

## If anything looks off (rollback — instant, safe)
- **Setup → Flows → Lead Group Access Check** → click the **previous version** → **Activate** (puts it back exactly as it was), **or**
- click the active version's dropdown → **Deactivate** (turns the whole thing off).

Nothing you did deletes data or is permanent.

---

## Still parked (NOT desktop tasks — they're decisions, waiting on others)
- **Hidden/Elior restricted list** — blocked by your Salesforce edition; needs Fausto's call on upgrading.
- **Duplicate leads (~10k)** — waiting on Fausto's "one shared record vs. private copies" answer.
- **Avigail (Abby)** — done (added to PlantationCom).
- **Gas lists, Ben, Chris, Yuniel, Martina, Kodiak** — all done.
