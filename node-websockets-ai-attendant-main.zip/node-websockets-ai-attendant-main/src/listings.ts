/**
 * Property listings — loaded from static JSON data.
 *
 * When Salesforce is connected, this data gets refreshed via salesforce.ts.
 * When SF is unavailable, it falls back to the bundled properties.json.
 *
 * Instead of dumping all 260 listings into the prompt, Claude gets:
 *   1. A summary (cities, types, price range) — ~150 tokens
 *   2. A search_properties tool to find matches — returns top results
 *
 * This keeps the system prompt small and Claude fast on the phone.
 */

import * as fs from 'fs';
import * as path from 'path';
import { buildSearchIndex, fuzzySearchProperties } from './search';
import { getGeographyContext } from './geography';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface Property {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  neighborhood?: string;
  propertyType: string; // e.g. "Retail", "Industrial", "Multi-Family"
  listingType: string; // "For Sale" or "For Lease"
  price?: number;
  buildingSqft?: number;
  lotSqft?: number;
  lotAcres?: number;
  units?: number;
  yearBuilt?: string;
  zoning?: string;
  description?: string;
  locationNotes?: string;
  listingAgent?: string;
  secondaryAgent?: string;
  tags?: string;
  pricing?: string;
  canText?: boolean;
}

// A listing's WP URL is shareable only when it's a pretty permalink
// (/property/<slug>/). Houzez serves drafts and unpublished posts under
// ?post_type=property&p=<id>; those return non-public pages to recipients.
export function isShareableListingUrl(url: string | null | undefined): boolean {
  if (!url) return false;
  return !/[?&]p=\d+/.test(url);
}

// Property types that are almost always sold, not leased. When the caller asks
// about one of these and doesn't specify intent, default to For Sale and skip
// the buy/lease question.
const SALE_ONLY_TYPE_PATTERNS = [
  /multi[\s-]?family/i,
  /multifamily/i,
  /apartment\s*building/i,
  /\bland\b/i,
  /development\s*site/i,
  /\bhotel\b/i,
  /\bmotel\b/i,
  /assemblage/i,
  /industrial\s*land/i,
];

function isSaleOnlyType(propertyType: string | undefined): boolean {
  if (!propertyType) return false;
  return SALE_ONLY_TYPE_PATTERNS.some((re) => re.test(propertyType));
}

// ---------------------------------------------------------------------------
// Load data
// ---------------------------------------------------------------------------

let properties: Property[] = [];

// Try loading from bundled JSON
try {
  const jsonPath = path.join(__dirname, '../data/properties.json');
  const raw = fs.readFileSync(jsonPath, 'utf-8');
  properties = JSON.parse(raw);
  console.log(`📦 Loaded ${properties.length} properties from properties.json`);
  buildSearchIndex(properties);
} catch {
  console.warn(
    '⚠️ No properties.json found — will use Salesforce data or empty'
  );
}

/**
 * Replace the property list (called by salesforce.ts on refresh).
 */
export function setProperties(props: Property[]): void {
  properties = props;
  buildSearchIndex(props);
}

export function getPropertyList(): Property[] {
  return properties;
}

// ---------------------------------------------------------------------------
// Search — used by Claude's search_properties tool
// ---------------------------------------------------------------------------

export interface SearchFilters {
  city?: string;
  propertyType?: string; // Retail, Industrial, Multi-Family, Office, Land, etc.
  listingType?: string; // "For Sale" or "For Lease"
  minPrice?: number;
  maxPrice?: number;
  minSqft?: number;
  maxSqft?: number;
  minLotSqft?: number;
  maxLotSqft?: number;
  keyword?: string; // Free text search across name, address, description, neighborhood
  sortBy?: 'relevance' | 'price_asc' | 'price_desc' | 'price_per_door_asc';
}

export interface SearchResult {
  properties: Property[];
  fallbackReason?: string; // Set when results came from a broadened retry
}

function applyStructuredFilters(
  source: Property[],
  filters: SearchFilters
): Property[] {
  let results = [...source];

  if (filters.city) {
    const city = filters.city.toLowerCase();
    results = results.filter(
      (p) =>
        p.city.toLowerCase().includes(city) ||
        (p.neighborhood && p.neighborhood.toLowerCase().includes(city))
    );
  }
  if (filters.propertyType) {
    const ptype = filters.propertyType.toLowerCase();
    results = results.filter((p) => p.propertyType.toLowerCase().includes(ptype));
  }
  if (filters.listingType) {
    const lt = filters.listingType.toLowerCase();
    results = results.filter((p) => p.listingType.toLowerCase().includes(lt));
  }
  if (filters.minPrice != null) {
    results = results.filter((p) => p.price && p.price >= filters.minPrice!);
  }
  if (filters.maxPrice != null) {
    results = results.filter((p) => p.price && p.price <= filters.maxPrice!);
  }
  if (filters.minSqft != null) {
    results = results.filter((p) => p.buildingSqft && p.buildingSqft >= filters.minSqft!);
  }
  if (filters.maxSqft != null) {
    results = results.filter((p) => p.buildingSqft && p.buildingSqft <= filters.maxSqft!);
  }
  if (filters.minLotSqft != null) {
    results = results.filter((p) => p.lotSqft && p.lotSqft >= filters.minLotSqft!);
  }
  if (filters.maxLotSqft != null) {
    results = results.filter((p) => p.lotSqft && p.lotSqft <= filters.maxLotSqft!);
  }
  return results;
}

function applySort(results: Property[], sortBy: SearchFilters['sortBy']): Property[] {
  if (!sortBy || sortBy === 'relevance') return results;
  const sorted = [...results];
  if (sortBy === 'price_asc') {
    return sorted
      .filter((p) => p.price != null && p.price > 0)
      .sort((a, b) => (a.price ?? 0) - (b.price ?? 0));
  }
  if (sortBy === 'price_desc') {
    return sorted
      .filter((p) => p.price != null && p.price > 0)
      .sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
  }
  if (sortBy === 'price_per_door_asc') {
    return sorted
      .filter((p) => p.price != null && p.price > 0 && p.units != null && p.units > 0)
      .sort(
        (a, b) =>
          (a.price ?? 0) / (a.units ?? 1) - (b.price ?? 0) / (b.units ?? 1)
      );
  }
  return sorted;
}

function runSearchOnce(
  effective: SearchFilters,
  pool: Property[],
  limit: number
): Property[] {
  let results = applyStructuredFilters(pool, effective);

  if (effective.keyword) {
    const fuzzyResults = fuzzySearchProperties(effective.keyword, limit * 3);
    const hasStructured = !!(
      effective.city ||
      effective.propertyType ||
      effective.listingType ||
      effective.minPrice != null ||
      effective.maxPrice != null ||
      effective.minSqft != null ||
      effective.maxSqft != null ||
      effective.minLotSqft != null ||
      effective.maxLotSqft != null
    );
    if (hasStructured) {
      const ids = new Set(results.map((p) => p.id));
      results = fuzzyResults.filter((r) => ids.has(r.property.id)).map((r) => r.property);
    } else {
      results = fuzzyResults.map((r) => r.property);
    }
  }

  results = applySort(results, effective.sortBy);
  return results.slice(0, limit);
}

export function searchPropertiesWithMeta(
  filters: SearchFilters,
  limit = 15
): SearchResult {
  // Default listingType: For Sale for property types that are almost never leased.
  const effective: SearchFilters = { ...filters };
  if (!effective.listingType && isSaleOnlyType(effective.propertyType)) {
    effective.listingType = 'For Sale';
  }

  const primary = runSearchOnce(effective, properties, limit);
  if (primary.length > 0) {
    return { properties: primary };
  }

  // Broaden in order of restrictiveness. Each retry drops one filter, the
  // earliest yielding non-empty results wins. Order roughly: tightest → softest.
  const retries: Array<{ name: string; filters: SearchFilters }> = [];

  if (effective.maxPrice != null) {
    retries.push({
      name: `relaxed budget (+25%)`,
      filters: { ...effective, maxPrice: Math.round(effective.maxPrice * 1.25) },
    });
  }
  if (effective.minSqft != null) {
    retries.push({
      name: `relaxed size`,
      filters: { ...effective, minSqft: Math.round(effective.minSqft / 2) },
    });
  }
  if (effective.minLotSqft != null) {
    retries.push({
      name: `relaxed lot size`,
      filters: { ...effective, minLotSqft: Math.round(effective.minLotSqft / 2) },
    });
  }
  if (effective.city) {
    retries.push({ name: `any city`, filters: { ...effective, city: undefined } });
  }
  if (effective.propertyType) {
    retries.push({
      name: `any property type`,
      filters: { ...effective, propertyType: undefined },
    });
  }

  for (const retry of retries) {
    const broadened = runSearchOnce(retry.filters, properties, limit);
    if (broadened.length > 0) {
      console.log(`🔄 Search broadened (${retry.name}) → ${broadened.length} results`);
      return { properties: broadened, fallbackReason: retry.name };
    }
  }

  return { properties: [] };
}

export function searchProperties(
  filters: SearchFilters,
  limit = 15
): Property[] {
  return searchPropertiesWithMeta(filters, limit).properties;
}

/**
 * Get geography context for a search query (used by Claude when results are sparse).
 */
export function getSearchGeographyContext(keyword: string): string | null {
  return getGeographyContext(keyword);
}

// ---------------------------------------------------------------------------
// Summary for system prompt — tiny footprint (~150 tokens)
// ---------------------------------------------------------------------------

export function getListingSummary(): string {
  if (properties.length === 0) {
    return '(No properties loaded)';
  }

  // City counts
  const cities: Record<string, number> = {};
  const types: Record<string, number> = {};
  const prices: number[] = [];

  for (const p of properties) {
    cities[p.city] = (cities[p.city] || 0) + 1;
    for (const t of p.propertyType.split(';')) {
      const trimmed = t.trim();
      if (trimmed) types[trimmed] = (types[trimmed] || 0) + 1;
    }
    if (p.price && p.price > 100) prices.push(p.price);
  }

  const topCities = Object.entries(cities)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12)
    .map(([c, n]) => `${c} (${n})`)
    .join(', ');

  const topTypes = Object.entries(types)
    .sort((a, b) => b[1] - a[1])
    .map(([t, n]) => `${t} (${n})`)
    .join(', ');

  const minPrice = prices.length ? Math.min(...prices) : 0;
  const maxPrice = prices.length ? Math.max(...prices) : 0;

  const forSale = properties.filter((p) => p.listingType === 'For Sale').length;
  const forLease = properties.filter(
    (p) => p.listingType === 'For Lease'
  ).length;

  return `We have ${properties.length} active listings (${forSale} for sale, ${forLease} for lease) across South Florida.
Cities: ${topCities}
Types: ${topTypes}
Price range: $${minPrice.toLocaleString()} — $${maxPrice.toLocaleString()}
Use the search_properties tool to find matching listings based on the caller's needs.`;
}

// ---------------------------------------------------------------------------
// Expand address abbreviations for TTS readability
// ---------------------------------------------------------------------------

function expandAddress(addr: string): string {
  if (!addr) return addr;

  // Direction abbreviations (must be word boundaries)
  const directions: Record<string, string> = {
    NW: 'Northwest',
    NE: 'Northeast',
    SW: 'Southwest',
    SE: 'Southeast',
    N: 'North',
    S: 'South',
    E: 'East',
    W: 'West',
  };

  // Street type abbreviations
  const streetTypes: Record<string, string> = {
    St: 'Street',
    Ave: 'Avenue',
    Blvd: 'Boulevard',
    Rd: 'Road',
    Dr: 'Drive',
    Ct: 'Court',
    Ln: 'Lane',
    Ter: 'Terrace',
    Pl: 'Place',
    Pkwy: 'Parkway',
    Hwy: 'Highway',
  };

  // Expand directions first (NW, NE, SW, SE before single letters)
  let result = addr;
  for (const [abbr, full] of Object.entries(directions).sort(
    (a, b) => b[0].length - a[0].length
  )) {
    result = result.replace(new RegExp(`\\b${abbr}\\b`, 'g'), full);
  }

  // Expand street types (case-insensitive but preserve position)
  for (const [abbr, full] of Object.entries(streetTypes)) {
    result = result.replace(new RegExp(`\\b${abbr}\\b`, 'gi'), full);
  }

  // Remove unit/suite hash notation: "# 1-6" → "Units 1-6"
  result = result.replace(/\s*#\s*(\d)/g, ' Unit $1');

  // Remove duplicate city in address (e.g. "640 SW 16th Ave, Fort Lauderdale, FL 33312")
  result = result.replace(/,\s*FL\s+\d{5}/, '');

  return result;
}

// ---------------------------------------------------------------------------
// Format search results for Claude to read aloud
// ---------------------------------------------------------------------------

export interface FormatOptions {
  showPricePerDoor?: boolean;
  showLotSize?: boolean;
}

export function formatResultsForClaude(
  results: Property[],
  opts: FormatOptions = {}
): string {
  if (results.length === 0) {
    return 'No matching properties found.';
  }

  return results
    .map((p, i) => {
      const parts: string[] = [];
      parts.push(`${i + 1}. [id:${p.id}] ${expandAddress(p.name)}`);
      parts.push(`Address: ${expandAddress(p.address)}, ${p.city}`);
      if (p.propertyType)
        parts.push(`Type: ${p.propertyType.replace(/;/g, '/')}`);
      parts.push(`${p.listingType}`);
      if (p.price) {
        const priceStr =
          p.price >= 1_000_000
            ? `$${(p.price / 1_000_000).toFixed(1)}M`
            : `$${p.price.toLocaleString()}`;
        parts.push(`Price: ${priceStr}`);
      }
      if (opts.showPricePerDoor && p.price && p.units) {
        const perDoor = Math.round(p.price / p.units);
        const perDoorStr =
          perDoor >= 1000
            ? `$${Math.round(perDoor / 1000)}k`
            : `$${perDoor.toLocaleString()}`;
        parts.push(`Price/door: ${perDoorStr}`);
      }
      if (p.pricing) parts.push(`Pricing: ${p.pricing}`);
      if (p.buildingSqft) parts.push(`${p.buildingSqft.toLocaleString()} sqft`);
      if (opts.showLotSize && (p.lotAcres || p.lotSqft)) {
        const acresPart = p.lotAcres ? `${p.lotAcres.toFixed(2)} acres` : null;
        const sqftPart = p.lotSqft ? `${p.lotSqft.toLocaleString()} lot sqft` : null;
        parts.push([acresPart, sqftPart].filter(Boolean).join(' / '));
      }
      if (p.units) parts.push(`${p.units} units`);
      if (p.neighborhood) parts.push(`Neighborhood: ${p.neighborhood}`);
      if (p.listingAgent) {
        const agents = p.secondaryAgent
          ? `${p.listingAgent} / ${p.secondaryAgent}`
          : p.listingAgent;
        parts.push(`Agent: ${agents}`);
      }
      if (p.description) parts.push(`Notes: ${p.description}`);
      if (p.canText === false) parts.push('No shareable URL');
      return parts.join(' | ');
    })
    .join('\n');
}
