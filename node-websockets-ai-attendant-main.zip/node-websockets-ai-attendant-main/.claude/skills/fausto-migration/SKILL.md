---
name: fausto-migration
description: Use when running any data-migration script under scripts/migrations/ in the Fausto repo (Salesforce/WP/Campaign Monitor data changes — reconcile, backfill, grandfather, cleanup, relink, etc.). Enforces dry-run-first safety because these scripts touch prod data and have inconsistent dry-run defaults.
---

# Running a Fausto data migration safely

Migration scripts in `scripts/migrations/` mutate **production** data (Salesforce,
WordPress, Campaign Monitor). Treat every run as a prod write. Follow this exactly.

## ⚠️ Dry-run defaults are NOT consistent — check before every run

Two conventions exist in this repo. **Always read the script's flag handling first:**

```bash
grep -nE "DRY_RUN|--commit|--dry-run|--target|--limit" scripts/migrations/<script>.ts
```

- **Safe-by-default:** `DRY_RUN = args['dry-run'] === true || !args.commit`
  → defaults to dry-run; you must pass **`--commit`** to write.
  (e.g. `migrate-agents-to-group-access.ts`)
- **Execute-by-default (DANGER):** `DRY_RUN = process.argv.includes('--dry-run')`
  → if you omit `--dry-run` it **writes immediately**. You MUST pass `--dry-run`
  to preview. (e.g. `sf-fix-3-mislinks.ts`, `sf-wp-cleanup-auto.ts`,
  `sf-null-3-broken-closed.ts`, `sf-relink-after-manual-deletes.ts`)

Never assume. The dry-run preview is always the safe first call.

## Procedure

1. **Read the script header** (usage block) + the grep above to learn its flags
   (`--dry-run` / `--commit`, `--target dev|prod`, `--limit N`).
2. **Dry-run first**, in the script's safe preview mode:
   ```bash
   npx tsx --env-file .env.local scripts/migrations/<script>.ts --dry-run --target dev
   # (or omit --commit for safe-by-default scripts)
   ```
3. **Summarize the preview** to the user: how many records change, which org,
   anomalies. Point to any report written under `data/archive/`.
4. **Get explicit approval.** This is a write gate — do not proceed without it.
   (If running unattended/away, STOP here — never auto-execute a migration.)
5. **Run for real** with the correct flag + target:
   ```bash
   npx tsx --env-file .env.local scripts/migrations/<script>.ts --commit --target prod
   # (or drop --dry-run for execute-by-default scripts)
   ```
   Prefer `--limit` for a small first batch on large migrations.
6. **Verify** with a read-only diagnostic or SOQL SELECT (no confirmation needed —
   use the `fausto-diagnose` skill).
7. If a rollback script exists (e.g. `rollback-grandfather-access.ts`), note it
   before running the forward migration.

## Never
- Never deploy Apex to prod — prod is Professional Edition (Flow only). See
  memory "Prod Salesforce is Professional Edition".
- Read-only (dry-runs, SELECTs, diagnostics) needs no confirmation; only the real
  write in step 5 requires sign-off.
