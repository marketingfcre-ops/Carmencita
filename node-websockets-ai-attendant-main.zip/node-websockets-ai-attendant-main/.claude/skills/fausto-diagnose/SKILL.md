---
name: fausto-diagnose
description: Use to run the read-only diagnostic scripts in scripts/diagnostics/ for the Fausto repo — auditing Salesforce↔WordPress link integrity, duplicate/orphan listings, agent-group reconciliation, security-track membership, WP auth health, etc. All read-only; safe to run without approval.
---

# Running Fausto diagnostics (read-only)

`scripts/diagnostics/` holds read-only investigation tools. They only SELECT /
GET — no writes — so per standing policy they run **without confirmation**.

## How to run
```bash
npx tsx --env-file .env.local scripts/diagnostics/<script>.ts
```
List what's available: `ls scripts/diagnostics/`. Read a script's header comment
for its purpose and any flags before running.

## Common picks by question
- **SF↔WP link integrity / mismatches:** `sf-wp-link-audit.ts`,
  `full-sf-wp-cross-reference.ts`, `closings-vs-sf-wp-audit.ts`
- **Duplicates / orphans:** `wp-duplicate-*-audit.ts`,
  `wp-internal-duplicate-clusters.ts`, `orphan-matcher.ts`, `sf-orphan-search.ts`
- **Agent groups / lead groups:** `agent-group-reconcile.ts`,
  `agent-group-cleanup.ts`, `find-owner-entity.ts`, `security-track-audit.ts`
- **WP publish/draft state:** `wp-state-report.ts`, `wp-publish-cause.ts`,
  `wp-drafts-by-sf-status.ts`, `wp-check-trash.ts`
- **WP auth:** `wp-auth-health-check.ts`, `wp-auth-debug.ts`

## Procedure
1. Pick the script that matches the question (or run a couple and combine).
2. Run it, capture the output, and **summarize the findings** — don't just dump
   raw logs.
3. If a diagnostic reveals data that needs fixing, hand off to the
   `fausto-migration` skill (which gates the write). Diagnostics never fix.

These are pre-approved read-only ops — run freely, announce briefly.
