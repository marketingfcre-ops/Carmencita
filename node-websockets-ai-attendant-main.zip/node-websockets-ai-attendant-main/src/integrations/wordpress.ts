/**
 * WordPress (Houzez) integration.
 *
 * Auth: HTTP Basic with WP_USER + WP_APP_PASSWORD.
 *
 * Endpoints used:
 *   GET  /wp-json/wp/v2/properties           — standard WP REST (Houzez post type)
 *   POST /wp-json/wp/v2/properties           — create draft
 *   PATCH /wp-json/wp/v2/properties/{id}     — update post (title, content, status, taxonomy terms)
 *   POST /wp-json/fausto/v1/property-meta/{id} — write Houzez `fave_*` meta fields (custom endpoint)
 *   GET  /wp-json/fausto/v1/push/{id}        — read property + meta in clean format (custom endpoint)
 *
 * Custom Fausto endpoints exist in WP via Code Snippets — see scripts/README.md.
 */

import {
  resolveCity,
  resolveState,
  resolvePropertyStatusByListingType,
  resolvePropertyStatusByKey,
  resolvePropertyTypes,
} from './wordpress-mappings';

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';

const API_BASE = `${WP_SITE_URL.replace(/\/$/, '')}/wp-json`;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Subset of SF Property__c needed to create or update a WP listing. */
export interface PropertyInput {
  sfId: string;
  name: string;
  marketingName?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  county?: string | null;
  propertyType?: string | null; // semicolon-separated SF picklist
  listingType?: string | null; // "For Sale" | "For Lease"
  price?: number | string | null;
  buildingSqft?: number | string | null;
  lotSqft?: number | string | null;
  units?: string | null;
  yearBuilt?: string | null;
  zoning?: string | null;
  description?: string | null;
  pricing?: string | null;
  /** Status key: "for-sale" | "for-lease" | "sold". Overrides listingType when set. */
  statusKey?: 'for-sale' | 'for-lease' | 'sold' | null;
}

export interface WpProperty {
  id: number;
  title: string;
  status: string; // post status: "publish" | "draft" | "private"
  permalink: string;
  meta: Record<string, string>;
}

export interface WpCreateResult {
  ok: boolean;
  wpId?: number;
  permalink?: string;
  error?: string;
}

// ---------------------------------------------------------------------------
// Auth helper
// ---------------------------------------------------------------------------

function authHeader(): string {
  const token = Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');
  return `Basic ${token}`;
}

function isConfigured(): boolean {
  return Boolean(WP_USER && WP_APP_PASSWORD);
}

// ---------------------------------------------------------------------------
// Field mapping: SF → Houzez post payload
// ---------------------------------------------------------------------------

function cleanPrice(val: number | string | null | undefined): string {
  if (val == null) return '';
  if (typeof val === 'number') return String(Math.trunc(val));
  const s = String(val).replace(/[$,]/g, '').trim();
  const n = Number(s);
  return Number.isFinite(n) ? String(Math.trunc(n)) : s;
}

function cleanSqft(val: number | string | null | undefined): string {
  if (val == null) return '';
  return String(val).replace(/\.0+$/, '').trim();
}

function buildFullAddress(p: PropertyInput): string {
  return [p.address || p.name, p.city, p.state, p.zipCode]
    .filter(Boolean)
    .join(', ');
}

function buildTitle(p: PropertyInput): string {
  const mktg = (p.marketingName || '').trim();
  const name = (p.name || '').trim();
  const addr = (p.address || '').trim();
  if (mktg && mktg !== addr) return mktg;
  if (name && name !== addr) return name;
  // Fallback descriptive title
  const ptype = (p.propertyType || '').split(';')[0].trim();
  const units = cleanSqft(p.units);
  const parts: string[] = [];
  if (units && units !== '0' && units !== '1') parts.push(`${units}-Unit`);
  if (ptype) parts.push(ptype);
  if (p.listingType) parts.push(p.listingType);
  if (addr) parts.push(`at ${addr}`);
  if (p.city) parts.push(`in ${p.city}`);
  return parts.length ? parts.join(' ') : addr || name;
}

/** Build the standard WP post body. Houzez meta is written separately. */
export function buildWpPostBody(p: PropertyInput): Record<string, unknown> {
  // Status taxonomy: explicit statusKey wins; otherwise derive from listingType
  const statusTermIds = p.statusKey
    ? [resolvePropertyStatusByKey(p.statusKey)].filter(Boolean)
    : resolvePropertyStatusByListingType(p.listingType || '');

  const body: Record<string, unknown> = {
    title: buildTitle(p),
    content: p.description || '',
    status: 'draft',
    property_type: resolvePropertyTypes(p.propertyType || ''),
    property_status: statusTermIds,
    property_city: resolveCity(p.city || ''),
    property_state: resolveState(p.county || ''),
  };

  // Strip empties
  for (const k of Object.keys(body)) {
    const v = body[k];
    if (v === '' || v == null || (Array.isArray(v) && v.length === 0)) {
      delete body[k];
    }
  }

  return body;
}

/** Build the Houzez `fave_*` meta payload. */
export function buildHouzezMeta(p: PropertyInput): Record<string, string> {
  const fullAddress = buildFullAddress(p);
  const meta: Record<string, string> = {
    fave_property_address: fullAddress,
    fave_property_map_address: fullAddress,
    fave_property_price: cleanPrice(p.price),
    fave_property_size: cleanSqft(p.buildingSqft),
    fave_property_size_prefix: 'ft²',
    fave_property_land: cleanSqft(p.lotSqft),
    fave_property_land_postfix: 'ft²',
    fave_property_year: cleanSqft(p.yearBuilt),
    fave_property_zip: p.zipCode || '',
    fave_agent_display_option: 'agent_info',
    fave_additional_features_enable: 'enable',
    // Internal — used to find this WP post from a SF ID later
    _sf_property_id: p.sfId,
  };

  // Strip empties
  for (const k of Object.keys(meta)) {
    if (meta[k] === '') delete meta[k];
  }

  return meta;
}

// ---------------------------------------------------------------------------
// API operations
// ---------------------------------------------------------------------------

/** Create a draft Property post in WP, then write Houzez meta. Returns WP post ID + permalink. */
export async function createPropertyDraft(
  p: PropertyInput
): Promise<WpCreateResult> {
  if (!isConfigured()) {
    return { ok: false, error: 'WP credentials not configured' };
  }

  const body = buildWpPostBody(p);
  const res = await fetch(`${API_BASE}/wp/v2/properties`, {
    method: 'POST',
    headers: {
      Authorization: authHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, error: `WP create failed: ${res.status} ${err.slice(0, 300)}` };
  }

  const created = (await res.json()) as { id: number; link: string };

  // Write Houzez meta
  const metaResult = await writeHouzezMeta(created.id, buildHouzezMeta(p));
  if (!metaResult.ok) {
    return {
      ok: false,
      error: `WP draft created (id=${created.id}) but meta write failed: ${metaResult.error}`,
      wpId: created.id,
      permalink: created.link,
    };
  }

  return { ok: true, wpId: created.id, permalink: created.link };
}

/** Patch an existing WP property post (title, content, taxonomy, status). */
export async function updatePropertyPost(
  wpId: number,
  fields: Partial<{
    title: string;
    content: string;
    status: 'publish' | 'draft' | 'private';
    property_status: number[];
    property_type: number[];
  }>
): Promise<{ ok: boolean; error?: string }> {
  if (!isConfigured()) return { ok: false, error: 'WP credentials not configured' };

  const res = await fetch(`${API_BASE}/wp/v2/properties/${wpId}`, {
    method: 'POST', // WP REST uses POST for updates with X-HTTP-Method-Override or as PATCH-equivalent
    headers: {
      Authorization: authHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(fields),
  });

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, error: `WP update failed: ${res.status} ${err.slice(0, 300)}` };
  }
  return { ok: true };
}

/** Write Houzez `fave_*` meta via the custom Fausto endpoint. */
export async function writeHouzezMeta(
  wpId: number,
  meta: Record<string, string>
): Promise<{ ok: boolean; error?: string }> {
  if (!isConfigured()) return { ok: false, error: 'WP credentials not configured' };

  const res = await fetch(`${API_BASE}/fausto/v1/property-meta/${wpId}`, {
    method: 'POST',
    headers: {
      Authorization: authHeader(),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(meta),
  });

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, error: `Houzez meta write failed: ${res.status} ${err.slice(0, 300)}` };
  }
  return { ok: true };
}

/**
 * Read a WP property post.
 *
 * IMPORTANT: Originally this hit the custom `/fausto/v1/push/{id}` endpoint,
 * but that endpoint was never registered on the WP side (every call returns
 * 404 → this function returned null) — which silently broke the
 * auto-publish guard in sf-property-changed.ts and caused ~120 drafts to
 * be force-published in May 2026. Now uses the standard WP REST endpoint
 * which we know works.
 *
 * Returns null on auth/network failure. Callers must NOT interpret null as
 * "post is publish" — fail-safe is to skip the operation entirely.
 */
export async function getProperty(wpId: number): Promise<WpProperty | null> {
  if (!isConfigured()) return null;
  const res = await fetch(
    `${API_BASE}/wp/v2/properties/${wpId}?context=edit&_fields=id,title,status,link`,
    {
      headers: { Authorization: authHeader() },
    }
  );
  if (!res.ok) {
    console.warn(`[wordpress.getProperty] ${wpId} failed: ${res.status}`);
    return null;
  }
  const data = (await res.json()) as {
    id: number;
    title?: { rendered?: string; raw?: string };
    status?: string;
    link?: string;
  };
  return {
    id: data.id,
    title: (data.title?.rendered || data.title?.raw || '').toString(),
    status: data.status || '',
    permalink: data.link || '',
    meta: {}, // not needed for current callers; can be expanded later via /fausto/v1/property-meta if needed
  };
}

/**
 * Find a property post ID by searching WP's native ?search= across title,
 * content, and excerpt. Used as a last-resort backfill when slug match AND
 * address-index match both fail.
 *
 * This catches posts where the address is in the TITLE or content but NOT
 * the `fave_property_address` Houzez meta (e.g. marketing-curated titles
 * like "Approved 36-Unit Development Opportunity" at 2306 Van Buren St).
 *
 * Returns the OLDEST matching post (by date) — assumes the original
 * marketing-curated post is the canonical, and any newer ones are likely
 * duplicates we shouldn't link SF to.
 */
export async function findPropertyIdByTitleSearch(
  address: string,
  city: string | null = null
): Promise<number | null> {
  if (!isConfigured() || !address) return null;
  // Use the first comma-segment of the address — most concentrated address text
  const searchTerm = address.split(',')[0].trim();
  if (!searchTerm || searchTerm.length < 3) return null;
  const url = `${API_BASE}/wp/v2/properties?search=${encodeURIComponent(
    searchTerm
  )}&status=publish,draft,private,pending&per_page=20&context=edit&_fields=id,date,title,fave_property_address`;
  const res = await fetch(url, { headers: { Authorization: authHeader() } });
  if (!res.ok) return null;
  type Hit = {
    id: number;
    date: string;
    title?: { rendered?: string };
    fave_property_address?: string;
  };
  const hits = (await res.json()) as Hit[];
  if (!Array.isArray(hits) || hits.length === 0) return null;

  // Require house number presence — WP search is too permissive to trust alone
  const houseMatch = searchTerm.match(/\b(\d{2,6})\b/);
  if (!houseMatch) return null;
  const houseNum = houseMatch[1];

  // Filter to hits where the house number appears at the start of the WP address
  // OR at the start of the title — guards against same-number-different-street.
  const filtered = hits.filter((h) => {
    const wpAddr = (h.fave_property_address || '').toLowerCase();
    const title = (h.title?.rendered || '').toLowerCase();
    const houseAtStart = new RegExp(`(?:^|,\\s+)${houseNum}\\b`, 'i');
    if (houseAtStart.test(wpAddr)) return true;
    // Title pattern like "1234 NW 5th St" or just leading "1234 "
    if (new RegExp(`(?:^|\\s)${houseNum}\\b`, 'i').test(title)) return true;
    return false;
  });
  if (filtered.length === 0) return null;

  // City filter if provided — drop hits whose address clearly mentions a
  // different city
  let candidates = filtered;
  if (city && city.length > 2) {
    const cityLow = city.toLowerCase();
    const withCity = filtered.filter((h) => {
      const wpAddr = (h.fave_property_address || '').toLowerCase();
      return wpAddr.includes(cityLow);
    });
    if (withCity.length > 0) candidates = withCity;
  }

  // Return the oldest match (lowest id ≈ earliest created)
  candidates.sort((a, b) => a.id - b.id);
  return candidates[0].id;
}

/**
 * Find a property post ID by its URL slug. Used to backfill WP_Post_ID__c on
 * SF records that were synced before the field existed.
 *
 * Returns the WP post ID if a single match is found; null otherwise.
 */
export async function findPropertyIdBySlug(
  slug: string
): Promise<number | null> {
  if (!isConfigured() || !slug) return null;
  const url = `${API_BASE}/wp/v2/properties?slug=${encodeURIComponent(slug)}&status=publish,draft,private,pending&per_page=2`;
  const res = await fetch(url, { headers: { Authorization: authHeader() } });
  if (!res.ok) return null;
  const posts = (await res.json()) as Array<{ id: number; slug: string }>;
  if (!Array.isArray(posts) || posts.length === 0) return null;
  if (posts.length > 1) {
    console.warn(
      `[wordpress] findPropertyIdBySlug: multiple posts match slug "${slug}" — using first (id=${posts[0].id})`
    );
  }
  return posts[0].id;
}

/**
 * Extract the WP slug from a Public URL like
 *   https://faustocommercial.com/property/prime-value-add-opportunity/
 * Returns null if the URL doesn't have the expected /property/<slug>/ shape.
 */
export function extractSlugFromPublicUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  // Match either /property/<slug>/ (pretty permalink) or skip query-style URLs
  const match = url.match(/\/property\/([^/?#]+)/);
  return match ? match[1] : null;
}

// ---------------------------------------------------------------------------
// Address-based property lookup (for backfill when slug match fails)
//
// Drafts created via earlier batch scripts have auto-generated slugs that
// don't match SF's Public_URL__c (or SF's URL is empty). To prevent the
// sync from creating a duplicate post, we also try matching by the
// `fave_property_address` Houzez meta.
//
// Stock WP REST can't filter by arbitrary meta, so we maintain an
// in-memory index of {normalized-address: [wp_post_id...]} built from a
// full property fetch on first call, refreshed every 5 minutes.
// ---------------------------------------------------------------------------

interface AddressIndexEntry {
  wpId: number;
  address: string;
  status: string;
  date: string;
}

let addressIndex: Map<string, AddressIndexEntry[]> | null = null;
let addressIndexBuiltAt = 0;
const ADDRESS_INDEX_TTL_MS = 5 * 60 * 1000;

function normalizeAddress(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase();
  // Strip everything after first comma (city/state/zip) so we compare street only.
  // Many WP addresses are "1465 SW 4 ST, Miami, Florida, 33135"; SF often
  // has just the street.
  a = a.split(',')[0];
  a = a.replace(/[#.]/g, ' ');
  // Direction abbrev → short form (consistent on both sides)
  a = a.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  a = a.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  // Street-type abbrev
  a = a.replace(/\b(street|str)\b/g, 'st');
  a = a.replace(/\b(avenue|av)\b/g, 'ave');
  a = a.replace(/\b(boulevard|boul)\b/g, 'blvd');
  a = a.replace(/\b(road)\b/g, 'rd');
  a = a.replace(/\b(drive)\b/g, 'dr');
  a = a.replace(/\b(terrace)\b/g, 'ter');
  a = a.replace(/\b(court)\b/g, 'ct');
  a = a.replace(/\b(place)\b/g, 'pl');
  // Ordinal suffixes: 4th → 4
  a = a.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  a = a.replace(/\s+/g, ' ').trim();
  return a;
}

async function buildAddressIndex(): Promise<void> {
  if (!isConfigured()) {
    addressIndex = new Map();
    addressIndexBuiltAt = Date.now();
    return;
  }
  const idx = new Map<string, AddressIndexEntry[]>();
  // Fetch all properties across all statuses, paginated
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 10; page++) {
      const url = `${API_BASE}/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: authHeader() } });
      if (!res.ok) break;
      const batch = (await res.json()) as Array<{
        id: number;
        date: string;
        status: string;
        fave_property_address?: string;
      }>;
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        const key = normalizeAddress(p.fave_property_address);
        if (!key) continue;
        const entries = idx.get(key) ?? [];
        entries.push({
          wpId: p.id,
          address: p.fave_property_address || '',
          status: p.status,
          date: p.date,
        });
        idx.set(key, entries);
      }
      if (batch.length < 100) break;
    }
  }
  addressIndex = idx;
  addressIndexBuiltAt = Date.now();
}

/**
 * Find an existing WP Property post that matches the given address.
 * Returns the OLDEST matching post ID (the original, in case of duplicates),
 * or null if no match.
 *
 * Used as a backfill fallback when the slug-based match in
 * `findPropertyIdBySlug` doesn't find anything.
 */
export async function findPropertyIdByAddress(
  address: string | null | undefined
): Promise<number | null> {
  const key = normalizeAddress(address);
  if (!key) return null;
  if (!addressIndex || Date.now() - addressIndexBuiltAt > ADDRESS_INDEX_TTL_MS) {
    await buildAddressIndex();
  }
  const entries = addressIndex?.get(key);
  if (!entries || entries.length === 0) return null;
  // Pick the OLDEST one — that's the original; newer matches are likely
  // duplicates from the sync bug we're working around.
  const sorted = [...entries].sort((a, b) => a.date.localeCompare(b.date));
  return sorted[0].wpId;
}

/** Force a rebuild of the address index. Used by migrations. */
export async function rebuildAddressIndex(): Promise<void> {
  addressIndex = null;
  await buildAddressIndex();
}

/** Convenience: change a property's listing status by key ("for-sale"/"for-lease"/"sold"). */
export async function setPropertyListingStatus(
  wpId: number,
  statusKey: 'for-sale' | 'for-lease' | 'sold'
): Promise<{ ok: boolean; error?: string }> {
  const termId = resolvePropertyStatusByKey(statusKey);
  if (!termId) {
    return { ok: false, error: `No WP term ID configured for status "${statusKey}"` };
  }
  return updatePropertyPost(wpId, { property_status: [termId] });
}
