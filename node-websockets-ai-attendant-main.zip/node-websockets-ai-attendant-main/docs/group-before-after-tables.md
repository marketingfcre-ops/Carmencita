# Lead Groups — Current State

_Generated live from Salesforce. Each original spelling is shown under the single group where its leads actually live; stray legacy tags are not counted._

**456 groups total** · 100,273 leads linked · 61 groups cleaned up from spelling variants · 139 kept exactly as-is.


## 1. Cleaned up — spelling variants consolidated into one group

| Original spellings | Now (one group) | Leads |
|---|---|---:|
| VicenteRolodex, VicentePRolodex | **VicenteRolodex** | 4,001 |
| LItHavApt, LItHavApts, LitHavAptHavApt, LitHavApt; BVM | **LittleHavanaApt** | 2,796 |
| PompanoBeach MF, PompanoMultiFam | **PompanoMultiFam** | 2,177 |
| SOUThMiamiAlberto, SOUthMiamiAlbertoU | **SouthMiami** | 1,839 |
| FLAGAMICOM, Flagami Commercial | **Flagami Com** | 1,654 |
| Design North | **DesignDist North** | 1,496 |
| SOUTHRETAIL, SouthMiamiOffices, RETAILSOUTH | **SouthRetail** | 1,347 |
| SOUTHMIAMIIND | **SouthMiaInd** | 1,109 |
| LIBCITYCOM, LibCityCom; BVM | **LibCityCom** | 1,065 |
| NM Retail | **NoMiamiRetail** | 1,045 |
| MIAMI BEACH, Surfside | **Miami Beach** | 1,018 |
| RoadsShehnSilverApts, RoadsShehnSilverApt | **RoadsShehnSilverApts** | 982 |
| OpaLockaInd, OpaLockaInd; BVM | **OpaLockaInd** | 914 |
| HiaApts, HialeahApt | **HialeahApt** | 913 |
| HiaRetail | **HialeahRetail** | 888 |
| JRLitHaitiWyn, JRLitHaitiWyn;WWNAPT, JRLitHaitiWyn(Jorge) | **JRLitHaitiWyn** | 814 |
| HiaGarden, HIAGARDENS | **HiaGardens** | 814 |
| SouthBrowardApts, SouthBrowardApt | **SouthBrowardApt** | 684 |
| CID, CID; BVM | **CID** | 664 |
| FTL Industrial | **FTLInd** | 636 |
| NorthMiaApts, NoMiApts, NoMiaApts | **NorthMiaApts** | 632 |
| LITTLEHAITICORRIDORS, LittleaitiCorridors | **LittleHaitiCorridor** | 632 |
| CORALWAY, Coralwaycom, Coral Way MF | **CoralWay** | 606 |
| Homestead FL, HOMESTEAD | **Homestead** | 573 |
| LITHAVCOM, Little Havana Com, LilHavanacom, LitHavCom; BVM | **LittleHavanaCom** | 530 |
| CivCen, Civic Center | **CivCen** | 525 |
| NorthMultiFamily, NorthMultiFamily;BVM | **NorthMultiFamily** | 428 |
| SW&WC, SWEETINDUSTRIAL | **SW&WC** | 415 |
| WESTchersterCom, WESTCHESTERCOM | **WestchesterCom** | 398 |
| LitHat, LITTLEHAVANA, LittleHav, LitHav, LittHav, Lilhavana | **LittleHavana** | 383 |
| MIAMIBEACHCOMM | **MiamiBeachCom** | 363 |
| LibertyCityApts | **LibCityApt** | 307 |
| SMiaMulti, SOUTH MIAMIMULTIFAMI | **SouthMiamiMF** | 269 |
| NewFlagami, NEW FAGAMI | **NewFlagami** | 263 |
| BIRDROAD COM, Bird RD | **BirdRoadCom** | 210 |
| GAS STATIONS, GAS STATION | **GasStation** | 206 |
| NoMia Land, NM Land | **NorthMiaLand** | 172 |
| Overtown C | **OvertownComm** | 169 |
| HIAGardens Warehouse | **HiaGardensWare** | 160 |
| NoMiWrhse | **NorthMiaWrhse** | 97 |
| VACANT LAND, VACANT LAND; BVM | **Vacant Land** | 95 |
| LIBERTY Multifamily, Liberty Multi | **LibCityMF** | 85 |
| WestchesterRetail, WestchersterRetail | **WestchesterRetail** | 77 |
| Little Haiti, Robin LH | **LittleHaiti** | 65 |
| JJ, joshuas buyer | **Joshua Jimenez** | 53 |
| Pickle/Padel, Pickle Paddle | **Pickle/Padel** | 48 |
| LITTLE RIVER, RIVER | **LittleRiver** | 38 |
| HiaGarden Warehouse | **HiaGardenWare** | 35 |
| exp listing | **Expired** | 24 |
| West Little River, West Little River Pa | **West Little River** | 23 |
| Opa LockaMultifamily | **OpaLockaMF** | 20 |
| preforeclosure, tax delinquent | **Distressed** | 19 |
| INSTITUCIONAL | **Institutional** | 18 |
| Flagami Apt | **FlagamiApts** | 16 |
| West Little Havana | **Little HavanaWest** | 16 |
| Miami Gardens Multif | **Miami Gardens MF** | 15 |
| allapattah multifamy | **AllapattahMF** | 12 |
| lil haiti multifam | **LittleHaitiMF** | 10 |
| Liberty City Comm | **LibertyCityCom** | 7 |
| LitHavLand | **LittleHavanaLand** | 6 |
| TAM AIRPOR WAREHOUSE | **AirportWarehouse** | 6 |

## 2. Kept exactly as-is — agent-specific / preserved groups

| Group | Leads |
|---|---:|
| BrowardMulti | 3,607 |
| Doral Industrial | 3,055 |
| FTL NE Ind | 2,898 |
| BrowardShopping | 2,739 |
| US1-Grovecom | 2,063 |
| SouthBrowardRetail | 1,756 |
| Hollywood33020Resi | 1,543 |
| HialeahCom | 1,510 |
| EastSide | 1,437 |
| CoralGablesCom | 1,408 |
| Allapattah | 1,346 |
| Doral HG&M&MS Retail | 1,335 |
| BobbyRetail | 1,229 |
| FTL MF East | 1,220 |
| JaxDwnTwnRet | 1,218 |
| FTLApts | 1,179 |
| EdgewaterOmniWyn | 1,146 |
| SouthBrowardInd | 1,107 |
| Flagami Apts | 1,099 |
| WestSideJax | 1,090 |
| W Fort Lauderdale MF | 1,049 |
| UniPrkSwtwtrSoDoral | 1,031 |
| DaniaMulti | 1,026 |
| HollywoodRetail | 998 |
| Hallandale MultiFam | 995 |
| NOBE | 988 |
| PlantationCom | 982 |
| DaniaIndustrial | 978 |
| The Roads | 965 |
| HollywoodApt33023_4 | 896 |
| LHT Land Robin | 884 |
| NoEastFlaHotel | 860 |
| LiquorKing | 852 |
| SURDEVRET | 805 |
| AllapattahMF | 804 |
| WestchesterWRetail | 787 |
| MiamiBeachRetail | 772 |
| Medley | 669 |
| JaxDwtwnSpring | 664 |
| CoralSpringsMF | 663 |
| VicenteLitHaiti | 656 |
| OaklandParkInd | 642 |
| HallandaleRetail | 629 |
| AirWest | 626 |
| NEMiamiRetail | 604 |
| SouthBrowardApt33020 | 580 |
| DeerfieldApts | 578 |
| Broward Gas | 533 |
| Broward MF 33021 | 523 |
| MiamiOfficesSouth | 500 |
| CoralTerrace | 500 |
| OrangeGas | 443 |
| GablesMulti | 439 |
| PalmBeachGas | 399 |
| Wynwood Norte | 350 |
| EHia | 343 |
| Name Brand Retailers | 329 |
| GroveRIN | 327 |
| HomesteadMultifamily | 301 |
| HillsboroughGas | 281 |
| NMB Land | 267 |
| LeeGas | 265 |
| WarehousesSouth | 236 |
| OvertownMultifamily | 209 |
| Big Game MF | 169 |
| Hialeah Gardens | 158 |
| ShenandoahApts | 140 |
| CalleOcho | 137 |
| Retail Leasing Leads | 114 |
| Allapattah; BVM | 111 |
| Overtown | 92 |
| Edgewater | 91 |
| MOBILE_HOMES | 82 |
| WWNAPT | 65 |
| MonroeGas | 62 |
| HendryGas | 58 |
| Bigmf | 50 |
| CivApts | 49 |
| Collier Gas | 47 |
| Fausto | 40 |
| Westchester | 39 |
| US1 | 34 |
| SelfStorage | 34 |
| BirdroadRetail | 32 |
| Buyer broker | 31 |
| Big MF list | 30 |
| South Developers | 28 |
| Wynwood | 28 |
| Flagami South | 27 |
| DadeHotelMotel | 26 |
| EHia Industrial | 25 |
| 27 Ave | 23 |
| Upper east side | 20 |
| Miami Gardens Retail | 20 |

_Plus 45 smaller preserved groups (under 20 leads each, 444 leads total)._

