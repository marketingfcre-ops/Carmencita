/**
 * Backfill Public_URL__c for listings that are PUBLISHED in WordPress but still
 * carry a draft/empty/wrong URL in Salesforce (because a manual WP publish never
 * fired the SF sync webhook). Also sets WP_Post_ID__c when it was missing.
 *
 * Only touches records where WP says status=publish AND the WP permalink is a
 * real /property/<slug>/ URL AND the SF value differs. Conservative by design.
 *
 * Dry-run by default. --execute to write. (Migration safety: always dry-run first.)
 *   npx tsx --env-file .env.local scripts/migrations/backfill-published-urls.ts
 *   npx tsx --env-file .env.local scripts/migrations/backfill-published-urls.ts --execute
 */

import { sfClient } from '../../src/integrations/sf-client';

const EXECUTE = process.argv.includes('--execute');
const API_BASE = `${(process.env.WP_SITE_URL || 'https://faustocommercial.com').replace(/\/$/, '')}/wp-json`;
const authHeader = () =>
  `Basic ${Buffer.from(`${process.env.WP_USER || ''}:${process.env.WP_APP_PASSWORD || ''}`).toString('base64')}`;
const isPretty = (u: string | null) => !!u && /\/property\//.test(u) && !/[?&]p=\d+/.test(u);
const postIdFromUrl = (u: string | null) => { const m = u?.match(/[?&]p=(\d+)/); return m ? Number(m[1]) : null; };
const chunk = <T,>(a: T[], n: number) => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };

async function main() {
  const sf = (await sfClient('prod')) as any;
  const props: any[] = await sf.soql(
    `SELECT Id, Name, Public_URL__c, WP_Post_ID__c FROM Property__c`
  );

  const wpIdByProp = new Map<string, number>();
  for (const p of props) {
    const id = p.WP_Post_ID__c ? Number(p.WP_Post_ID__c) : postIdFromUrl(p.Public_URL__c);
    if (id) wpIdByProp.set(p.Id, id);
  }
  const wp = new Map<number, { status: string; link: string }>();
  for (const ids of chunk([...new Set(wpIdByProp.values())], 100)) {
    const url = `${API_BASE}/wp/v2/properties?include=${ids.join(',')}&per_page=100` +
      `&status=publish,draft,private,pending,future&context=edit&_fields=id,status,link`;
    const res = await fetch(url, { headers: { Authorization: authHeader() } });
    if (!res.ok) { console.warn(`WP fetch ${res.status}`); continue; }
    for (const r of (await res.json()) as any[]) wp.set(r.id, { status: r.status, link: r.link });
  }

  const fixes: { id: string; name: string; from: string; to: string; setWpId: number | null }[] = [];
  for (const p of props) {
    const wpId = wpIdByProp.get(p.Id);
    if (!wpId) continue;
    const w = wp.get(wpId);
    if (!w || w.status !== 'publish' || !isPretty(w.link)) continue;
    if (p.Public_URL__c === w.link) continue; // already correct
    fixes.push({
      id: p.Id, name: p.Name, from: p.Public_URL__c || '(empty)', to: w.link,
      setWpId: p.WP_Post_ID__c ? null : wpId,
    });
  }

  console.log(`\n🔧 ${EXECUTE ? 'EXECUTE' : 'DRY-RUN'} — ${fixes.length} published listings with a stale SF URL\n`);
  for (const f of fixes) console.log(`   ${f.name}\n      ${f.from}\n      → ${f.to}${f.setWpId ? `  (+WP_Post_ID__c=${f.setWpId})` : ''}`);

  if (!EXECUTE) { console.log(`\n(dry-run — re-run with --execute to write)\n`); return; }

  let ok = 0, fail = 0;
  for (const f of fixes) {
    const fields: Record<string, unknown> = { Public_URL__c: f.to };
    if (f.setWpId) fields.WP_Post_ID__c = f.setWpId;
    try { await sf.update('Property__c', f.id, fields); ok++; }
    catch (e: any) { fail++; console.warn(`   ✗ ${f.name}: ${e.message?.slice(0, 100)}`); }
  }
  console.log(`\n   ✓ updated ${ok}, failed ${fail}\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
