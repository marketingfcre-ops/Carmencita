/**
 * Rollback the User_Group_Access__c rows created by
 * grandfather-user-group-access.ts. Looks up the audit log by timestamp
 * slug, finds every row created by the integration user since that
 * timestamp, and DELETEs them (soft-delete — goes to Recycle Bin for 15
 * days, fully restorable).
 *
 * Usage:
 *   tsx --env-file .env.local scripts/migrations/rollback-grandfather-access.ts <timestamp-slug>
 *   tsx --env-file .env.local scripts/migrations/rollback-grandfather-access.ts 2026-05-28T23-59-12 --commit
 *
 * The timestamp slug is the same one the grandfather script prints (also
 * embedded in the audit-log filename).
 *
 * Dry-run by default — shows count + audit-log summary. Pass --commit to
 * actually delete. If you panic later, restore from Recycle Bin (Setup →
 * Data → Mass Delete Records → undelete, or click "Undelete" on each row
 * within 15 days).
 */

import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const TARGET: SfTarget = 'prod';
const COMMIT = process.argv.includes('--commit');
const tsSlug = process.argv.find((a) => /^\d{4}-\d{2}-\d{2}T/.test(a));

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const ARCHIVE_DIR = path.join(REPO_ROOT, 'data', 'archive');

async function main() {
  if (!tsSlug) {
    console.error(`Usage: tsx rollback-grandfather-access.ts <timestamp-slug> [--commit]`);
    console.error(`       (timestamp slug looks like 2026-05-28T23-59-12 — printed by the grandfather script)`);
    process.exit(1);
  }

  const logPath = path.join(ARCHIVE_DIR, `grandfather-access-${tsSlug}.json`);
  if (!fs.existsSync(logPath)) {
    console.error(`\n⚠ Audit log not found: ${path.relative(REPO_ROOT, logPath)}`);
    console.error(`  Proceeding by SF timestamp alone — confirm the rollback isotime below is correct.\n`);
  } else {
    const log = JSON.parse(fs.readFileSync(logPath, 'utf8'));
    console.log(`\n📄 Audit log: ${path.relative(REPO_ROOT, logPath)}`);
    console.log(`   Original timestamp: ${log.timestamp}`);
    console.log(`   Mode: ${log.mode}`);
    console.log(`   Rows created at run time: ${log.toCreate}`);
  }

  const isoTime = tsSlug.replace(/-/g, ':').replace(/^(\d{4}):(\d{2}):(\d{2})T/, '$1-$2-$3T') + 'Z';
  console.log(`\n🔍 Looking for User_Group_Access__c rows created on/after ${isoTime}`);

  const sf = (await sfClient(TARGET)) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // Find me (the integration user) so we don't accidentally delete things
  // created by other admins/agents through normal use.
  const meRes: any = await fetch(
    `${sf.instanceUrl}/services/oauth2/userinfo`,
    { headers: { Authorization: `Bearer ${sf.accessToken}` } }
  );
  const me: any = await meRes.json();
  const meId = me.user_id;
  console.log(`Integration user: ${me.name} (${meId})\n`);

  const candidates: any[] = await sf.soql(
    `SELECT Id, User__c, Group__c, CreatedDate, CreatedById FROM User_Group_Access__c
     WHERE CreatedDate >= ${isoTime} AND CreatedById = '${meId}'`
  );
  console.log(`Found ${candidates.length} rows to delete.`);

  if (candidates.length === 0) {
    console.log(`Nothing to roll back.`);
    return;
  }

  if (!COMMIT) {
    console.log(`\n🧪 Dry-run only. Re-run with --commit to actually delete.`);
    console.log(`   Sample (first 5):`);
    for (const c of candidates.slice(0, 5)) {
      console.log(`     ${c.Id}  user=${c.User__c}  group=${c.Group__c}  created ${c.CreatedDate}`);
    }
    return;
  }

  // Batched DELETE via composite/sobjects?ids=...
  console.log(`\nDELETing ${candidates.length} rows in batches of 200...`);
  let deleted = 0, failed = 0;
  const BATCH = 200;
  for (let off = 0; off < candidates.length; off += BATCH) {
    const ids = candidates.slice(off, off + BATCH).map((c) => c.Id).join(',');
    const url = `${sf.instanceUrl}/services/data/v59.0/composite/sobjects?ids=${ids}&allOrNone=false`;
    const res = await fetch(url, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${sf.accessToken}` },
    });
    if (!res.ok) {
      console.error(`  batch ${off}: ${res.status} ${await res.text()}`);
      failed += Math.min(BATCH, candidates.length - off);
      continue;
    }
    const results: any[] = await res.json();
    for (const r of results) {
      if (r.success) deleted++;
      else failed++;
    }
    console.log(`  [${Math.min(off + BATCH, candidates.length)}/${candidates.length}] deleted=${deleted} failed=${failed}`);
  }
  console.log(`\n✅ Done. Deleted ${deleted}, failed ${failed}.`);
  console.log(`   The deleted rows are in the SF Recycle Bin for 15 days if you need to restore.`);
}

main().catch((e) => { console.error('💀 Crashed:', e); process.exit(1); });
