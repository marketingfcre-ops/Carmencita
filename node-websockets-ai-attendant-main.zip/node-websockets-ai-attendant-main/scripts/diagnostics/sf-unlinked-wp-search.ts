/**
 * For each Active SF record with no WP link, exhaustively search WP for any
 * post that could plausibly be the missing match (by address house number,
 * partial title overlap, slug substring).
 *
 * If WP candidates exist → human should review and decide whether to link.
 * If no candidates → safe to create a fresh draft.
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  City__c: string | null;
  Status__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  CreatedDate: string;
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  slug: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function fetchAllWp(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,slug,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || '').toString(),
          slug: p.slug || '',
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function main() {
  return (async () => {
    const { token, instance } = await sfAuth();

    const soql = `SELECT Id, Name, Address__c, City__c, Status__c,
                         Listing_Agent__r.Name, CreatedDate
                    FROM Property__c
                   WHERE WP_Post_ID__c = NULL
                     AND Status__c = 'Active'`;
    const r = await fetch(
      `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const data = (await r.json()) as { records: SfProperty[] };
    const sfRecords = data.records || [];

    console.log(`\n🔎 Searching WP for ${sfRecords.length} unlinked Active SF records\n`);
    const wp = await fetchAllWp();
    console.log(`Loaded ${wp.length} WP posts.\n`);

    let totalWithMatches = 0;
    let totalNoMatches = 0;

    for (const sf of sfRecords) {
      // Extract candidate tokens from the SF address — house numbers (any),
      // and city. SF addresses for these records sometimes contain MULTIPLE
      // street numbers (e.g. "320 mendoza ave, 324 mendoza ave, 1610 salzedo
      // st"). Search by each number to maximize hits.
      const addr = (sf.Address__c || sf.Name || '').toLowerCase();
      const houseNumbers = Array.from(addr.matchAll(/\b\d{2,5}\b/g)).map((m) => m[0]);
      const uniqueHouseNumbers = Array.from(new Set(houseNumbers));
      const cityLower = (sf.City__c || '').toLowerCase();

      // Search WP — match if WP post's address/title/slug contains ANY of
      // the SF house numbers AND has the right city (or no city if SF has none)
      const candidates: { wp: WpPost; matchedNumber: string; cityMatch: boolean }[] = [];
      for (const p of wp) {
        const wpAddr = p.fave_property_address.toLowerCase();
        const title = p.title.toLowerCase();
        const slug = p.slug.toLowerCase();
        for (const n of uniqueHouseNumbers) {
          const re = new RegExp(`\\b${n}\\b`);
          if (re.test(wpAddr) || re.test(title) || slug.includes(n)) {
            const cityMatch = cityLower ? wpAddr.includes(cityLower) || title.includes(cityLower) : true;
            candidates.push({ wp: p, matchedNumber: n, cityMatch });
            break; // only show post once even if multiple numbers match
          }
        }
      }

      // Prioritize: city-match first, then by date desc
      candidates.sort((a, b) => {
        const c = (a.cityMatch ? 0 : 1) - (b.cityMatch ? 0 : 1);
        if (c !== 0) return c;
        return b.wp.date.localeCompare(a.wp.date);
      });

      const hasCityMatch = candidates.some((c) => c.cityMatch);

      console.log('═'.repeat(78));
      console.log(`SF ${sf.Id}   ${sf.Listing_Agent__r?.Name || '(no agent)'}   created ${sf.CreatedDate.slice(0, 10)}`);
      console.log(`   Address:    "${sf.Address__c || sf.Name}"`);
      console.log(`   City:       ${sf.City__c || '—'}`);
      console.log('═'.repeat(78));

      if (candidates.length === 0) {
        console.log('   ✅ No WP candidates — safe to create a fresh draft.\n');
        totalNoMatches++;
        continue;
      }

      const tag = hasCityMatch ? '🟨 candidates with city match — likely missing-link' : '⚪ candidates but no city match — probably new draft';
      console.log(`   ${tag}\n`);
      for (const c of candidates.slice(0, 5)) {
        const cityMatchTag = c.cityMatch ? '✓city' : '  ';
        const photo = c.wp.featured_media > 0 ? '📷' : '🚫';
        console.log(`   wp:${c.wp.id} ${c.wp.status.padEnd(8)} ${c.wp.date.slice(0, 10)} ${cityMatchTag} ${photo}  matched "${c.matchedNumber}"`);
        console.log(`     "${c.wp.title.replace(/&#8211;/g, '–').slice(0, 70)}"`);
        console.log(`     addr: "${c.wp.fave_property_address.slice(0, 70)}"`);
      }
      if (candidates.length > 5) console.log(`     ... and ${candidates.length - 5} more`);
      console.log('');

      if (hasCityMatch) totalWithMatches++;
      else totalNoMatches++;
    }

    console.log('═'.repeat(78));
    console.log('SUMMARY');
    console.log('═'.repeat(78));
    console.log(`   🟨 With city-matching WP candidates (need human review): ${totalWithMatches}`);
    console.log(`   ✅ No matches (safe to create fresh drafts):             ${totalNoMatches}`);
    console.log('');
    process.exit(0);
  })();
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
