/**
 * Check if the 3 SF orphan WP IDs exist in trash (or were permanently deleted).
 * Read-only.
 *
 * For each ID, queries multiple endpoints to determine state:
 *   - GET /wp/v2/properties/{id} — returns 404 if gone OR trashed-and-not-visible
 *   - GET /wp/v2/properties/{id}?status=trash — explicit trash query
 *   - GET /wp/v2/properties?status=any&include={id} — broadest catch-all
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const IDS_TO_CHECK = [23470, 23091, 63126];

async function getJson(path: string): Promise<{ status: number; body: any }> {
  const res = await fetch(`${WP_SITE_URL}${path}`, { headers: { Authorization: WP_AUTH } });
  let body: any = null;
  try { body = await res.json(); } catch { body = null; }
  return { status: res.status, body };
}

async function main() {
  console.log('\n🗑️  Check if WP posts exist in trash\n');

  // First, let's also fetch all trashed posts in one shot to see if any of our IDs are there
  console.log('── Step 1: list ALL trashed property posts ──');
  const trashedList = await getJson('/wp-json/wp/v2/properties?per_page=100&status=trash&context=edit&_fields=id,date,title,slug,fave_property_address');
  if (trashedList.status === 200 && Array.isArray(trashedList.body)) {
    console.log(`Found ${trashedList.body.length} trashed property posts.`);
    if (trashedList.body.length > 0) {
      console.log('\nTrashed posts:');
      for (const p of trashedList.body) {
        const matches = IDS_TO_CHECK.includes(p.id) ? '  ⭐ MATCHES ONE OF OUR ORPHANS' : '';
        console.log(`   wp:${p.id}  ${p.date.slice(0, 10)}  "${(p.title?.rendered || '').slice(0, 60)}"  slug=${p.slug}${matches}`);
        if (p.fave_property_address) console.log(`     addr: "${p.fave_property_address}"`);
      }
    }
  } else {
    console.log(`   ❌ ${trashedList.status}: ${JSON.stringify(trashedList.body).slice(0, 200)}`);
  }
  console.log('');

  // Now check each specific ID
  console.log('── Step 2: probe each orphan ID individually ──\n');
  for (const id of IDS_TO_CHECK) {
    console.log(`wp:${id}`);

    const std = await getJson(`/wp-json/wp/v2/properties/${id}?context=edit`);
    console.log(`   /wp/v2/properties/${id}?context=edit → ${std.status}`);
    if (std.status === 200) {
      console.log(`      status=${std.body.status}, title="${(std.body.title?.rendered || '').slice(0, 60)}"`);
    } else if (std.status === 404) {
      console.log(`      (not found via standard endpoint — could be trashed or permanently deleted)`);
    }

    // Try with explicit status=trash filter on the list endpoint
    const trashCheck = await getJson(`/wp-json/wp/v2/properties?include=${id}&status=trash&context=edit&_fields=id,date,status,title,slug,fave_property_address`);
    if (trashCheck.status === 200 && Array.isArray(trashCheck.body) && trashCheck.body.length > 0) {
      const p = trashCheck.body[0];
      console.log(`   ⭐ FOUND IN TRASH:`);
      console.log(`      title:  "${(p.title?.rendered || '').slice(0, 70)}"`);
      console.log(`      slug:   ${p.slug}`);
      console.log(`      addr:   "${p.fave_property_address || '(none)'}"`);
      console.log(`      date:   ${p.date}`);
    } else {
      // Try broadest filter
      const anyCheck = await getJson(`/wp-json/wp/v2/properties?include=${id}&status=any&context=edit&_fields=id,status,title`);
      if (anyCheck.status === 200 && Array.isArray(anyCheck.body) && anyCheck.body.length > 0) {
        const p = anyCheck.body[0];
        console.log(`   Found via status=any: status=${p.status}, title="${(p.title?.rendered || '').slice(0, 60)}"`);
      } else {
        console.log(`   ❌ Not found in trash either — likely permanently deleted.`);
      }
    }
    console.log('');
  }
  process.exit(0);
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
