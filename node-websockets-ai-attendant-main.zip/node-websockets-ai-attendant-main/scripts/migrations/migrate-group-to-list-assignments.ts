/**
 * Migration: Lead.Group__c → Lead_List_Assignment__c (junction object)
 *
 * Per the security-track design doc:
 * - A Lead can belong to multiple lists (groups)
 * - Each membership is a Lead_List_Assignment__c record with a Status__c
 * - Existing single-group memberships are grandfathered as Status='Approved'
 *
 * This script reads every Lead with Group__c set and creates a corresponding
 * Lead_List_Assignment__c. It is IDEMPOTENT — re-running won't create dupes,
 * because we check for an existing assignment with the same Lead_ID + Group_ID
 * before inserting.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrate-group-to-list-assignments.ts --target dev [--dry-run] [--limit 100]
 *   tsx --env-file .env.local scripts/migrate-group-to-list-assignments.ts --target prod [--dry-run] [--limit 100]
 *
 * Prerequisites (in the target org):
 *   - Lead_List_Assignment__c custom object exists with these fields:
 *       Lead__c          (Master-Detail to Lead, or Lookup)
 *       Group__c         (Lookup to Group__c)
 *       Status__c        (Picklist: 'Pending', 'Approved')
 *       Approved_By__c   (Lookup to User, optional)
 *       Approved_Date__c (DateTime, optional)
 *
 *   If the object doesn't exist yet, the script fails fast with a clear error
 *   so you know to create the schema first (UI or seed-dev-schema script).
 */

import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

interface LeadWithGroup {
  Id: string;
  Name: string;
  Group__c: string;
}

interface ExistingAssignment {
  Lead__c: string;
  Group__c: string;
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'prod' ? 'prod' : 'dev';
const DRY_RUN = args['dry-run'] === true;
const LIMIT = typeof args.limit === 'string' ? Number(args.limit) : 0;
const BATCH_SIZE = 200; // SF Composite Collections max
const API_VERSION = '59.0';

async function main() {
  console.log(
    `\n🔄 Migrating Lead.Group__c → Lead_List_Assignment__c  (target=${TARGET}${DRY_RUN ? ', DRY RUN' : ''}${LIMIT ? `, limit=${LIMIT}` : ''})\n`
  );

  const sf = await sfClient(TARGET);
  console.log(`Connected to ${sf.instance}`);

  // Sanity check: confirm the junction object exists
  try {
    await sf.describe('Lead_List_Assignment__c');
  } catch (err) {
    console.error(
      '\n❌ Lead_List_Assignment__c does not exist in this org. Create the object first (UI or seed-dev-schema script). Aborting.\n'
    );
    process.exit(1);
  }

  // Step 1: snapshot existing assignments so we don't duplicate
  console.log('Loading existing Lead_List_Assignment__c records...');
  // sf.soql() paginates internally — no LIMIT clause needed
  const existing = await sf.soql<ExistingAssignment>(
    `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c`
  );
  const existingKeys = new Set(existing.map((e) => `${e.Lead__c}|${e.Group__c}`));
  console.log(`  ${existing.length} assignments already in place.`);

  // Step 2: load Leads with Group__c set
  console.log('\nLoading Leads with Group__c populated...');
  const leadLimit = LIMIT > 0 ? `LIMIT ${LIMIT}` : '';
  const leads = await sf.soql<LeadWithGroup>(
    `SELECT Id, Name, Group__c FROM Lead WHERE Group__c != null ${leadLimit}`
  );
  console.log(`  ${leads.length} candidate Leads.`);

  // Step 3: collect missing junction records, batch-insert via Composite API
  const toCreate: Array<{ Lead__c: string; Group__c: string }> = [];
  let skipped = 0;
  for (const lead of leads) {
    const key = `${lead.Id}|${lead.Group__c}`;
    if (existingKeys.has(key)) skipped++;
    else toCreate.push({ Lead__c: lead.Id, Group__c: lead.Group__c });
  }
  console.log(`  ${skipped} already exist (skip), ${toCreate.length} to insert\n`);

  let created = 0;
  let failed = 0;
  const failures: Array<{ leadId: string; groupId: string; err: string }> = [];

  if (DRY_RUN) {
    console.log(`[dry-run] would insert ${toCreate.length} records in ${Math.ceil(toCreate.length / BATCH_SIZE)} batches`);
    created = toCreate.length;
  } else {
    // Batch into chunks of 200 and POST via composite/sobjects
    for (let off = 0; off < toCreate.length; off += BATCH_SIZE) {
      const chunk = toCreate.slice(off, off + BATCH_SIZE);
      const records = chunk.map((r) => ({
        attributes: { type: 'Lead_List_Assignment__c' },
        Lead__c: r.Lead__c,
        Group__c: r.Group__c,
        Status__c: 'Approved',
      }));
      const url = `${(sf as any).instanceUrl}/services/data/v${API_VERSION}/composite/sobjects`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${(sf as any).accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ allOrNone: false, records }),
      });
      if (!res.ok) {
        console.error(`Batch ${off}: HTTP ${res.status} ${await res.text()}`);
        failed += chunk.length;
        continue;
      }
      const results: Array<{ success: boolean; id?: string; errors?: any[] }> = await res.json();
      for (let i = 0; i < results.length; i++) {
        if (results[i].success) created++;
        else {
          failed++;
          if (failures.length < 20) {
            failures.push({
              leadId: chunk[i].Lead__c,
              groupId: chunk[i].Group__c,
              err: JSON.stringify(results[i].errors || []).slice(0, 200),
            });
          }
        }
      }
      console.log(
        `[${Math.min(off + BATCH_SIZE, toCreate.length)}/${toCreate.length}] created=${created} failed=${failed}`
      );
    }
  }

  // Step 4: report
  console.log('\n=== Summary ===');
  console.log(`Total Leads scanned:   ${leads.length}`);
  console.log(`✅ ${DRY_RUN ? 'Would create' : 'Created'}:        ${created}`);
  console.log(`⚠️  Skipped (existing): ${skipped}`);
  console.log(`❌ Failed:             ${failed}`);

  if (failures.length > 0) {
    console.log('\n=== Failures (first 10) ===');
    for (const f of failures.slice(0, 10)) {
      console.log(`  Lead ${f.leadId} → Group ${f.groupId}`);
      console.log(`    ${f.err}`);
    }
  }

  console.log('');
  process.exit(failed > 0 ? 1 : 0);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        out[key] = next;
        i++;
      } else {
        out[key] = true;
      }
    }
  }
  return out;
}

main().catch((err) => {
  console.error('💀 Migration crashed:', err);
  process.exit(1);
});
