# Voice Pipeline & Conversation Engine

*Project handover — Fausto Commercial AI Phone Attendant ("Carmencita")*

This document covers the real-time voice call subsystem: how a phone call is
turned into a natural, low-latency conversation with an AI receptionist. It is
written for two readers. **If you run the business**, the "Plain-language
overview" and "The clever bits" sections explain what was built and why it is
hard. **If you inherit the code**, every section after that cites exact files,
functions, and line numbers so you can operate and modify it.

---

## 1. Plain-language overview — what this does

When someone calls Fausto Commercial, they do not reach a menu ("press 1 for
sales"). They reach an AI receptionist that talks. The caller can speak normally,
in English or Spanish, interrupt, change their mind, ask about a specific
warehouse on a specific street — and the AI answers in a natural voice within
about a second, having actually looked up real listings from the live Salesforce
database.

Making that feel natural over a phone line is genuinely hard. Phone audio is
low-quality (8 kHz, compressed), callers are often in cars or noisy offices, and
people talk over each other constantly. The system has to:

- **Hear** the caller accurately despite noise and accents (speech-to-text).
- **Decide when the caller is actually done talking** vs. just pausing — getting
  this wrong either cuts people off or leaves awkward silence.
- **Think** — understand the request, search real inventory, and decide what to say.
- **Speak** the answer in a lifelike voice, fast.
- **Handle interruptions** gracefully — if the caller starts talking while the AI
  is mid-sentence, the AI must stop instantly and listen, and remember what it
  had said vs. what got cut off.

The engineering investment here is overwhelmingly in those "in-between" problems
— turn-taking, interruption, noise rejection, and latency — not just in wiring
up the AI. That is what separates this from a toy chatbot bolted to a phone.

---

## 2. The real-time pipeline, end to end

### The audio path

```
Caller (phone)
   │  μ-law 8kHz audio, 20ms frames over the phone network
   ▼
Twilio  ──<Connect><Stream>──►  WebSocket /stream
   │
   ▼
CallHandler (src/call-handler.ts)  ── the orchestrator for one call
   │
   ├─► Deepgram STT  (src/stt-flux.ts — Flux; or Nova-3)   ── speech → text + turn signals
   │
   ├─► Claude API   (src/claude.ts)  ── text → reasoning, tool calls, reply text (streamed)
   │
   ├─► ElevenLabs TTS (src/tts.ts)   ── reply text → μ-law 8kHz audio (streamed)
   │
   └─► back over the same WebSocket ──► Twilio ──► Caller
```

One `CallHandler` instance is created per call when the WebSocket connects, and
it owns all per-call state (`src/call-handler.ts:88`). Twilio messages
(`connected`, `start`, `media`, `mark`, `stop`) are dispatched in `onTwilioMsg`
(`src/call-handler.ts:165`). On `start`, the handler captures the caller's phone
number from Twilio custom parameters, builds the `SpeechAnalyzer` and
`CallLogger`, plays the greeting, and opens the STT stream
(`src/call-handler.ts:170-180`). Inbound `media` frames are base64-decoded and
forwarded straight to the active STT connection (`src/call-handler.ts:181-190`).

### Step 1 — Speech to text (Deepgram)

Two STT engines are supported, selected by the `STT_MODEL` env var
(`src/call-handler.ts:35`):

- **Flux** (`flux-general-multi`, the default) — Deepgram's conversational model
  with *native turn detection*. It is multilingual (English + Spanish in one
  model) and tells us, via discrete events, when a speaker is starting,
  pausing, probably done, or definitely done. Implemented as a raw WebSocket
  client in `src/stt-flux.ts` (`FluxConnection`, line 104) because these events
  are not in the Deepgram SDK.
- **Nova-3** (`language: 'multi'`) — the previous architecture, kept for
  comparison and as a fallback. It uses classic endpointing
  (`endpointing: 600`, `utterance_end_ms: 1800`) plus our own
  `SpeechAnalyzer` heuristics to decide when a turn is over
  (`startNovaSTT`, `src/call-handler.ts:536`).

Both engines are primed with the same domain vocabulary — a weighted `keyterms`
list of commercial-real-estate terms, Miami neighborhoods, and the company name
(`CallHandler.KEYTERMS`, `src/call-handler.ts:255`) — so the recognizer is biased
toward words callers actually use ("Allapattah", "Doral", "NNN", "warehouse").

### Step 2 — Deciding the caller is done (turn-taking)

This is the heart of the pipeline. With **Flux**, turn-taking is event-driven
(`startFluxSTT`, `src/call-handler.ts:292`):

- **`EagerEndOfTurn`** (confidence ≥ 0.5) — Flux *thinks* the caller may be
  finished. We treat this as a **speculative trigger**: start calling Claude
  immediately so we get a head start on latency
  (`onEagerEndOfTurn`, `src/call-handler.ts:320`).
- **`TurnResumed`** — the caller kept talking after the eager guess. We
  **cancel the speculative Claude call** and wait
  (`onTurnResumed`, `src/call-handler.ts:395`). This is the safety valve that
  makes eager triggering safe: guess early, retract cleanly if wrong.
- **`EndOfTurn`** (confidence ≥ 0.7) — the *definitive* "caller is done" signal.
  If the eager call already started and was not cancelled, we let it stand;
  otherwise we respond now (`onEndOfTurn`, `src/call-handler.ts:406`).
- **`StartOfTurn`** — caller began speaking; used as a barge-in hint but we
  deliberately *don't* act on it until we see actual words, to avoid reacting to
  a cough or door slam (`onStartOfTurn`, `src/call-handler.ts:453`).

Several guards prevent premature or annoying responses:

- **Short low-confidence hold** — ≤2 words below 0.7 confidence are held for the
  definitive `EndOfTurn` rather than firing a speculative call
  (`src/call-handler.ts:366-372`).
- **Yes/no follow-up hold** — if the AI just asked "anything else?" and the
  caller says only "yes", the real question is still coming, so we hold instead
  of racing them with "what question?" (`src/call-handler.ts:378-386`,
  `isAffirmative`, `src/call-handler.ts:45`).

With **Nova-3**, the equivalent logic lives in `SpeechAnalyzer.isThoughtComplete`
(`src/speech-analyzer.ts:395`) — punctuation + word-count + "bridge word"
detection (don't trigger if the last word is "and", "the", "para"…) — and a
final `UtteranceEnd` safety trigger (`src/call-handler.ts:662`).

### Step 3 — Claude generates the reply (streaming)

`flushAndRespond` (`src/call-handler.ts:715`) combines the final transcript(s)
and calls `respond` (`src/call-handler.ts:786`), which streams the turn through
`chatStream` (`src/claude.ts:876`).

Key latency and correctness design:

- **Single streaming call, not two.** Earlier versions made one call to decide on
  tools and another for text. Now a single `client.messages.stream` handles tool
  use *and* text; only if a tool is called does it loop for follow-up text (up to
  3 rounds, `src/claude.ts:891`). Comment at `src/claude.ts:860-870`.
- **Streamed token-by-token.** Text deltas are pushed to the caller's TTS as they
  arrive (`onTextChunk`), and the time-to-first-token is logged
  (`src/call-handler.ts:892-901`).
- **Haiku model for speed.** `MODEL = 'claude-haiku-4-5-20251001'`
  (`src/claude.ts:471`), `max_tokens: 250` (`src/claude.ts:897`) — small, fast
  responses suit a phone call.
- **Prompt caching.** The large system prompt is sent with
  `cache_control: { type: 'ephemeral' }` (`src/claude.ts:898-904`) so repeated
  turns within a call don't re-pay for the prompt tokens — cheaper and faster
  first token.

### Step 4 — Text to speech (ElevenLabs)

Reply text is streamed into `ElevenLabsStream` (`src/tts.ts:27`), which opens a
WebSocket to the `eleven_flash_v2_5` model and requests **`ulaw_8000`** output —
exactly Twilio's required format, so no transcoding is needed
(`src/tts.ts:48`). Audio chunks come back base64-encoded and are relayed
verbatim to Twilio (`sendBase64Audio`, `src/call-handler.ts:1208`). Voice is
language-specific: Hope (EN) / Marcela (ES) (`VOICES`, `src/tts.ts:11`).

`sync_alignment=true` is requested (`src/tts.ts:48`) so each audio chunk carries
character-level timing — this is what powers accurate barge-in recovery (below).

> **Note on naming.** The pipeline currently uses **Deepgram for STT and
> ElevenLabs for TTS**. The project's top-level `CLAUDE.md` describes Deepgram
> TTS — the code is the source of truth here: TTS is ElevenLabs
> (`src/tts.ts:1-9`).

### Step 5 — Confirming the caller actually heard it (Twilio marks)

The system never assumes audio was heard just because it was *sent*. After
queuing audio it sends a Twilio **mark** and waits for Twilio to echo it back,
which means the caller's device has played everything up to that point
(`waitForPlayback`, `src/call-handler.ts:1244`; mark handling at
`src/call-handler.ts:191-203`). Only then does it unlock for the next turn,
process stashed input, or hang up. There is always a fallback timeout (scaled to
response length, ~`words/2.5 * 1000 + 5000` ms) in case the caller hung up and
the mark never returns (`src/call-handler.ts:1016-1021`).

### Latency budget (why it feels instant)

- **Greeting is pre-baked** — no Claude call on pickup, saving an estimated
  7–11s (`getGreeting`, `src/claude.ts:1017`).
- **Speculative (eager) Claude calls** start before the caller fully finishes.
- **Token streaming into streaming TTS** — the caller hears the first words in
  ~1–1.5s rather than after the full reply is generated.
- **Reactive fillers** mask the slowest turns (tool searches) — see §5.
- **μ-law end-to-end** — STT and TTS both speak Twilio's native codec, no
  resampling.

---

## 3. Barge-in and interruption handling

This is the most sophisticated part of the system, spread across the STT
callbacks, `cancel()`, and the barge-in context tracker.

**Detecting a barge-in.** While the AI is talking (`isProcessing === true`),
incoming transcripts are classified by length:

- **Flux:** a short utterance (≤3 words) during processing is *stashed* (likely a
  back-channel "okay", "mhm", or noise); a longer one is treated as a real
  interruption — cancel and respond (`src/call-handler.ts:338-360`).
- **Nova-3:** finer-grained — ≤2 words stashed (and dropped entirely if
  confidence < 0.55, i.e. probable noise), 3 words stashed as "medium", 4+ words
  is a true barge-in (`src/call-handler.ts:612-656`). Transcripts arriving during
  the *filler* phase are always stashed (`src/call-handler.ts:615-621`).

**The "stash" mechanism.** Input that arrives at an awkward moment (during
playback, during a filler) isn't thrown away — it is queued in
`pendingTranscripts` and replayed once the current turn's playback is confirmed
(`src/call-handler.ts:1041-1085`). Stashed text that turns out to be a duplicate
or subset of the turn just handled is discarded to avoid double-answering
(`src/call-handler.ts:1050-1055`).

**Cancelling cleanly.** `cancel()` (`src/call-handler.ts:734`) increments a
**`generationId`** — a monotonic counter that stamps every turn. Every async
callback checks `if (gen !== this.generationId) return;` before doing anything
(e.g. `src/call-handler.ts:893`, `930`, `1005`, `1022`). This is the core
concurrency-safety trick: stale Claude tokens or TTS chunks from an interrupted
turn are silently dropped, so an interrupted response can never "leak" audio over
the new one. `cancel()` also clears Twilio's audio buffer, aborts the TTS
WebSocket, and clears all pending mark timers.

**Remembering what was actually said.** This is the clever part. When a barge-in
happens mid-sentence, Claude's conversation history would otherwise record the
*entire* intended reply as if the caller heard all of it — leading to confusing
follow-ups. Instead, on cancel the system reads ElevenLabs' character-level
alignment (`getSpokenText`, `src/tts.ts:157`) to determine exactly how far
playback got, computes the unspoken remainder (`computeUnspokenText`,
`src/call-handler.ts:1353`), and **rewrites the last assistant message** to the
spoken portion plus an explicit note:

> `[INTERRUPTED — the caller started speaking here and did not hear the rest.
> You were going to say: "…" — work this information into your next response
> naturally if still relevant.]`

(`updateHistoryForBargeIn`, `src/call-handler.ts:1369-1409`). If the unanswered
question was in the *unspoken* part, the pending-question flag is cleared so the
AI doesn't assume it was asked (`src/call-handler.ts:1402-1408`).

---

## 4. The Claude tool-calling system

Claude is given a set of tools it can call mid-response. The tool list is
assembled in `src/claude.ts:290-462` and dispatched in `processToolUse`
(`src/claude.ts:473`). SMS and email tools are conditionally included based on
feature flags.

| Tool | Purpose | Defined | Handler |
|---|---|---|---|
| **`search_properties`** | Search live listings by city, type, listing type (sale/lease), price range, building/lot size, free-text keyword, and sort order (incl. `price_per_door_asc` for cheapest-per-door on multifamily). Returns the top matches formatted for speech; auto-broadens when nothing matches and appends a geography hint when results are thin. | `src/claude.ts:291` | `src/claude.ts:478-522` |
| **`log_lead`** | Record a caller as a lead (name, property, interest, asset type, city, buy/lease intent). De-duplicated per call (`deduplicateLead`, `src/claude.ts:74`); fire-and-forget write to Salesforce so it never blocks the call (`src/claude.ts:551-565`). On draft (no-website) listings it injects a just-in-time instruction to offer the flyer by email. | `src/claude.ts:344` | `src/claude.ts:524-594` |
| **`end_call`** | Hang up after a mutual farewell. Returns the `CALL_ENDED` sentinel, which sets `shouldEndCall` and schedules a graceful hangup *after* the farewell audio is confirmed played. | `src/claude.ts:374` | `src/claude.ts:841-851` |
| **`send_property_sms`** *(if `SMS_ENABLED`)* | Text the caller a property link. Resolves the Salesforce property by id (falling back to address match), refuses if the listing has no shareable public URL, respects opt-outs, and runs the A2P consent flow ("reply YES" for first-time recipients vs. immediate send for confirmed numbers). | `src/claude.ts:392` | `src/claude.ts:596-697` |
| **`send_email`** *(if `EMAIL_ENABLED`)* | Email a flyer (PDF) + link to an address the caller stated out loud. Validates the email, checks a flyer or web page actually exists before promising anything, then sends fire-and-forget. | `src/claude.ts:419` | `src/claude.ts:699-766` |
| **`text_for_email`** *(if `EMAIL_ENABLED`)* | The preferred email path: text the caller asking them to *reply with their email*, so they never have to spell an address aloud. Batches multiple properties into one email sent on reply. | `src/claude.ts:442` | `src/claude.ts:768-839` |

**How tool results steer the conversation.** Tool results are not just data —
they carry *instructions back to the model*. For example, a refused SMS returns
text telling Claude exactly what to say instead ("Do NOT say 'I sent you a
text'… offer to email the flyer"), and `log_lead` injects a "NEXT, RIGHT NOW"
nudge to offer the flyer. This deterministic steering compensates for the small
Haiku model occasionally ignoring the system prompt (`src/claude.ts:568-591`,
`637-643`).

**Streaming loop.** `chatStream` (`src/claude.ts:876`) parses the streamed event
types: `content_block_start` for a tool fires the `onToolCall` callback
*immediately* (so the filler can play the instant a tool begins,
`src/claude.ts:916-927`); `input_json_delta` accumulates tool arguments;
`content_block_stop` finalizes them. Tool calls in a round are executed in
parallel via `Promise.all` (`src/claude.ts:976-979`), and the assistant/tool
exchange is appended to the per-call history (`src/claude.ts:982-985`).

---

## 5. Fillers — masking the slow turns

A property search takes a few seconds (Claude → Salesforce → format → Claude
again). Silence on a phone feels broken. The fix: the **instant** Claude decides
to call a tool, a short spoken acknowledgment plays
("Let me check what we have." / "Déjeme ver qué tenemos.").

This is triggered by the real tool-call event, not by a timer or a guess — see
the comment block at `src/call-handler.ts:226-231` and the `TOOL_FILLERS` map at
`src/call-handler.ts:881-885`. Because of this, the system prompt explicitly
forbids Claude from *also* opening with "Let me search…" (it would double up):
`src/claude.ts:156-162`. Any preamble text Claude emits before the tool call is
stripped (the filler already covered it) and only restored if Claude produces no
post-tool text, so the caller is never left in silence
(`src/call-handler.ts:903-925`, `940-945`). Phrases live in `FILLER_PHRASES`
(`src/speech-analyzer.ts:68`); the whole feature can be disabled with
`FILLER_ENABLED=false` (`src/call-handler.ts:41`).

---

## 6. Language handling (English / Spanish)

The attendant is fully bilingual and switches automatically — no "press 2 for
Spanish".

- **Detection.** Flux Multilingual reports the detected language per turn;
  `adoptFluxLanguage` (`src/call-handler.ts:480`) flips `callerLang` on a clear
  primary signal (short/ambiguous turns stay "sticky" on the current language).
- **Belt-and-suspenders.** Flux sometimes omits the language array on short
  utterances, leaving `callerLang` stuck on the default. So per turn the system
  also runs two text-based detectors and prefers Spanish if *either* is confident
  — an English filler on a Spanish call is jarring, while the reverse essentially
  never happens because both detectors are conservative about Spanish
  (`src/call-handler.ts:866-877`; `detectLanguage` in `src/tts.ts:165`, and
  `SpeechAnalyzer`'s `SPANISH_INDICATORS` at `src/speech-analyzer.ts:163`).
- **Voice selection.** Language picks the ElevenLabs voice and `language_code`
  (`src/tts.ts:11-20`, `40-48`).
- **In the Nova-3 path** there is also a `switchToNova` mechanism that tears down
  Flux and restarts in Spanish-capable Nova-3 mid-call if needed, cancelling any
  in-flight (likely garbled) response first (`src/call-handler.ts:511-530`).
- **Claude's behavior** is governed by the BILINGUAL SUPPORT block in the system
  prompt (`src/claude.ts:121-126`): switch fully to Spanish if the caller does,
  match Spanglish, use natural Miami/Latin-American Spanish.

### Greeting and recording disclosure

The greeting is **pre-baked** (no API call) and includes the recording
disclosure in the very first utterance (`GREETINGS`, `src/claude.ts:1008-1011`):

> EN: "Thank you for calling Fausto Commercial. This call may be recorded for
> quality. How can I help?"
> ES: "Gracias por llamar a Fausto Commercial. Esta llamada puede ser grabada
> para fines de calidad. ¿En qué le puedo ayudar?"

This is a **legal requirement, not a nicety**: Florida is a two-party
(all-party) consent state, and calls are recorded dual-channel for QA, so consent
must be disclosed up front (comment at `src/claude.ts:1005-1007`). The greeting
also seeds the conversation history with a `[Call connected]` turn so Claude
knows it has already greeted (`src/claude.ts:1019-1022`), and the prompt tells it
not to re-greet (`src/claude.ts:116-119`).

---

## 7. The clever bits worth highlighting

For the non-technical reader: these are the parts that took real engineering and
make the difference between "robotic IVR" and "talks like a person."

1. **Speculative responses with clean retraction.** The AI starts thinking
   before the caller has fully finished, then *un-thinks* it if the caller keeps
   talking (`onEagerEndOfTurn` / `onTurnResumed`,
   `src/call-handler.ts:320`, `395`). This shaves a noticeable chunk off every
   response while staying safe.

2. **Generation-ID concurrency guard.** A single integer (`generationId`) makes
   interruptions bulletproof: any audio or text from a superseded turn is
   discarded automatically (`src/call-handler.ts:734-735`, checked everywhere).
   Simple, and it eliminates an entire class of "two voices at once" bugs.

3. **Alignment-based barge-in memory.** Using ElevenLabs' character-timing to
   reconstruct *exactly* what the caller heard, then telling Claude what got cut
   off, so the next reply picks up naturally (`src/call-handler.ts:1353-1409`).
   Most voice bots simply forget — this one recovers like a human would.

4. **Playback confirmation via Twilio marks.** The system waits for proof the
   caller *heard* the audio before moving on or hanging up — no fixed guesses,
   with length-scaled timeout fallbacks (`waitForPlayback`,
   `src/call-handler.ts:1244`).

5. **Tool-triggered fillers with preamble stripping.** Zero-guess fillers fired
   by the real tool-call event, with redundant preamble removed so it never
   sounds repetitive (`src/call-handler.ts:903-925`).

6. **Deterministic correction of business-critical mishearings.** "Buy" / "bye" /
   "goodbye" are near-identical on a phone. When the AI just asked "buy or
   lease?", a farewell-sounding reply is *hard-overridden* to "To buy." in code,
   because the small model otherwise sometimes hangs up on a live lead — a direct
   revenue bug (`src/call-handler.ts:802-851`, plus the STT `replace`/regex maps
   at `src/call-handler.ts:552-563` and `src/stt-flux.ts:76-98`).

7. **Tool results as conversational instructions.** Handlers return prose that
   *tells Claude what to say next*, compensating for small-model drift and
   enforcing SMS/A2P compliance deterministically (`src/claude.ts:568-591`,
   `637-643`).

8. **Domain-tuned recognition.** A weighted keyterm list of CRE jargon + Miami
   geography biases the recognizer toward the words callers actually use
   (`src/call-handler.ts:255-278`), and the system prompt teaches address/number
   pronunciation rules so the TTS reads "1805" as "eighteen oh five", in both
   languages (`src/claude.ts:183-195`).

---

## 8. Key files & functions (reference)

| File | Role | Notable symbols (file:line) |
|---|---|---|
| `src/call-handler.ts` | Per-call orchestrator; owns all turn-taking, barge-in, fillers, playback confirmation, hangup. | `CallHandler` (88), `onTwilioMsg` (165), `startFluxSTT` (292), `adoptFluxLanguage` (480), `startNovaSTT` (536), `flushAndRespond` (715), `cancel` (734), `respond` (786), `waitForPlayback` (1244), `computeUnspokenText` (1353), `updateHistoryForBargeIn` (1369), `detectPendingQuestion` (1415) |
| `src/claude.ts` | Claude streaming wrapper; tool defs + handlers; system prompt; pre-baked greeting. | `SYSTEM_PROMPT` (107), `tools` (290), `processToolUse` (473), `chatStream` (876), `MODEL` (471), `getGreeting` (1017), `GREETINGS` (1008) |
| `src/stt-flux.ts` | Raw-WebSocket Deepgram Flux client with native turn events. | `FluxConnection` (104), `handleMessage`/TurnInfo parsing (225), `applyReplacements` (92) |
| `src/tts.ts` | ElevenLabs streaming TTS (μ-law 8k), alignment tracking, language→voice. | `ElevenLabsStream` (27), `pushText` (107), `getSpokenText` (157), `detectLanguage` (165), `VOICES` (11) |
| `src/speech-analyzer.ts` | Noise filtering, language detection, filler selection, Nova-3 turn heuristics, pending-question state. | `SpeechAnalyzer` (170), `getDecision` (258), `isThoughtComplete` (395), `pickFiller` (346), `FILLER_PHRASES` (68), `setPendingQuestion` (186) |
| `src/call-logger.ts` | Per-call structured timeline → console + JSON, with per-turn latency breakdowns. | `CallLogger` (74), `flush` (323), `printTimeline` (328), `saveJSON` (432) |

---

## 9. Configuration / environment variables

| Variable | Used in | Effect | Default |
|---|---|---|---|
| `DEEPGRAM_API_KEY` | `src/call-handler.ts:31` | Deepgram STT auth (Flux + Nova-3). | required |
| `STT_MODEL` | `src/call-handler.ts:35` | `flux` (default) or `nova-3`. | `flux` |
| `FILLER_ENABLED` | `src/call-handler.ts:41` | `false` disables filler phrases (silence during tool calls). | on |
| `ELEVENLABS_API_KEY` | `src/tts.ts:9` | ElevenLabs TTS auth. | required |
| `ANTHROPIC_API_KEY` | implicit, `new Anthropic()` `src/claude.ts:468` | Claude API auth (SDK reads it from env). | required |
| `SMS_ENABLED` | `src/claude.ts:24` | `false` removes the `send_property_sms` tool. | on |
| `EMAIL_ENABLED` | `src/claude.ts:25` | `true` adds `send_email` + `text_for_email` tools (Resend). | off |
| `TWILIO_ACCOUNT_SID` / `TWILIO_SID` | `src/call-handler.ts:1164` | REST auth to hang up calls. Without it, auto-hangup is skipped. | — |
| `TWILIO_AUTH_TOKEN` / `TWILIO_TOKEN` | `src/call-handler.ts:1166` | REST auth (token) for hangup. | — |
| `CALL_LOG_DIR` | `src/call-logger.ts:72` | Where per-call JSON timelines are written. | `/tmp/call-logs` |

Tunable in code (not env): Flux thresholds — `eotThreshold: 0.7`,
`eagerEotThreshold: 0.5`, `eotTimeoutMs: 3000` (`src/call-handler.ts:298-307`);
Nova-3 endpointing — `endpointing: 600`, `utterance_end_ms: 1800`
(`src/call-handler.ts:549-550`); Claude `max_tokens: 250` and model id
(`src/claude.ts:471`, `897`); TTS voices and model (`src/tts.ts:3`, `11`).

---

## 10. Gotchas & operational notes

- **TTS is ElevenLabs, not Deepgram.** The repo's `CLAUDE.md` says Deepgram TTS;
  the code uses ElevenLabs (`src/tts.ts`). Trust the code. The `ElevenLabsStream`
  file header even still mentions a "Deepgram TTS" lineage in older comments
  — ignore.
- **Two STT engines exist.** Flux is default; Nova-3 is a parallel, fully wired
  fallback with its *own* (older) turn-taking logic. Changes to turn-taking must
  often be made in both paths. The `switchToNova` mid-call escape hatch
  (`src/call-handler.ts:511`) only triggers from the Nova path; in pure-Flux mode
  Spanish is handled natively by `flux-general-multi`.
- **The "buy/bye" hard override is load-bearing.** Do not remove
  `src/call-handler.ts:831-848`. The small Haiku model has repeatedly hung up on
  live buyers without it. If you upgrade the model, re-test this scenario before
  trusting the prompt alone.
- **Model is Claude Haiku 4.5** (`claude-haiku-4-5-20251001`, `src/claude.ts:471`)
  chosen for latency. It occasionally needs the deterministic tool-result nudges
  to behave. Swapping to a larger model would improve adherence but hurt
  first-token latency — measure before changing.
- **Conversation + lead state is in-memory** (`conversations`, `leads`,
  `loggedLeadsPerCall` maps, `src/claude.ts:52-54`). State is per-process and is
  cleared on call end (`clearConversation`, `src/claude.ts:65`). A Railway
  restart drops any in-flight call's context. Leads are persisted out to
  Salesforce (fire-and-forget), but the in-memory `leads` array itself is
  ephemeral.
- **Call logs go to `/tmp` by default** (`src/call-logger.ts:72`) — ephemeral on
  Railway. For durable post-mortems set `CALL_LOG_DIR` to a persistent volume, or
  read the live console timeline (`printTimeline`) and per-turn latency
  breakdown, which is the fastest way to debug "why was that turn slow / cut off".
- **Hangup needs Twilio REST creds.** If `TWILIO_ACCOUNT_SID`/`AUTH_TOKEN` are
  unset, `end_call` will say goodbye but the line won't actually disconnect
  (warning logged at `src/call-handler.ts:1170-1174`).
- **Tool-call rounds are capped at 3** (`src/claude.ts:891`) to bound latency and
  cost; a turn needing more tool hops will be cut off. Rare in practice.
- **Pending-question state expires after 30s** (`src/speech-analyzer.ts:190`), so
  context-based STT corrections (e.g. interpreting "Liz" as "lease") only apply
  promptly after the AI asks the relevant question.
- **`max_tokens: 250`** can truncate an unusually long reply. The prompt heavily
  pushes 1–2 sentence answers, so this is intentional, but it is the first knob
  to check if a response ever sounds cut off mid-sentence (vs. barge-in cut off).
</content>
