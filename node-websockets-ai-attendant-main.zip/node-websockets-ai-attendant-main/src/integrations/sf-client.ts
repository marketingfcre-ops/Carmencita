/**
 * Generic Salesforce client.
 *
 * Use this for one-off scripts that need to target either the production org
 * or the Dev Edition org. The existing `src/salesforce.ts` is the long-lived
 * server-side client bound to production — it remains unchanged.
 *
 * Auth: OAuth 2.0 Client Credentials flow.
 *
 * Usage:
 *   const sf = await sfClient('prod');           // reads SF_*
 *   const sf = await sfClient('dev');            // reads SF_DEV_*
 *   const sf = await sfClient({ loginUrl, clientId, clientSecret });  // explicit
 *
 *   const records = await sf.soql<{ Id: string; Name: string }>(
 *     `SELECT Id, Name FROM Property__c LIMIT 5`
 *   );
 *   await sf.update('Property__c', 'a0R...', { Status__c: 'Active' });
 */

export interface SfCredentials {
  loginUrl: string;
  clientId: string;
  clientSecret: string;
}

export type SfTarget = 'prod' | 'dev' | SfCredentials;

export interface SoqlResponse<T> {
  totalSize: number;
  done: boolean;
  records: T[];
  nextRecordsUrl?: string;
}

export class SfClient {
  private accessToken = '';
  private instanceUrl = '';
  private readonly creds: SfCredentials;

  constructor(creds: SfCredentials) {
    this.creds = creds;
  }

  /** OAuth 2.0 client_credentials flow. Resolves with access token + instance URL. */
  async authenticate(): Promise<void> {
    const params = new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: this.creds.clientId.trim(),
      client_secret: this.creds.clientSecret.trim(),
    });
    const res = await fetch(`${this.creds.loginUrl}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    });
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`SF auth failed: ${res.status} ${err}`);
    }
    const data = (await res.json()) as { access_token: string; instance_url: string };
    this.accessToken = data.access_token;
    this.instanceUrl = data.instance_url;
  }

  /** Run a SOQL query. Auto re-auth on 401. Follows nextRecordsUrl pagination. */
  async soql<T = unknown>(query: string): Promise<T[]> {
    let url: string | null =
      `${this.instanceUrl}/services/data/v59.0/query?q=${encodeURIComponent(query)}`;
    const all: T[] = [];
    while (url) {
      const res = await this.req(url, { headers: this.authHeaders() });
      const data = (await res.json()) as SoqlResponse<T>;
      if (data.records) all.push(...data.records);
      url = data.nextRecordsUrl ? `${this.instanceUrl}${data.nextRecordsUrl}` : null;
    }
    return all;
  }

  /** Run a Tooling API SOQL query. Follows nextRecordsUrl pagination. */
  async toolingQuery<T = unknown>(query: string): Promise<T[]> {
    let url: string | null =
      `${this.instanceUrl}/services/data/v59.0/tooling/query?q=${encodeURIComponent(query)}`;
    const all: T[] = [];
    while (url) {
      const res = await this.req(url, { headers: this.authHeaders() });
      const data = (await res.json()) as SoqlResponse<T>;
      if (data.records) all.push(...data.records);
      url = data.nextRecordsUrl ? `${this.instanceUrl}${data.nextRecordsUrl}` : null;
    }
    return all;
  }

  /** GET a single record by Id. */
  async retrieve<T = unknown>(sobject: string, id: string): Promise<T> {
    const url = `${this.instanceUrl}/services/data/v59.0/sobjects/${sobject}/${id}`;
    const res = await this.req(url, { headers: this.authHeaders() });
    return (await res.json()) as T;
  }

  /** Describe an SObject (schema). */
  async describe(sobject: string): Promise<any> {
    const url = `${this.instanceUrl}/services/data/v59.0/sobjects/${sobject}/describe`;
    const res = await this.req(url, { headers: this.authHeaders() });
    return res.json();
  }

  /** POST: create a record. Returns the new ID. */
  async create(sobject: string, fields: Record<string, unknown>): Promise<string> {
    const url = `${this.instanceUrl}/services/data/v59.0/sobjects/${sobject}/`;
    const res = await this.req(url, {
      method: 'POST',
      headers: { ...this.authHeaders(), 'Content-Type': 'application/json' },
      body: JSON.stringify(fields),
    });
    const data = (await res.json()) as { id: string };
    return data.id;
  }

  /** PATCH: update fields on an existing record. */
  async update(
    sobject: string,
    id: string,
    fields: Record<string, unknown>
  ): Promise<void> {
    const url = `${this.instanceUrl}/services/data/v59.0/sobjects/${sobject}/${id}`;
    await this.req(url, {
      method: 'PATCH',
      headers: { ...this.authHeaders(), 'Content-Type': 'application/json' },
      body: JSON.stringify(fields),
    });
  }

  /** DELETE: remove a record. */
  async delete(sobject: string, id: string): Promise<void> {
    const url = `${this.instanceUrl}/services/data/v59.0/sobjects/${sobject}/${id}`;
    await this.req(url, { method: 'DELETE', headers: this.authHeaders() });
  }

  /** Tooling API: create metadata (custom field, validation rule, etc.). */
  async toolingCreate(
    sobject: string,
    body: Record<string, unknown>
  ): Promise<{ id: string }> {
    const url = `${this.instanceUrl}/services/data/v59.0/tooling/sobjects/${sobject}/`;
    const res = await this.req(url, {
      method: 'POST',
      headers: { ...this.authHeaders(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return (await res.json()) as { id: string };
  }

  /** Get instance URL (for Lightning links etc). */
  get instance(): string {
    return this.instanceUrl;
  }

  /** Get the bearer token. Use sparingly — prefer the client's helpers. */
  get token(): string {
    return this.accessToken;
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  private authHeaders(): Record<string, string> {
    return { Authorization: `Bearer ${this.accessToken}` };
  }

  /** Generic HTTP with one re-auth retry on 401. */
  private async req(url: string, init: RequestInit = {}): Promise<Response> {
    const doFetch = () => fetch(url, init);
    let res = await doFetch();
    if (res.status === 401) {
      await this.authenticate();
      // refresh auth header in init
      if (init.headers && (init.headers as Record<string, string>).Authorization) {
        (init.headers as Record<string, string>).Authorization =
          `Bearer ${this.accessToken}`;
      }
      res = await doFetch();
    }
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`SF ${init.method || 'GET'} ${url.split('?')[0]} → ${res.status}: ${err.slice(0, 400)}`);
    }
    return res;
  }
}

// ---------------------------------------------------------------------------
// Factory
// ---------------------------------------------------------------------------

/** Resolve credentials from env or explicit creds object. Authenticates eagerly. */
export async function sfClient(target: SfTarget = 'prod'): Promise<SfClient> {
  let creds: SfCredentials;
  if (target === 'prod') {
    creds = {
      loginUrl: requireEnv('SF_LOGIN_URL'),
      clientId: requireEnv('SF_CLIENT_ID'),
      clientSecret: requireEnv('SF_CLIENT_SECRET'),
    };
  } else if (target === 'dev') {
    creds = {
      loginUrl: requireEnv('SF_DEV_LOGIN_URL'),
      clientId: requireEnv('SF_DEV_CLIENT_ID'),
      clientSecret: requireEnv('SF_DEV_CLIENT_SECRET'),
    };
  } else {
    creds = target;
  }
  const c = new SfClient(creds);
  await c.authenticate();
  return c;
}

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}
