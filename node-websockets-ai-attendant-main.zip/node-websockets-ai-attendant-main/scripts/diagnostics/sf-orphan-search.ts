/**
 * Exhaustive WP search for the 3 SF orphan records (pointing at WP IDs
 * that no longer exist). Same approach as sf-mislink-exhaustive-search.ts.
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';
const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

const TARGETS = [
  { sfId: 'a0RJw000008GkGnMAK', sfAddress: '2459 & 2463 Pierce St', currentWp: 23470 },
  { sfId: 'a0RJw000008GnRZMA0', sfAddress: '10822-10824 NW 7th Ave', currentWp: 23091 },
  { sfId: 'a0RJw000009A8lVMAS', sfAddress: '1746 W Commercial BLVD', currentWp: 63126 },
];

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  slug: string;
  fave_property_address: string;
  excerpt: string;
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,slug,excerpt,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || '').toString(),
          slug: p.slug || '',
          fave_property_address: p.fave_property_address || '',
          excerpt: (p.excerpt?.rendered || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').slice(0, 100),
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

interface SfProperty {
  Id: string;
  Address__c: string | null;
  City__c: string | null;
  Public_URL__c: string | null;
}

async function main() {
  if (!WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔎 Exhaustive WP search for 3 SF orphans\n');
  const { token, instance } = await sfAuth();
  const wp = await fetchAllWpPosts();
  console.log(`Loaded ${wp.length} WP posts.\n`);

  // Get fresh SF data
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(
    `SELECT Id, Address__c, City__c, Public_URL__c FROM Property__c WHERE Id IN ('${TARGETS.map((t) => t.sfId).join("','")}')`
  )}`;
  const sfRes = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  const sfData = (await sfRes.json()) as { records: SfProperty[] };
  const sfById = new Map<string, SfProperty>();
  for (const r of sfData.records) sfById.set(r.Id, r);

  for (const t of TARGETS) {
    const sf = sfById.get(t.sfId);
    console.log('═'.repeat(72));
    console.log(`SF ${t.sfId}`);
    console.log(`   Address:        "${sf?.Address__c || t.sfAddress}"`);
    console.log(`   City:           ${sf?.City__c || '(none)'}`);
    console.log(`   Public_URL__c:  ${sf?.Public_URL__c || '(none)'}`);
    console.log(`   Linked at:      wp:${t.currentWp}  ❌ (does not exist)`);
    console.log('═'.repeat(72));

    // Extract house number from address
    const addr = (sf?.Address__c || t.sfAddress).toLowerCase();
    const houseNumberMatch = addr.match(/\d+/);
    const houseNumber = houseNumberMatch ? houseNumberMatch[0] : '';
    const cityLower = (sf?.City__c || '').toLowerCase();

    console.log(`\nSearch for posts containing "${houseNumber}":\n`);

    const candidates: WpPost[] = [];
    for (const p of wp) {
      const wpAddr = p.fave_property_address.toLowerCase();
      const title = p.title.toLowerCase();
      const slug = p.slug.toLowerCase();
      const excerpt = p.excerpt.toLowerCase();
      if (!houseNumber) continue;
      const re = new RegExp(`\\b${houseNumber}\\b`);
      if (re.test(wpAddr) || re.test(title) || slug.includes(houseNumber) || re.test(excerpt)) {
        candidates.push(p);
      }
    }

    candidates.sort((a, b) => {
      const cityA = a.fave_property_address.toLowerCase().includes(cityLower) ? 0 : 1;
      const cityB = b.fave_property_address.toLowerCase().includes(cityLower) ? 0 : 1;
      return cityA - cityB || a.id - b.id;
    });

    console.log(`Found ${candidates.length} WP posts containing "${houseNumber}":\n`);
    for (const p of candidates) {
      console.log(`   wp:${p.id} ${p.status.padEnd(8)} ${p.date.slice(0, 10)}`);
      console.log(`     title:  "${p.title.replace(/&#8211;/g, '–').slice(0, 72)}"`);
      console.log(`     addr:   "${p.fave_property_address}"`);
      console.log(`     slug:   ${p.slug}`);
      if (p.excerpt) console.log(`     excerpt: ${p.excerpt}`);
      console.log('');
    }

    console.log('');
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
