/**
 * Agent Listing Review — page for agents to confirm listing status.
 *
 * Each agent gets a unique link: /review?agent={SF_USER_ID}
 * They see their listings with links to SF and Website.
 * They mark each as: Active / Sold / Lost / Needs Update
 * Responses saved to Salesforce Notes_for_Marketing__c (and local backup).
 *
 * No auth — the SF user ID in the URL is the "token". Temporary tooling.
 */

import type { FastifyInstance } from 'fastify';
import { readFile, writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { getProperties, getAgents, updatePropertyField } from './salesforce';

const REVIEW_DIR = process.env.REVIEW_DIR || '/tmp/agent-reviews';
const SF_INSTANCE = 'https://d30000001hp0jeas.lightning.force.com';

interface PriorReview {
  date: string;
  agent: string;
  status: string; // ACTIVE | SOLD | LOST | NEEDS UPDATE | INACTIVE/SOLD (legacy)
  notes: string;
}

interface Listing {
  sf_id: string;
  address: string;
  city: string;
  type: string;
  listing_type: string;
  price: string;
  status: string;
  website_url: string;
  sf_url: string;
  prior: PriorReview | null;
}

// Parse the most recent agent-review entry from Notes_for_Marketing__c.
// Format examples:
//   [Agent Review 2026-04-09] Yuniel De Varona: ACTIVE
//   [Agent Review 2026-04-09] Ernesto Diaz: NEEDS UPDATE — pending sale
//   [Agent Review 2026-04-21] Halain Suarez: INACTIVE/SOLD     (legacy)
function parsePriorReview(note: string | null): PriorReview | null {
  if (!note) return null;
  // Match all reviews; take the last one (most recent submission)
  const re =
    /\[Agent Review (\d{4}-\d{2}-\d{2})\]\s*([^:]+):\s*([A-Z/ ]+?)(?:\s*—\s*(.*?))?(?=\[Agent Review|\s*$)/gs;
  let last: PriorReview | null = null;
  let m: RegExpExecArray | null;
  while ((m = re.exec(note)) !== null) {
    last = {
      date: m[1],
      agent: m[2].trim(),
      status: m[3].trim(),
      notes: (m[4] || '').trim(),
    };
  }
  return last;
}

function loadAgentListings(agentId: string): {
  agentName: string;
  listings: Listing[];
} | null {
  const props = getProperties();
  const agents = getAgents();
  if (props.length === 0) return null;

  const agentMap: Record<string, string> = {};
  for (const a of agents) agentMap[a.id] = a.name;

  const mine = props.filter((p) => (p.listingAgentId || '') === agentId);
  if (mine.length === 0) {
    // Agent has no listings (or unknown ID) — return empty so we can render a friendly page
    return { agentName: agentMap[agentId] || agentId, listings: [] };
  }

  const agentName =
    mine[0].listingAgentName || agentMap[agentId] || agentId;

  const listings: Listing[] = mine.map((p) => ({
    sf_id: p.id,
    address: p.address || p.name,
    city: p.city || '',
    type: p.propertyType || '',
    listing_type: p.listingType || '',
    price: p.price?.toString() || '',
    status: p.status || 'Active',
    website_url: p.publicUrl?.startsWith('http') ? p.publicUrl : '',
    sf_url: `${SF_INSTANCE}/lightning/r/Property__c/${p.id}/view`,
    prior: parsePriorReview(p.notesForMarketing),
  }));

  // Pending first, reviewed last
  listings.sort((a, b) => {
    if (a.prior && !b.prior) return 1;
    if (!a.prior && b.prior) return -1;
    return a.address.localeCompare(b.address);
  });

  return { agentName, listings };
}

function formatPrice(p: string): string {
  if (!p) return '';
  try {
    const n = parseFloat(p.replace(/,/g, ''));
    if (isNaN(n) || n === 0) return '';
    if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `$${(n / 1000).toFixed(0)}K`;
    return `$${n.toFixed(0)}`;
  } catch {
    return '';
  }
}

function statusBadge(status: string): string {
  const s = status.toUpperCase();
  if (s === 'ACTIVE')
    return '<span class="badge badge-active">✅ Active</span>';
  if (s === 'SOLD')
    return '<span class="badge badge-sold">🏆 Sold</span>';
  if (s === 'LOST')
    return '<span class="badge badge-lost">💔 Lost</span>';
  if (s === 'NEEDS UPDATE')
    return '<span class="badge badge-needs">⚠️ Needs Update</span>';
  // Legacy "INACTIVE/SOLD" — agents marked it before we split sold/lost
  if (s === 'INACTIVE/SOLD' || s === 'INACTIVE')
    return '<span class="badge badge-sold">❌ Inactive/Sold</span>';
  return `<span class="badge">${status}</span>`;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderReviewPage(
  agentName: string,
  agentId: string,
  listings: Listing[]
): string {
  const reviewedCount = listings.filter((l) => l.prior).length;
  const pendingCount = listings.length - reviewedCount;
  const missingWebsite = listings.filter((l) => !l.website_url).length;

  const rows = listings
    .map((l, i) => {
      const isReviewed = !!l.prior;
      const priorBadge = l.prior
        ? `${statusBadge(l.prior.status)}<br><span class="meta">${escapeHtml(l.prior.date)} · ${escapeHtml(l.prior.agent)}${l.prior.notes ? ` · "${escapeHtml(l.prior.notes)}"` : ''}</span>`
        : '';

      return `
    <tr id="row-${l.sf_id}" class="${isReviewed ? 'row-reviewed' : ''}" data-reviewed="${isReviewed ? '1' : '0'}">
      <td>${i + 1}</td>
      <td>
        <strong>${escapeHtml(l.address)}</strong><br>
        <span class="meta">${escapeHtml(l.city)} · ${escapeHtml(l.type)} · ${escapeHtml(l.listing_type)} · ${formatPrice(l.price)}</span>
      </td>
      <td>${l.sf_url ? `<a href="${l.sf_url}" target="_blank">SF</a>` : '—'}</td>
      <td>${l.website_url ? `<a href="${l.website_url}" target="_blank">Website</a>` : '<span class="missing">Missing</span>'}</td>
      <td class="prior-cell">${priorBadge || '<span class="meta">—</span>'}</td>
      <td>
        <select name="status_${l.sf_id}" class="status-select" ${isReviewed ? 'disabled' : ''}>
          <option value="">— Select —</option>
          <option value="active">✅ Still Active</option>
          <option value="sold">🏆 Sold (Closed Won)</option>
          <option value="lost">💔 Lost (Closed Lost)</option>
          <option value="needs_update">⚠️ Needs Update</option>
        </select>
        ${isReviewed ? `<br><button type="button" class="change-btn" onclick="enableRow('${l.sf_id}')">Change</button>` : ''}
      </td>
      <td><input type="text" name="notes_${l.sf_id}" placeholder="Optional notes..." class="notes-input" ${isReviewed ? 'disabled' : ''}></td>
    </tr>`;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Listing Review — ${escapeHtml(agentName)}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 20px; max-width: 1200px; margin: 0 auto; }
    h1 { font-size: 22px; margin-bottom: 4px; }
    .subtitle { color: #666; font-size: 14px; margin-bottom: 20px; }
    .instructions { background: #e3f2fd; border-radius: 8px; padding: 16px; margin-bottom: 20px; font-size: 14px; line-height: 1.6; }
    .instructions strong { color: #1565c0; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    th { background: #1a1a2e; color: #fff; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
    td { padding: 10px 12px; border-bottom: 1px solid #eee; font-size: 13px; vertical-align: top; }
    tr:hover { background: #f8f9fa; }
    tr.row-reviewed { background: #fafafa; opacity: 0.85; }
    tr.row-reviewed strong { color: #555; }
    tr.row-failed { background: #ffebee; }
    tr.row-failed strong { color: #c62828; }
    .err-msg { color: #c62828; font-size: 11px; margin-top: 4px; display: block; max-width: 260px; word-break: break-word; }
    a { color: #1565c0; text-decoration: none; font-weight: 600; }
    a:hover { text-decoration: underline; }
    .missing { color: #e53935; font-size: 11px; font-weight: 600; }
    .meta { color: #888; font-size: 11px; }
    .status-select { padding: 4px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; }
    .status-select:disabled { background: #f0f0f0; cursor: not-allowed; }
    .notes-input { padding: 4px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; width: 100%; min-width: 120px; }
    .notes-input:disabled { background: #f0f0f0; cursor: not-allowed; }
    .change-btn { margin-top: 4px; padding: 2px 8px; background: transparent; border: 1px solid #1565c0; color: #1565c0; border-radius: 3px; font-size: 11px; cursor: pointer; }
    .change-btn:hover { background: #e3f2fd; }
    .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
    .badge-active { background: #e8f5e9; color: #2e7d32; }
    .badge-sold { background: #fff3e0; color: #e65100; }
    .badge-lost { background: #ffebee; color: #c62828; }
    .badge-needs { background: #fffde7; color: #f57f17; }
    .submit-bar { position: sticky; bottom: 0; background: #fff; padding: 16px; border-top: 2px solid #1a1a2e; text-align: center; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); }
    .submit-btn { background: #1565c0; color: #fff; border: none; padding: 12px 40px; font-size: 16px; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .submit-btn:hover { background: #0d47a1; }
    .submit-btn:disabled { background: #ccc; cursor: not-allowed; }
    .toast { display: none; position: fixed; top: 20px; right: 20px; background: #2e7d32; color: #fff; padding: 12px 20px; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); font-size: 14px; z-index: 1000; }
    .toast.error { background: #c62828; }
    .count-bar { display: flex; gap: 16px; margin-bottom: 16px; flex-wrap: wrap; }
    .count-card { background: #fff; padding: 10px 16px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); min-width: 140px; }
    .count-card strong { font-size: 20px; }
    .count-card.pending strong { color: #1565c0; }
    .count-card.reviewed strong { color: #2e7d32; }
    .count-card.missing strong { color: #e53935; }
    .count-card span { font-size: 11px; color: #888; display: block; }
    .empty { background: #fff; padding: 40px; border-radius: 8px; text-align: center; color: #666; }
  </style>
</head>
<body>
  <div id="toast" class="toast">✅ Saved</div>

  <h1>📋 Listing Review — ${escapeHtml(agentName)}</h1>
  <div class="subtitle">${listings.length} listing${listings.length === 1 ? '' : 's'} assigned to you</div>

  ${
    listings.length === 0
      ? '<div class="empty">You have no active listings assigned. Nothing to review.</div>'
      : `
  <div class="instructions">
    <strong>Please review each pending listing:</strong><br>
    • Click the <strong>SF</strong> and <strong>Website</strong> links to verify the listing is current<br>
    • Mark each as <strong>Still Active</strong>, <strong>Sold</strong>, <strong>Lost</strong>, or <strong>Needs Update</strong><br>
    • Add notes for anything that needs attention (missing photos, wrong price, etc.)<br>
    • Click <strong>Submit</strong> when done — already-reviewed listings are locked but you can click <em>Change</em> to update
  </div>

  <div class="count-bar">
    <div class="count-card"><strong id="count-total">${listings.length}</strong><span>Total</span></div>
    <div class="count-card reviewed"><strong id="count-reviewed">${reviewedCount}</strong><span>Reviewed</span></div>
    <div class="count-card pending"><strong id="count-pending">${pendingCount}</strong><span>Pending</span></div>
    <div class="count-card missing"><strong>${missingWebsite}</strong><span>Missing Website</span></div>
  </div>

  <form id="reviewForm">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Property</th>
          <th>SF</th>
          <th>Website</th>
          <th>Prior Review</th>
          <th>Status</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>

    <div class="submit-bar">
      <button type="submit" class="submit-btn" id="submitBtn">Save Reviews</button>
    </div>
  </form>
  `
  }

  <script>
    const STATUS_LABELS = {
      active: ['✅ Active', 'badge-active'],
      sold: ['🏆 Sold', 'badge-sold'],
      lost: ['💔 Lost', 'badge-lost'],
      needs_update: ['⚠️ Needs Update', 'badge-needs'],
    };

    function showToast(msg, isError) {
      const el = document.getElementById('toast');
      el.textContent = msg;
      el.classList.toggle('error', !!isError);
      el.style.display = 'block';
      setTimeout(() => { el.style.display = 'none'; }, 3000);
    }

    function enableRow(sfId) {
      const row = document.getElementById('row-' + sfId);
      if (!row) return;
      row.dataset.reviewed = '0';
      row.classList.remove('row-reviewed');
      row.querySelector('.status-select').disabled = false;
      row.querySelector('.notes-input').disabled = false;
      const btn = row.querySelector('.change-btn');
      if (btn) btn.remove();
      updateCounts();
    }

    function markRowFailed(sfId, errMsg) {
      const row = document.getElementById('row-' + sfId);
      if (!row) return;
      row.classList.add('row-failed');
      const cell = row.querySelector('.prior-cell');
      // Truncate long SF error messages
      const short = (errMsg || '').slice(0, 300);
      cell.innerHTML = '<span class="badge badge-lost">❌ Save Failed</span><span class="err-msg">' + short.replace(/</g, '&lt;') + '</span>';
      // Leave the row editable so the agent can try again
    }

    function markRowReviewed(sfId, statusKey, notes) {
      const row = document.getElementById('row-' + sfId);
      if (!row) return;
      const today = new Date().toISOString().split('T')[0];
      const [label, badgeClass] = STATUS_LABELS[statusKey] || [statusKey.toUpperCase(), 'badge'];
      const cell = row.querySelector('.prior-cell');
      cell.innerHTML =
        '<span class="badge ' + badgeClass + '">' + label + '</span>' +
        '<br><span class="meta">' + today + ' · You' + (notes ? ' · "' + notes.replace(/"/g, '&quot;') + '"' : '') + '</span>';
      row.dataset.reviewed = '1';
      row.classList.add('row-reviewed');
      row.querySelector('.status-select').disabled = true;
      row.querySelector('.notes-input').disabled = true;
    }

    function updateCounts() {
      const rows = document.querySelectorAll('tr[data-reviewed]');
      const total = rows.length;
      const reviewed = document.querySelectorAll('tr[data-reviewed="1"]').length;
      document.getElementById('count-reviewed').textContent = reviewed;
      document.getElementById('count-pending').textContent = total - reviewed;
    }

    const form = document.getElementById('reviewForm');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.textContent = 'Saving...';

        const formData = new FormData(e.target);
        const reviews = {};
        for (const [key, value] of formData.entries()) {
          if (key.startsWith('status_') && value) {
            const sfId = key.replace('status_', '');
            const row = document.getElementById('row-' + sfId);
            // Only submit rows that are currently editable (not reviewed)
            if (row && row.dataset.reviewed === '0') {
              reviews[sfId] = {
                status: value,
                notes: formData.get('notes_' + sfId) || '',
              };
            }
          }
        }

        if (Object.keys(reviews).length === 0) {
          showToast('Nothing to save — pick a status first', true);
          btn.disabled = false;
          btn.textContent = 'Save Reviews';
          return;
        }

        try {
          const params = new URLSearchParams(window.location.search);
          const res = await fetch('/review/submit?agent=' + params.get('agent'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reviews }),
          });
          if (res.ok) {
            const result = await res.json();
            const perResult = result.perResult || {};
            let savedCount = 0;
            let failedCount = 0;
            const failedDetails = [];
            // Only flip rows that actually saved; mark failures inline
            for (const sfId of Object.keys(reviews)) {
              const pr = perResult[sfId] || { ok: false, error: 'No response' };
              if (pr.ok) {
                markRowReviewed(sfId, reviews[sfId].status, reviews[sfId].notes);
                savedCount++;
              } else {
                failedCount++;
                markRowFailed(sfId, pr.error || 'Save failed');
                failedDetails.push(sfId);
              }
            }
            updateCounts();
            if (failedCount === 0) {
              showToast('✅ Saved ' + savedCount + ' review' + (savedCount === 1 ? '' : 's'));
            } else if (savedCount === 0) {
              showToast('❌ All ' + failedCount + ' save' + (failedCount === 1 ? '' : 's') + ' failed — see red rows', true);
            } else {
              showToast('⚠️ Saved ' + savedCount + ', ' + failedCount + ' failed (red rows)', true);
            }
            btn.disabled = false;
            btn.textContent = 'Save Reviews';
          } else {
            showToast('Error saving — please try again', true);
            btn.disabled = false;
            btn.textContent = 'Save Reviews';
          }
        } catch (err) {
          showToast('Network error — please try again', true);
          btn.disabled = false;
          btn.textContent = 'Save Reviews';
        }
      });
    }
  </script>
</body>
</html>`;
}

export async function registerReviewRoutes(
  fastify: FastifyInstance
): Promise<void> {
  await mkdir(REVIEW_DIR, { recursive: true }).catch(() => {});

  // Agent review page
  fastify.get('/review', async (req, reply) => {
    const query = req.query as Record<string, string>;
    const agentId = query.agent;
    if (!agentId) {
      reply.code(400).send('Missing agent parameter');
      return;
    }

    const data = loadAgentListings(agentId);
    if (!data) {
      reply.code(503).send('Salesforce data not loaded yet — please retry in a moment.');
      return;
    }

    reply.type('text/html').send(renderReviewPage(data.agentName, agentId, data.listings));
  });

  // Submit review — saves to Salesforce Notes_for_Marketing__c (append, not replace)
  fastify.post('/review/submit', async (req, reply) => {
    const query = req.query as Record<string, string>;
    const agentId = query.agent;
    if (!agentId) {
      reply.code(400).send({ error: 'Missing agent' });
      return;
    }

    const body = req.body as {
      reviews: Record<string, { status: string; notes: string }>;
    };
    const data = loadAgentListings(agentId);
    const agentName = data?.agentName || agentId;
    const date = new Date().toISOString().split('T')[0];

    // Build a quick lookup of existing notes per property so we can APPEND
    const props = getProperties();
    const existingNotes: Record<string, string> = {};
    for (const p of props) {
      if (p.notesForMarketing) existingNotes[p.id] = p.notesForMarketing;
    }

    // Build a quick lookup of property data so we can fill placeholders for
    // empty required fields (Photo_URL__c, Listing_Date__c, Zoning__c, etc).
    // SF rejects PATCH on records with empty required fields, even if we're
    // only updating Notes_for_Marketing__c. Same trick as sf_import_with_bypass.py.
    const propByIdLocal: Record<string, any> = {};
    for (const p of props) propByIdLocal[p.id] = p;

    const placeholders: Record<string, any> = {
      Photo_URL__c: 'pending',
      Listing_Date__c: date,
      Zoning__c: 'TBD',
      Year_Built__c: 0,
      Building_Size_sqft__c: 0,
      Units__c: 0,
      Lot_Size_sqft__c: 0,
    };

    let success = 0;
    let errors = 0;
    // Per-listing result for the frontend
    const perResult: Record<string, { ok: boolean; error?: string }> = {};

    for (const [sfId, review] of Object.entries(body.reviews)) {
      const statusLabel =
        review.status === 'active'
          ? 'ACTIVE'
          : review.status === 'sold'
          ? 'SOLD'
          : review.status === 'lost'
          ? 'LOST'
          : review.status === 'needs_update'
          ? 'NEEDS UPDATE'
          : review.status.toUpperCase();

      const newEntry = `[Agent Review ${date}] ${agentName}: ${statusLabel}${
        review.notes ? ` — ${review.notes}` : ''
      }`;
      const existing = existingNotes[sfId] || '';
      const combined = existing
        ? `${existing.trim()}\n${newEntry}`.slice(0, 30000)
        : newEntry;

      // Build payload — include placeholders for empty required fields
      const payload: Record<string, unknown> = {
        Notes_for_Marketing__c: combined,
      };
      const prop = propByIdLocal[sfId];
      if (prop) {
        // Helper: treat null/undefined/empty-string/0 as "missing"
        const isMissing = (v: unknown) =>
          v === null ||
          v === undefined ||
          v === '' ||
          v === 0 ||
          (typeof v === 'string' && v.trim() === '');

        if (isMissing(prop.photoUrl)) payload.Photo_URL__c = placeholders.Photo_URL__c;
        // Listing_Date__c not on SFProperty type — we can still send a default; SF ignores if already set
        // But we don't know if it's set without an extra query, so only set if we have a strong signal.
        // Safer: don't send Listing_Date__c unless we know it's missing. For now, skip.
        // (Halain's case was Photo_URL__c + Listing_Date__c missing. We'll try without and see.)
        if (isMissing(prop.zoning)) payload.Zoning__c = placeholders.Zoning__c;
        if (isMissing(prop.yearBuilt)) payload.Year_Built__c = placeholders.Year_Built__c;
        if (isMissing(prop.buildingSqft)) payload.Building_Size_sqft__c = placeholders.Building_Size_sqft__c;
        if (isMissing(prop.units)) payload.Units__c = placeholders.Units__c;
        if (isMissing(prop.lotSqft)) payload.Lot_Size_sqft__c = placeholders.Lot_Size_sqft__c;
      }

      const result = await updatePropertyField(sfId, payload);

      // If the first attempt failed with REQUIRED_FIELD_MISSING for Listing_Date__c,
      // retry with that placeholder added.
      if (!result.ok && result.error && result.error.includes('Listing_Date__c')) {
        const retry = await updatePropertyField(sfId, {
          ...payload,
          Listing_Date__c: placeholders.Listing_Date__c,
        });
        if (retry.ok) {
          success++;
          perResult[sfId] = { ok: true };
          continue;
        }
        perResult[sfId] = { ok: false, error: retry.error };
        errors++;
        continue;
      }

      if (result.ok) {
        success++;
        perResult[sfId] = { ok: true };
      } else {
        errors++;
        perResult[sfId] = { ok: false, error: result.error };
        console.warn(`  ↳ ${sfId} failed: ${result.error}`);
      }
    }

    // Backup to disk
    try {
      const filepath = join(REVIEW_DIR, `${agentId}-${Date.now()}.json`);
      await writeFile(
        filepath,
        JSON.stringify(
          {
            agentId,
            agentName,
            submittedAt: new Date().toISOString(),
            reviews: body.reviews,
            sfUpdates: { success, errors },
          },
          null,
          2
        )
      );
    } catch {
      /* backup save failed — not critical */
    }

    console.log(
      `📋 Agent review submitted: ${agentName} — ${success} saved to SF, ${errors} errors`
    );

    return { success: true, count: success, errors, perResult };
  });

  // Admin: view all submitted reviews (local backups only)
  fastify.get('/review/results', async (req, reply) => {
    const query = req.query as Record<string, string>;
    const adminKey = process.env.ADMIN_KEY || 'fausto2026';
    if (query.key !== adminKey) {
      reply.code(404).send('Not found');
      return;
    }

    const { readdir } = await import('fs/promises');
    try {
      const files = await readdir(REVIEW_DIR);
      const results: any[] = [];
      for (const file of files) {
        if (!file.endsWith('.json')) continue;
        const raw = await readFile(join(REVIEW_DIR, file), 'utf-8');
        results.push(JSON.parse(raw));
      }
      return { totalSubmissions: results.length, results };
    } catch {
      return { totalSubmissions: 0, results: [] };
    }
  });
}
