/**
 * Set up the test-agent-001 user with a Group_ID__c value so they can
 * exercise the validation rule. Also reports a few sample leads in their
 * group + a few outside it for demo target choices.
 *
 * Run: tsx --env-file .env.local scripts/setup-test-agent.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

const TEST_USERNAME = 'test-agent-001@27colab.com.dev';
const TARGET_GROUP_NAME = 'LittleHavanaMF';

async function main() {
  const sf = await sfClient('dev');

  // 1. Find the test user
  const users = await sf.soql<{ Id: string; Username: string; Profile: { Name: string } }>(
    `SELECT Id, Username, Profile.Name FROM User WHERE Username = '${TEST_USERNAME}'`
  );
  if (users.length === 0) {
    console.error(`✗ User ${TEST_USERNAME} not found.`);
    process.exit(1);
  }
  const user = users[0];
  console.log(`✓ Found user ${user.Username} (profile: ${user.Profile.Name})`);

  // 2. Find target group
  const groups = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c WHERE Name = '${TARGET_GROUP_NAME}' LIMIT 1`
  );
  if (groups.length === 0) {
    console.error(`✗ Group ${TARGET_GROUP_NAME} not found.`);
    process.exit(1);
  }
  const group = groups[0];
  console.log(`✓ Group ${group.Name} = ${group.Id}`);

  // 3. Assign user to group
  await sf.update('User', user.Id, { Group_ID__c: group.Id });
  console.log(`✓ Set ${user.Username}.Group_ID__c = ${group.Id}`);

  // 4. Show sample test leads — IN group (should be editable) and OUT (should be blocked)
  console.log('\n📋 Sample leads for the demo:\n');

  const inGroup = await sf.soql<{ Id: string; Name: string; Email: string }>(
    `SELECT Id, Name, Email FROM Lead WHERE Group__c = '${group.Id}' ORDER BY LastModifiedDate DESC LIMIT 3`
  );
  console.log(`  ✅ IN-GROUP (test user CAN edit) — ${TARGET_GROUP_NAME}:`);
  for (const l of inGroup) {
    console.log(`     ${l.Id}  ${l.Name}  <${l.Email || 'no email'}>`);
  }

  const outOfGroup = await sf.soql<{
    Id: string;
    Name: string;
    Email: string;
    Group__r: { Name: string };
  }>(
    `SELECT Id, Name, Email, Group__r.Name FROM Lead
     WHERE Group__c != null AND Group__c != '${group.Id}'
     ORDER BY LastModifiedDate DESC LIMIT 3`
  );
  console.log(`\n  ❌ OUT-OF-GROUP (test user should be BLOCKED):`);
  for (const l of outOfGroup) {
    console.log(`     ${l.Id}  ${l.Name}  <${l.Email || 'no email'}>  [${l.Group__r?.Name}]`);
  }

  console.log('\n✅ Test agent ready. Demo: log in as test-agent-001@27colab.com.dev and try to edit each.\n');
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
