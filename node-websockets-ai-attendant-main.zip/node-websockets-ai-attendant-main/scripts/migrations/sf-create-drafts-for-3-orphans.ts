/**
 * Direct draft creation for the 3 SF orphan records.
 *
 * Verified state (May 2026):
 *   - SF records point at WP IDs 23470 / 23091 / 63126
 *   - All three return 404 on standard endpoint
 *   - None present in trash (verified via /wp/v2/properties?status=trash)
 *   - None recoverable
 *   - No matching WP post exists at any of the 3 SF addresses
 *
 * Action: directly create fresh WP drafts and overwrite SF link fields.
 * Same approach as sf-create-drafts-for-3-mislinks.ts.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-create-drafts-for-3-orphans.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-create-drafts-for-3-orphans.ts
 */

import {
  createPropertyDraft,
  type PropertyInput,
} from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 300;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const TARGETS = [
  'a0RJw000008GkGnMAK', // 2459 & 2463 Pierce St (Hollywood)
  'a0RJw000008GnRZMA0', // 10822-10824 NW 7th Ave (Miami)
  'a0RJw000009A8lVMAS', // 1746 W Commercial BLVD (Davie)
];

// Sanity gate: refuse to act unless these records still point at the
// EXPECTED dead IDs we audited. If someone re-linked them between then
// and now, situation has changed and we should re-investigate.
const EXPECTED_DEAD_WP_IDS = new Set([23470, 23091, 63126]);

interface SfProperty {
  Id: string;
  Name: string;
  Marketing_Name__c: string | null;
  Address__c: string | null;
  City__c: string | null;
  State__c: string | null;
  Zip_Code__c: string | null;
  County__c: string | null;
  Property_Type__c: string | null;
  Listing_Type__c: string | null;
  Status__c: string | null;
  Price__c: number | null;
  Building_Size_sqft__c: number | null;
  Lot_Size_sqft__c: number | null;
  Units__c: number | null;
  Year_Built__c: number | null;
  Zoning__c: string | null;
  Description__c: string | null;
  Pricing__c: string | null;
  WP_Post_ID__c: number | null;
  Public_URL__c: string | null;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true };
  return { ok: false, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true };
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false, error: lastError };
  }
  return { ok: false, error: lastError };
}

function sfToPropertyInput(sf: SfProperty): PropertyInput {
  return {
    sfId: sf.Id,
    name: sf.Name || '',
    marketingName: sf.Marketing_Name__c,
    address: sf.Address__c,
    city: sf.City__c,
    state: sf.State__c,
    zipCode: sf.Zip_Code__c,
    county: sf.County__c,
    propertyType: sf.Property_Type__c,
    listingType: sf.Listing_Type__c,
    price: sf.Price__c,
    buildingSqft: sf.Building_Size_sqft__c,
    lotSqft: sf.Lot_Size_sqft__c,
    units: sf.Units__c,
    yearBuilt: sf.Year_Built__c,
    zoning: sf.Zoning__c,
    description: sf.Description__c,
    pricing: sf.Pricing__c,
  };
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID) {
    console.error('❌ Missing SF env vars.');
    process.exit(1);
  }

  console.log(`\n📝 Create drafts for 3 SF orphans ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();
  const records = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c,
            Zip_Code__c, County__c, Property_Type__c, Listing_Type__c,
            Status__c, Price__c, Building_Size_sqft__c, Lot_Size_sqft__c,
            Units__c, Year_Built__c, Zoning__c, Description__c, Pricing__c,
            WP_Post_ID__c, Public_URL__c
       FROM Property__c
      WHERE Id IN ('${TARGETS.join("','")}')`
  );

  console.log(`Found ${records.length} SF records.\n`);

  // Sanity check: refuse if any record no longer points at a known dead ID.
  for (const sf of records) {
    if (sf.WP_Post_ID__c === null) {
      console.error(
        `❌ ${sf.Id} now has WP_Post_ID__c=null. Did someone re-link it? Aborting.`
      );
      process.exit(1);
    }
    if (!EXPECTED_DEAD_WP_IDS.has(sf.WP_Post_ID__c)) {
      console.error(
        `❌ ${sf.Id} now points at wp:${sf.WP_Post_ID__c}, not in expected dead set (23470/23091/63126). Aborting.`
      );
      process.exit(1);
    }
  }
  console.log('✓ All 3 records confirmed pointing at expected dead IDs. Safe to proceed.\n');

  console.log('── Plan ──\n');
  for (const sf of records) {
    console.log(`SF ${sf.Id}`);
    console.log(`   Name:        ${sf.Name}`);
    console.log(`   Address:     ${sf.Address__c}`);
    console.log(`   City:        ${sf.City__c}`);
    console.log(`   Type:        ${sf.Property_Type__c} / ${sf.Listing_Type__c}`);
    console.log(`   Price:       ${sf.Price__c}`);
    console.log(`   Currently:   WP_Post_ID__c=${sf.WP_Post_ID__c} (DEAD)`);
    console.log(`   Action:      Create fresh WP draft, overwrite link fields`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('→ Executing...\n');
  let ok = 0;
  let err = 0;
  for (const sf of records) {
    const input = sfToPropertyInput(sf);
    const result = await createPropertyDraft(input);
    if (!result.ok || !result.wpId) {
      err++;
      console.warn(`   ❌ ${sf.Id}: WP draft creation failed: ${result.error}`);
      continue;
    }
    console.log(`   ✓ ${sf.Id}: created wp:${result.wpId} (${result.permalink})`);

    const writeBack = await sfUpdateWithRetry(token, instance, sf.Id, {
      WP_Post_ID__c: result.wpId,
      Public_URL__c: result.permalink,
    });
    if (!writeBack.ok) {
      err++;
      console.warn(
        `      ⚠️  WP draft created but SF write-back FAILED: ${writeBack.error}\n` +
          `      MANUAL FIXUP NEEDED: set SF.${sf.Id}.WP_Post_ID__c=${result.wpId}, Public_URL__c=${result.permalink}`
      );
      continue;
    }
    ok++;
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Drafts created + linked:  ${ok}`);
  console.log(`Failures:                 ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
