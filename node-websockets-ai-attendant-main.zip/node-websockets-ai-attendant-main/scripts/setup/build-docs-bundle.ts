/**
 * Generates src/docs-bundle.ts from docs/handoff/*.md for the in-app /admin/docs
 * viewer. The handoff markdown (docs/handoff/00-*.md … 07-*.md) is the source of
 * truth; this script bundles it into a TS module so it deploys reliably regardless
 * of whether the (git-tracked) docs/ dir is present in the build.
 *
 * Section 08 (ownership/handover) is INTENTIONALLY EXCLUDED — it's internal/business
 * and must not be served in the client-facing dashboard. Any table-of-contents row
 * that links to it (in section 00) is stripped too.
 *
 * Usage:
 *   npx tsx scripts/setup/build-docs-bundle.ts           # regenerate the bundle
 *   npx tsx scripts/setup/build-docs-bundle.ts --check    # verify it's in sync (CI)
 *
 * Run this after editing any docs/handoff/*.md.
 */
import { readFileSync, readdirSync, writeFileSync } from 'fs';
import path from 'path';

const HANDOFF_DIR = path.join(__dirname, '../../docs/handoff');
const BUNDLE_PATH = path.join(__dirname, '../../src/docs-bundle.ts');

// Sections to bundle for the in-app viewer, with their display titles.
// 08 is deliberately absent — see the file header.
const SECTIONS: { id: string; title: string }[] = [
  { id: '00', title: 'Overview' },
  { id: '01', title: 'Voice Call Pipeline' },
  { id: '02', title: 'Search & Geographic Intelligence' },
  { id: '03', title: 'Salesforce Security & Sync' },
  { id: '04', title: 'SF Automation, Backups & Ops' },
  { id: '05', title: 'WordPress & Marketing' },
  { id: '06', title: 'SMS, Email & Consent' },
  { id: '07', title: 'Admin, Architecture & Env Vars' },
];

const EXCLUDED_LINK = '08-handover-operations.md';

const HEADER =
  `// AUTO-GENERATED from docs/handoff/*.md by scripts/setup/build-docs-bundle.ts.\n` +
  `// Do NOT edit by hand — run \`npx tsx scripts/setup/build-docs-bundle.ts\` to regenerate.\n` +
  `// Section 08 (ownership/handover) is intentionally excluded from the in-app viewer.\n\n` +
  `export interface DocSection { id: string; title: string; md: string; }\n\n` +
  `export const DOCS: DocSection[] = `;

function build(): string {
  const files = readdirSync(HANDOFF_DIR);
  const docs = SECTIONS.map(({ id, title }) => {
    const fname = files.find((f) => f.startsWith(`${id}-`) && f.endsWith('.md'));
    if (!fname) throw new Error(`No handoff markdown found for section ${id} in ${HANDOFF_DIR}`);
    let md = readFileSync(path.join(HANDOFF_DIR, fname), 'utf8');
    // Drop any line that links to the excluded section (e.g. the 08 row in the TOC).
    md = md
      .split('\n')
      .filter((line) => !line.includes(EXCLUDED_LINK))
      .join('\n');
    return { id, title, md };
  });
  return HEADER + JSON.stringify(docs, null, 2) + ';\n';
}

const generated = build();
const check = process.argv.includes('--check');

if (check) {
  const current = readFileSync(BUNDLE_PATH, 'utf8');
  if (current !== generated) {
    console.error(
      '❌ src/docs-bundle.ts is out of sync with docs/handoff/*.md.\n' +
        '   Run: npx tsx scripts/setup/build-docs-bundle.ts'
    );
    process.exit(1);
  }
  console.log('✅ src/docs-bundle.ts is in sync with docs/handoff/*.md.');
} else {
  writeFileSync(BUNDLE_PATH, generated);
  console.log(`✅ Wrote ${SECTIONS.length} sections to src/docs-bundle.ts (section 08 excluded).`);
}
