import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // License info per profile
  const profs: any[] = await sf.soql(
    `SELECT Id, Name, UserLicense.Name, UserLicense.TotalLicenses, UserLicense.UsedLicenses, UserLicense.Status
     FROM Profile WHERE Name IN ('Account for Agents','System Administrator','Etico Agents')`
  );
  console.log('Profile licenses:');
  for (const p of profs) {
    console.log(`  ${p.Name.padEnd(28)} License="${p.UserLicense?.Name}"  used=${p.UserLicense?.UsedLicenses}/${p.UserLicense?.TotalLicenses}  status=${p.UserLicense?.Status}`);
  }
  // All user licenses available in the org
  const all: any[] = await sf.soql(
    `SELECT Id, Name, TotalLicenses, UsedLicenses, Status FROM UserLicense ORDER BY Name`
  );
  console.log(`\nAll user licenses (${all.length}):`);
  for (const u of all) console.log(`  ${u.Name.padEnd(35)} ${u.UsedLicenses}/${u.TotalLicenses}  ${u.Status}`);
}
main().catch(e=>{console.error(e);process.exit(1);});
