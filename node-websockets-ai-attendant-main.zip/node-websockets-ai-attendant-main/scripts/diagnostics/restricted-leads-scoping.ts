/**
 * Restricted-leads scoping — grounds the Restricted_Lead__c design in the real org.
 *
 * Answers: what edition are we (sharing-rule capability), do the 11 restricted
 * "list" names already exist as Group__c records, what native Queues/Public
 * Groups exist today, and who are the agents + admins that need access.
 *
 * Read-only. Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/restricted-leads-scoping.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

const LIST_NAMES = [
  'ALFs broward Palm', 'DaniaMulti', 'SouthBrowardApts', 'hollywoodapt33023_4',
  'southbrowardapt33020', 'Hallandale MF', 'NorthMiaApts', 'PompanoMultiFam',
  'browardmulti', 'w fort laderdale mf', 'FTLApts',
];

const AGENT_NAMES = ['Elior Levi', 'Adir Bezalely', 'Mitchell Lieberman', 'Ryan Carney', 'Arun Mohan'];

async function main() {
  const sf = (await sfClient('prod')) as any;

  // 1. Edition (sharing-rule capability hinges on this).
  const [org] = await sf.soql(
    `SELECT OrganizationType, InstanceName, IsSandbox, Name FROM Organization LIMIT 1`
  );
  console.log(`\n🏢 Org: ${org.Name} — ${org.OrganizationType} (${org.InstanceName}, sandbox=${org.IsSandbox})`);

  // 2. Do the 11 list names already exist as Group__c records?
  const inList = LIST_NAMES.map((n) => `'${n.replace(/'/g, "\\'")}'`).join(', ');
  const groups = await sf.soql(
    `SELECT Id, Name FROM Group__c WHERE Name IN (${inList})`
  );
  const foundNames = new Set(groups.map((g: any) => g.Name));
  console.log(`\n📋 Restricted "lists" as existing Group__c records: ${groups.length}/${LIST_NAMES.length}`);
  for (const n of LIST_NAMES) {
    const hit = groups.find((g: any) => g.Name === n);
    console.log(`   ${hit ? '✓' : '✗'} ${n.padEnd(24)} ${hit ? hit.Id : '(no Group__c by this exact name)'}`);
  }

  // 3. Native Queues + Public Groups already in the org.
  const nativeGroups = await sf.soql(
    `SELECT Id, Name, DeveloperName, Type FROM Group WHERE Type IN ('Regular','Queue') ORDER BY Type, Name`
  );
  const queues = nativeGroups.filter((g: any) => g.Type === 'Queue');
  const pubGroups = nativeGroups.filter((g: any) => g.Type === 'Regular');
  console.log(`\n👥 Native Public Groups: ${pubGroups.length}`);
  for (const g of pubGroups) console.log(`   - ${g.Name} (${g.DeveloperName})`);
  console.log(`\n📨 Native Queues: ${queues.length}`);
  for (const g of queues) console.log(`   - ${g.Name} (${g.DeveloperName})`);

  // 4. Identify the agents + the admins ("Fausto, Temperan, and Me").
  const nameFilter = AGENT_NAMES.map((n) => `'${n}'`).join(', ');
  const users = await sf.soql(
    `SELECT Id, Name, Username, IsActive, Profile.Name FROM User
     WHERE Name IN (${nameFilter})
        OR Name LIKE '%Temperan%' OR Name LIKE '%Fausto%' OR Name LIKE 'Carlos%'
     ORDER BY Name`
  );
  console.log(`\n🧑 Users (assigned agents + candidate admins):`);
  for (const u of users) {
    console.log(`   ${u.IsActive ? ' ' : '✗'} ${u.Name.padEnd(24)} ${(u.Profile?.Name || '').padEnd(22)} ${u.Username}`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
