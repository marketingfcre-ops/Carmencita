/**
 * Grant Armando Sanchez-Bueno → Medley + Doral access.
 * Hyphenated last name; earlier scripts missed him by searching "Sanchez Bueno".
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const GRANTS = [
  { user: 'Armando Sanchez-Bueno', group: 'Medley' },
  { user: 'Armando Sanchez-Bueno', group: 'Doral' },
];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  for (const g of GRANTS) {
    console.log(`\n=== ${g.user} → "${g.group}" ===`);
    const u: any[] = await sf.soql(
      `SELECT Id FROM User WHERE Name = '${g.user}' AND IsActive = true LIMIT 5`
    );
    if (u.length !== 1) { console.log(`  ✗ User: ${u.length} matches`); continue; }
    const grp: any[] = await sf.soql(
      `SELECT Id FROM Group__c WHERE Name = '${g.group}' LIMIT 5`
    );
    if (grp.length !== 1) { console.log(`  ✗ Group: ${grp.length} matches`); continue; }
    const existing: any[] = await sf.soql(
      `SELECT Status__c FROM User_Group_Access__c WHERE User__c = '${u[0].Id}' AND Group__c = '${grp[0].Id}'`
    );
    if (existing.find((r) => r.Status__c === 'Approved')) { console.log(`  ✓ Already Approved`); continue; }
    if (DRY) { console.log(`  Plan: CREATE User_Group_Access (Approved)`); continue; }
    const id = await sf.create('User_Group_Access__c', {
      User__c: u[0].Id, Group__c: grp[0].Id, Status__c: 'Approved',
    });
    console.log(`  ✓ Created ${id}`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
