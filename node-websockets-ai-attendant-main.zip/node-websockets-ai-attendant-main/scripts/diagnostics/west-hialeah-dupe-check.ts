/**
 * West Hialeah Industrial list — duplicate check against Salesforce Leads.
 *
 * The CSV from the team contains parcels Halain wants to upload as Leads
 * (a Lead = a prospecting target = a property + its owner LLC). This script
 * checks each row against existing Leads in SF to flag duplicates.
 *
 * Data model discovered (see probe-hialeah-leads-v2.ts):
 *   - Lead.Company                       = property address(es), often comma-separated
 *   - Lead.Name                          = owner person (signer)
 *   - Lead.Owning_Entity_LLC_Name__c     = LLC name
 *   - Lead.Mailing_Address__c            = LLC mailing address
 *   - Lead.City                          = property city
 *
 * Format quirks:
 *   - Lead.Company stores "3811 W 108 ST" while CSV has "3811 W 108TH ST"
 *     (ordinal suffix stripped). Sometimes the suffix is kept ("4340 W 104TH ST").
 *   - Lead.Company can hold multiple addresses: "4281 W 108 ST, 4341 W 108 ST"
 *   - Unit suffixes appear inconsistently: "#180", "UNIT: 10", "STE 150"
 *
 * Match priorities (highest wins):
 *   1. Address (normalized) matches a sub-address in Lead.Company
 *      AND owner LLC name aligns                            → DUPLICATE
 *   2. Address matches a sub-address in Lead.Company         → DUPLICATE
 *   3. Owner LLC name matches Lead.Owning_Entity_LLC_Name__c → AMBIGUOUS
 *      (same LLC owns many properties — could be different parcel)
 *
 * Read-only. Output: annotated CSV.
 */

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const INPUT_CSV = resolve(
  process.env.HOME || '',
  'Downloads/West Hialeah Industrial - Sheet1.csv'
);
const OUTPUT_CSV = resolve(
  __dirname,
  '../../data/west-hialeah-dupe-check.csv'
);

// ---------------------------------------------------------------------------
// SF helpers
// ---------------------------------------------------------------------------

async function sfAuth(): Promise<{ token: string; instance: string }> {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  if (!res.ok) throw new Error(`SF auth failed: ${res.status} ${await res.text()}`);
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function soql<T = any>(query: string, token: string, instance: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(query)}`;
  const out: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    const j = (await res.json()) as any;
    if (j.records) out.push(...j.records);
    url = j.nextRecordsUrl ? `${instance}${j.nextRecordsUrl}` : null;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Address normalization
// ---------------------------------------------------------------------------

const STREET_TYPES: Record<string, string> = {
  STREET: 'ST', ST: 'ST',
  AVENUE: 'AVE', AVE: 'AVE', AV: 'AVE',
  ROAD: 'RD', RD: 'RD',
  BOULEVARD: 'BLVD', BLVD: 'BLVD', BL: 'BLVD',
  COURT: 'CT', CT: 'CT',
  CIRCLE: 'CIR', CIR: 'CIR',
  DRIVE: 'DR', DR: 'DR',
  LANE: 'LN', LN: 'LN',
  PLACE: 'PL', PL: 'PL',
  TERRACE: 'TER', TER: 'TER', TERR: 'TER',
  PARKWAY: 'PKWY', PKWY: 'PKWY',
  HIGHWAY: 'HWY', HWY: 'HWY',
  TRAIL: 'TRL', TRL: 'TRL',
  WAY: 'WAY',
};

const DIRECTIONS: Record<string, string> = {
  NORTH: 'N', N: 'N',
  SOUTH: 'S', S: 'S',
  EAST: 'E', E: 'E',
  WEST: 'W', W: 'W',
  NORTHEAST: 'NE', NE: 'NE',
  NORTHWEST: 'NW', NW: 'NW',
  SOUTHEAST: 'SE', SE: 'SE',
  SOUTHWEST: 'SW', SW: 'SW',
};

/**
 * Normalize an address for matching. Strips unit/suite, drops ordinal
 * suffixes from numeric street names ("108TH" → "108"), and standardizes
 * directionals and street types.
 *
 * Returns "" for empty/unparseable input.
 */
function normalizeAddress(raw: string | null | undefined): string {
  if (!raw) return '';
  let s = String(raw).toUpperCase().trim();

  // strip newlines and collapse whitespace early
  s = s.replace(/\s+/g, ' ').trim();

  // strip unit-style suffixes anywhere
  s = s.replace(/\s+UNIT\s*:?\s*[\w-]+/g, '');
  s = s.replace(/\s+STE\s+[\w-]+/g, '');
  s = s.replace(/\s+SUITE\s+[\w-]+/g, '');
  s = s.replace(/\s+APT\s+[\w-]+/g, '');
  s = s.replace(/\s+BLDG\s+[\w-]+/g, '');
  s = s.replace(/\s+#\s*[\w-]+/g, '');
  s = s.replace(/\s+#[\w-]+/g, '');
  s = s.replace(/[.,]/g, ' ');
  s = s.replace(/\s+/g, ' ').trim();

  // drop ordinal suffix on numeric streets ("108TH" → "108", "21ST" → "21")
  s = s.replace(/(\d+)(ST|ND|RD|TH)\b/g, '$1');

  const tokens = s.split(' ').map((t) => {
    if (DIRECTIONS[t]) return DIRECTIONS[t];
    if (STREET_TYPES[t]) return STREET_TYPES[t];
    return t;
  });
  return tokens.join(' ').trim();
}

/**
 * Lead.Company can hold multiple addresses (comma-separated). Split and
 * normalize each.
 */
function splitCompanyAddresses(company: string | null | undefined): string[] {
  if (!company) return [];
  return company.split(/[,;]/).map((a) => normalizeAddress(a)).filter(Boolean);
}

/**
 * Normalize LLC names. Strip suffixes like LLC/INC/CORP and punctuation
 * so "BSREP HIALEAH GARDENS LLC" matches "BSREP III HIALEAH GARDENS LLC".
 *
 * We keep this conservative — only used as a tiebreaker / ambiguity signal.
 */
function normalizeLLC(raw: string | null | undefined): string {
  if (!raw) return '';
  return String(raw)
    .toUpperCase()
    .replace(/[.,&]/g, ' ')
    .replace(/\b(LLC|INC|CORP|CORPORATION|LTD|LP|LLP|CO)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------

function parseCsv(text: string): string[][] {
  const lines = text.split(/\r?\n/);
  return lines.map((line) => {
    const out: string[] = [];
    let cur = '';
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (q && line[i + 1] === '"') { cur += '"'; i++; }
        else q = !q;
      } else if (c === ',' && !q) {
        out.push(cur);
        cur = '';
      } else {
        cur += c;
      }
    }
    out.push(cur);
    return out;
  });
}

function csvEscape(v: string): string {
  if (v == null) return '';
  const s = String(v);
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

interface SfLead {
  id: string;
  status: string | null;
  name: string | null;
  company: string | null;
  llc: string | null;
  mailingAddr: string | null;
  street: string | null;
  city: string | null;
  // derived
  propertyAddrs: string[]; // normalized addresses extracted from Company (or Street if inverted)
  llcNorm: string;
}

/**
 * Pull the property addresses out of a Lead. Two schema conventions exist:
 *   1. Standard:  Company holds the address (often comma-separated).
 *                 Owning_Entity_LLC_Name__c holds the LLC.
 *   2. Inverted:  Company holds the LLC name; Street holds the property
 *                 address. Detected when Company doesn't start with a digit.
 */
function extractPropertyAddrs(company: string | null, street: string | null): string[] {
  if (company && /^\s*\d/.test(company)) {
    return splitCompanyAddresses(company);
  }
  // Company doesn't look like an address — try Street. Street can be
  // multi-line ("4280 W 104 ST\nHIALEAH, FL"). Take the first line.
  if (street) {
    const firstLine = street.split(/[\r\n]+/)[0];
    if (/^\s*\d/.test(firstLine)) {
      return splitCompanyAddresses(firstLine);
    }
  }
  return [];
}

function extractLlc(company: string | null, llcField: string | null): string {
  // Prefer the explicit LLC field. Fall back to Company when it's NOT a
  // street address (inverted schema).
  if (llcField) return normalizeLLC(llcField);
  if (company && !/^\s*\d/.test(company)) return normalizeLLC(company);
  return '';
}

async function main() {
  console.log('🔐 Authenticating to Salesforce…');
  const { token, instance } = await sfAuth();

  // 81% of leads have City=null, so we can't filter by city. Pull all leads
  // (~100k) and match in memory. Also includes Lead.Street because some
  // leads use an inverted schema (LLC in Company, address in Street).
  const query = `
    SELECT Id, Status, Name, Company, Owning_Entity_LLC_Name__c,
           Mailing_Address__c, Street, City
    FROM Lead
  `.trim();

  console.log('📥 Fetching ALL Leads (~100k, paginated)…');
  const t0 = Date.now();
  const records = await soql<any>(query, token, instance);
  console.log(`   Got ${records.length} leads in ${((Date.now() - t0) / 1000).toFixed(1)}s`);

  const leads: SfLead[] = records.map((r) => {
    const company = r.Company || null;
    const llcField = r.Owning_Entity_LLC_Name__c || null;
    const street = r.Street || null;
    return {
      id: r.Id,
      status: r.Status || null,
      name: r.Name || null,
      company,
      llc: llcField,
      mailingAddr: r.Mailing_Address__c || null,
      street,
      city: r.City || null,
      propertyAddrs: extractPropertyAddrs(company, street),
      llcNorm: extractLlc(company, llcField),
    };
  });

  // Build indexes
  // 1. Address index: normalized sub-address → leads
  const byAddr = new Map<string, SfLead[]>();
  for (const l of leads) {
    for (const a of l.propertyAddrs) {
      if (!byAddr.has(a)) byAddr.set(a, []);
      byAddr.get(a)!.push(l);
    }
  }

  // 1b. Parcel ID index: some leads pack the Miami-Dade folio into Company
  //     ("04-2020-001-0100, 4030 W 88 ST"). Match these too.
  const folioRe = /\b\d{2}-\d{4}-\d{3}-\d{4}\b/g;
  const byFolio = new Map<string, SfLead[]>();
  for (const l of leads) {
    if (!l.company) continue;
    const found = l.company.match(folioRe);
    if (!found) continue;
    for (const f of found) {
      const k = f.replace(/-/g, '');
      if (!byFolio.has(k)) byFolio.set(k, []);
      byFolio.get(k)!.push(l);
    }
  }

  // 2. LLC index: normalized LLC name → leads
  const byLlc = new Map<string, SfLead[]>();
  for (const l of leads) {
    if (l.llcNorm) {
      if (!byLlc.has(l.llcNorm)) byLlc.set(l.llcNorm, []);
      byLlc.get(l.llcNorm)!.push(l);
    }
  }

  console.log(`   ${byAddr.size} unique normalized addresses across leads`);
  console.log(`   ${byLlc.size} unique normalized LLC names`);

  // Read CSV
  console.log(`📄 Reading ${INPUT_CSV}`);
  const csvText = readFileSync(INPUT_CSV, 'utf8');
  const rows = parseCsv(csvText).filter((r) => r.some((c) => c.trim() !== ''));
  const header = rows[0];
  const dataRows = rows.slice(1);
  console.log(`   ${dataRows.length} CSV rows to check`);

  // Match each row
  const outRows: string[][] = [];
  outRows.push([
    ...header,
    'sf_status',
    'sf_match_id',
    'sf_match_lead_status',
    'sf_match_company',
    'sf_match_llc',
    'sf_match_basis',
  ]);

  const counts = { NEW: 0, DUPLICATE: 0, AMBIGUOUS: 0 };

  for (const row of dataRows) {
    const csvParcel = (row[0] || '').trim();
    const csvAddr = (row[1] || '').trim();
    const csvOwner = (row[3] || '').trim();

    const folioKey = csvParcel.replace(/-/g, '');
    const addrN = normalizeAddress(csvAddr);
    const ownerN = normalizeLLC(csvOwner);

    const folioMatches = folioKey ? (byFolio.get(folioKey) || []) : [];
    const addrMatches = addrN ? (byAddr.get(addrN) || []) : [];
    const llcMatches = ownerN ? (byLlc.get(ownerN) || []) : [];

    // Find addrMatches whose LLC also lines up
    const strongMatches = addrMatches.filter(
      (l) => ownerN && l.llcNorm && l.llcNorm === ownerN
    );

    let status: 'NEW' | 'DUPLICATE' | 'AMBIGUOUS';
    let basis = '';
    let matched: SfLead | undefined;

    if (folioMatches.length > 0) {
      status = 'DUPLICATE';
      basis = 'folio';
      matched = folioMatches[0];
    } else if (strongMatches.length > 0) {
      status = 'DUPLICATE';
      basis = 'address+llc';
      matched = strongMatches[0];
    } else if (addrMatches.length === 1) {
      status = 'DUPLICATE';
      basis = 'address-only';
      matched = addrMatches[0];
    } else if (addrMatches.length > 1) {
      status = 'AMBIGUOUS';
      basis = `address (${addrMatches.length} leads share this address)`;
      matched = addrMatches[0];
    } else if (llcMatches.length > 0) {
      status = 'AMBIGUOUS';
      basis = `llc-only (${llcMatches.length} other lead${llcMatches.length === 1 ? '' : 's'} same LLC — different property?)`;
      matched = llcMatches[0];
    } else {
      status = 'NEW';
    }

    counts[status]++;

    outRows.push([
      ...row,
      status,
      matched?.id || '',
      matched?.status || '',
      matched?.company || '',
      matched?.llc || '',
      basis,
    ]);
  }

  // Write output
  const outText = outRows.map((r) => r.map(csvEscape).join(',')).join('\n');
  writeFileSync(OUTPUT_CSV, outText);

  console.log('');
  console.log('───────────────────────────────────────');
  console.log(`Total CSV rows:    ${dataRows.length}`);
  console.log(`  NEW:             ${counts.NEW}   (safe to upload)`);
  console.log(`  DUPLICATE:       ${counts.DUPLICATE}   (already in SF)`);
  console.log(`  AMBIGUOUS:       ${counts.AMBIGUOUS}   (review by hand)`);
  console.log('───────────────────────────────────────');
  console.log(`Output: ${OUTPUT_CSV}`);

  process.exit(0);
}

main().catch((e) => {
  console.error('💀 Crashed:', e);
  process.exit(1);
});
