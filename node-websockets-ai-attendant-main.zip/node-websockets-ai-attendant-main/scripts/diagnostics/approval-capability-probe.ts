/**
 * Probe what automation/approval machinery this PE org actually supports, to
 * decide whether a new-lead-list-assignment approval workflow can live IN
 * Salesforce or has to be email/form based. Read-only.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/approval-capability-probe.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

async function probe(sf: any, label: string, soql: string, tooling = true) {
  try {
    const rows: any[] = tooling ? await sf.toolingQuery(soql) : await sf.soql(soql);
    return { label, ok: true, count: rows.length, rows };
  } catch (e: any) {
    const msg = String(e.message || e);
    const ns = /not supported|INVALID_TYPE/i.test(msg);
    return { label, ok: false, notSupported: ns, msg: msg.slice(0, 80) };
  }
}

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  console.log('=== Automation / approval features ===');
  const checks = [
    ['Approval Processes (ProcessDefinition)', `SELECT Id, DeveloperName, Type FROM ProcessDefinition`],
    ['Workflow Rules', `SELECT Id, Name FROM WorkflowRule`],
    ['Email Alerts (workflow)', `SELECT Id, DeveloperName FROM WorkflowAlert`],
    ['Flows (all)', `SELECT Id, DeveloperName, ProcessType FROM FlowDefinitionView`],
  ] as const;
  for (const [label, q] of checks) {
    const r = await probe(sf, label, q);
    if (r.ok) console.log(`  ✅ ${label.padEnd(38)} ${r.count} present`);
    else console.log(`  ${r.notSupported ? '❌ NOT AVAILABLE' : '⚠️  ' + r.msg}  ${label}`);
  }

  // Screen flows specifically (intake form for agents)?
  const flows = await probe(sf, 'flows', `SELECT DeveloperName, ProcessType FROM FlowDefinitionView WHERE IsActive = true`);
  if (flows.ok) {
    const byType: Record<string, number> = {};
    for (const f of flows.rows!) byType[f.ProcessType] = (byType[f.ProcessType] || 0) + 1;
    console.log(`\n  Active flow types: ${Object.entries(byType).map(([k, v]) => `${k}=${v}`).join(', ') || '(none)'}`);
  }

  console.log('\n=== Custom object headroom (for a request object) ===');
  const cust = await probe(sf, 'custom objects', `SELECT QualifiedApiName, Label FROM EntityDefinition WHERE QualifiedApiName LIKE '%__c' ORDER BY QualifiedApiName`);
  if (cust.ok) {
    console.log(`  ${cust.count} custom objects exist. A new Group_Access_Request__c would be one more.`);
    console.log(`  Existing (relevant):`);
    for (const e of cust.rows!.filter((x: any) => /group|access|assignment|request|lead_list/i.test(x.QualifiedApiName))) {
      console.log(`    ${e.QualifiedApiName}  "${e.Label}"`);
    }
  }

  console.log('\n=== Can agents even reach Salesforce? (profile of the agent users) ===');
  const prof: any[] = await sf.soql(
    `SELECT Profile.Name, COUNT(Id) c FROM User WHERE IsActive = true GROUP BY Profile.Name ORDER BY COUNT(Id) DESC`
  ).catch(() => []);
  for (const p of prof) console.log(`  ${String(p.c).padStart(3)}  ${p['Profile'] ? p.Profile.Name : p.Name || '(profile)'}`);

  // does the agent profile have API enabled / can create custom object records?
  const agentProf: any[] = await sf.soql(
    `SELECT Name, UserType, PermissionsApiEnabled FROM Profile WHERE Name = 'Account for Agents'`
  ).catch((e: any) => { console.log('  (profile detail query failed: ' + e.message.slice(0, 60) + ')'); return []; });
  for (const p of agentProf) console.log(`  Agent profile "${p.Name}"  userType=${p.UserType}  apiEnabled=${p.PermissionsApiEnabled}`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
