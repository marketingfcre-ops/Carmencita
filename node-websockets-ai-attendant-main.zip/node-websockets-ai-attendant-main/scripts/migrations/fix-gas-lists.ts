/**
 * Fix the 3 gas lists that were added "the old way" — names typed into the
 * legacy Group_old2__c text on ~1,040 leads, with no real Group__c link (so the
 * leads are ungrouped/uneditable and the lists don't exist as records).
 *
 * Properly:
 *   1. Ensure 3 list records exist (reuse BrevardGas; create DuvalGas, PolkGas).
 *   2. Link the matching ungrouped leads: set Lead.Group__c + Approved junction.
 *   3. Assign Bobby Berrido + Armando Sanchez-Bueno to all 3 lists.
 *
 * Dry-run by default.
 *   npx tsx --env-file .env.local scripts/migrations/fix-gas-lists.ts
 *   npx tsx --env-file .env.local scripts/migrations/fix-gas-lists.ts --commit
 */
import { sfClient } from '../../src/integrations/sf-client';

const API = '59.0';
const COMMIT = process.argv.includes('--commit');
const norm = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

// normalized old-text -> canonical list name
const MAP: Record<string, string> = { duvalgas: 'DuvalGas', polkgas: 'PolkGas', brevardgas: 'BrevardGas' };
const AGENTS = ['Bobby Berrido', 'Armando Sanchez-Bueno'];

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`\nFix gas lists — ${COMMIT ? '🔥 COMMIT' : '🧪 DRY-RUN'}\n`);

  const post = async (obj: string, records: any[]) => {
    const out: any[] = [];
    for (let i = 0; i < records.length; i += 200) {
      const res = await fetch(`${sf.instanceUrl}/services/data/v${API}/composite/sobjects`, {
        method: 'POST', headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ allOrNone: false, records: records.slice(i, i + 200).map((r) => ({ attributes: { type: obj }, ...r })) }) });
      out.push(...(await res.json()));
    }
    return out;
  };
  const patch = async (records: any[]) => {
    for (let i = 0; i < records.length; i += 200) {
      const res = await fetch(`${sf.instanceUrl}/services/data/v${API}/composite/sobjects`, {
        method: 'PATCH', headers: { Authorization: `Bearer ${sf.accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ allOrNone: false, records: records.slice(i, i + 200) }) });
      const j = await res.json(); const f = j.filter((r: any) => !r.success).length;
      console.log(`   patched ${Math.min(i + 200, records.length)}/${records.length}${f ? ` (${f} failed)` : ''}`);
    }
  };

  // 1. resolve/create the 3 list records
  const existing = await sf.soql(`SELECT Id, Name FROM Group__c WHERE Name IN ('BrevardGas','DuvalGas','PolkGas')`);
  const idByName = new Map<string, string>(existing.map((g: any) => [g.Name, g.Id]));
  const needCreate = ['BrevardGas', 'DuvalGas', 'PolkGas'].filter((n) => !idByName.has(n));
  console.log(`Lists: reuse [${[...idByName.keys()].join(', ') || 'none'}] | create [${needCreate.join(', ') || 'none'}]`);
  if (COMMIT && needCreate.length) {
    const created = await post('Group__c', needCreate.map((Name) => ({ Name })));
    needCreate.forEach((n, i) => { if (created[i]?.success) idByName.set(n, created[i].id); });
    console.log(`  created: ${needCreate.map((n) => `${n}=${idByName.get(n)}`).join(', ')}`);
  }

  // 2. ungrouped leads carrying these gas names in the old text field
  const leads = await sf.soql(`SELECT Id, Group_old2__c FROM Lead WHERE Group__c = null AND IsConverted=false AND (Group_old2__c LIKE '%uval%Gas%' OR Group_old2__c LIKE '%olk%Gas%' OR Group_old2__c LIKE '%revard%Gas%')`);
  const byList = new Map<string, string[]>();
  for (const l of leads) {
    const target = MAP[norm(l.Group_old2__c)]; if (!target) continue;
    if (!byList.has(target)) byList.set(target, []);
    byList.get(target)!.push(l.Id);
  }
  console.log(`\nLeads to link:`);
  for (const [name, ids] of byList) console.log(`  ${name}: ${ids.length}`);

  // 3. agents
  const agentIds: Record<string, string> = {};
  for (const a of AGENTS) agentIds[a] = (await sf.soql(`SELECT Id FROM User WHERE Name='${a.replace(/'/g, "\\'")}' AND IsActive=true`))[0]?.Id;
  console.log(`\nAssign ${AGENTS.join(' + ')} to all 3 lists (6 access rows).`);

  if (!COMMIT) { console.log(`\n🧪 Dry-run only. Re-run with --commit.`); return; }

  // apply lead links
  for (const [name, ids] of byList) {
    const gid = idByName.get(name); if (!gid) { console.log(`  skip ${name} (no group id)`); continue; }
    console.log(`\nLinking ${ids.length} leads -> ${name}`);
    await patch(ids.map((Id) => ({ attributes: { type: 'Lead' }, Id, Group__c: gid })));
    const jx = await post('Lead_List_Assignment__c', ids.map((Lead__c) => ({ Lead__c, Group__c: gid, Status__c: 'Approved' })));
    console.log(`   junctions: ${jx.filter((r: any) => r.success).length}/${ids.length} created`);
  }

  // apply agent access (idempotent)
  const accessRecs: any[] = [];
  for (const name of ['BrevardGas', 'DuvalGas', 'PolkGas']) {
    const gid = idByName.get(name); if (!gid) continue;
    for (const a of AGENTS) {
      const uId = agentIds[a]; if (!uId) continue;
      const ex = await sf.soql(`SELECT Id FROM User_Group_Access__c WHERE User__c='${uId}' AND Group__c='${gid}'`);
      if (!ex.length) accessRecs.push({ User__c: uId, Group__c: gid, Status__c: 'Approved' });
    }
  }
  const ar = await post('User_Group_Access__c', accessRecs);
  console.log(`\nAgent access rows created: ${ar.filter((r: any) => r.success).length}/${accessRecs.length}`);
  console.log(`\n✅ Done.`);
}
main().catch((e) => { console.error('💀', e); process.exit(1); });
