/**
 * Null SF.WP_Post_ID__c on 3 records whose WP post was deleted and the SF
 * record is in a closed state (Closed Lost / Closed Won). No public listing
 * is needed for closed deals — keeps the SF data tidy and prevents
 * "WP post not found" 404s from triggering retries on any future SF change.
 *
 * Adds an audit note for traceability, same pattern as the closing-marker.
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface Op {
  sfId: string;
  address: string;
  sfStatus: string;
  deletedWp: number;
}

const OPS: Op[] = [
  { sfId: 'a0RJw000008GljBMAS', address: '1025 E 45th St', sfStatus: 'Closed Lost', deletedWp: 29677 },
  { sfId: 'a0RJw000008GnQ1MAK', address: '140 NW 8th Ave', sfStatus: 'Closed Lost', deletedWp: 22447 },
  { sfId: 'a0RJw000009A8lVMAS', address: '1746 W Commercial BLVD', sfStatus: 'Closed Won', deletedWp: 63424 },
];

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { records?: T[] };
  return data.records || [];
}

async function sfUpdate(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true } as const;
  return { ok: false as const, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(token: string, instance: string, id: string, fields: Record<string, unknown>) {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true } as const;
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false as const, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false as const, error: lastError };
  }
  return { ok: false as const, error: lastError };
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID) {
    console.error('❌ Missing SF env vars.');
    process.exit(1);
  }

  console.log(`\n🧹 Null 3 broken-link closed-deal SF records ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();
  const sfNow = await sfQuery<{
    Id: string;
    Status__c: string | null;
    WP_Post_ID__c: number | null;
    Notes_for_Marketing__c: string | null;
  }>(
    token,
    instance,
    `SELECT Id, Status__c, WP_Post_ID__c, Notes_for_Marketing__c
       FROM Property__c WHERE Id IN ('${OPS.map((o) => o.sfId).join("','")}')`
  );
  const sfById = new Map(sfNow.map((r) => [r.Id, r]));

  console.log('── Plan ──\n');
  let needSkip = 0;
  for (const op of OPS) {
    const cur = sfById.get(op.sfId);
    const note = cur && cur.WP_Post_ID__c !== op.deletedWp
      ? ` [SKIP — current WP_Post_ID__c=${cur.WP_Post_ID__c}, not the expected ${op.deletedWp}]`
      : '';
    if (note) needSkip++;
    console.log(`SF ${op.sfId}  ${op.sfStatus}${note}`);
    console.log(`   Address:  ${op.address}`);
    console.log(`   Action:   WP_Post_ID__c=${op.deletedWp} (deleted) → null, Public_URL__c → null`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  const today = new Date().toISOString().slice(0, 10);
  console.log('── Executing ──\n');
  let ok = 0;
  let skipped = 0;
  let err = 0;
  for (const op of OPS) {
    const cur = sfById.get(op.sfId);
    if (!cur || cur.WP_Post_ID__c !== op.deletedWp) {
      console.log(`   ⏭️  ${op.sfId} skipped (state drift)`);
      skipped++;
      continue;
    }
    const auditNote = `[Link Cleanup ${today}] WP post wp:${op.deletedWp} deleted externally — SF link nulled (record is ${op.sfStatus}, no public listing needed)`;
    const existing = (cur.Notes_for_Marketing__c || '').trim();
    const combined = existing ? `${existing}\n${auditNote}` : auditNote;

    const result = await sfUpdateWithRetry(token, instance, op.sfId, {
      WP_Post_ID__c: null,
      Public_URL__c: null,
      Notes_for_Marketing__c: combined.slice(0, 30000),
    });
    if (result.ok) {
      console.log(`   ✓ ${op.sfId} → WP link nulled + audit note`);
      ok++;
    } else {
      console.warn(`   ❌ ${op.sfId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Nulled:       ${ok}`);
  console.log(`Skipped:      ${skipped}`);
  console.log(`Failures:     ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
