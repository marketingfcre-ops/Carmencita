/**
 * Twilio SMS integration.
 *
 * Sends SMS via Twilio REST API (no SDK needed — we already have credentials).
 * Fire-and-forget: never blocks the phone call.
 *
 * A2P/10DLC compliance: marketing sends are gated on an opt-in record in
 * sms-consent. Use requestPropertyConfirmation() for the first contact; that
 * sends the "Reply YES to confirm" message and only fires the actual property
 * SMS when the YES arrives (handled by the inbound webhook).
 *
 * Env vars needed:
 *   TWILIO_ACCOUNT_SID  — Twilio Account SID (already set for voice)
 *   TWILIO_AUTH_TOKEN   — Twilio Auth Token (already set for voice)
 *   TWILIO_PHONE_NUMBER — Twilio phone number to send SMS from (e.g. +13051234567)
 */

import {
  isConfirmed,
  isOptedOut,
  addPendingProperty,
  getPendingProperties,
  clearPending,
  addFlyerPending,
  getFlyerPending,
  clearFlyerPending,
  markFlyerPrompted,
  wasRecentlyFlyerPrompted,
} from './sms-consent';

const TWILIO_ACCOUNT_SID =
  process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_SID || '';
const TWILIO_AUTH_TOKEN =
  process.env.TWILIO_AUTH_TOKEN || process.env.TWILIO_TOKEN || '';
const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER || '';
// Optional but recommended for A2P 10DLC: when set, send via Messaging Service
// instead of raw From number. A2P approval lives on the service, so sending
// via the service is the more reliable route once the number is attached.
const TWILIO_MESSAGING_SERVICE_SID =
  process.env.TWILIO_MESSAGING_SERVICE_SID || '';

const STOP_FOOTER = 'Reply STOP to opt out.';
const BRAND = 'Fausto Commercial';
// Email delivery is gated behind Resend (not live yet). Default off; set
// EMAIL_ENABLED=true to start offering email-by-reply once it's wired up.
const EMAIL_ENABLED = process.env.EMAIL_ENABLED === 'true';

// ---------------------------------------------------------------------------
// Low-level send — no compliance gating. Use only for transactional replies
// (confirmation, HELP, STOP-confirmation) that A2P treats separately.
// ---------------------------------------------------------------------------

export async function sendSms(to: string, body: string): Promise<boolean> {
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) {
    console.warn('⚠️ Twilio credentials not set — SMS not sent');
    return false;
  }
  if (!TWILIO_PHONE_NUMBER && !TWILIO_MESSAGING_SERVICE_SID) {
    console.warn('⚠️ Neither TWILIO_PHONE_NUMBER nor TWILIO_MESSAGING_SERVICE_SID set — SMS not sent');
    return false;
  }

  try {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;

    // Prefer MessagingServiceSid when available — A2P 10DLC routing is tied to
    // the service. Fall back to raw From number for environments without one.
    const paramsObj: Record<string, string> = { To: to, Body: body };
    if (TWILIO_MESSAGING_SERVICE_SID) {
      paramsObj.MessagingServiceSid = TWILIO_MESSAGING_SERVICE_SID;
    } else {
      paramsObj.From = TWILIO_PHONE_NUMBER;
    }
    const params = new URLSearchParams(paramsObj);

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization:
          'Basic ' +
          Buffer.from(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`).toString(
            'base64'
          ),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error(`❌ SMS send failed (${res.status}): ${err}`);
      return false;
    }

    const data = (await res.json()) as { sid?: string };
    console.log(`✅ SMS sent to ${to}: ${data.sid}`);
    return true;
  } catch (err) {
    console.error('❌ SMS send error:', err);
    return false;
  }
}

// ---------------------------------------------------------------------------
// Property text — gated on confirmed consent. For first-contact callers,
// requestPropertyConfirmation() handles the double-opt-in dance and queues
// the actual property send until the YES reply arrives.
// ---------------------------------------------------------------------------

function buildPropertyBody(
  propertyName: string,
  propertyAddress: string,
  publicUrl: string | null
): string {
  const lines = [`${BRAND}`, ``, `${propertyName}`, `${propertyAddress}`];
  if (publicUrl) lines.push(``, `View details: ${publicUrl}`);
  if (EMAIL_ENABLED) {
    lines.push(``, `Reply with your email to receive property documents.`);
  }
  lines.push(``, `${STOP_FOOTER}`);
  return lines.join('\n');
}

/**
 * Send property info SMS. Only fires if the phone has confirmed consent on file.
 * If consent is pending or missing, no-op (the confirmation flow handles it).
 */
export async function sendPropertySms(
  to: string,
  propertyId: string,
  propertyName: string,
  propertyAddress: string,
  publicUrl: string | null
): Promise<boolean> {
  if (isOptedOut(to)) {
    console.warn(`🚫 SMS suppressed — ${to} is opted out`);
    return false;
  }
  if (!isConfirmed(to)) {
    console.warn(`🚫 SMS suppressed — ${to} has no confirmed consent`);
    return false;
  }
  const body = buildPropertyBody(propertyName, propertyAddress, publicUrl);
  const ok = await sendSms(to, body);
  // The body invites an email reply (when EMAIL_ENABLED) — queue this property
  // so the EMAIL inbound case knows what flyer to send.
  if (ok && EMAIL_ENABLED && propertyId) addFlyerPending(to, { propertyId, propertyName });
  return ok;
}

/**
 * Double-opt-in entry point. Caller verbally agreed during the call → we send
 * a "Reply YES to confirm" SMS and queue the property send for when YES arrives.
 *
 * If the caller has previously confirmed and is not opted out, we skip the
 * confirmation dance and send the property SMS immediately.
 *
 * Returns a tag describing what happened so the caller can be told the truth.
 */
export async function requestPropertyConfirmation(
  to: string,
  property: {
    propertyId: string;
    propertyName: string;
    propertyAddress: string;
    publicUrl: string | null;
  }
): Promise<'sent_immediately' | 'confirmation_sent' | 'queued' | 'opted_out' | 'failed'> {
  if (isOptedOut(to)) {
    console.warn(`🚫 SMS not requested — ${to} is opted out`);
    return 'opted_out';
  }

  if (isConfirmed(to)) {
    const ok = await sendPropertySms(to, property.propertyId, property.propertyName, property.propertyAddress, property.publicUrl);
    return ok ? 'sent_immediately' : 'failed';
  }

  // First-time caller — queue the property. If we already asked for YES this
  // window, just add it (no second confirmation text); it goes out on YES.
  const alreadyPrompted = getPendingProperties(to).length > 0;
  addPendingProperty(to, property);
  if (alreadyPrompted) return 'queued';

  const body = `${BRAND}: Reply YES to receive property details by text. Msg & data rates may apply. Reply STOP to opt out. Reply HELP for help.`;
  const ok = await sendSms(to, body);
  return ok ? 'confirmation_sent' : 'failed';
}

/**
 * Fire the queued property SMS after the caller confirms via YES.
 * Called from the inbound SMS webhook. No-op if nothing is pending.
 */
export async function deliverPendingPropertySms(to: string): Promise<boolean> {
  const list = getPendingProperties(to);
  if (!list.length) return false;
  let any = false;
  for (const p of list) {
    const ok = await sendPropertySms(to, p.propertyId, p.propertyName || 'Property', p.propertyAddress, p.publicUrl ?? null);
    any = any || ok;
  }
  if (any) clearPending(to);
  return any;
}

// ---------------------------------------------------------------------------
// Flyer-by-email — text the caller asking for their email, then send the flyer
// when they reply. Lets a caller get the flyer without spelling the address on
// the call, and works for draft listings (no public URL, just a flyer).
// ---------------------------------------------------------------------------

/**
 * Text the caller asking them to reply with their email, and remember which
 * property's flyer to send. The first SMS is itself the opt-in/transactional
 * message (carries STOP), so no prior YES is required.
 */
export async function requestFlyerByEmail(
  to: string,
  property: { propertyId: string; propertyName: string }
): Promise<'sent' | 'added' | 'opted_out' | 'failed'> {
  if (isOptedOut(to)) {
    console.warn(`🚫 Flyer-by-email not requested — ${to} is opted out`);
    return 'opted_out';
  }
  // Only suppress the prompt for genuinely back-to-back requests (a couple of
  // text_for_email calls in the same breath). Do NOT key off the pending list —
  // a property text sets that passively and would wrongly suppress a real request.
  const recentlyPrompted = wasRecentlyFlyerPrompted(to);
  addFlyerPending(to, property);
  if (recentlyPrompted) return 'added';

  const body =
    `${BRAND}: Reply to this text with your email and we'll send you the flyer for ${property.propertyName} ` +
    `(plus any others you ask about). One-time send — Msg & data rates may apply. Reply STOP to opt out, HELP for help.`;
  const ok = await sendSms(to, body);
  if (ok) markFlyerPrompted(to);
  return ok ? 'sent' : 'failed';
}

/**
 * Caller replied to a text with their email → email them ALL pending flyers in
 * one message. Called from the inbound SMS webhook. No-op if nothing is pending.
 */
export async function deliverFlyerByEmail(to: string, email: string): Promise<boolean> {
  if (isOptedOut(to)) return false;
  const pending = getFlyerPending(to);
  if (!pending.length) {
    console.log(`📧 ${to} sent an email but no flyer is pending — ignoring`);
    return false;
  }
  // Lazy import avoids any module cycle with the email handler.
  const { emailListingsToLead } = await import('./handlers/email');
  const result = await emailListingsToLead(pending.map((p) => p.propertyId), email).catch((e) => {
    console.warn(`📧 deliverFlyerByEmail send failed:`, e?.message);
    return null;
  });

  if (result?.ok) {
    clearFlyerPending(to);
    const n = result.listings.length;
    await sendSms(to, `${BRAND}: Sent! Check your inbox (and spam) for ${n > 1 ? `${n} property flyers` : 'the flyer'}.`);
    return true;
  }
  await sendSms(to, `${BRAND}: Sorry, we couldn't send that. Please double-check the email or call us at 305-851-2820.`);
  return false;
}

// ---------------------------------------------------------------------------
// Compliance replies — transactional messages required by Twilio for A2P.
// ---------------------------------------------------------------------------

export async function sendHelpReply(to: string): Promise<boolean> {
  const body = `${BRAND}: Property alert texts. Msg freq varies. Msg & data rates may apply. Reply STOP to opt out. Questions? Call 305-851-2820.`;
  return sendSms(to, body);
}

export async function sendStopConfirmation(to: string): Promise<boolean> {
  const body = `${BRAND}: You're opted out. You will not receive further texts. Reply START to resubscribe.`;
  return sendSms(to, body);
}

export async function sendStartReply(to: string): Promise<boolean> {
  const body = `${BRAND}: You're resubscribed. We'll text you again only after you opt in to a specific property on a call.`;
  return sendSms(to, body);
}
