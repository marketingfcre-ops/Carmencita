/**
 * WP auth health check — verify WP_USER + WP_APP_PASSWORD can still edit
 * properties end-to-end. Use this when SF→WP sync starts returning 401
 * (rest_cannot_edit / rest_cannot_create / rest_forbidden_context) or after
 * any change to a WP security plugin (Wordfence, iThemes, etc.) that may
 * silently strip Authorization headers from REST calls.
 *
 * Steps:
 *   1. /users/me?context=edit — who are we, what role, what capabilities
 *   2. Pick a recently-modified published property as a canary
 *   3. Send an empty PATCH to it (no-op, but exercises edit permission)
 *   4. Create a draft property, then delete it
 *
 * Read-only-ish: creates and immediately removes one canary draft.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-auth-health-check.ts
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH = 'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

async function wp(path: string, init?: RequestInit) {
  const res = await fetch(`${WP_SITE_URL}${path}`, {
    ...init,
    headers: { Authorization: WP_AUTH, ...(init?.headers || {}) },
  });
  let body: any = null;
  try { body = await res.json(); } catch {}
  return { status: res.status, body };
}

async function main() {
  console.log(`\nWP auth health check — user=${WP_USER}\n`);

  // 1. Identity + capabilities
  console.log('── 1. /users/me?context=edit ──');
  const me = await wp('/wp-json/wp/v2/users/me?context=edit');
  if (me.status !== 200) {
    console.log(`   ❌ ${me.status}: ${JSON.stringify(me.body).slice(0, 400)}`);
    console.log('\n   STOP — credentials not authenticating. Common causes:');
    console.log('   - Wordfence (or other security plugin) stripping Authorization header');
    console.log('   - WP_APP_PASSWORD was revoked / regenerated');
    console.log('   - admin-em user disabled or role downgraded');
    process.exit(1);
  }
  console.log(`   id=${me.body.id} slug=${me.body.slug} roles=${JSON.stringify(me.body.roles)}`);
  const caps = me.body.capabilities || {};
  const required = ['edit_properties', 'edit_others_properties', 'edit_published_properties', 'publish_properties'];
  const missing = required.filter(k => !caps[k]);
  if (missing.length === 0) {
    console.log(`   ✓ has all property edit capabilities`);
  } else {
    console.log(`   ❌ missing capabilities: ${missing.join(', ')}`);
  }

  // 2. Pick a recent published property as canary
  console.log('\n── 2. Pick canary (most recently modified published property) ──');
  const list = await wp('/wp-json/wp/v2/properties?per_page=1&orderby=modified&order=desc&status=publish&_fields=id,slug,modified');
  if (list.status !== 200 || !Array.isArray(list.body) || list.body.length === 0) {
    console.log(`   ❌ couldn't fetch a canary post: ${list.status}`);
    process.exit(1);
  }
  const canary = list.body[0];
  console.log(`   canary: wp:${canary.id} slug=${canary.slug} mod=${canary.modified}`);

  // 3. Empty PATCH on canary
  console.log(`\n── 3. Empty PATCH on wp:${canary.id} (no-op, tests edit) ──`);
  const patch = await wp(`/wp-json/wp/v2/properties/${canary.id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  });
  if (patch.status === 200) {
    console.log(`   ✓ 200 OK — edit works`);
  } else {
    console.log(`   ❌ ${patch.status}: ${JSON.stringify(patch.body).slice(0, 400)}`);
  }

  // 4. CREATE → DELETE canary draft
  console.log('\n── 4. CREATE draft canary, then DELETE ──');
  const cr = await wp('/wp-json/wp/v2/properties', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: '[CANARY — auto-deleted] auth health check', status: 'draft' }),
  });
  if (cr.status === 201 && cr.body?.id) {
    console.log(`   ✓ 201 created wp:${cr.body.id}`);
    const del = await wp(`/wp-json/wp/v2/properties/${cr.body.id}?force=true`, { method: 'DELETE' });
    console.log(`   ${del.status === 200 ? '✓' : '❌'} cleanup DELETE = ${del.status}`);
  } else {
    console.log(`   ❌ create failed ${cr.status}: ${JSON.stringify(cr.body).slice(0, 400)}`);
  }

  console.log('\nDone.');
  process.exit(0);
}

main().catch((err) => { console.error('💀', err); process.exit(1); });
