/**
 * Grant wildcard all-leads access (User_Group_Access__c row with
 * All_Groups__c = true, Status = Approved, Group blank) to one or more users
 * by name. Idempotent — skips users who already have an Approved wildcard row.
 *
 *   npx tsx --env-file .env.local scripts/migrations/grant-wildcard-access.ts --users "Pedro Galindo,Nathalie Aguirre" --dry-run
 *   npx tsx --env-file .env.local scripts/migrations/grant-wildcard-access.ts --users "Pedro Galindo,Nathalie Aguirre" --apply
 *
 * Required Flow state: Lead_Group_Access_Check v3+ (reads Get_My_Wildcard_Access
 * and ORs into Is_Admin). Without v3 the row is inert.
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const usersArgIdx = process.argv.indexOf('--users');
if (usersArgIdx < 0 || !process.argv[usersArgIdx + 1]) {
  console.error('Usage: --users "Name1,Name2,..." [--apply]');
  process.exit(1);
}
const NAMES = process.argv[usersArgIdx + 1]
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN (no writes). Pass --apply to execute.' : 'APPLY mode — will create.');
  console.log(`Users: ${NAMES.join(', ')}\n`);

  // Field sanity
  const describe: any = await sf.describe('User_Group_Access__c');
  const fields = (describe.fields || []) as any[];
  if (!fields.find((f) => f.name === 'All_Groups__c')) {
    console.error('❌ User_Group_Access__c.All_Groups__c missing. Add the checkbox first.');
    process.exit(1);
  }

  // Resolve all users in one SOQL
  const nameList = NAMES.map((n) => `'${n.replace(/'/g, "\\'")}'`).join(',');
  const users: any[] = await sf.soql(
    `SELECT Id, Name, IsActive, Profile.Name FROM User WHERE Name IN (${nameList})`
  );

  const found = new Map<string, any[]>();
  for (const u of users) {
    if (!found.has(u.Name)) found.set(u.Name, []);
    found.get(u.Name)!.push(u);
  }

  const targets: any[] = [];
  for (const name of NAMES) {
    const matches = found.get(name) || [];
    if (matches.length === 0) {
      console.log(`✗ ${name}: no User found — skipping.`);
      continue;
    }
    if (matches.length > 1) {
      console.log(`✗ ${name}: ${matches.length} ambiguous matches — skipping:`);
      for (const m of matches) console.log(`     ${m.Id}  active=${m.IsActive}  profile=${m.Profile?.Name}`);
      continue;
    }
    const u = matches[0];
    if (!u.IsActive) {
      console.log(`✗ ${name}: inactive (${u.Id}) — skipping.`);
      continue;
    }
    console.log(`✓ ${name}  →  ${u.Id}  profile=${u.Profile?.Name}`);
    targets.push(u);
  }

  if (!targets.length) {
    console.log('\nNothing to do.');
    return;
  }

  // Check existing wildcard rows in bulk
  const userIds = targets.map((u) => `'${u.Id}'`).join(',');
  const existing: any[] = await sf.soql(
    `SELECT Id, User__c, User__r.Name, Status__c, Group__c
     FROM User_Group_Access__c
     WHERE User__c IN (${userIds}) AND All_Groups__c = true`
  );
  const existingByUser = new Map<string, any[]>();
  for (const r of existing) {
    if (!existingByUser.has(r.User__c)) existingByUser.set(r.User__c, []);
    existingByUser.get(r.User__c)!.push(r);
  }

  console.log('\nPlan:');
  const toCreate: any[] = [];
  for (const u of targets) {
    const rows = existingByUser.get(u.Id) || [];
    const approved = rows.find((r) => r.Status__c === 'Approved');
    if (approved) {
      console.log(`  SKIP  ${u.Name.padEnd(28)} already has Approved wildcard row ${approved.Id}`);
      continue;
    }
    if (rows.length) {
      console.log(`  SKIP  ${u.Name.padEnd(28)} has ${rows.length} wildcard row(s) but none Approved — manual review:`);
      for (const r of rows) console.log(`        ${r.Id}  Status=${r.Status__c}`);
      continue;
    }
    console.log(`  CREATE ${u.Name.padEnd(28)} (${u.Id})`);
    toCreate.push(u);
  }

  if (!toCreate.length) {
    console.log('\nAll targets already have wildcard access. Nothing to write.');
    return;
  }

  if (DRY) {
    console.log(`\n${toCreate.length} row(s) would be created. Re-run with --apply.`);
    return;
  }

  console.log('');
  for (const u of toCreate) {
    const id = await sf.create('User_Group_Access__c', {
      User__c: u.Id,
      Status__c: 'Approved',
      All_Groups__c: true,
    });
    console.log(`  ✓ Created ${id}  for  ${u.Name}`);
  }

  // Verify
  const after: any[] = await sf.soql(
    `SELECT Id, User__r.Name, Status__c, All_Groups__c, Group__c
     FROM User_Group_Access__c
     WHERE User__c IN (${userIds}) AND All_Groups__c = true
     ORDER BY User__r.Name`
  );
  console.log('\nWildcard rows after run:');
  for (const r of after) {
    console.log(`  ${r.Id}  ${r.User__r?.Name.padEnd(28)} Status=${r.Status__c}  Group=${r.Group__c || '(blank)'}`);
  }
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
