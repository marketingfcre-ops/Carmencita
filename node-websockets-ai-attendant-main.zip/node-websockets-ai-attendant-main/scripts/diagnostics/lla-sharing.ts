import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // Org-wide default sharing
  try {
    const r: any[] = await sf.toolingQuery(
      `SELECT QualifiedApiName, InternalSharingModel, ExternalSharingModel FROM EntityDefinition WHERE QualifiedApiName IN ('Lead_List_Assignment__c','User_Group_Access__c','Group__c','Lead')`
    );
    console.log('Org-wide sharing defaults:');
    for (const e of r) console.log(`  ${e.QualifiedApiName.padEnd(30)} internal=${e.InternalSharingModel}  external=${e.ExternalSharingModel}`);
  } catch (e:any) { console.log(`err: ${e.message?.slice(0,200)}`); }
}
main().catch(e=>{console.error(e);process.exit(1);});
