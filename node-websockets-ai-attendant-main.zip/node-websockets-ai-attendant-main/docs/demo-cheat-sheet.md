# Agent Roundtable — Security Demo Cheat Sheet

Audience: **Fausto + agents (Mauricio, Joshua, Halain, Robin)**
Goal: validate group-based edit restrictions and the audit trail before promoting to production.

> Marketing automation (Phase 1 wishlist — SF→WP sync, flyer, etc.) is a **separate meeting** with marketing.

## Before everyone arrives

```bash
# Reset PROP-001s and reset test-agent's group assignment
npx tsx --env-file .env.local scripts/setup-test-agent.ts
```

That confirms test-agent-001 is assigned to LittleHavanaMF and prints sample leads to use.

## Tabs to pre-open

1. **Lead 140 LLC** (cross-group, will be blocked):
   `https://orgfarm-865fac3527-dev-ed.develop.lightning.force.com/lightning/r/Lead/00Qg5000003Uk25EAC/view`

2. **Lead Maria Lopez** (in-group, will succeed):
   `https://orgfarm-865fac3527-dev-ed.develop.lightning.force.com/lightning/r/Lead/00Qg5000003UcMHEA0/view`

3. **Lead List Assignment list** (multi-list junction):
   `https://orgfarm-865fac3527-dev-ed.develop.lightning.force.com/lightning/o/Lead_List_Assignment__c/list`
   *(switch view to "All")*

4. **Users** (for Login As):
   `https://orgfarm-865fac3527-dev-ed.develop.lightning.force.com/lightning/setup/ManageUsers/home`

## Logins

| Role | Username | How |
|---|---|---|
| Admin (you) | `hello@27colab.com` | Standard login |
| Test agent (LittleHavanaMF) | `test-agent-001@27colab.com.dev` | Use **Login As** from the Users list |

## Demo sequence (~10 min)

| # | Step | Tab | Action | Expected |
|---|---|---|---|---|
| 1 | Show real data | Leads list | Switch to "All Leads", point out Hialeah, BigMF list, AllapattahMF | Familiar names |
| 2 | Admin can edit anything | Tab 1 (140 LLC) | Edit a field → save | Saves successfully |
| 3 | **Login As test-agent** | Tab 4 (Users) | Click "Login" link in test-agent-001 row | New session as test-agent |
| 4 | Non-admin BLOCKED | Tab 1 (140 LLC) reload | Edit → save | **Validation error**: "You can only edit leads assigned to your group..." |
| 5 | Non-admin CAN edit | Tab 2 (Maria Lopez) | Edit → save | Saves successfully |
| 6 | Field History | Tab 2 → **Chatter** tab → "Most Recent Activity" | Show audit trail | Every status change with old → new value, who, when |
| 7 | Multi-list assignments | Tab 3 (Junction list) | Show 9 records, point at LLA-0009 (Pending) | Demonstrate that one lead can be on multiple lists; Pending awaiting admin approval |
| 8 | Recovery runbook | `docs/security-track-design.md` § 5 | Walk through "incident → restore" steps | — |
| 9 | Q&A | — | — | — |

## Talking points

- "**Real data** — 25 of your actual groups, 95 real leads. You'll recognize names from your daily work."
- "**Admin still has full control** — you and your assistant bypass all restrictions. This is for everyone else."
- "**Same-group edits stay fast** — agents working their own list see no change."
- "**Cross-group edits are blocked at save time** — no popup until the user tries to save, so they can still view and copy contact info if needed for legitimate referral conversations."
- "**Audit trail is free** — Salesforce native Field History, 18-month retention. Every change recorded."
- "**Multi-list with admin approval** — junction object is built. When an agent wants access to a new list, they propose it; you approve. Approval UI is the next iteration."
- "**Recovery, not prevention** — if anyone ever vandalizes data, we restore from the weekly backup. Field History tells us exactly who did what."
- "**This rule is in the sandbox today.** We promote it to production after this meeting if you give the green light."

## What's still pending (mention if asked)

These need a brief Setup-clicks session in production after sign-off:
- **Export lockdown** — strip "Export Reports" + "API Enabled" from the agent profile; grant via permission set to admins only
- **Weekly Data Export** — Setup → Data Management → Schedule (2-min UI step)
- **Field History Tracking** in production — already enabled
- **Multi-list approval workflow UI** — design phase

## If something goes wrong

| Symptom | Fix |
|---|---|
| Test agent can edit cross-group leads | Run `scripts/setup-test-agent.ts` to reset their `Group_ID__c` |
| "Login" link missing on Users page | Setup → Login Access Policies → check "Administrators Can Log in as Any User" → Save |
| Validation error message looks different | Check `docs/security-track-design.md` for the canonical message; the rule is editable in Setup → Object Manager → Lead → Validation Rules |
| Page Layout edit gives "Insufficient Privileges" / "type parameter" error | Known SF Lightning bug — for this demo we don't edit any layouts |

## Sample leads (already prepared)

**LittleHavanaMF — test-agent CAN edit:**
- Maria Lopez `<mlopez@example.com>` — `00Qg5000003UcMHEA0`
- Carlos Garcia `<carlos.g@example.com>` — `00Qg5000003UcKfEAK`
- Test Multi `<multi@example.com>` — `00Qg5000003UcVxEAK`

**EastSide — test-agent BLOCKED:**
- 140 LLC `<cinavajas@gmail.com>` — `00Qg5000003Uk25EAC`
- Neeta Ally & LLC `<floridatrades@aol.com>` — `00Qg5000003UjikEAC`
- David Becker `<davidbeckercpa@gmail.com>` — `00Qg5000003Uk0TEAS`

## After the demo

If Fausto green-lights:

1. Run `migrate-group-to-list-assignments.ts --target prod` to seed junction records in production from the existing `Lead.Group__c`
2. Adapt `seed-dev-validation-rule.ts` for production's permission set ID and run it
3. Add `User.Group_ID__c` to production User object (UI: Setup → Object Manager → User → New custom field, Text(18))
4. Populate `User.Group_ID__c` for all 52 production agents (one Excel/CSV import)
5. Schedule weekly backup in production
6. Send a short "what changed" email to all agents
