/**
 * Lead → Lead_List_Assignment__c reconciliation.
 *
 * WHY THIS EXISTS
 * ---------------
 * When an admin assigns a Lead to a list by setting `Lead.Group__c`, the lead's
 * group access is enforced by the `Lead_Group_Access_Check` Flow, which keys off
 * the `Lead_List_Assignment__c` junction. Until a matching assignment exists, the
 * assigned agents can't work the lead.
 *
 * The "create the assignment automatically" step would normally be a
 * record-triggered Flow, but the org is Professional Edition and already at the
 * hard cap of 5 autolaunched flows (see CLAUDE.md / handoffs). Rather than burn a
 * scarce flow slot — or hack the create into an unrelated Lead flow whose narrow
 * Qualified+Converted entry conditions would never fire on a Group change — we
 * reconcile on a schedule from the always-on server.
 *
 * GUARANTEES
 * ----------
 * - Create-only: never updates or deletes. Fails closed (a missing assignment
 *   means *no* access, never accidental access).
 * - Idempotent: skips any (Lead, Group) pair that already has an assignment.
 * - New assignments land as Status='Approved' (an admin set the Group, so the
 *   access is sanctioned — this is the same grandfathering rule the original
 *   migrate-group-to-list-assignments.ts migration used).
 *
 * The same logic backs the manual CLI (scripts/migrations/reconcile-lla.ts) so a
 * dry-run there exercises exactly what the scheduler runs.
 */

import fs from 'fs';
import path from 'path';
import { sfClient } from './sf-client';
import { sendEmail } from './resend';

export interface ReconcileResult {
  candidates: number; // Leads with Group__c set
  existing: number; // assignments already in place
  created: number; // assignments created this run (or would-create, when dryRun)
  skipped: number; // (Lead, Group) pairs that already existed
  failed: number; // creates that errored
  capped: boolean; // true if MAX_PER_RUN limited the work
  failures: Array<{ leadId: string; groupId: string; error: string }>;
  dryRun: boolean;
}

interface LeadWithGroup {
  Id: string;
  Group__c: string;
}

interface ExistingAssignment {
  Lead__c: string;
  Group__c: string;
}

/**
 * Safety valve so a first run against an unexpectedly large backlog can't spin
 * forever or hammer the API. Steady-state backlog is ~0 (existing leads were
 * grandfathered by the original migration), so this should never bite in normal
 * operation — but if it does, we log it rather than silently truncating.
 */
const MAX_PER_RUN = 500;

/**
 * Find Leads with a Group set but no matching Lead_List_Assignment__c and create
 * the missing assignments. Authenticates a fresh prod client per call so the
 * scheduler never trips over an expired token between runs.
 */
export async function reconcileLeadGroupAssignments(
  opts: { dryRun?: boolean } = {}
): Promise<ReconcileResult> {
  const dryRun = opts.dryRun ?? false;
  const sf = await sfClient('prod');

  // 1. Existing assignments → dedup key set.
  const existing = await sf.soql<ExistingAssignment>(
    `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c`
  );
  const existingKeys = new Set(
    existing.map((e) => `${e.Lead__c}|${e.Group__c}`)
  );

  // 2. Leads that have a Group set.
  const leads = await sf.soql<LeadWithGroup>(
    `SELECT Id, Group__c FROM Lead WHERE Group__c != null`
  );

  // 3. Diff.
  const toCreate: Array<{ Lead__c: string; Group__c: string }> = [];
  let skipped = 0;
  for (const lead of leads) {
    if (existingKeys.has(`${lead.Id}|${lead.Group__c}`)) {
      skipped++;
    } else {
      toCreate.push({ Lead__c: lead.Id, Group__c: lead.Group__c });
    }
  }

  const capped = toCreate.length > MAX_PER_RUN;
  const batch = capped ? toCreate.slice(0, MAX_PER_RUN) : toCreate;

  const result: ReconcileResult = {
    candidates: leads.length,
    existing: existing.length,
    created: 0,
    skipped,
    failed: 0,
    capped,
    failures: [],
    dryRun,
  };

  if (dryRun) {
    result.created = batch.length; // would-create
    return result;
  }

  // 4. Create one at a time — leverages sf-client's 401 re-auth + clear errors.
  //    Volumes per run are tiny in steady state, so this is plenty.
  for (const rec of batch) {
    try {
      await sf.create('Lead_List_Assignment__c', {
        Lead__c: rec.Lead__c,
        Group__c: rec.Group__c,
        Status__c: 'Approved',
      });
      result.created++;
    } catch (err) {
      result.failed++;
      result.failures.push({
        leadId: rec.Lead__c,
        groupId: rec.Group__c,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// Pending-assignment notification (the agent-request side)
// ---------------------------------------------------------------------------
//
// Agents create Lead_List_Assignment__c with Status='Pending' to REQUEST access;
// an admin (Nathalie) approves. This emails her a digest of NEW pending requests.
// "New" = created since the last time we notified, tracked by a watermark file on
// the Railway volume (same persistence pattern as the SMS consent store) so we
// don't re-nag her about the same unapproved requests every tick.

const NOTIFY_STORE_DIR =
  process.env.LLA_NOTIFY_STORE_DIR ||
  process.env.RAILWAY_VOLUME_MOUNT_PATH ||
  path.join(__dirname, '..', '..', 'data');
const NOTIFY_STORE_PATH = path.join(NOTIFY_STORE_DIR, 'lla-notify-watermark.json');

/** SF datetime literals don't take milliseconds — `2026-06-27T12:00:00Z`. */
function toSoqlDateTime(iso: string): string {
  return iso.replace(/\.\d{3}Z$/, 'Z');
}

function readWatermark(): string | null {
  try {
    if (fs.existsSync(NOTIFY_STORE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(NOTIFY_STORE_PATH, 'utf-8'));
      if (typeof raw?.lastCreatedDate === 'string') return raw.lastCreatedDate;
    }
  } catch (err) {
    console.warn('⚠️ lla-notify: failed to read watermark, treating as fresh:', err);
  }
  return null;
}

function writeWatermark(iso: string): void {
  try {
    fs.mkdirSync(NOTIFY_STORE_DIR, { recursive: true });
    fs.writeFileSync(NOTIFY_STORE_PATH, JSON.stringify({ lastCreatedDate: iso }, null, 2));
  } catch (err) {
    console.error('❌ lla-notify: failed to persist watermark:', err);
  }
}

/**
 * Clickable Lightning record links live on the My Domain Lightning host
 * (`<mydomain>.lightning.force.com`), not the OAuth instance host
 * (`<mydomain>.my.salesforce.com`) — the latter is for API calls and 404s the UI
 * path. Derive the Lightning host from the instance host; allow an env override in
 * the unlikely event the My Domain is ever renamed.
 */
function lightningBaseUrl(instanceUrl: string): string {
  const override = process.env.SF_LIGHTNING_BASE_URL;
  if (override) return override.replace(/\/$/, '');
  return instanceUrl.replace('.my.salesforce.com', '.lightning.force.com');
}

interface PendingAssignment {
  Id: string;
  CreatedDate: string;
  Lead__c?: string | null;
  Group__c?: string | null;
  Lead__r?: { Name?: string } | null;
  Group__r?: { Name?: string } | null;
  CreatedBy?: { Name?: string } | null;
}

export interface NotifyResult {
  found: number; // new actionable requests (after suppression)
  notified: boolean; // whether an email was actually sent
  suppressed: number; // pendings skipped because access is already Approved
  recipient: string;
  initialized: boolean; // first run: watermark seeded, nothing sent
  error?: string;
}

/**
 * Email the admin a digest of pending Lead_List_Assignment__c requests created
 * since the last notification, then advance the watermark.
 *
 * First run (no watermark file) seeds the watermark to "now" and sends nothing —
 * so enabling this never blasts a digest of the entire historical backlog. Any
 * existing pending requests should be cleared manually once; notifications then
 * cover everything created afterward.
 */
export async function notifyPendingAssignments(): Promise<NotifyResult> {
  const recipient = process.env.LLA_NOTIFY_EMAIL || 'na@faustocommercial.com';
  const nowIso = new Date().toISOString();
  const watermark = readWatermark();

  // First run: start the clock, don't email about pre-existing pendings.
  if (!watermark) {
    writeWatermark(nowIso);
    return { found: 0, notified: false, suppressed: 0, recipient, initialized: true };
  }

  const sf = await sfClient('prod');
  const rows = await sf.soql<PendingAssignment>(
    `SELECT Id, CreatedDate, Lead__c, Group__c, Lead__r.Name, Group__r.Name, CreatedBy.Name ` +
      `FROM Lead_List_Assignment__c ` +
      `WHERE Status__c = 'Pending' AND CreatedDate > ${toSoqlDateTime(watermark)} ` +
      `ORDER BY CreatedDate ASC LIMIT 200`
  );

  if (rows.length === 0) {
    return { found: 0, notified: false, suppressed: 0, recipient, initialized: false };
  }

  // Suppress pendings that already have an Approved LLA for the same lead+group:
  // the agent already has access (e.g. they created the lead in their own group and
  // the reconcile auto-approved it), so there's nothing for the admin to approve.
  const leadIds = [...new Set(rows.map((r) => r.Lead__c).filter(Boolean))] as string[];
  const approvedKeys = new Set<string>();
  if (leadIds.length) {
    const approved = await sf.soql<{ Lead__c: string; Group__c: string }>(
      `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c ` +
        `WHERE Status__c = 'Approved' AND Lead__c IN (${leadIds.map((id) => `'${id}'`).join(',')})`
    );
    for (const a of approved) approvedKeys.add(`${a.Lead__c}|${a.Group__c}`);
  }
  const actionable = rows.filter((r) => !approvedKeys.has(`${r.Lead__c}|${r.Group__c}`));
  const suppressed = rows.length - actionable.length;
  // Watermark covers every row we examined (incl. suppressed), so we don't re-check them.
  const newWatermark = rows[rows.length - 1].CreatedDate;

  if (actionable.length === 0) {
    writeWatermark(newWatermark);
    return { found: 0, notified: false, suppressed, recipient, initialized: false };
  }

  const base = lightningBaseUrl(sf.instance);
  const rowsHtml = actionable
    .map((r) => {
      const lead = r.Lead__r?.Name || '(unknown lead)';
      const group = r.Group__r?.Name || '(unknown group)';
      const by = r.CreatedBy?.Name || '(unknown)';
      const when = r.CreatedDate?.replace('T', ' ').replace(/\.\d+Z$/, ' UTC');
      const link = `${base}/lightning/r/Lead_List_Assignment__c/${r.Id}/view`;
      return `<tr><td style="padding:4px 12px 4px 0">${lead}</td><td style="padding:4px 12px 4px 0">${group}</td><td style="padding:4px 12px 4px 0">${by}</td><td style="padding:4px 12px 4px 0">${when}</td><td style="padding:4px 0"><a href="${link}">Review</a></td></tr>`;
    })
    .join('');

  const html =
    `<p>${actionable.length} new lead-list assignment request(s) are pending your approval:</p>` +
    `<table style="border-collapse:collapse;font-family:sans-serif;font-size:14px">` +
    `<tr style="text-align:left"><th style="padding:4px 12px 4px 0">Lead</th><th style="padding:4px 12px 4px 0">Group</th><th style="padding:4px 12px 4px 0">Requested by</th><th style="padding:4px 12px 4px 0">Created (UTC)</th><th></th></tr>` +
    rowsHtml +
    `</table>` +
    `<p style="color:#666;font-size:12px">You're receiving this because you approve lead-list access requests. Approve them in Salesforce by setting Status to Approved.</p>`;

  const subject =
    actionable.length === 1
      ? `1 new lead-list assignment request pending approval`
      : `${actionable.length} new lead-list assignment requests pending approval`;

  const res = await sendEmail({ to: recipient, subject, html });
  if (!res.ok) {
    // Do NOT advance the watermark — retry these on the next tick.
    return {
      found: actionable.length,
      notified: false,
      suppressed,
      recipient,
      initialized: false,
      error: res.error || 'send failed',
    };
  }

  // Advance watermark to the newest request we examined.
  writeWatermark(newWatermark);
  return { found: actionable.length, notified: true, suppressed, recipient, initialized: false };
}

export interface TidyResult {
  checked: number; // pending LLAs examined
  deleted: number; // redundant pendings removed
}

/**
 * Delete Pending Lead_List_Assignment__c records that already have an Approved
 * LLA for the same lead+group. This happens when an agent creates a lead in their
 * own group (auto-approved by the reconcile) and then also files a request — the
 * Pending is harmless but redundant, so we tidy it up to keep the lead clean.
 * Provably safe: we only delete a Pending when access is already Approved.
 */
export async function tidyRedundantPendings(): Promise<TidyResult> {
  const sf = await sfClient('prod');
  const pendings = await sf.soql<{ Id: string; Lead__c: string | null; Group__c: string | null }>(
    `SELECT Id, Lead__c, Group__c FROM Lead_List_Assignment__c WHERE Status__c = 'Pending'`
  );
  if (pendings.length === 0) return { checked: 0, deleted: 0 };

  const leadIds = [...new Set(pendings.map((p) => p.Lead__c).filter(Boolean))] as string[];
  const approvedKeys = new Set<string>();
  for (let i = 0; i < leadIds.length; i += 200) {
    const chunk = leadIds.slice(i, i + 200);
    const approved = await sf.soql<{ Lead__c: string; Group__c: string }>(
      `SELECT Lead__c, Group__c FROM Lead_List_Assignment__c ` +
        `WHERE Status__c = 'Approved' AND Lead__c IN (${chunk.map((id) => `'${id}'`).join(',')})`
    );
    for (const a of approved) approvedKeys.add(`${a.Lead__c}|${a.Group__c}`);
  }

  const redundant = pendings.filter(
    (p) => p.Lead__c && approvedKeys.has(`${p.Lead__c}|${p.Group__c}`)
  );
  let deleted = 0;
  for (const r of redundant) {
    try {
      await sf.delete('Lead_List_Assignment__c', r.Id);
      deleted++;
    } catch (err) {
      console.error(
        `tidy: failed to delete ${r.Id}:`,
        err instanceof Error ? err.message : err
      );
    }
  }
  return { checked: pendings.length, deleted };
}

let reconcileTimer: ReturnType<typeof setInterval> | undefined;

/**
 * Start the in-process LLA scheduler. Two independent jobs share one tick:
 *   - reconcile (create missing Approved assignments) — LLA_RECONCILE_ENABLED
 *   - notify Nathalie of new Pending requests          — LLA_NOTIFY_ENABLED
 * No-op unless at least one is enabled, so it stays dark until switched on in the
 * Railway environment. Runs one pass ~30s after boot (without blocking startup),
 * then every LLA_RECONCILE_INTERVAL_MIN minutes (default 10).
 */
export function startLlaReconcileScheduler(): void {
  const reconcileEnabled = process.env.LLA_RECONCILE_ENABLED === 'true';
  const notifyEnabled = process.env.LLA_NOTIFY_ENABLED === 'true';

  if (!reconcileEnabled && !notifyEnabled) {
    console.log(
      'ℹ️  LLA scheduler disabled (set LLA_RECONCILE_ENABLED and/or LLA_NOTIFY_ENABLED=true)'
    );
    return;
  }

  const intervalMin = Math.max(
    1,
    parseInt(process.env.LLA_RECONCILE_INTERVAL_MIN || '10', 10) || 10
  );
  const intervalMs = intervalMin * 60_000;

  const run = () => {
    if (reconcileEnabled) {
      reconcileLeadGroupAssignments()
        .then((r) => {
          const tail = r.failed
            ? ` ⚠️ ${r.failed} failed (first: ${r.failures[0]?.error?.slice(0, 160)})`
            : '';
          const cap = r.capped ? ` [capped at ${MAX_PER_RUN}, more remain]` : '';
          console.log(
            `🔁 LLA reconcile: created ${r.created}, skipped ${r.skipped} ` +
              `(candidates ${r.candidates}, existing ${r.existing})${cap}${tail}`
          );
        })
        .catch((err) => console.error('LLA reconcile error:', err));

      // Remove Pending requests that are already Approved (redundant duplicates).
      tidyRedundantPendings()
        .then((t) => {
          if (t.deleted) {
            console.log(`🧹 LLA tidy: removed ${t.deleted} redundant pending(s) already approved`);
          }
        })
        .catch((err) => console.error('LLA tidy error:', err));
    }

    if (notifyEnabled) {
      notifyPendingAssignments()
        .then((n) => {
          if (n.initialized) {
            console.log('📧 LLA notify: watermark initialized — notifying new requests going forward');
          } else if (n.error) {
            console.error(`📧 LLA notify: ${n.found} pending, send FAILED — ${n.error}`);
          } else if (n.notified) {
            const sup = n.suppressed ? ` (${n.suppressed} already-approved suppressed)` : '';
            console.log(`📧 LLA notify: emailed ${n.recipient} about ${n.found} new request(s)${sup}`);
          } else if (n.suppressed) {
            console.log(`📧 LLA notify: ${n.suppressed} new pending(s) already approved — nothing to send`);
          }
        })
        .catch((err) => console.error('LLA notify error:', err));
    }
  };

  // First pass 30s after boot so it doesn't compete with startup work.
  setTimeout(run, 30_000);
  reconcileTimer = setInterval(run, intervalMs);

  const jobs = [
    reconcileEnabled ? 'reconcile' : null,
    notifyEnabled ? 'notify' : null,
  ]
    .filter(Boolean)
    .join(' + ');
  console.log(`🔁 LLA scheduler (${jobs}) every ${intervalMin} min`);
}

/** Stop the scheduler (used by tests / graceful shutdown). */
export function stopLlaReconcileScheduler(): void {
  if (reconcileTimer) clearInterval(reconcileTimer);
  reconcileTimer = undefined;
}
