import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log('=== Account for Agents CRUD on Lead_List_Assignment__c ===');
  const op: any[] = await sf.soql(
    `SELECT Parent.Profile.Name, Parent.Label, PermissionsRead, PermissionsCreate, PermissionsEdit, PermissionsDelete
     FROM ObjectPermissions WHERE SobjectType = 'Lead_List_Assignment__c'`
  );
  for (const r of op) {
    const owner = r.Parent?.Profile?.Name ? `profile=${r.Parent.Profile.Name}` : `permset="${r.Parent?.Label}"`;
    const flags = (r.PermissionsRead?'R':'-')+(r.PermissionsCreate?'C':'-')+(r.PermissionsEdit?'E':'-')+(r.PermissionsDelete?'D':'-');
    console.log(`  ${flags}  ${owner}`);
  }

  // For the specific lead we're testing — what assignments are queryable AS the integration user?
  console.log('\n=== Lead 00QJw00000Ot9gQMAR — assignments ===');
  const a: any[] = await sf.soql(
    `SELECT Id, Group__r.Name, Status__c FROM Lead_List_Assignment__c WHERE Lead__c = '00QJw00000Ot9gQMAR'`
  );
  console.log(`  ${a.length} assignments:`);
  for (const r of a) console.log(`    ${r.Id}  ${r.Status__c}  Group=${r.Group__r?.Name}`);
}
main().catch(e=>{console.error(e);process.exit(1);});
