/**
 * Property public-URL audit — read-only (SF reads + WP GETs).
 *
 * The theory (per Fausto): publishing a listing in WordPress does NOT update the
 * Salesforce Public_URL__c, so published listings can still carry a draft-format
 * URL (`?post_type=property&p=<id>`) in SF. This audit cross-checks each property
 * against WordPress to find exactly those — and surfaces the CORRECT permalink we
 * could backfill.
 *
 * Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/property-url-audit.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/property-url-audit.ts --fixlist  # dump SF id → correct URL
 */

import { sfClient } from '../../src/integrations/sf-client';

const FIXLIST = process.argv.includes('--fixlist');
const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const API_BASE = `${WP_SITE_URL.replace(/\/$/, '')}/wp-json`;
const authHeader = () =>
  `Basic ${Buffer.from(`${process.env.WP_USER || ''}:${process.env.WP_APP_PASSWORD || ''}`).toString('base64')}`;

const isDraftUrl = (u: string | null) => !!u && /[?&]p=\d+/.test(u);
const isPrettyUrl = (u: string | null) => !!u && /\/property\//.test(u) && !/[?&]p=\d+/.test(u);
const postIdFromUrl = (u: string | null) => { const m = u?.match(/[?&]p=(\d+)/); return m ? Number(m[1]) : null; };
const chunk = <T,>(a: T[], n: number) => { const o: T[][] = []; for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };

async function main() {
  const sf = (await sfClient('prod')) as any;
  const props: any[] = await sf.soql(
    `SELECT Id, Name, Status__c, Public_URL__c, WP_Post_ID__c FROM Property__c`
  );
  console.log(`\n🔗 Public-URL audit over ${props.length} Property__c records\n`);

  // Resolve a WP post id per property (field first, else parse from URL).
  const wpIdByProp = new Map<string, number>();
  for (const p of props) {
    const wpId = p.WP_Post_ID__c ? Number(p.WP_Post_ID__c) : postIdFromUrl(p.Public_URL__c);
    if (wpId) wpIdByProp.set(p.Id, wpId);
  }

  // Bulk-fetch WP posts (all statuses) by include=.
  const wp = new Map<number, { status: string; link: string }>();
  const allIds = [...new Set([...wpIdByProp.values()])];
  for (const ids of chunk(allIds, 100)) {
    const url = `${API_BASE}/wp/v2/properties?include=${ids.join(',')}&per_page=100` +
      `&status=publish,draft,private,pending,future&context=edit&_fields=id,status,link`;
    const res = await fetch(url, { headers: { Authorization: authHeader() } });
    if (!res.ok) { console.warn(`WP fetch failed ${res.status} for batch of ${ids.length}`); continue; }
    const rows = (await res.json()) as Array<{ id: number; status: string; link: string }>;
    for (const r of rows) wp.set(r.id, { status: r.status, link: r.link });
  }
  console.log(`Resolved ${wpIdByProp.size}/${props.length} properties to a WP post; fetched ${wp.size} WP records.\n`);

  // Classify.
  let noWpId = 0, wpMissing = 0;
  let publishedCleanSf = 0;     // WP publish + SF already pretty (good)
  let publishedStaleSf = 0;     // WP publish + pretty permalink, but SF draft/empty/wrong  ← THE PROBLEM
  let notPublished = 0;         // WP draft/pending — SF ?p= is arguably correct
  const fixes: { id: string; name: string; sfUrl: string; correct: string; sfStatus: string }[] = [];

  for (const p of props) {
    const wpId = wpIdByProp.get(p.Id);
    if (!wpId) { noWpId++; continue; }
    const w = wp.get(wpId);
    if (!w) { wpMissing++; continue; }
    const wpPublished = w.status === 'publish';
    const wpPretty = isPrettyUrl(w.link);
    if (wpPublished && wpPretty) {
      if (isPrettyUrl(p.Public_URL__c) && p.Public_URL__c === w.link) publishedCleanSf++;
      else {
        publishedStaleSf++;
        fixes.push({ id: p.Id, name: p.Name, sfUrl: p.Public_URL__c || '(empty)', correct: w.link, sfStatus: p.Status__c });
      }
    } else {
      notPublished++;
    }
  }

  console.log(`WP says PUBLISHED with a real permalink:`);
  console.log(`   ✓ SF already has the correct pretty URL:     ${publishedCleanSf}`);
  console.log(`   ⚠️ SF still has a DRAFT/empty/wrong URL:       ${publishedStaleSf}   ← fixable (we have the right URL)`);
  console.log(`WP NOT published (draft/pending) — SF ?p= is OK: ${notPublished}`);
  console.log(`No WP post id resolvable on SF record:            ${noWpId}`);
  console.log(`WP post id set but post not found in WP:          ${wpMissing}`);

  // SF Status of the stale ones (are they marked Active in SF?)
  const byStatus = new Map<string, number>();
  for (const f of fixes) byStatus.set(f.sfStatus || '(null)', (byStatus.get(f.sfStatus || '(null)') || 0) + 1);
  console.log(`\nThe ${publishedStaleSf} stale-URL properties by SF Status__c:`);
  for (const [k, v] of [...byStatus].sort((a, b) => b[1] - a[1])) console.log(`   ${k.padEnd(20)} ${v}`);

  console.log(`\nExamples (SF url → correct WP url):`);
  for (const f of fixes.slice(0, 12)) console.log(`   ${f.name}\n      ${f.sfUrl}\n      → ${f.correct}`);

  if (FIXLIST) {
    console.log(`\n--- FIXLIST (${fixes.length}) ---`);
    for (const f of fixes) console.log(`${f.id}\t${f.correct}`);
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
