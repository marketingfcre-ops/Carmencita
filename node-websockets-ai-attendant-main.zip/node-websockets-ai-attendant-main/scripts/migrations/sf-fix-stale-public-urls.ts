/**
 * Bulk-fix stale SF.Public_URL__c values.
 *
 * For every SF record whose WP_Post_ID__c points at an existing WP post,
 * compares SF.Public_URL__c to the WP post's `.link`. If they differ,
 * PATCH SF.Public_URL__c = WP.link.
 *
 * Why this is needed: the dedupe migration repointed SF.WP_Post_ID__c to
 * canonical posts but never updated Public_URL__c. Result: ~65 SF records
 * have URLs pointing at the OLD wp_id (some of which are now deleted),
 * giving agents 404s when they click through.
 *
 * Safe to run repeatedly — idempotent. Records already in sync are skipped.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-fix-stale-public-urls.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-fix-stale-public-urls.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 150;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Address__c: string | null;
  WP_Post_ID__c: number | null;
  Public_URL__c: string | null;
}

interface WpPost {
  id: number;
  status: string;
  link: string;
  title: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function sfUpdate(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true };
  return { ok: false, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true };
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false, error: lastError };
  }
  return { ok: false, error: lastError };
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,status,link,title`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          status: p.status || '',
          link: p.link || '',
          title: (p.title?.rendered || '').toString(),
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log(`\n🔗 Sync SF.Public_URL__c with WP.link ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();
  const [sfRecords, wpPosts] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Address__c, WP_Post_ID__c, Public_URL__c
         FROM Property__c
        WHERE WP_Post_ID__c != NULL`
    ),
    fetchAllWpPosts(),
  ]);

  const wpById = new Map<number, WpPost>();
  for (const p of wpPosts) wpById.set(p.id, p);

  // Build plan: only records whose Public_URL__c differs from current WP.link
  const plan: { sf: SfProperty; wp: WpPost; oldUrl: string; newUrl: string }[] = [];
  for (const sf of sfRecords) {
    if (!sf.WP_Post_ID__c) continue;
    const wp = wpById.get(sf.WP_Post_ID__c);
    if (!wp) {
      console.warn(`   ⚠️  SF ${sf.Id} → wp:${sf.WP_Post_ID__c} doesn't exist (skip — orphan)`);
      continue;
    }
    if (!wp.link) continue;
    const current = (sf.Public_URL__c || '').trim();
    if (current === wp.link) continue; // already in sync
    plan.push({ sf, wp, oldUrl: current, newUrl: wp.link });
  }

  console.log(`SF records with WP link:     ${sfRecords.length}`);
  console.log(`Already in sync:             ${sfRecords.length - plan.length}`);
  console.log(`Need URL update:             ${plan.length}\n`);

  if (plan.length === 0) {
    console.log('Nothing to do.\n');
    process.exit(0);
  }

  console.log('── Plan ──\n');
  for (const p of plan.slice(0, 100)) {
    console.log(`SF ${p.sf.Id}  ${p.sf.Address__c || ''}  →  wp:${p.wp.id} (${p.wp.status})`);
    console.log(`   OLD: ${p.oldUrl || '(empty)'}`);
    console.log(`   NEW: ${p.newUrl}`);
    console.log('');
  }
  if (plan.length > 100) console.log(`... and ${plan.length - 100} more\n`);

  if (DRY_RUN) {
    console.log(`[DRY RUN] Would update ${plan.length} records. No changes made.\n`);
    process.exit(0);
  }

  console.log('→ Executing...\n');
  let ok = 0;
  let err = 0;
  for (const p of plan) {
    const result = await sfUpdateWithRetry(token, instance, p.sf.Id, {
      Public_URL__c: p.newUrl,
    });
    if (result.ok) {
      ok++;
      if (ok % 25 === 0) console.log(`   ...${ok}/${plan.length} updated`);
    } else {
      err++;
      console.warn(`   ❌ ${p.sf.Id}: ${result.error}`);
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Updated:   ${ok}`);
  console.log(`Failures:  ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
