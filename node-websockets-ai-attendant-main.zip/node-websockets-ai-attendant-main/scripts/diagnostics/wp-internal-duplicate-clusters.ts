/**
 * WP↔WP duplicate-cluster audit. Finds groups of WP property posts that
 * appear to be duplicates of each other, using multiple matching signals:
 *
 *   1. Normalized fave_property_address (street part)
 *   2. Address extracted from the post TITLE (e.g. "Industrial For Sale
 *      at 2860 State Road 84..." → match on "2860 state road")
 *   3. House number + city co-occurrence (looser fallback for cross-checking)
 *
 * For each cluster of 2+ posts, shows:
 *   - Cluster size
 *   - Which posts are SF-linked vs orphan
 *   - WP post details so a human can decide canonical
 *
 * The big question: of the 246 WP-only posts (no SF backing), how many
 * cluster with SF-linked posts? Those are duplicates we missed during the
 * bulk import — likely because we created a new draft when an existing
 * marketing-titled post already existed.
 *
 * Read-only.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-internal-duplicate-clusters.ts
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface WpPost {
  id: number;
  date: string;
  status: string;
  title: string;
  fave_property_address: string;
  featured_media: number;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfLinkedWpIds(token: string, instance: string): Promise<Set<number>> {
  const url = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(
    `SELECT WP_Post_ID__c FROM Property__c WHERE WP_Post_ID__c != NULL`
  )}`;
  const set = new Set<number>();
  let next: string | null = url;
  while (next) {
    const res = await fetch(next, { headers: { Authorization: `Bearer ${token}` } });
    const data = (await res.json()) as { records: any[]; nextRecordsUrl?: string };
    for (const r of data.records) if (r.WP_Post_ID__c) set.add(r.WP_Post_ID__c);
    next = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return set;
}

async function fetchAllWp(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,date,status,title,fave_property_address,featured_media`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          date: p.date || '',
          status: p.status || '',
          title: (p.title?.rendered || '').toString(),
          fave_property_address: p.fave_property_address || '',
          featured_media: p.featured_media || 0,
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/**
 * Normalize an address string to a comparable street-only key.
 * Handles both Houzez "1800, Northwest 19th Terrace, Miami,..." format
 * and SF-typed "1800 NW 19 Terr" format.
 */
function normAddrKey(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = addr.toLowerCase().trim();
  // Skip leading non-numeric "building name" tokens
  const firstDigit = a.search(/\d/);
  if (firstDigit > 0) a = a.substring(firstDigit);

  const parts = a.split(',').map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) return '';

  let s = parts[0];
  let i = 1;
  while (i < parts.length && /^[\d\s\-#/]+$/.test(s)) {
    s = s + ' ' + parts[i];
    i++;
  }

  s = s.replace(/[#.,/]/g, ' ');
  s = s.replace(/(\d+)[\s\-]+\d+([\s\-]+\d+)*/g, '$1'); // ranges → first num
  s = s.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  s = s.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  s = s.replace(/\bnorthwesr\b/g, 'nw'); // known typo
  s = s.replace(/\bnorth\b/g, 'n').replace(/\bsouth\b/g, 's');
  s = s.replace(/\beast\b/g, 'e').replace(/\bwest\b/g, 'w');
  s = s.replace(/\b(street|str)\b/g, 'st');
  s = s.replace(/\b(avenue|av)\b/g, 'ave');
  s = s.replace(/\b(boulevard|boul)\b/g, 'blvd');
  s = s.replace(/\broad\b/g, 'rd');
  s = s.replace(/\bdrive\b/g, 'dr');
  s = s.replace(/\bterrace\b/g, 'ter');
  s = s.replace(/\bcourt\b/g, 'ct');
  s = s.replace(/\bplace\b/g, 'pl');
  s = s.replace(/\bhighway\b/g, 'hwy');
  s = s.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  s = s.replace(
    /\b(miami|miami-dade county|broward county|duval county|florida|fl|united states|hialeah|opa-locka|opalocka|jacksonville|dania beach|hollywood|north miami beach|miami beach|coral gables|miramar|fort lauderdale|pompano beach|pompano|davie|deerfield beach|lake worth beach|west park|pembroke park|pembroke pines|hallandale beach|hallandale|medley|homestead|allapattah|wynwood|little havana)\b/g,
    ''
  );
  s = s.replace(/\b\d{5}(-\d{4})?\b/g, ''); // zip codes
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

/**
 * Extract address-like strings from a title.
 * E.g. "Industrial For Sale at 2860 State Road 84, Unit #113 in Dania Beach"
 *     → ["2860 state road 84"]
 *     "1234 SW 5th St"  → ["1234 sw 5 st"]
 *
 * Returns an array of normalized keys (may be empty if no address found).
 */
function extractAddrFromTitle(title: string): string[] {
  if (!title) return [];
  const decoded = title.replace(/&#8211;/g, '–').replace(/&#038;/g, '&').replace(/&amp;/g, '&');
  // Find house-number + street-name + street-type patterns
  // Look for: \d{2,6}  optionally followed by direction  followed by some words  ending in street-type
  const re =
    /\b(\d{2,6})\s+((?:n|s|e|w|nw|ne|sw|se|north|south|east|west|northwest|northeast|southwest|southeast)\s+)?([\w\d\s]+?)\s+(st|ave|rd|dr|blvd|ter|ct|pl|way|hwy|lane|court|place|terrace|avenue|street|road|drive|boulevard|highway)\b/gi;
  const out: string[] = [];
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = re.exec(decoded)) !== null) {
    const fullMatch = m[0];
    const normalized = normAddrKey(fullMatch);
    if (normalized && !seen.has(normalized)) {
      seen.add(normalized);
      out.push(normalized);
    }
    // Limit to first 3 matches to avoid runaway titles
    if (out.length >= 3) break;
  }
  return out;
}

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔬 WP↔WP duplicate-cluster audit (read-only)\n');

  const { token, instance } = await sfAuth();
  const [linkedSet, wpAll] = await Promise.all([
    sfLinkedWpIds(token, instance),
    fetchAllWp(),
  ]);

  console.log(`WP posts:               ${wpAll.length}`);
  console.log(`SF-linked WP posts:     ${linkedSet.size}`);
  console.log(`WP-only (orphan) posts: ${wpAll.length - [...linkedSet].filter((id) => wpAll.find((p) => p.id === id)).length}\n`);

  // Build the cluster index — each post can contribute multiple keys (one
  // from its address, possibly multiple from its title).
  const byKey = new Map<string, WpPost[]>();
  const postKeys = new Map<number, Set<string>>();

  for (const p of wpAll) {
    const keys = new Set<string>();
    const addrKey = normAddrKey(p.fave_property_address);
    if (addrKey && addrKey.length >= 4) keys.add(addrKey);
    for (const tk of extractAddrFromTitle(p.title)) {
      if (tk.length >= 4) keys.add(tk);
    }
    postKeys.set(p.id, keys);
    for (const k of keys) {
      const arr = byKey.get(k) || [];
      arr.push(p);
      byKey.set(k, arr);
    }
  }

  // Find clusters (keys with 2+ posts). De-dup by post-set since one
  // address could appear under multiple keys.
  type Cluster = { key: string; posts: WpPost[]; hasLinked: boolean; hasOrphan: boolean };
  const seenPostSets = new Set<string>();
  const clusters: Cluster[] = [];

  for (const [key, posts] of byKey.entries()) {
    if (posts.length < 2) continue;
    const ids = posts.map((p) => p.id).sort((a, b) => a - b);
    const fingerprint = ids.join('|');
    if (seenPostSets.has(fingerprint)) continue;
    seenPostSets.add(fingerprint);
    const hasLinked = posts.some((p) => linkedSet.has(p.id));
    const hasOrphan = posts.some((p) => !linkedSet.has(p.id));
    clusters.push({ key, posts, hasLinked, hasOrphan });
  }

  // Categorize clusters
  const mixedClusters = clusters.filter((c) => c.hasLinked && c.hasOrphan);
  const allLinkedClusters = clusters.filter((c) => c.hasLinked && !c.hasOrphan);
  const allOrphanClusters = clusters.filter((c) => !c.hasLinked && c.hasOrphan);

  console.log('═'.repeat(78));
  console.log('CLUSTER SUMMARY');
  console.log('═'.repeat(78));
  console.log(`
  Total clusters (2+ posts sharing address):     ${clusters.length}
  ┃
  ┣━ MIXED (some SF-linked, some orphan):        ${mixedClusters.length}
  ┃    → These are the "duplicate we missed" cases. An orphan WP post
  ┃      exists at the same address as an SF-linked post. The SF record
  ┃      points at one; the other (orphan) might be a duplicate we
  ┃      created or older content.
  ┃
  ┣━ ALL SF-LINKED (multiple SF records same address): ${allLinkedClusters.length}
  ┃    → Multiple SF records linking to same address. Could be intentional
  ┃      (separate units in a building) or a SF-side data issue.
  ┃
  ┗━ ALL ORPHAN (none SF-linked):                ${allOrphanClusters.length}
       → Multiple WP-only posts at same address. Pure WP-side dups.
  `);

  // ─── MIXED CLUSTERS (highest priority) ───────────────────────────────
  if (mixedClusters.length > 0) {
    console.log('═'.repeat(78));
    console.log(`MIXED CLUSTERS (${mixedClusters.length}) — orphan WP post + SF-linked WP post at same address`);
    console.log('═'.repeat(78));
    // Sort by cluster size desc
    mixedClusters.sort((a, b) => b.posts.length - a.posts.length);
    for (const c of mixedClusters) {
      console.log(`\nKey: "${c.key}"`);
      // Sort posts within cluster: linked first, then by id
      const sorted = [...c.posts].sort((a, b) => {
        const al = linkedSet.has(a.id) ? 0 : 1;
        const bl = linkedSet.has(b.id) ? 0 : 1;
        return al - bl || a.id - b.id;
      });
      for (const p of sorted) {
        const linked = linkedSet.has(p.id) ? '🔗 LINKED' : '👻 ORPHAN';
        const photo = p.featured_media > 0 ? '📷' : '🚫';
        console.log(`   ${linked} wp:${String(p.id).padEnd(6)} ${p.status.padEnd(8)} ${p.date.slice(0, 10)} ${photo}  "${trunc(p.title.replace(/&#8211;/g, '–'), 55)}"`);
        if (p.fave_property_address) console.log(`     addr: "${trunc(p.fave_property_address, 80)}"`);
      }
    }
  }

  // ─── ALL ORPHAN CLUSTERS ─────────────────────────────────────────────
  if (allOrphanClusters.length > 0) {
    console.log('\n' + '═'.repeat(78));
    console.log(`ALL-ORPHAN CLUSTERS (${allOrphanClusters.length}) — multiple WP-only posts at same address`);
    console.log('═'.repeat(78));
    allOrphanClusters.sort((a, b) => b.posts.length - a.posts.length);
    for (const c of allOrphanClusters.slice(0, 30)) {
      console.log(`\nKey: "${c.key}"`);
      for (const p of c.posts.sort((a, b) => a.id - b.id)) {
        const photo = p.featured_media > 0 ? '📷' : '🚫';
        console.log(`   wp:${String(p.id).padEnd(6)} ${p.status.padEnd(8)} ${p.date.slice(0, 10)} ${photo}  "${trunc(p.title.replace(/&#8211;/g, '–'), 55)}"`);
        if (p.fave_property_address) console.log(`     addr: "${trunc(p.fave_property_address, 80)}"`);
      }
    }
    if (allOrphanClusters.length > 30) console.log(`\n... and ${allOrphanClusters.length - 30} more orphan clusters`);
  }

  // ─── ALL-LINKED CLUSTERS (briefer) ───────────────────────────────────
  if (allLinkedClusters.length > 0) {
    console.log('\n' + '═'.repeat(78));
    console.log(`ALL-SF-LINKED CLUSTERS (${allLinkedClusters.length}) — multiple SF records → same address`);
    console.log('═'.repeat(78));
    console.log('  (Could be intentional units/lots in same building, or SF-side dup records)\n');
    allLinkedClusters.sort((a, b) => b.posts.length - a.posts.length);
    for (const c of allLinkedClusters) {
      console.log(`Key: "${c.key}"  (${c.posts.length} posts)`);
      for (const p of c.posts.sort((a, b) => a.id - b.id)) {
        console.log(`   wp:${String(p.id).padEnd(6)} ${p.status}  "${trunc(p.title.replace(/&#8211;/g, '–'), 55)}"`);
      }
      console.log('');
    }
  }

  // ─── ORPHAN GRAND TOTAL ──────────────────────────────────────────────
  const allOrphans = wpAll.filter((p) => !linkedSet.has(p.id));
  const orphansInClusters = new Set<number>();
  for (const c of mixedClusters.concat(allOrphanClusters)) {
    for (const p of c.posts) if (!linkedSet.has(p.id)) orphansInClusters.add(p.id);
  }
  const cleanOrphans = allOrphans.length - orphansInClusters.size;

  console.log('═'.repeat(78));
  console.log('ORPHAN ROLLUP');
  console.log('═'.repeat(78));
  console.log(`
  Total WP-only (no SF) posts:                    ${allOrphans.length}
  ┣━ In MIXED clusters (likely missed dup):       ${[...orphansInClusters].filter((id) => mixedClusters.some((c) => c.posts.some((p) => p.id === id))).length}
  ┣━ In ALL-ORPHAN clusters (pure WP dup):        ${[...orphansInClusters].filter((id) => !mixedClusters.some((c) => c.posts.some((p) => p.id === id))).length}
  ┗━ Standalone (truly unique WP-only content):   ${cleanOrphans}
  `);

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
