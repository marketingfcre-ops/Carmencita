import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // Get the Lead's child relationship for Lead_List_Assignment__c
  const desc: any = await sf.describe('Lead');
  const rel = (desc.childRelationships || []).find((r: any) => r.childSObject === 'Lead_List_Assignment__c');
  console.log('Lead.childRelationship for Lead_List_Assignment__c:');
  console.log(`  relationshipName: ${rel?.relationshipName}`);
  console.log(`  childSObject: ${rel?.childSObject}`);
  console.log(`  field (FK on child): ${rel?.field}`);
  // Same for Group__c
  const descG: any = await sf.describe('Group__c');
  const relG = (descG.childRelationships || []).find((r: any) => r.childSObject === 'Lead_List_Assignment__c');
  console.log('\nGroup__c.childRelationship for Lead_List_Assignment__c:');
  console.log(`  relationshipName: ${relG?.relationshipName}`);
}
main().catch(e=>{console.error(e);process.exit(1);});
