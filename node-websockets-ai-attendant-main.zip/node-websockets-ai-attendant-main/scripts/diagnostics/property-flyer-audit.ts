/**
 * Property flyer-attachment audit — read-only.
 *
 * Answers, across all Property__c records:
 *   - how many have at least one attached file (modern Files / ContentDocument),
 *   - how many have a file whose name contains "flyer" (so we can tell flyers
 *     apart from other docs),
 *   - whether flyer naming is consistent, and which properties have files but
 *     NO flyer-named file (i.e. can't be auto-identified yet).
 *
 * Safe to run without approval.
 *   npx tsx --env-file .env.local scripts/diagnostics/property-flyer-audit.ts
 *   npx tsx --env-file .env.local scripts/diagnostics/property-flyer-audit.ts --list-missing  # list props w/ files but no flyer
 */

import { sfClient } from '../../src/integrations/sf-client';

const LIST_MISSING = process.argv.includes('--list-missing');
const FLYER_RE = /flyer/i;

function chunk<T>(arr: T[], n: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}

async function main() {
  const sf = (await sfClient('prod')) as any;

  const props: any[] = await sf.soql(`SELECT Id, Name FROM Property__c`);
  const nameById = new Map<string, string>(props.map((p) => [p.Id, p.Name]));
  console.log(`\n📄 Flyer audit over ${props.length} Property__c records\n`);

  // 1. ContentDocumentLinks: property → document ids.
  const docsByProp = new Map<string, string[]>(); // propId → contentDocumentIds
  const allDocIds = new Set<string>();
  for (const ids of chunk(props.map((p) => p.Id), 150)) {
    const inList = ids.map((i) => `'${i}'`).join(',');
    const links: any[] = await sf.soql(
      `SELECT LinkedEntityId, ContentDocumentId FROM ContentDocumentLink WHERE LinkedEntityId IN (${inList})`
    );
    for (const l of links) {
      if (!l.LinkedEntityId?.startsWith('a')) continue; // only property links (skip user/feed links)
      const arr = docsByProp.get(l.LinkedEntityId) || [];
      arr.push(l.ContentDocumentId);
      docsByProp.set(l.LinkedEntityId, arr);
      allDocIds.add(l.ContentDocumentId);
    }
  }

  // 2. ContentVersion (latest) for those docs: title + original filename + type.
  const verByDoc = new Map<string, { title: string; path: string; ext: string; size: number }>();
  for (const ids of chunk([...allDocIds], 150)) {
    const inList = ids.map((i) => `'${i}'`).join(',');
    const vers: any[] = await sf.soql(
      `SELECT ContentDocumentId, Title, PathOnClient, FileExtension, ContentSize
       FROM ContentVersion WHERE ContentDocumentId IN (${inList}) AND IsLatest = true`
    );
    for (const v of vers) {
      verByDoc.set(v.ContentDocumentId, {
        title: v.Title || '', path: v.PathOnClient || '', ext: (v.FileExtension || '').toLowerCase(), size: v.ContentSize || 0,
      });
    }
  }

  // 3. Aggregate. The "flyer" convention lives in the ORIGINAL filename
  // (PathOnClient), e.g. "<ADDR>-<AGENT>-FLYER.pdf". Title is often a clean address.
  let withAnyFile = 0, withFlyer = 0, filesButNoFlyer = 0;
  let totalFiles = 0, flyerFiles = 0, cleanFlyer = 0, messyFlyer = 0, pdfFiles = 0;
  const extCounts = new Map<string, number>();
  const flyerNameSamples: string[] = [];
  const nonFlyerPdfSamples: string[] = [];
  const messySamples: string[] = [];
  const missingFlyerProps: { id: string; name: string; files: string[] }[] = [];

  const fname = (v: { title: string; path: string; ext: string }) =>
    (v.path || (v.title + (v.ext ? '.' + v.ext : ''))); // prefer the real upload filename

  for (const p of props) {
    const docIds = docsByProp.get(p.Id) || [];
    if (docIds.length === 0) continue;
    withAnyFile++;
    let propHasFlyer = false;
    const fileNames: string[] = [];
    for (const d of docIds) {
      const v = verByDoc.get(d);
      if (!v) continue;
      totalFiles++;
      const display = fname(v);
      fileNames.push(display);
      extCounts.set(v.ext || '(none)', (extCounts.get(v.ext || '(none)') || 0) + 1);
      if (v.ext === 'pdf') pdfFiles++;
      const isFlyer = FLYER_RE.test(v.title) || FLYER_RE.test(v.path);
      if (isFlyer) {
        flyerFiles++; propHasFlyer = true;
        // "clean" = ends in -FLYER.pdf (the dominant convention); else messy (typos, doubled ext, mid-name)
        if (/-flyer\.pdf$/i.test(display)) { cleanFlyer++; if (flyerNameSamples.length < 18) flyerNameSamples.push(display); }
        else { messyFlyer++; if (messySamples.length < 18) messySamples.push(display); }
      } else if (v.ext === 'pdf' && nonFlyerPdfSamples.length < 18) {
        nonFlyerPdfSamples.push(display);
      }
    }
    if (propHasFlyer) withFlyer++;
    else { filesButNoFlyer++; missingFlyerProps.push({ id: p.Id, name: p.Name, files: fileNames }); }
  }

  const pct = (n: number) => `${((n / props.length) * 100).toFixed(0)}%`;
  console.log(`Properties with ≥1 attached file:        ${withAnyFile} (${pct(withAnyFile)})`);
  console.log(`Properties with a "flyer"-named file:     ${withFlyer} (${pct(withFlyer)})`);
  console.log(`Properties with files but NO flyer name:  ${filesButNoFlyer}`);
  console.log(`Properties with NO files at all:          ${props.length - withAnyFile}`);
  console.log(`\nTotal files: ${totalFiles}  (PDFs: ${pdfFiles})`);
  console.log(`Flyer-named files: ${flyerFiles}  →  clean "-FLYER.pdf": ${cleanFlyer}  |  messy/typo/other: ${messyFlyer}`);
  console.log(`\nFile types:`);
  for (const [ext, c] of [...extCounts].sort((a, b) => b[1] - a[1])) console.log(`   ${ext.padEnd(8)} ${c}`);

  console.log(`\nClean "-FLYER.pdf" examples:`);
  for (const s of flyerNameSamples) console.log(`   ✓ ${s}`);
  console.log(`\nMessy flyer names (have "flyer" but inconsistent — typos / doubled .pdf / mid-name):`);
  for (const s of messySamples) console.log(`   ⚠️ ${s}`);
  console.log(`\nPDFs with NO "flyer" in the name (could be flyers OR other docs — ambiguous):`);
  for (const s of nonFlyerPdfSamples) console.log(`   ? ${s}`);

  if (LIST_MISSING) {
    const { writeFile } = await import('fs/promises');
    const csv = ['Name,SF_Id,Attached_Files,Likely_Flyer_Guess']
      .concat(missingFlyerProps.map((m) => {
        // guess: a single PDF named like the address is probably the flyer
        const pdfs = m.files.filter((f) => /\.pdf$/i.test(f));
        const guess = pdfs.length === 1 ? pdfs[0] : '';
        return [m.name, m.id, m.files.join(' | '), guess].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',');
      }));
    const path = 'data/flyer-missing-2026-06-22.csv';
    await writeFile(path, csv.join('\n'));
    console.log(`\n📄 ${missingFlyerProps.length} properties with files but no flyer-named file → ${path}`);
    console.log(`   (Likely_Flyer_Guess filled when there's exactly one PDF — confirm, then rename.)`);
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
