/**
 * Add Group__c (lookup) to the Lead page layouts so agents can set Group
 * directly when creating or editing a lead. Required behavior — fixes the
 * orphan-on-create problem at the source.
 *
 * Last night I removed Group_old2__c (legacy text). It turns out Group__c
 * (the new lookup) was NEVER on these layouts, so now agents have no Group
 * field at all. This adds it.
 *
 * Etico Lead Layout is left alone — apartments workflow doesn't use Groups.
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;
const FIELD = 'Group__c';
const TARGET_LAYOUTS = ['Lead Layout']; // Skip Etico Lead Layout

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  const layouts: any[] = await (sf as any).toolingQuery(
    `SELECT Id, Name FROM Layout WHERE EntityDefinition.QualifiedApiName = 'Lead'`
  );
  for (const l of layouts) {
    if (!TARGET_LAYOUTS.includes(l.Name)) { console.log(`SKIP: ${l.Name} (${l.Id})`); continue; }
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);

    const full: any = await toolingGet(sf, 'Layout', l.Id);
    const meta = full.Metadata || {};
    const sections = (meta.layoutSections || []) as any[];

    // Already present?
    let alreadyPresent = false;
    for (const s of sections) for (const col of s.layoutColumns || []) for (const item of col.layoutItems || []) {
      if (item.field === FIELD) alreadyPresent = true;
    }
    if (alreadyPresent) { console.log(`  ✓ ${FIELD} already on layout — skip`); continue; }

    // Insert into "Lead Information" section (first section that has that label),
    // in the FIRST column, right after Company.
    const leadInfoIdx = sections.findIndex((s: any) => /lead information/i.test(s.label || ''));
    if (leadInfoIdx === -1) { console.log(`  ✗ "Lead Information" section not found — manual add needed`); continue; }
    const newItem = {
      analyticsCloudComponent: null,
      behavior: 'Required',
      canvas: null,
      component: null,
      customLink: null,
      emptySpace: null,
      field: FIELD,
      height: null,
      page: null,
      reportChartComponent: null,
      scontrol: null,
      showLabel: null,
      showScrollbars: null,
      width: null,
    };

    // Clone section and inject into first column
    const newSections = sections.map((s: any, sIdx: number) => {
      if (sIdx !== leadInfoIdx) return s;
      const cols = (s.layoutColumns || []);
      const newCols = cols.map((col: any, cIdx: number) => {
        if (cIdx !== 0) return col;
        const items = col.layoutItems || [];
        // Insert after Company if present, else at end
        const companyIdx = items.findIndex((it: any) => it.field === 'Company');
        const newItems = [...items];
        if (companyIdx >= 0) newItems.splice(companyIdx + 1, 0, newItem);
        else newItems.push(newItem);
        return { ...col, layoutItems: newItems };
      });
      return { ...s, layoutColumns: newCols };
    });

    console.log(`  Plan: insert ${FIELD} (Required) into "Lead Information" section, col 1, after Company`);
    if (DRY) continue;
    await toolingPatch(sf, 'Layout', l.Id, { Metadata: { layoutSections: newSections } });
    console.log(`  ✓ PATCH succeeded`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
