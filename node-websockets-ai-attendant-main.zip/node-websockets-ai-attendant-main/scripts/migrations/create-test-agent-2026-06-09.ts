/**
 * Create a test user on the Account for Agents profile to verify whether
 * the Classic-switcher issue is fixed for that profile.
 *
 * Idempotent — won't create if a user with the same username already exists.
 *
 *   npx tsx --env-file .env.local scripts/migrations/create-test-agent-2026-06-09.ts
 *   npx tsx --env-file .env.local scripts/migrations/create-test-agent-2026-06-09.ts --apply
 */
import { sfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const TEST_USER = {
  username: 'classic.test.agent@faustocommercial.com.test', // unique across all SF
  email: 'jesus.wmr+testagent@gmail.com',
  firstName: 'Classic',
  lastName: 'Test Agent',
  alias: 'classict',  // ≤ 8 chars
  profileName: 'Account for Agents',
  timeZoneSidKey: 'America/New_York',
  localeSidKey: 'en_US',
  emailEncodingKey: 'UTF-8',
  languageLocaleKey: 'en_US',
};

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // Existing?
  const existing: any[] = await sf.soql(
    `SELECT Id, Name, IsActive FROM User WHERE Username = '${TEST_USER.username}'`
  );
  if (existing.length) {
    console.log(`  ✓ Test user already exists: ${existing[0].Id}  active=${existing[0].IsActive}`);
    return;
  }

  // Profile lookup
  const profs: any[] = await sf.soql(
    `SELECT Id FROM Profile WHERE Name = '${TEST_USER.profileName}' LIMIT 1`
  );
  if (!profs.length) { console.error(`Profile not found`); process.exit(1); }
  const profileId = profs[0].Id;

  // License capacity check
  const lic: any[] = await sf.soql(
    `SELECT Name, TotalLicenses, UsedLicenses FROM UserLicense WHERE Name = 'Salesforce'`
  );
  const seat = lic[0];
  if (seat.UsedLicenses >= seat.TotalLicenses) {
    console.error(`Salesforce license pool is full (${seat.UsedLicenses}/${seat.TotalLicenses})`);
    process.exit(1);
  }
  console.log(`✓ Salesforce license seat available: ${seat.UsedLicenses}/${seat.TotalLicenses}`);

  const payload = {
    Username: TEST_USER.username,
    Email: TEST_USER.email,
    FirstName: TEST_USER.firstName,
    LastName: TEST_USER.lastName,
    Alias: TEST_USER.alias,
    ProfileId: profileId,
    TimeZoneSidKey: TEST_USER.timeZoneSidKey,
    LocaleSidKey: TEST_USER.localeSidKey,
    EmailEncodingKey: TEST_USER.emailEncodingKey,
    LanguageLocaleKey: TEST_USER.languageLocaleKey,
    IsActive: true,
    UserPreferencesHideS1BrowserUI: false,  // <-- the key: don't hide Classic switcher
  };
  console.log('\nPlanned create:');
  console.log(JSON.stringify(payload, null, 2));

  if (DRY) {
    console.log('\nDry-run complete. Re-run with --apply.');
    return;
  }

  const id = await sf.create('User', payload);
  console.log(`\n✓ Created User ${id}`);
  console.log(`  Username: ${TEST_USER.username}`);
  console.log(`  Email: ${TEST_USER.email}`);
  console.log(`  Profile: ${TEST_USER.profileName}`);
  console.log(`  Watch your inbox for the SF welcome email — click the link to set password.`);
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
