/**
 * Salesforce integration service.
 *
 * - Fetches Property__c records and User records (agents) at startup
 * - Caches in memory, refreshes every 4 hours
 * - Creates leads directly via SF REST API (fire-and-forget, no call latency)
 * - Falls back to Make.com webhook if MAKE_WEBHOOK_URL is set
 *
 * Auth: OAuth 2.0 Client Credentials flow (server-to-server).
 * Env vars needed:
 *   SF_LOGIN_URL       — https://your-org.my.salesforce.com (custom domain, NOT login.salesforce.com)
 *   SF_CLIENT_ID       — Connected App consumer key
 *   SF_CLIENT_SECRET   — Connected App consumer secret
 *   MAKE_WEBHOOK_URL   — (optional, legacy) Make.com webhook URL for lead creation
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface SFProperty {
  id: string;
  name: string; // Property Name (Name field)
  marketingName: string | null; // Marketing_Name__c
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  county: string | null;
  neighborhood: string | null;
  propertyType: string | null; // Multi-select picklist, comma-separated
  listingType: string | null; // Sale, Lease, etc.
  status: string | null;
  price: number | null;
  expectedPrice: number | null;
  buildingSqft: number | null;
  lotSqft: number | null;
  lotAcres: number | null;
  units: number | null;
  yearBuilt: string | null;
  zoning: string | null;
  description: string | null;
  locationNotes: string | null;
  listingAgentId: string | null;
  listingAgentName: string | null;
  secondaryAgentId: string | null;
  secondaryAgentName: string | null;
  pricing: string | null; // Pricing picklist
  tags: string | null;
  publicUrl: string | null;
  photoUrl: string | null;
  loopnetId: string | null;
  notesForMarketing: string | null;
}

export interface SFAgent {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
}

export interface LeadCreateData {
  firstName?: string;
  lastName: string;
  phone: string;
  propertyId?: string;
  propertyName?: string;
  interest?: string;
  notes?: string;
  leadSource?: string;
  // Enrichment fields
  propertyType?: string;   // e.g. "Multi-Family", "Retail", "Industrial"
  city?: string;           // e.g. "Miami", "Fort Lauderdale"
  intent?: string;         // "Buyer Lead" or "Owner Lease Lead"
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || 'https://login.salesforce.com';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';
const MAKE_WEBHOOK_URL = process.env.MAKE_WEBHOOK_URL || '';

const REFRESH_INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 hours

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

let accessToken = '';
let instanceUrl = '';
let properties: SFProperty[] = [];
let agents: SFAgent[] = [];
let lastRefresh = 0;
let refreshTimer: NodeJS.Timeout | null = null;

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

async function authenticate(): Promise<void> {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET) {
    console.warn(
      '⚠️ Salesforce configuration missing: SF_CLIENT_ID, SF_CLIENT_SECRET'
    );
    return;
  }

  const params = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: SF_CLIENT_ID.trim(),
    client_secret: SF_CLIENT_SECRET.trim(),
  });

  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
  });

  if (!res.ok) {
    const err = await res.text();
    console.error(`❌ Salesforce Auth Failed (${res.status}): ${err}`);
    throw new Error(`Salesforce auth failed: ${res.status} ${err}`);
  }

  const data = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  accessToken = data.access_token;
  instanceUrl = data.instance_url;
  console.log(`🔐 Salesforce authenticated successfully: ${instanceUrl}`);
}

// ---------------------------------------------------------------------------
// SOQL query helper
// ---------------------------------------------------------------------------

async function soqlQuery<T = any>(query: string): Promise<T[]> {
  // SF returns at most ~200-2000 records per response (heap-limited).
  // For larger result sets it includes a `nextRecordsUrl` we must follow.
  //
  // BUG HISTORY: this used to only fetch the first batch, silently truncating
  // larger result sets. Result: the in-memory cache was missing ~64 of 314
  // active Property__c records (~20% gone). That bug invisibly shrunk:
  //   - the agent /review dashboard (agents saw fewer listings than they had)
  //   - the voice handler's property search (callers couldn't find listings)
  // Now paginates fully via nextRecordsUrl.
  let url: string | null = `${instanceUrl}/services/data/v59.0/query?q=${encodeURIComponent(query)}`;
  const all: T[] = [];

  while (url) {
    let res = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });

    if (res.status === 401) {
      // Token expired — re-auth and retry the same page once
      await authenticate();
      res = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
    }
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`SOQL query failed: ${res.status} ${err}`);
    }

    const data = (await res.json()) as {
      records?: T[];
      nextRecordsUrl?: string;
      done?: boolean;
    };
    if (data.records) all.push(...data.records);
    url = data.nextRecordsUrl ? `${instanceUrl}${data.nextRecordsUrl}` : null;
  }

  return all;
}

// ---------------------------------------------------------------------------
// REST API helper (POST/PATCH to SF objects)
// ---------------------------------------------------------------------------

async function sfApiRequest(
  path: string,
  method: 'POST' | 'PATCH',
  body: Record<string, unknown>
): Promise<{ ok: boolean; id?: string; error?: string }> {
  const url = `${instanceUrl}/services/data/v59.0${path}`;
  const doRequest = async () => {
    const res = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    return res;
  };

  let res = await doRequest();

  // Token expired — re-auth and retry once
  if (res.status === 401) {
    await authenticate();
    res = await doRequest();
  }

  if (!res.ok) {
    const err = await res.text();
    return { ok: false, error: `${res.status} ${err}` };
  }

  // 201 Created returns { id, ... }; 204 No Content returns nothing
  if (res.status === 204) return { ok: true };
  const data = (await res.json()) as { id?: string };
  return { ok: true, id: data.id };
}

// ---------------------------------------------------------------------------
// Fetch properties
// ---------------------------------------------------------------------------

async function fetchProperties(): Promise<SFProperty[]> {
  const query = `
    SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c, 
           Zip_Code__c, County__c, Neighborhood__c, Property_Type__c,
           Listing_Type__c, Status__c, Price__c, Expected_Sales_Lease_Price__c,
           Building_Size_sqft__c, Lot_Size_sqft__c, Units__c, Year_Built__c,
           Zoning__c, Description__c, Location_Notes__c,
           Listing_Agent__c, Listing_Agent__r.Name,
           Secondary_Agent__c, Secondary_Agent__r.Name,
           Pricing__c, Tag_s__c, Public_URL__c, Photo_URL__c, Loopnet_ID__c,
           Notes_for_Marketing__c
    FROM Property__c
    WHERE Status__c = 'Active'
    ORDER BY Name
  `.trim();

  const records = await soqlQuery(query);

  return records.map((r: any) => {
    const lotSqftRaw: number | null = r.Lot_Size_sqft__c || null;
    // 1 acre = 43,560 sqft. Compute acres from sqft so callers and Claude can
    // reason about either unit without us needing a separate SF acres field.
    const lotAcres: number | null = lotSqftRaw ? lotSqftRaw / 43_560 : null;

    return {
    id: r.Id,
    name: r.Name || '',
    marketingName: r.Marketing_Name__c || null,
    address: r.Address__c || null,
    city: r.City__c || null,
    state: r.State__c || null,
    zipCode: r.Zip_Code__c || null,
    county: r.County__c || null,
    neighborhood: r.Neighborhood__c || null,
    propertyType: r.Property_Type__c || null,
    listingType: r.Listing_Type__c || null,
    status: r.Status__c || null,
    price: r.Price__c || null,
    expectedPrice: r.Expected_Sales_Lease_Price__c || null,
    buildingSqft: r.Building_Size_sqft__c || null,
    lotSqft: lotSqftRaw,
    lotAcres,
    units: r.Units__c || null,
    yearBuilt: r.Year_Built__c || null,
    zoning: r.Zoning__c || null,
    description: r.Description__c || null,
    locationNotes: r.Location_Notes__c || null,
    listingAgentId: r.Listing_Agent__c || null,
    listingAgentName: r.Listing_Agent__r?.Name || null,
    secondaryAgentId: r.Secondary_Agent__c || null,
    secondaryAgentName: r.Secondary_Agent__r?.Name || null,
    pricing: r.Pricing__c || null,
    tags: r.Tag_s__c || null,
    publicUrl: r.Public_URL__c || null,
    photoUrl: r.Photo_URL__c || null,
    loopnetId: r.Loopnet_ID__c || null,
    notesForMarketing: r.Notes_for_Marketing__c || null,
    };
  });
}

// ---------------------------------------------------------------------------
// Fetch agents (Users who are active)
// ---------------------------------------------------------------------------

async function fetchAgents(): Promise<SFAgent[]> {
  const query = `
    SELECT Id, Name, Email, Phone
    FROM User
    WHERE IsActive = true
      AND Profile.Name != 'Chatter Free User'
    ORDER BY Name
  `.trim();

  const records = await soqlQuery(query);

  return records.map((r: any) => ({
    id: r.Id,
    name: r.Name || '',
    email: r.Email || null,
    phone: r.Phone || null,
  }));
}

// ---------------------------------------------------------------------------
// Initialize and refresh
// ---------------------------------------------------------------------------

export async function initSalesforce(): Promise<void> {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET) {
    console.warn('⚠️ Salesforce not configured — skipping data fetch');
    console.warn('   Set SF_CLIENT_ID, SF_CLIENT_SECRET, SF_LOGIN_URL');
    return;
  }

  try {
    await authenticate();
    await refreshData();

    // Auto-refresh every 4 hours to keep data reasonably fresh without hitting API limits
    refreshTimer = setInterval(() => {
      refreshData().catch((err) => console.error('SF refresh error:', err));
    }, REFRESH_INTERVAL_MS);

    console.log(
      `🔄 Salesforce auto-refresh every ${REFRESH_INTERVAL_MS / 3600000} hours`
    );
  } catch (err) {
    console.error('❌ Salesforce init failed:', err);
    console.warn(
      '   Falling back to empty data. Check credentials and try again.'
    );
  }
}

async function refreshData(): Promise<void> {
  const t0 = Date.now();
  const [props, ags] = await Promise.all([fetchProperties(), fetchAgents()]);
  properties = props;
  agents = ags;
  lastRefresh = Date.now();

  // Push SF data into the listings module so search_properties uses live data
  try {
    const { setProperties: setListingProps, isShareableListingUrl } = await import('./listings');
    setListingProps(
      props.map((p) => ({
        id: p.id,
        name: p.marketingName || p.name,
        address: p.address || '',
        city: p.city || '',
        state: p.state || '',
        zipCode: p.zipCode || '',
        neighborhood: p.neighborhood || undefined,
        propertyType: p.propertyType || '',
        listingType: p.listingType || '',
        price: p.price || undefined,
        buildingSqft: p.buildingSqft || undefined,
        lotSqft: p.lotSqft || undefined,
        lotAcres: p.lotAcres || undefined,
        units: p.units || undefined,
        yearBuilt: p.yearBuilt || undefined,
        zoning: p.zoning || undefined,
        description: p.description?.slice(0, 250) || undefined,
        locationNotes: p.locationNotes?.slice(0, 150) || undefined,
        listingAgent: p.listingAgentName || undefined,
        secondaryAgent: p.secondaryAgentName || undefined,
        tags: p.tags || undefined,
        pricing: p.pricing || undefined,
        canText: isShareableListingUrl(p.publicUrl),
      }))
    );
  } catch (err) {
    console.error('Failed to sync SF data to listings:', err);
  }

  console.log(
    `📊 Salesforce data refreshed: ${properties.length} properties, ${agents.length} agents (${Date.now() - t0}ms)`
  );
}

// ---------------------------------------------------------------------------
// Fetch a single Property__c by ID — used by the WP sync webhook handler
// ---------------------------------------------------------------------------

/** Subset of Property__c needed for WP sync. Includes the link-back fields. */
export interface SFPropertyForSync {
  id: string;
  name: string;
  marketingName: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  county: string | null;
  propertyType: string | null;
  listingType: string | null;
  status: string | null;
  price: number | null;
  buildingSqft: number | null;
  lotSqft: number | null;
  units: string | null;
  yearBuilt: string | null;
  zoning: string | null;
  description: string | null;
  pricing: string | null;
  publicUrl: string | null;
  wpPostId: number | null;
  /** Listing agent's email — used as the email reply-to so replies reach the agent. */
  listingAgentEmail?: string | null;
}

export async function fetchPropertyForSync(
  propertyId: string
): Promise<SFPropertyForSync | null> {
  if (!accessToken || !instanceUrl) {
    console.warn('⚠️ SF not connected — cannot fetch property');
    return null;
  }

  // Escape single quotes to prevent SOQL injection
  const safeId = propertyId.replace(/'/g, "\\'");
  const query = `
    SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c,
           Zip_Code__c, County__c, Property_Type__c, Listing_Type__c, Status__c,
           Price__c, Building_Size_sqft__c, Lot_Size_sqft__c, Units__c,
           Year_Built__c, Zoning__c, Description__c, Pricing__c,
           Public_URL__c, WP_Post_ID__c, Listing_Agent__r.Email
    FROM Property__c
    WHERE Id = '${safeId}'
    LIMIT 1
  `.trim();

  const records = await soqlQuery<any>(query);
  if (records.length === 0) return null;

  const r = records[0];
  return {
    id: r.Id,
    name: r.Name || '',
    marketingName: r.Marketing_Name__c || null,
    address: r.Address__c || null,
    city: r.City__c || null,
    state: r.State__c || null,
    zipCode: r.Zip_Code__c || null,
    county: r.County__c || null,
    propertyType: r.Property_Type__c || null,
    listingType: r.Listing_Type__c || null,
    status: r.Status__c || null,
    price: r.Price__c ?? null,
    buildingSqft: r.Building_Size_sqft__c ?? null,
    lotSqft: r.Lot_Size_sqft__c ?? null,
    units: r.Units__c || null,
    yearBuilt: r.Year_Built__c || null,
    zoning: r.Zoning__c || null,
    description: r.Description__c || null,
    pricing: r.Pricing__c || null,
    publicUrl: r.Public_URL__c || null,
    wpPostId: r.WP_Post_ID__c ?? null,
    listingAgentEmail: r.Listing_Agent__r?.Email || null,
  };
}

// ---------------------------------------------------------------------------
// Update a single field on a Property__c record
// ---------------------------------------------------------------------------

export async function updatePropertyField(
  propertyId: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  if (!accessToken || !instanceUrl) {
    console.warn('⚠️ SF not connected — cannot update property');
    return { ok: false, error: 'SF not connected' };
  }
  try {
    const result = await sfApiRequest(
      `/sobjects/Property__c/${propertyId}`,
      'PATCH',
      fields
    );
    if (result.ok) return { ok: true };
    return { ok: false, error: result.error || 'Unknown error' };
  } catch (err: any) {
    const msg = err?.message || String(err);
    console.error(`❌ Failed to update Property__c ${propertyId}:`, msg);
    return { ok: false, error: msg };
  }
}

// ---------------------------------------------------------------------------
// Getters
// ---------------------------------------------------------------------------

export function getProperties(): SFProperty[] {
  return properties;
}

export function getAgents(): SFAgent[] {
  return agents;
}

export function getLastRefresh(): number {
  return lastRefresh;
}

// formatPropertiesForPrompt removed — listings.ts now provides getListingSummary() + search_properties tool

// ---------------------------------------------------------------------------
// Create lead — direct Salesforce REST API
// ---------------------------------------------------------------------------

/**
 * Fire-and-forget lead creation directly in Salesforce.
 * Falls back to Make.com webhook if SF credentials are missing.
 * Does NOT block the phone call — errors are logged but don't affect the caller.
 */
export async function createLead(data: LeadCreateData): Promise<void> {
  // If SF is not configured, fall back to Make.com webhook
  if (!accessToken || !instanceUrl) {
    if (MAKE_WEBHOOK_URL) {
      return createLeadViaMakeWebhook(data);
    }
    console.warn('⚠️ No Salesforce connection or Make.com URL — lead logged locally only');
    console.log('📋 Lead data (local only):', JSON.stringify(data, null, 2));
    return;
  }

  try {
    const sfLead: Record<string, unknown> = {
      LastName: data.lastName,
      Company: data.propertyName || 'General Inquiry',
      Phone: data.phone,
      LeadSource: data.leadSource || 'AI Phone Attendant',
      Description: [
        data.interest ? `Interest: ${data.interest}` : '',
        data.notes ? `Notes: ${data.notes}` : '',
        data.propertyName ? `Property: ${data.propertyName}` : '',
      ]
        .filter(Boolean)
        .join('\n'),
    };

    if (data.firstName) sfLead.FirstName = data.firstName;

    // Lead enrichment — intent & asset categorization
    if (data.intent) {
      // Map to SF picklist: "Buyer Lead", "Owner Lease Lead"
      const intentMap: Record<string, string> = {
        buy: 'Buyer Lead',
        purchase: 'Buyer Lead',
        lease: 'Owner Lease Lead',
        rent: 'Owner Lease Lead',
      };
      const mapped = intentMap[data.intent.toLowerCase()] || data.intent;
      sfLead.Lead_Intent__c = mapped;
    }
    if (data.city) {
      // Map to SF picklist: "MIA", "JAX"
      const cityMap: Record<string, string> = {
        miami: 'MIA', hialeah: 'MIA', doral: 'MIA', 'coral gables': 'MIA',
        hollywood: 'MIA', 'fort lauderdale': 'MIA', 'pompano beach': 'MIA',
        homestead: 'MIA', 'miami beach': 'MIA', medley: 'MIA',
        jacksonville: 'JAX',
      };
      sfLead.Interested_City__c = cityMap[data.city.toLowerCase()] || '';
    }
    // Property type goes in Description (no matching SF picklist for asset types)
    if (data.propertyType) {
      sfLead.Description = `Asset Type: ${data.propertyType}\n${sfLead.Description || ''}`;
    }

    console.log(
      `📤 [SF] Creating lead: ${data.firstName || ''} ${data.lastName} → ${data.propertyName || 'general'}`
    );

    const result = await sfApiRequest('/sobjects/Lead/', 'POST', sfLead);

    if (result.ok) {
      console.log(`✅ Lead created in Salesforce: ${result.id}`);
    } else {
      console.error(`❌ Salesforce lead creation failed: ${result.error}`);
      // Fall back to Make.com if SF write fails
      if (MAKE_WEBHOOK_URL) {
        console.log('   ↳ Falling back to Make.com webhook...');
        await createLeadViaMakeWebhook(data);
      }
    }
  } catch (err) {
    // Fire-and-forget — don't crash the call
    console.error('❌ Salesforce lead creation error:', err);
    if (MAKE_WEBHOOK_URL) {
      console.log('   ↳ Falling back to Make.com webhook...');
      await createLeadViaMakeWebhook(data).catch(() => {});
    }
  }
}

// ---------------------------------------------------------------------------
// Make.com webhook fallback (legacy)
// ---------------------------------------------------------------------------

async function createLeadViaMakeWebhook(data: LeadCreateData): Promise<void> {
  try {
    const payload = {
      firstName: data.firstName || '',
      lastName: data.lastName,
      phone: data.phone,
      propertyId: data.propertyId || '',
      propertyName: data.propertyName || '',
      interest: data.interest || '',
      notes: data.notes || '',
      leadSource: data.leadSource || 'AI Phone Attendant',
      timestamp: new Date().toISOString(),
    };

    console.log(
      `📤 Sending lead to Make.com: ${data.firstName || ''} ${data.lastName} → ${data.propertyName || 'general'}`
    );

    const res = await fetch(MAKE_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      console.error(
        `❌ Make.com webhook failed: ${res.status} ${await res.text()}`
      );
    } else {
      console.log(`✅ Lead sent to Make.com successfully`);
    }
  } catch (err) {
    console.error('❌ Make.com webhook error:', err);
  }
}
