/**
 * Salesforce full-org export — SPIKE / proof-of-concept (2026-06-21).
 *
 * WHY THIS EXISTS
 * ---------------
 * Production is Professional Edition. PE's *native* scheduled Data Export is
 * capped at MONTHLY, and the export ZIPs aren't cleanly API-fetchable. This
 * script sidesteps that entirely: it's just SOQL reads (no PE export limit),
 * so we can back up on any cadence we want and own the output format.
 *
 * WHAT IT DOES
 * ------------
 *   1. Global-describe the org, pick every queryable custom object (__c) plus a
 *      core set of standard objects.
 *   2. For each, describe → build a SELECT of all scalar fields → page through
 *      all records.
 *   3. Report per-object record counts + JSON byte sizes (always).
 *   4. With --write, dump each object to ./backups/<timestamp>/<Object>.json
 *      and a manifest.json summarizing the run.
 *
 * WHAT IT IS NOT (yet)
 * --------------------
 *   - No object storage (R2/B2) upload — that's the real build.
 *   - No scheduling (GitHub Action / cron) — real build.
 *   - No files/attachments (ContentVersion Body is binary; skipped here).
 *   - No restore tooling — and a backup you can't restore is theoretical.
 *
 * USAGE
 * -----
 *   npx tsx scripts/backup/sf-export.ts                  # dry-run: counts + sizes only
 *   npx tsx scripts/backup/sf-export.ts --write          # actually write JSON locally
 *   npx tsx scripts/backup/sf-export.ts --objects=Lead,Account__c
 *   npx tsx scripts/backup/sf-export.ts --limit=5        # cap rows/object (smoke test)
 *
 * Read-only against prod. Safe to run without approval.
 */

import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { sfClient } from '../../src/integrations/sf-client';

// --- args -------------------------------------------------------------------
const args = process.argv.slice(2);
const WRITE = args.includes('--write');
const objectsArg = args.find((a) => a.startsWith('--objects='))?.split('=')[1];
const ONLY = objectsArg ? new Set(objectsArg.split(',').map((s) => s.trim())) : null;
const limitArg = args.find((a) => a.startsWith('--limit='))?.split('=')[1];
const ROW_LIMIT = limitArg ? parseInt(limitArg, 10) : null;

// Standard objects worth backing up in this org (custom __c are auto-included).
const STANDARD_KEEP = new Set([
  'Lead', 'Account', 'Contact', 'Task', 'Event',
  'Opportunity', 'Campaign', 'CampaignMember', 'User',
]);

// Skip noisy / system / binary sobjects even if queryable.
const SKIP_SUFFIX = ['__Share', '__History', '__Feed', '__ChangeEvent', '__Tag', '__mdt'];
const SKIP_FIELD_TYPES = new Set(['address', 'location', 'base64']);

interface GlobalDescribe {
  sobjects: { name: string; queryable: boolean; custom: boolean }[];
}
interface FieldDescribe { name: string; type: string }

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

async function main() {
  const sf = await sfClient('prod');

  // 1. Global describe (the client has no helper for this — raw GET).
  const gdRes = await fetch(`${sf.instance}/services/data/v59.0/sobjects/`, {
    headers: { Authorization: `Bearer ${sf.token}` },
  });
  if (!gdRes.ok) throw new Error(`global describe failed: ${gdRes.status}`);
  const gd = (await gdRes.json()) as GlobalDescribe;

  const targets = gd.sobjects
    .filter((o) => o.queryable)
    .filter((o) => o.custom || STANDARD_KEEP.has(o.name))
    .filter((o) => !SKIP_SUFFIX.some((s) => o.name.endsWith(s)))
    .map((o) => o.name)
    .filter((name) => (ONLY ? ONLY.has(name) : true))
    .sort();

  console.log(`\n📦 SF export spike — ${WRITE ? 'WRITE' : 'DRY-RUN'} mode`);
  console.log(`   ${targets.length} objects targeted${ROW_LIMIT ? `, row limit ${ROW_LIMIT}` : ''}\n`);

  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const outDir = join(process.cwd(), 'backups', stamp);
  if (WRITE) await mkdir(outDir, { recursive: true });

  const manifest: { object: string; records: number; bytes: number }[] = [];
  let totalRecords = 0;
  let totalBytes = 0;

  for (const obj of targets) {
    try {
      const desc = await sf.describe(obj);
      const fields = (desc.fields as FieldDescribe[])
        .filter((f) => !SKIP_FIELD_TYPES.has(f.type))
        .map((f) => f.name);
      const soql =
        `SELECT ${fields.join(', ')} FROM ${obj}` + (ROW_LIMIT ? ` LIMIT ${ROW_LIMIT}` : '');
      const rows = await sf.soql(soql);
      const json = JSON.stringify(rows, null, WRITE ? 0 : undefined);
      const bytes = Buffer.byteLength(json);

      manifest.push({ object: obj, records: rows.length, bytes });
      totalRecords += rows.length;
      totalBytes += bytes;

      if (WRITE) await writeFile(join(outDir, `${obj}.json`), json);
      console.log(`   ✓ ${obj.padEnd(34)} ${String(rows.length).padStart(6)} rows  ${fmtBytes(bytes).padStart(10)}`);
    } catch (err: any) {
      console.log(`   ✗ ${obj.padEnd(34)} ERROR: ${err.message?.slice(0, 80)}`);
    }
  }

  console.log(`\n   ── total: ${totalRecords} records, ${fmtBytes(totalBytes)} ──`);
  if (WRITE) {
    await writeFile(
      join(outDir, 'manifest.json'),
      JSON.stringify({ stamp, totalRecords, totalBytes, objects: manifest }, null, 2)
    );
    console.log(`\n   📁 written to ${outDir}\n`);
  } else {
    console.log(`\n   (dry-run — re-run with --write to dump JSON locally)\n`);
  }
}

main().catch((e) => {
  console.error('Export failed:', e);
  process.exit(1);
});
