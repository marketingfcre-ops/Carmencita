/**
 * WordPress (Houzez) taxonomy term ID mappings.
 *
 * Ported from scripts/field_mappings.py.
 *
 * Term IDs are environment-specific to faustocommercial.com. If a new term is
 * created in WP, add it here. The "sold" entry is intentionally null until the
 * term is created in WP — see TODO below.
 */

// ---------------------------------------------------------------------------
// Property type (taxonomy: property_type)
// ---------------------------------------------------------------------------

const WP_PROPERTY_TYPE: Record<string, number> = {
  industrial: 129,
  'land development': 130,
  land: 130,
  'multi-family': 127,
  office: 126,
  retail: 128,
};

export function resolvePropertyTypes(sfType: string): number[] {
  if (!sfType) return [];
  const ids: number[] = [];
  for (const t of sfType.split(';')) {
    const tid = WP_PROPERTY_TYPE[t.trim().toLowerCase()];
    if (tid && !ids.includes(tid)) ids.push(tid);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// Property status (taxonomy: property_status)
//
// Currently only "for-sale" and "for-lease" exist in WP. The "sold" term must
// be created in WP before the Won/Lost handler can use it. See README.
// ---------------------------------------------------------------------------

const WP_PROPERTY_STATUS_BY_KEY: Record<string, number | null> = {
  'for-sale': 29,
  'for-lease': 28,
  sold: 175,
  'off-market': 176,
};

const WP_PROPERTY_STATUS_BY_LISTING_TYPE: Record<string, number> = {
  'for sale': 29,
  'for lease': 28,
};

export function resolvePropertyStatusByKey(
  key: 'for-sale' | 'for-lease' | 'sold' | 'off-market'
): number | null {
  return WP_PROPERTY_STATUS_BY_KEY[key] ?? null;
}

export function resolvePropertyStatusByListingType(
  sfListingType: string
): number[] {
  if (!sfListingType) return [];
  const tid = WP_PROPERTY_STATUS_BY_LISTING_TYPE[sfListingType.trim().toLowerCase()];
  return tid ? [tid] : [];
}

// ---------------------------------------------------------------------------
// City (taxonomy: property_city)
// ---------------------------------------------------------------------------

const WP_PROPERTY_CITY: Record<string, number> = {
  'coral springs': 149,
  'dania beach': 166,
  doral: 143,
  'fort caroline': 169,
  'fort lauderdale': 155,
  'fort myers': 170,
  hialeah: 139,
  hollywood: 141,
  homestead: 150,
  jacksonville: 167,
  miami: 102,
  'miami beach': 152,
  miramar: 164,
  'pembroke pines': 145,
  'pompano beach': 162,
};

export function resolveCity(sfCity: string): number[] {
  if (!sfCity) return [];
  const tid = WP_PROPERTY_CITY[sfCity.trim().toLowerCase()];
  return tid ? [tid] : [];
}

// ---------------------------------------------------------------------------
// State (taxonomy: property_state) — derived from County__c
// ---------------------------------------------------------------------------

const COUNTY_TO_WP_STATE: Record<string, number> = {
  'miami-dade': 137,
  broward: 134,
  duval: 168,
  lee: 171,
  'palm beach': 101, // fallback to Florida
};

const WP_FLORIDA_TERM_ID = 101;

export function resolveState(sfCounty: string): number[] {
  if (!sfCounty) return [WP_FLORIDA_TERM_ID];
  const cleaned = sfCounty.trim().toLowerCase().replace(/\s+county$/, '');
  return [COUNTY_TO_WP_STATE[cleaned] ?? WP_FLORIDA_TERM_ID];
}

// ---------------------------------------------------------------------------
// SF Property__c.Status__c → WP action mapping
//
// Picklist values (from SF describe):
//   Draft/Pre-Market, Pending, LOI Signed, Contract Signed, Closed Won, Active, Closed Lost
// ---------------------------------------------------------------------------

export type SfPropertyStatus =
  | 'Draft/Pre-Market'
  | 'Pending'
  | 'LOI Signed'
  | 'Contract Signed'
  | 'Closed Won'
  | 'Active'
  | 'Closed Lost';

export interface WpSyncAction {
  /** WP post status: publish (live), draft (hidden), private (logged-in only). */
  postStatus?: 'publish' | 'draft' | 'private';
  /** WP property_status taxonomy key — maps to a term ID via WP_PROPERTY_STATUS_BY_KEY. */
  listingStatusKey?:
    | 'for-sale'
    | 'for-lease'
    | 'sold'
    | 'off-market'
    | 'inherit-from-listing-type';
}

/**
 * Map an SF status to the action we take on the WP listing.
 *
 * "inherit-from-listing-type" means: derive sale/lease from Property__c.Listing_Type__c
 * — used while the property is still active in the marketing pipeline.
 */
export function mapSfStatusToWpAction(status: string): WpSyncAction {
  switch (status) {
    case 'Active':
    case 'Pending':
    case 'LOI Signed':
    case 'Contract Signed':
      return { postStatus: 'publish', listingStatusKey: 'inherit-from-listing-type' };

    case 'Closed Won':
      // We closed the deal — keep public with SOLD badge (Zillow-style trophy).
      return { postStatus: 'publish', listingStatusKey: 'sold' };

    case 'Closed Lost':
      // Per marketing: keep the listing browsable on the public site with an
      // OFF MARKET badge (Zillow-style). Historical record + SEO juice + the
      // "our own LoopNet" future use case all benefit from keeping it live.
      return { postStatus: 'publish', listingStatusKey: 'off-market' };

    case 'Draft/Pre-Market':
      return { postStatus: 'draft' };

    default:
      // Unknown future status — be safe, leave the post alone.
      return {};
  }
}
