/**
 * Add the "Lead Group Assignments" (Lead_List_Assignment__c) related list to
 * the commercial Lead Layouts so agents can see + edit assignments without
 * navigating away from the lead.
 *
 * Idempotent. Dry-run by default.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const RELATED_LIST = {
  customButtons: [],
  excludeButtons: [],
  fields: ['NAME', 'Group__c', 'Status__c', 'Approved_By__c', 'Approved_Date__c'],
  quickActions: [],
  relatedList: 'Lead_List_Assignment__c.Lead__c',
  sortField: null,
  sortOrder: null,
};

const TARGET_LAYOUTS = ['Lead Layout']; // both Lead Layout entries; skip Etico (already has)

async function toolingGet<T = any>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return res.json() as Promise<T>;
}

async function toolingPatch(sf: SfClient, sobject: string, id: string, body: any): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  const layouts: any[] = await (sf as any).toolingQuery(
    `SELECT Id, Name FROM Layout WHERE EntityDefinition.QualifiedApiName = 'Lead'`
  );
  for (const l of layouts) {
    if (!TARGET_LAYOUTS.includes(l.Name)) { console.log(`SKIP: ${l.Name} (${l.Id})`); continue; }
    console.log(`\n=== ${l.Name} (${l.Id}) ===`);
    const full: any = await toolingGet(sf, 'Layout', l.Id);
    const meta = full.Metadata || {};
    const rls = (meta.relatedLists || []) as any[];
    if (rls.some((rl: any) => rl.relatedList === RELATED_LIST.relatedList)) {
      console.log(`  ✓ Lead List Assignment already present — skip`);
      continue;
    }
    const newRls = [...rls, RELATED_LIST];
    if (DRY) {
      console.log(`  Would APPEND Lead_List_Assignment__c.Lead__c related list (current count: ${rls.length} → ${newRls.length})`);
      continue;
    }
    // Must include layoutSections too — partial PATCH on Layout rejects
    // "no sections" if layoutSections isn't sent.
    await toolingPatch(sf, 'Layout', l.Id, {
      Metadata: { layoutSections: meta.layoutSections, relatedLists: newRls },
    });
    console.log(`  ✓ PATCH succeeded (now ${newRls.length} related lists)`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
