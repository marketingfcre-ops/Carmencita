import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;

  // Lightning Record Pages (FlexiPage) for Lead
  console.log('=== Lightning Record Pages (FlexiPage) for Lead ===');
  const fp: any[] = await sf.toolingQuery(
    `SELECT Id, DeveloperName, MasterLabel, Type, EntityDefinitionId FROM FlexiPage WHERE Type IN ('RecordPage','HomePage','AppPage')`
  );
  // Lead-related ones
  const leadFp = fp.filter((f:any) => f.EntityDefinitionId === 'Lead' || f.DeveloperName.toLowerCase().includes('lead'));
  for (const f of leadFp) console.log(`  ${f.Id}  ${f.DeveloperName.padEnd(40)} type=${f.Type}  entity=${f.EntityDefinitionId}`);
  console.log(`\n(${leadFp.length} of ${fp.length} FlexiPages relate to Lead)`);

  // ProfileLayout including Lightning pages
  console.log('\n=== Profile-page assignments for Lead (via tooling) ===');
  try {
    const pl: any[] = await sf.toolingQuery(
      `SELECT Profile.Name, LayoutId, RecordTypeId
       FROM ProfileLayout
       WHERE TableEnumOrId = 'Lead' AND Profile.Name IN ('Account for Agents','System Administrator')
       ORDER BY Profile.Name`
    );
    for (const r of pl) console.log(`  ${r.Profile?.Name?.padEnd(22)} layout=${r.LayoutId}  recordType=${r.RecordTypeId || '(master)'}`);
  } catch (e:any) { console.log(`  err: ${e.message?.slice(0,150)}`); }

  // FlexiPage assignments — there's AppDefinition, ProfilePageAssignment, etc.
  // Try AppDefinitionSelector or similar
  console.log('\n=== Looking for Lightning App + FlexiPage assignment objects ===');
  for (const obj of ['AppDefinition','FlexiPageRegionInfo','AuraDefinition','LightningExperienceTheme','UiFormulaCriterion']) {
    try {
      const r: any[] = await sf.toolingQuery(`SELECT Id FROM ${obj} LIMIT 1`);
      console.log(`  ${obj}: queryable (${r.length})`);
    } catch (e:any) { console.log(`  ${obj}: not available`); }
  }

  // Check ProfileFlexiPageAssignment alternative names
  for (const obj of ['ProfileFlexiPageAssignment','LightningPageEntry']) {
    try {
      const r: any[] = await sf.toolingQuery(`SELECT Id FROM ${obj} LIMIT 1`);
      console.log(`  ${obj}: queryable`);
    } catch (e:any) { console.log(`  ${obj}: not available`); }
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
