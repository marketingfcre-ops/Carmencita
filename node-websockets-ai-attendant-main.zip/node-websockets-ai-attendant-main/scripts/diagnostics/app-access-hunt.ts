import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  // Apps + profile visibility
  console.log('=== AppMenuItem (visible apps) ===');
  try {
    const apps: any[] = await sf.soql(
      `SELECT Id, Label, Type, IsAccessible, IsVisible FROM AppMenuItem ORDER BY SortOrder LIMIT 50`
    );
    for (const a of apps) console.log(`  ${a.Type.padEnd(12)} ${(a.Label||'').padEnd(40)} access=${a.IsAccessible} visible=${a.IsVisible}`);
  } catch (e:any) { console.log(`  err: ${e.message?.slice(0,150)}`); }

  // CustomApplication metadata — uiType (Lightning vs Classic vs Aloha)
  console.log('\n=== CustomApplication uiType per app ===');
  const apps: any[] = await sf.toolingQuery(
    `SELECT Id, DeveloperName, Label FROM CustomApplication ORDER BY Label LIMIT 30`
  );
  for (const a of apps) {
    const url = `${sf.instanceUrl}/services/data/v59.0/tooling/sobjects/CustomApplication/${a.Id}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
    const full: any = await res.json();
    const m = full.Metadata || {};
    console.log(`  ${a.DeveloperName.padEnd(35)} navType=${m.navType || '(none)'}  uiType=${m.uiType || '(none)'}  defaultLandingTab=${m.defaultLandingTab || '(none)'}`);
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
