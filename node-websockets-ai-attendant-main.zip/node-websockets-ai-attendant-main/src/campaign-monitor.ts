/**
 * Campaign Monitor API client.
 *
 * Thin wrapper around the v3.3 REST API. Auth is HTTP Basic with the API key
 * as the username (password is ignored by CM but must be present).
 *
 * Docs: https://www.campaignmonitor.com/api/v3-3/
 *
 * Env:
 *   CM_API_KEY — Campaign Monitor account API key
 */

const CM_BASE = 'https://api.createsend.com/api/v3.3';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface CMClient {
  ClientID: string;
  Name: string;
}

export interface CMList {
  ListID: string;
  Name: string;
}

export interface CMListStats {
  TotalActiveSubscribers: number;
  NewActiveSubscribers: number;
  TotalUnsubscribes: number;
  NewUnsubscribes: number;
  TotalDeleted: number;
  NewDeleted: number;
  TotalBounces: number;
  NewBounces: number;
}

export interface CMCustomField {
  FieldName: string;
  Key: string; // e.g. "[LastLoopNetID]"
  DataType: 'Text' | 'Number' | 'MultiSelectOne' | 'MultiSelectMany' | 'Date' | 'Country' | 'USState';
  FieldOptions?: string[];
  VisibleInPreferenceCenter?: boolean;
}

export interface CMSubscriber {
  EmailAddress: string;
  Name: string;
  Date: string; // "YYYY-MM-DD HH:mm:ss"
  State: 'Active' | 'Unconfirmed' | 'Unsubscribed' | 'Bounced' | 'Deleted';
  CustomFields: Array<{ Key: string; Value: string }>;
  ReadsEmailWith?: string;
  ConsentToTrack?: 'Yes' | 'No' | 'Unchanged';
}

export interface CMSubscriberPage {
  Results: CMSubscriber[];
  PageNumber: number;
  PageSize: number;
  RecordsOnThisPage: number;
  TotalNumberOfRecords: number;
  NumberOfPages: number;
}

export interface CMSubscriberInput {
  EmailAddress: string;
  Name?: string;
  CustomFields?: Array<{ Key: string; Value: string; Clear?: boolean }>;
  ConsentToTrack?: 'Yes' | 'No' | 'Unchanged';
}

export interface CMImportResult {
  TotalUniqueEmailsSubmitted: number;
  TotalExistingSubscribers: number;
  TotalNewSubscribers: number;
  DuplicateEmailsInSubmission: string[];
  FailureDetails: Array<{
    EmailAddress: string;
    Code: number;
    Message: string;
  }>;
}

// ---------------------------------------------------------------------------
// Core request helper
// ---------------------------------------------------------------------------

function authHeader(apiKey: string): string {
  return 'Basic ' + Buffer.from(`${apiKey}:x`).toString('base64');
}

async function cmRequest<T>(
  apiKey: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  path: string,
  body?: unknown
): Promise<T> {
  const res = await fetch(`${CM_BASE}${path}`, {
    method,
    headers: {
      Authorization: authHeader(apiKey),
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`CM ${method} ${path} failed: ${res.status} ${text}`);
  }

  if (res.status === 204) return undefined as T;
  const text = await res.text();
  if (!text) return undefined as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    // Some endpoints (e.g. DELETE /subscribers) return a 200 with an empty or
    // plain-text body; hand that back as-is rather than throwing.
    return text as unknown as T;
  }
}

// ---------------------------------------------------------------------------
// Account / list discovery
// ---------------------------------------------------------------------------

export async function listClients(apiKey: string): Promise<CMClient[]> {
  return cmRequest<CMClient[]>(apiKey, 'GET', '/clients.json');
}

export async function listLists(apiKey: string, clientId: string): Promise<CMList[]> {
  return cmRequest<CMList[]>(apiKey, 'GET', `/clients/${clientId}/lists.json`);
}

export async function getListStats(apiKey: string, listId: string): Promise<CMListStats> {
  return cmRequest<CMListStats>(apiKey, 'GET', `/lists/${listId}/stats.json`);
}

export async function getListCustomFields(
  apiKey: string,
  listId: string
): Promise<CMCustomField[]> {
  return cmRequest<CMCustomField[]>(apiKey, 'GET', `/lists/${listId}/customfields.json`);
}

// ---------------------------------------------------------------------------
// Subscriber read
// ---------------------------------------------------------------------------

/** Fetch a single page of subscribers in one of CM's state buckets. */
export async function getSubscribersPage(
  apiKey: string,
  listId: string,
  state: 'active' | 'unconfirmed' | 'unsubscribed' | 'bounced' | 'deleted',
  page: number,
  pageSize: number = 1000
): Promise<CMSubscriberPage> {
  const q = `?pagesize=${pageSize}&page=${page}&orderfield=date&orderdirection=asc`;
  return cmRequest<CMSubscriberPage>(apiKey, 'GET', `/lists/${listId}/${state}.json${q}`);
}

/** Fetch all subscribers in a given state, paginated under the hood. */
export async function getAllSubscribers(
  apiKey: string,
  listId: string,
  state: 'active' | 'unconfirmed' | 'unsubscribed' | 'bounced' | 'deleted' = 'active'
): Promise<CMSubscriber[]> {
  const out: CMSubscriber[] = [];
  let page = 1;
  for (;;) {
    const data = await getSubscribersPage(apiKey, listId, state, page);
    out.push(...data.Results);
    if (page >= data.NumberOfPages || data.RecordsOnThisPage === 0) break;
    page++;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Subscriber write
// ---------------------------------------------------------------------------

/**
 * Batch import subscribers (max 1000 per call).
 *
 * CM returns HTTP 400 with Code 210 when *some* subscribers failed but the
 * import partially succeeded. We treat that as a successful call and return
 * the ResultData (which lists the per-subscriber failures).
 */
export async function importSubscribers(
  apiKey: string,
  listId: string,
  subscribers: CMSubscriberInput[],
  opts: {
    resubscribe?: boolean;
    queueAutoResponders?: boolean;
    restartAutoResponders?: boolean;
  } = {}
): Promise<CMImportResult> {
  const body = {
    Subscribers: subscribers,
    Resubscribe: opts.resubscribe ?? false,
    QueueSubscriptionBasedAutoResponders: opts.queueAutoResponders ?? false,
    RestartSubscriptionBasedAutoresponders: opts.restartAutoResponders ?? false,
  };
  const res = await fetch(`${CM_BASE}/subscribers/${listId}/import.json`, {
    method: 'POST',
    headers: {
      Authorization: authHeader(apiKey),
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (res.ok) return data as CMImportResult;
  // Partial-success: CM sticks the real result inside ResultData.
  if (
    res.status === 400 &&
    (data as any)?.Code === 210 &&
    (data as any)?.ResultData
  ) {
    return (data as any).ResultData as CMImportResult;
  }
  throw new Error(
    `CM import failed: ${res.status} ${JSON.stringify(data).slice(0, 500)}`
  );
}

/** Import subscribers in CM_BATCH_SIZE chunks; aggregates results. */
const CM_BATCH_SIZE = 1000;

export async function importSubscribersBatched(
  apiKey: string,
  listId: string,
  subscribers: CMSubscriberInput[],
  opts: Parameters<typeof importSubscribers>[3] = {}
): Promise<CMImportResult> {
  const agg: CMImportResult = {
    TotalUniqueEmailsSubmitted: 0,
    TotalExistingSubscribers: 0,
    TotalNewSubscribers: 0,
    DuplicateEmailsInSubmission: [],
    FailureDetails: [],
  };
  for (let i = 0; i < subscribers.length; i += CM_BATCH_SIZE) {
    const batch = subscribers.slice(i, i + CM_BATCH_SIZE);
    const r = await importSubscribers(apiKey, listId, batch, opts);
    agg.TotalUniqueEmailsSubmitted += r.TotalUniqueEmailsSubmitted;
    agg.TotalExistingSubscribers += r.TotalExistingSubscribers;
    agg.TotalNewSubscribers += r.TotalNewSubscribers;
    agg.DuplicateEmailsInSubmission.push(...r.DuplicateEmailsInSubmission);
    agg.FailureDetails.push(...r.FailureDetails);
  }
  return agg;
}

/** Remove (not unsubscribe) a subscriber from a list. */
export async function deleteSubscriber(
  apiKey: string,
  listId: string,
  email: string
): Promise<void> {
  const q = `?email=${encodeURIComponent(email)}`;
  await cmRequest<void>(apiKey, 'DELETE', `/subscribers/${listId}.json${q}`);
}

// ---------------------------------------------------------------------------
// Single subscriber add/update — for incremental sync (e.g. new buyer captured
// from a phone call → added to "Buyers Industrial" list immediately).
// ---------------------------------------------------------------------------

/**
 * Add or update a single subscriber on a list. Idempotent.
 * Use this when reacting to events; use importSubscribers for bulk loads.
 */
export async function addOrUpdateSubscriber(
  apiKey: string,
  listId: string,
  subscriber: CMSubscriberInput
): Promise<void> {
  await cmRequest<void>(apiKey, 'POST', `/subscribers/${listId}.json`, {
    EmailAddress: subscriber.EmailAddress,
    Name: subscriber.Name,
    CustomFields: subscriber.CustomFields,
    ConsentToTrack: subscriber.ConsentToTrack || 'Yes',
    Resubscribe: true,
    RestartSubscriptionBasedAutoresponders: false,
  });
}

// ---------------------------------------------------------------------------
// Smart Email (transactional) — for price-drop / new-listing notifications.
//
// CM Smart Emails are templated emails created in the CM UI; we trigger sends
// programmatically with merge data. Different endpoint from regular campaigns.
// Docs: https://www.campaignmonitor.com/api/v3-3/transactional/smart-email/
// ---------------------------------------------------------------------------

export interface CMSmartEmailRecipient {
  /** "Name <email@example.com>" or just "email@example.com" */
  to: string[];
  cc?: string[];
  bcc?: string[];
  /** Per-recipient merge data, keyed by template variable name. */
  data?: Record<string, string | number | boolean>;
}

export interface CMSmartEmailSendResult {
  MessageID: string;
  Recipient: string;
  Status: string; // 'Accepted' | 'Rejected' | etc.
}

/**
 * Send a Smart Email (templated transactional) to one or more recipients.
 *
 * @param apiKey
 * @param smartEmailId  Configured in CM UI; the template ID (UUID-like).
 * @param recipient     Single recipient with merge data.
 */
export async function sendSmartEmail(
  apiKey: string,
  smartEmailId: string,
  recipient: CMSmartEmailRecipient
): Promise<CMSmartEmailSendResult[]> {
  return cmRequest<CMSmartEmailSendResult[]>(
    apiKey,
    'POST',
    `/transactional/smartEmail/${smartEmailId}/send`,
    {
      To: recipient.to,
      CC: recipient.cc,
      BCC: recipient.bcc,
      Data: recipient.data,
      ConsentToTrack: 'Yes',
    }
  );
}

// ---------------------------------------------------------------------------
// Segments — discover and read segments on a list.
//
// We use segments for "buyers interested in [asset type]" targeting.
// Segments are defined in the CM UI; this is read-only.
// ---------------------------------------------------------------------------

export interface CMSegment {
  ListID: string;
  SegmentID: string;
  Title: string;
  ActiveSubscribers: number;
}

/** List all segments defined for a CM list. */
export async function listSegments(
  apiKey: string,
  listId: string
): Promise<CMSegment[]> {
  return cmRequest<CMSegment[]>(apiKey, 'GET', `/lists/${listId}/segments.json`);
}

// ---------------------------------------------------------------------------
// Sent campaigns — read-only reporting.
//
// The functions above sync subscribers; the marketing dashboard needs the
// *send* side: which campaigns went out in a window and how each performed.
// Docs: https://www.campaignmonitor.com/api/v3-3/campaigns/
// ---------------------------------------------------------------------------

/** One row from GET /clients/{clientid}/campaigns.json (a sent campaign). */
export interface CMSentCampaign {
  CampaignID: string;
  Name: string;
  Subject: string;
  FromName: string;
  FromEmail: string;
  ReplyTo: string;
  /** ISO-ish "YYYY-MM-DD HH:mm:ss" in the CM account's timezone. */
  SentDate: string;
  TotalRecipients: number;
  WebVersionURL: string;
  WebVersionTextURL: string;
}

/** GET /campaigns/{campaignid}/summary.json — aggregate engagement for one send. */
export interface CMCampaignSummary {
  Recipients: number;
  TotalOpened: number;
  Clicks: number;
  Unsubscribed: number;
  Bounced: number;
  UniqueOpened: number;
  Mentions: number;
  Forwards: number;
  Likes: number;
  SpamComplaints: number;
  WorldviewURL: string;
}

/** Paged envelope returned by the sent-campaigns endpoint. */
interface CMCampaignPage {
  Results: CMSentCampaign[];
  PageNumber: number;
  NumberOfPages: number;
  RecordsOnThisPage: number;
}

/**
 * List campaigns already sent for a client, newest-first (ordered by SentDate).
 *
 * The endpoint returns a *paged envelope* (`{ Results, NumberOfPages, … }`),
 * not a bare array, and there is no server-side date filter — callers filter by
 * `SentDate` for a reporting window. This follows all pages under the hood.
 */
export async function listSentCampaigns(
  apiKey: string,
  clientId: string
): Promise<CMSentCampaign[]> {
  const out: CMSentCampaign[] = [];
  let page = 1;
  for (;;) {
    const data = await cmRequest<CMCampaignPage>(
      apiKey,
      'GET',
      `/clients/${clientId}/campaigns.json?page=${page}&pagesize=1000&orderfield=sentdate&orderdirection=desc`
    );
    out.push(...(data.Results ?? []));
    if (!data.NumberOfPages || page >= data.NumberOfPages || data.RecordsOnThisPage === 0) break;
    page++;
  }
  return out;
}

/** Fetch the engagement summary for a single sent campaign. */
export async function getCampaignSummary(
  apiKey: string,
  campaignId: string
): Promise<CMCampaignSummary> {
  return cmRequest<CMCampaignSummary>(
    apiKey,
    'GET',
    `/campaigns/${campaignId}/summary.json`
  );
}
