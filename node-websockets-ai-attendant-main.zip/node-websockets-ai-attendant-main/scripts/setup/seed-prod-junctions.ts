/**
 * Add fields to the v2 junction objects in PROD.
 *
 * PREREQUISITE: the two custom OBJECT shells must already exist (created via
 * SF UI):
 *   - Lead_List_Assignment__c  (Name = Auto Number "LLA-{0000}")
 *   - User_Group_Access__c     (Name = Auto Number "UGA-{0000}")
 *
 * If they don't exist, this script fails fast with instructions.
 *
 * This script then adds (idempotently):
 *   Lead_List_Assignment__c:
 *     Lead__c           (Lookup → Lead)
 *     Group__c          (Lookup → Group__c)
 *     Status__c         (Picklist: Pending | Approved, default Pending)
 *     Approved_By__c    (Lookup → User)
 *     Approved_Date__c  (DateTime)
 *
 *   User_Group_Access__c:
 *     User__c           (Lookup → User)
 *     Group__c          (Lookup → Group__c)
 *     Status__c         (Picklist: Pending | Approved, default Pending)
 *     Approved_By__c    (Lookup → User)
 *     Approved_Date__c  (DateTime)
 *
 * Idempotent. Safe to re-run. Grants FLS on the Lead_Data_Export perm set if
 * fields need it (System Admin profile usually auto-grants, but we try anyway).
 *
 * Run: tsx --env-file .env.local scripts/setup/seed-prod-junctions.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

// Permission set on prod we'll grant FLS to as a fallback. System Admin
// usually doesn't need it, but Tooling-API-created fields sometimes don't
// auto-grant.
const PROD_INTEGRATION_PERM_SET_ID = '0PSJw000000ZWoDOAW'; // Lead_Data_Export

const ok = (msg: string) => console.log(`  ✓ ${msg}`);
const skip = (msg: string) => console.log(`  ⊘ ${msg} (already exists)`);

async function main() {
  console.log('\n🌱 Seeding PROD junction object fields\n');

  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}\n`);

  // -------------------------------------------------------------------------
  // PHASE 1 — Verify object shells exist
  // -------------------------------------------------------------------------
  console.log('Phase 1: verifying object shells exist');
  for (const obj of ['Lead_List_Assignment__c', 'User_Group_Access__c']) {
    if (!(await objectExists(sf, obj))) {
      console.error(`  ✗ ${obj} does not exist.`);
      console.error(
        `    Create the object shell in PROD UI first:`
      );
      console.error(
        `    Setup → Object Manager → Create → Custom Object`
      );
      console.error(`    Label: "${labelFor(obj)}"`);
      console.error(`    Object Name: "${obj.replace('__c', '')}"`);
      console.error(`    Record Name: "${recordNameFor(obj)}" (Auto Number "${prefixFor(obj)}-{0000}")`);
      process.exit(1);
    }
    ok(`${obj} exists`);
  }

  // -------------------------------------------------------------------------
  // PHASE 2 — Lead_List_Assignment__c fields
  // -------------------------------------------------------------------------
  console.log('\nPhase 2: Lead_List_Assignment__c fields');

  await ensureField(sf, 'Lead_List_Assignment__c', 'Lead__c', {
    label: 'Lead',
    type: 'Lookup',
    referenceTo: 'Lead',
    relationshipLabel: 'Lead List Assignments',
    relationshipName: 'Lead_List_Assignments',
    // SF only allows SetNull for Lookups to Lead, AND won't enforce required
    // when the constraint is SetNull. App-level: migration scripts always
    // populate this field; trigger ignores rows where it's null.
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Group__c', {
    label: 'Group',
    type: 'Lookup',
    referenceTo: 'Group__c',
    relationshipLabel: 'Lead List Assignments',
    relationshipName: 'Lead_List_Assignments',
    deleteConstraint: 'Restrict',
    required: true,
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Status__c', {
    label: 'Status',
    type: 'Picklist',
    required: true,
    valueSet: {
      valueSetDefinition: {
        sorted: false,
        value: [
          { fullName: 'Pending', default: true, label: 'Pending' },
          { fullName: 'Approved', default: false, label: 'Approved' },
        ],
      },
    },
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Approved_By__c', {
    label: 'Approved By',
    type: 'Lookup',
    referenceTo: 'User',
    relationshipLabel: 'Approved Lead List Assignments',
    relationshipName: 'Approved_Lead_List_Assignments',
    deleteConstraint: 'SetNull',
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Approved_Date__c', {
    label: 'Approved Date',
    type: 'DateTime',
  });

  // -------------------------------------------------------------------------
  // PHASE 3 — User_Group_Access__c fields
  // -------------------------------------------------------------------------
  console.log('\nPhase 3: User_Group_Access__c fields');

  await ensureField(sf, 'User_Group_Access__c', 'User__c', {
    label: 'User',
    type: 'Lookup',
    referenceTo: 'User',
    relationshipLabel: 'Group Accesses',
    relationshipName: 'Group_Accesses',
    // Same as Lead — SetNull-only on standard User object. Required at the
    // app layer (migration always populates) but not at the schema layer.
  });

  await ensureField(sf, 'User_Group_Access__c', 'Group__c', {
    label: 'Group',
    type: 'Lookup',
    referenceTo: 'Group__c',
    relationshipLabel: 'User Group Accesses',
    relationshipName: 'User_Group_Accesses',
    deleteConstraint: 'Restrict',
    required: true,
  });

  await ensureField(sf, 'User_Group_Access__c', 'Status__c', {
    label: 'Status',
    type: 'Picklist',
    required: true,
    valueSet: {
      valueSetDefinition: {
        sorted: false,
        value: [
          { fullName: 'Pending', default: true, label: 'Pending' },
          { fullName: 'Approved', default: false, label: 'Approved' },
        ],
      },
    },
  });

  await ensureField(sf, 'User_Group_Access__c', 'Approved_By__c', {
    label: 'Approved By',
    type: 'Lookup',
    referenceTo: 'User',
    relationshipLabel: 'Approved Group Accesses',
    relationshipName: 'Approved_Group_Accesses',
    deleteConstraint: 'SetNull',
  });

  await ensureField(sf, 'User_Group_Access__c', 'Approved_Date__c', {
    label: 'Approved Date',
    type: 'DateTime',
  });

  console.log('\n✅ Schema seed complete.\n');
  console.log('Next steps:');
  console.log('  1. tsx scripts/migrations/migrate-group-to-list-assignments.ts --target prod --dry-run');
  console.log('  2. tsx scripts/migrations/migrate-agents-to-group-access.ts --target prod --dry-run');
  console.log('  3. Review counts, then re-run with --commit\n');
}

// ---------------------------------------------------------------------------
// Helpers (same shape as scripts/setup/seed-dev-org.ts)
// ---------------------------------------------------------------------------

async function objectExists(
  sf: Awaited<ReturnType<typeof sfClient>>,
  name: string
): Promise<boolean> {
  try {
    await sf.describe(name);
    return true;
  } catch {
    return false;
  }
}

async function fieldExists(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<boolean> {
  try {
    const d = await sf.describe(obj);
    return d.fields.some((f: { name: string }) => f.name === field);
  } catch {
    return false;
  }
}

async function ensureField(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string,
  metadata: Record<string, unknown>
): Promise<void> {
  if (await fieldExists(sf, obj, field)) {
    skip(`${obj}.${field}`);
    await grantFls(sf, obj, field);
    return;
  }
  try {
    await sf.toolingCreate('CustomField', {
      FullName: `${obj}.${field}`,
      Metadata: metadata,
    });
    await sleep(700);
    await grantFls(sf, obj, field);
    ok(`${obj}.${field}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('DUPLICATE_DEVELOPER_NAME')) {
      await grantFls(sf, obj, field);
      console.log(`  ⊘ ${obj}.${field} (existed without FLS — granted)`);
      return;
    }
    console.error(`  ✗ ${obj}.${field} — ${msg}`);
    throw err;
  }
}

async function grantFls(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<void> {
  try {
    await sf.create('FieldPermissions', {
      ParentId: PROD_INTEGRATION_PERM_SET_ID,
      SobjectType: obj,
      Field: `${obj}.${field}`,
      PermissionsRead: true,
      PermissionsEdit: true,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (
      !msg.includes('DUPLICATE_VALUE') &&
      !msg.includes('already exists') &&
      !msg.includes('INVALID_FIELD')
    ) {
      console.warn(`    (FLS for ${obj}.${field}: ${msg.slice(0, 100)})`);
    }
  }
}

function labelFor(api: string): string {
  return api.replace('__c', '').replace(/_/g, ' ');
}

function recordNameFor(api: string): string {
  if (api === 'Lead_List_Assignment__c') return 'LLA Number';
  if (api === 'User_Group_Access__c') return 'UGA Number';
  return 'Record Name';
}

function prefixFor(api: string): string {
  if (api === 'Lead_List_Assignment__c') return 'LLA';
  if (api === 'User_Group_Access__c') return 'UGA';
  return 'REC';
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Seed crashed:', err);
  process.exit(1);
});
