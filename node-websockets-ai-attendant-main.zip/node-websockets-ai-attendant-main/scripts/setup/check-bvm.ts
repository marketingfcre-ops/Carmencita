import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = await sfClient('prod');

  console.log('\n=== Owners of leads with "BVM" in Group_old2__c (top 20) ===');
  const ownerCounts: any[] = await sf.soql(
    `SELECT Owner.Name, COUNT(Id) cnt FROM Lead
     WHERE Group_old2__c LIKE '%BVM%'
     GROUP BY Owner.Name ORDER BY COUNT(Id) DESC LIMIT 20`
  );
  for (const r of ownerCounts) console.log(`  ${r.Name}  →  ${r.cnt} leads`);

  console.log('\n=== Created by of leads with "BVM" (top 10) ===');
  const createdByCounts: any[] = await sf.soql(
    `SELECT CreatedBy.Name, COUNT(Id) cnt FROM Lead
     WHERE Group_old2__c LIKE '%BVM%'
     GROUP BY CreatedBy.Name ORDER BY COUNT(Id) DESC LIMIT 10`
  );
  for (const r of createdByCounts) console.log(`  ${r.Name}  →  ${r.cnt} leads`);

  console.log('\n=== Users with BVM in name/alias/email ===');
  const users: any[] = await sf.soql(
    `SELECT Name, Alias, Email, IsActive FROM User
     WHERE Name LIKE '%BVM%' OR Alias LIKE 'BVM%' OR Email LIKE '%bvm%'`
  );
  if (users.length === 0) console.log('  (no users with BVM in any name field)');
  else for (const u of users) console.log(`  ${u.Name} (${u.Alias}) <${u.Email}> active=${u.IsActive}`);

  console.log('\n=== Distinct BVM-containing Group_old2 values ===');
  const distincts: any[] = await sf.soql(
    `SELECT Group_old2__c, COUNT(Id) cnt FROM Lead
     WHERE Group_old2__c LIKE '%BVM%'
     GROUP BY Group_old2__c ORDER BY COUNT(Id) DESC LIMIT 20`
  );
  for (const r of distincts) console.log(`  "${r.Group_old2__c}"  →  ${r.cnt}`);

  console.log('\n=== Sample BVM leads ===');
  const samples: any[] = await sf.soql(
    `SELECT Id, Name, Group_old2__c, Owner.Name, CreatedDate FROM Lead
     WHERE Group_old2__c LIKE '%BVM%' ORDER BY CreatedDate DESC LIMIT 5`
  );
  for (const s of samples) console.log(`  ${s.Name} | "${s.Group_old2__c}" | ${s.Owner?.Name} | ${s.CreatedDate}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
