import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;

  // 1. Agent CRUD on Lead_List_Assignment__c — can they even READ assignments?
  console.log('=== Agent CRUD on Lead_List_Assignment__c ===');
  const op: any[] = await sf.soql(
    `SELECT Parent.Profile.Name, Parent.Label, PermissionsRead, PermissionsCreate, PermissionsEdit, PermissionsDelete
     FROM ObjectPermissions WHERE SobjectType = 'Lead_List_Assignment__c'`
  );
  for (const r of op) {
    const owner = r.Parent?.Profile?.Name ? `profile=${r.Parent.Profile.Name}` : `permset="${r.Parent?.Label}"`;
    const flags = (r.PermissionsRead?'R':'-')+(r.PermissionsCreate?'C':'-')+(r.PermissionsEdit?'E':'-')+(r.PermissionsDelete?'D':'-');
    console.log(`  ${flags}  ${owner}`);
  }

  // Same for Group__c
  console.log('\n=== Agent CRUD on Group__c ===');
  const og: any[] = await sf.soql(
    `SELECT Parent.Profile.Name, Parent.Label, PermissionsRead FROM ObjectPermissions WHERE SobjectType = 'Group__c' AND Parent.Profile.Name = 'Account for Agents'`
  );
  for (const r of og) console.log(`  Read=${r.PermissionsRead}  profile=${r.Parent?.Profile?.Name}`);

  // 2. Full FlexiPage dump — including field references
  console.log('\n\n=== FlexiPage "Leads" — looking for Group field references ===');
  const url = `${sf.instanceUrl}/services/data/v59.0/tooling/sobjects/FlexiPage/0M0Jw00000015aLKAQ`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  const fp: any = await res.json();
  const allItems: any[] = [];
  function walk(node: any, path: string) {
    if (!node) return;
    if (Array.isArray(node)) { for (const x of node) walk(x, path); return; }
    if (node.itemInstances) walk(node.itemInstances, path);
    if (node.componentInstance) walk(node.componentInstance, path);
    if (node.fieldInstance) walk(node.fieldInstance, path);
    if (node.componentInstanceProperties) {
      for (const p of node.componentInstanceProperties) {
        if (typeof p.value === 'string' && (p.value.toLowerCase().includes('group') || p.value.toLowerCase().includes('lead'))) {
          if (p.value !== 'standard-Lead' && p.value !== 'Lead.Id') allItems.push(`prop ${p.name}=${p.value}`);
        }
      }
    }
    if (node.fieldItem) allItems.push(`field: ${node.fieldItem}`);
    if (node.componentName) {
      if (node.componentName.includes('field')) allItems.push(`component: ${node.componentName}`);
    }
    for (const k of Object.keys(node)) if (typeof node[k] === 'object') walk(node[k], `${path}.${k}`);
  }
  walk(fp.Metadata, 'root');
  // Find Group references
  console.log('All items mentioning "group":');
  for (const it of allItems) if (it.toLowerCase().includes('group')) console.log(`  ${it}`);
  console.log('\nAll items mentioning "lead":');
  for (const it of allItems) if (it.toLowerCase().includes('lead') && !it.includes('Lead.Id')) console.log(`  ${it}`);

  // 3. Dump itemInstances in regions properly
  console.log('\n\n=== Field items in each region ===');
  for (const r of fp.Metadata?.flexiPageRegions || []) {
    const items = r.itemInstances || [];
    if (!items.length) continue;
    for (const it of items) {
      if (it.fieldInstance) {
        console.log(`  Region ${r.name.slice(0,40)} → field: ${it.fieldInstance.fieldItem || JSON.stringify(it.fieldInstance).slice(0,200)}`);
      }
    }
  }
}
main().catch(e=>{console.error(e);process.exit(1);});
