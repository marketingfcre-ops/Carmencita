/**
 * Fix the mistake from grant-access-tab-visibility.ts:
 *   - REVOKE tab visibility from Account for Agents profile (agents shouldn't
 *     see User Group Access or Lead Group Assignment tabs).
 *   - GRANT tab visibility on the Lead_Data_Export permission set instead, so
 *     Nathalie, Carlos, Elizabeth (the holders of that permset) see them.
 *
 * Idempotent.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

const TABS = ['User_Group_Access__c', 'Lead_List_Assignment__c'];
const ACCOUNT_FOR_AGENTS_PPS = '0PSJw000000502bOAA';
const LEAD_DATA_EXPORT_PERMSET = '0PSJw000000ZWoDOAW';

async function toolingDelete(sf: SfClient, sobject: string, id: string) {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { method: 'DELETE', headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`DELETE ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function toolingCreate(sf: SfClient, sobject: string, body: any) {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`${res.status}: ${text.slice(0, 500)}`);
  return JSON.parse(text);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN. Pass --apply.\n' : 'APPLY mode.\n');

  // 1. REVOKE from Account for Agents (delete the PermissionSetTabSetting rows)
  console.log('=== Revoke from Account for Agents PPS ===');
  for (const tab of TABS) {
    const rows: any[] = await (sf as any).toolingQuery(
      `SELECT Id, Visibility FROM PermissionSetTabSetting
       WHERE ParentId = '${ACCOUNT_FOR_AGENTS_PPS}' AND Name = '${tab}'`
    );
    if (!rows.length) { console.log(`  ${tab}: no record → already revoked`); continue; }
    console.log(`  ${tab}: found ${rows[0].Id} (Visibility=${rows[0].Visibility})`);
    if (DRY) { console.log(`    would DELETE`); continue; }
    await toolingDelete(sf, 'PermissionSetTabSetting', rows[0].Id);
    console.log(`    ✓ Deleted`);
  }

  // 2. GRANT on Lead_Data_Export permset
  console.log('\n=== Grant on Lead Data Export permset (Nathalie/Carlos/Elizabeth) ===');
  for (const tab of TABS) {
    const existing: any[] = await (sf as any).toolingQuery(
      `SELECT Id, Visibility FROM PermissionSetTabSetting
       WHERE ParentId = '${LEAD_DATA_EXPORT_PERMSET}' AND Name = '${tab}'`
    );
    if (existing.length) { console.log(`  ${tab}: already set (${existing[0].Visibility}) → skip`); continue; }
    if (DRY) { console.log(`  ${tab}: would CREATE Visibility=DefaultOn`); continue; }
    const r = await toolingCreate(sf, 'PermissionSetTabSetting', {
      ParentId: LEAD_DATA_EXPORT_PERMSET, Name: tab, Visibility: 'DefaultOn',
    });
    console.log(`  ${tab}: ✓ Created ${r.id}`);
  }

  // 3. Verification: list all PermissionSetTabSetting for these tabs
  console.log('\n=== Final state ===');
  for (const tab of TABS) {
    const all: any[] = await (sf as any).toolingQuery(
      `SELECT Id, Visibility, Parent.Name, Parent.Label, Parent.Profile.Name
       FROM PermissionSetTabSetting WHERE Name = '${tab}'`
    );
    console.log(`  ${tab}:`);
    for (const r of all) {
      const owner = r.Parent?.Profile?.Name ? `profile=${r.Parent.Profile.Name}` : `permset="${r.Parent?.Label || r.Parent?.Name}"`;
      console.log(`    ${r.Visibility.padEnd(10)} ${owner}`);
    }
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
