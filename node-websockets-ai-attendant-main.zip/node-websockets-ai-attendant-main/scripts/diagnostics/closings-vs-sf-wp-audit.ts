/**
 * Cross-reference closings spreadsheet against SF + WP.
 *
 * For each closing in /tmp/closings.json, find any matching SF Property__c
 * record and/or WP post by address. Categorize:
 *
 *   ✅ BOTH MATCHED: SF + WP both have a record. Confident "mark sold."
 *   📋 SF ONLY:      SF record exists, no WP post (was deleted, or
 *                    never had one — common for older closings).
 *   🌐 WP ONLY:      WP post exists, no SF record. Most likely a
 *                    pre-SF marketing page that ended up being sold.
 *   ❓ NO MATCH:     No address match in SF or WP. Likely buyer-side
 *                    (we represented buyer, no listing of our own).
 *
 * Also reports overall state numbers (WP total, SF count, link counts).
 *
 * Read-only.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/closings-vs-sf-wp-audit.ts
 */

import { readFileSync, writeFileSync } from 'fs';

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface Closing {
  'Timestamp': string;
  'Property Address': string | null;
  'Closing Price': number | string | null;
  'Property Type': string | null;
  'Agents Involved': string | null;
  'Notes': string | null;
  'Listing Date': string | null;
  'Source of Buyer': string | null;
  [k: string]: any;
}

interface SfProperty {
  Id: string;
  Address__c: string | null;
  Status__c: string | null;
  Listing_Type__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  status: string;
  title: string;
  fave_property_address: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function fetchAllWp(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,status,title,fave_property_address`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          status: p.status || '',
          title: (p.title?.rendered || '').toString(),
          fave_property_address: p.fave_property_address || '',
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

/**
 * Build a comparable "house number + street name + suffix" key from any
 * address-like string. Handles SF-typed, Houzez-geocoded, and human-typed
 * spreadsheet formats.
 */
function normAddr(addr: string | null | undefined): string {
  if (!addr) return '';
  let a = String(addr).toLowerCase().trim();

  // Skip non-numeric prefix (building names like "Castle Beach Club, 5445, ...")
  const firstDigit = a.search(/\d/);
  if (firstDigit > 0) a = a.substring(firstDigit);

  const parts = a.split(',').map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) return '';

  let s = parts[0];
  let i = 1;
  while (i < parts.length && /^[\d\s\-#/]+$/.test(s)) {
    s = s + ' ' + parts[i];
    i++;
  }

  s = s.replace(/[#.,/]/g, ' ');
  s = s.replace(/(\d+)[\s\-]+\d+([\s\-]+\d+)*/g, '$1');
  s = s.replace(/\bnorthwest\b/g, 'nw').replace(/\bnortheast\b/g, 'ne');
  s = s.replace(/\bsouthwest\b/g, 'sw').replace(/\bsoutheast\b/g, 'se');
  s = s.replace(/\bnorthwesr\b/g, 'nw');
  s = s.replace(/\bnorth\b/g, 'n').replace(/\bsouth\b/g, 's');
  s = s.replace(/\beast\b/g, 'e').replace(/\bwest\b/g, 'w');
  s = s.replace(/\b(street|str)\b/g, 'st');
  s = s.replace(/\b(avenue|av)\b/g, 'ave');
  s = s.replace(/\b(boulevard|boul)\b/g, 'blvd');
  s = s.replace(/\broad\b/g, 'rd');
  s = s.replace(/\bdrive\b/g, 'dr');
  s = s.replace(/\bterrace\b/g, 'ter');
  s = s.replace(/\bcourt\b/g, 'ct');
  s = s.replace(/\bplace\b/g, 'pl');
  s = s.replace(/\bhighway\b/g, 'hwy');
  s = s.replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');
  // City strip: only AFTER first comma-split filtered to street chunk.
  // City names in actual street name positions are rare; this catches the
  // occasional "street, miami" embedded edge case.
  s = s.replace(
    /\b(miami|miami-dade county|broward county|duval county|florida|fl|united states|hialeah|opa-locka|opalocka|jacksonville|dania beach|hollywood|north miami beach|miami beach|coral gables|miramar|fort lauderdale|pompano beach|pompano|davie|deerfield beach|lake worth beach|west park|pembroke park|pembroke pines|hallandale beach|hallandale|medley|homestead|allapattah|wynwood|little havana)\b/g,
    ''
  );
  // INTENTIONALLY no zip-code strip here — the regex /\b\d{5}\b/ also matches
  // 5-digit house numbers (14025, 18319, 17010, 12931, 11150...) and silently
  // truncates them, causing different buildings on the same street to collide
  // under the same key. The comma-split above already isolates zip codes into
  // separate chunks that never reach this point.
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

/**
 * Generate candidate normalized keys for a raw address string. Handles:
 *   - Standard form: "1234 NW 5th St"  → ["1234 nw 5 st"]
 *   - Ordinal-with-space: "700 E 1 st Ave" (= "700 E 1st Ave") → also try "700 e 1 ave"
 *   - Slash-separated multi: "3162 / 3170 SW 16 ST" → both numbers with the street
 *   - Comma-prefix multi: "1628, 1632, 1642 SW 7 ST" → each number with street
 *   - Unit indicators: strip "Unit X", "Apt X", "Suite X", "Ste X"
 *   - Trailing "(...)" parenthetical notes
 */
function addressVariants(raw: string | number | null | undefined): string[] {
  if (raw == null || raw === '') return [];
  const out = new Set<string>();

  // Strip parenthetical notes like "(10822 NW 7 Ave - listing)"
  let cleaned = String(raw).replace(/\([^)]*\)/g, ' ').trim();
  // Collapse newlines
  cleaned = cleaned.replace(/\s+/g, ' ').trim();

  // Variant 1: as-is
  const k1 = normAddr(cleaned);
  if (k1 && k1.length >= 4) out.add(k1);

  // Variant 2: collapse space-separated ordinal suffixes (e.g. "1 st" → "1")
  const collapsed = cleaned.replace(/(\d+)\s+(st|nd|rd|th)\b/gi, '$1');
  if (collapsed !== cleaned) {
    const k = normAddr(collapsed);
    if (k && k.length >= 4) out.add(k);
  }

  // Variant 3: strip unit indicators (works on both raw and collapsed variants)
  for (const base of [cleaned, collapsed]) {
    const stripped = base
      .replace(/\b(unit|apt|suite|ste)\s*[\w\d-]+/gi, '')
      .replace(/#\s*[\w\d-]+/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    const k = normAddr(stripped);
    if (k && k.length >= 4) out.add(k);
  }

  // Variant 4: split on " / " or " - " (slash separator) — each piece could
  // be its own address OR a number-only piece that pairs with the street
  // from another piece
  const slashParts = cleaned.split(/\s*[/]\s*/);
  if (slashParts.length > 1) {
    // Find the last part that contains alpha (the "real" street part)
    const streetPartIdx = slashParts.findIndex((p) => /[a-z]/i.test(p) && /\d/.test(p));
    const streetPart = streetPartIdx >= 0 ? slashParts[streetPartIdx] : null;
    // Extract its street tail (everything after first digit-run)
    if (streetPart) {
      const streetTailMatch = streetPart.match(/\d+\s+(.+)/);
      const streetTail = streetTailMatch ? streetTailMatch[1].trim() : null;
      for (const part of slashParts) {
        // Just a number?
        const numMatch = part.trim().match(/^(\d+)$/);
        if (numMatch && streetTail) {
          const k = normAddr(`${numMatch[1]} ${streetTail}`);
          if (k && k.length >= 4) out.add(k);
        } else {
          const k = normAddr(part);
          if (k && k.length >= 4) out.add(k);
        }
      }
    }
  }

  // Variant 5: comma-separated leading numbers like "1628, 1632, 1642 SW 7 ST"
  const commaNumMatch = cleaned.match(/^([\d,\s]+)\s+([a-zA-Z].+)$/);
  if (commaNumMatch) {
    const nums = commaNumMatch[1].split(',').map((s) => s.trim()).filter((s) => /^\d+$/.test(s));
    const street = commaNumMatch[2];
    for (const n of nums) {
      const k = normAddr(`${n} ${street}`);
      if (k && k.length >= 4) out.add(k);
    }
  }

  return Array.from(out);
}

/** Extract address-like patterns from a title for additional matching. */
function extractTitleAddrs(title: string): string[] {
  if (!title) return [];
  const decoded = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const re =
    /\b(\d{2,6})\s+((?:n|s|e|w|nw|ne|sw|se|north|south|east|west|northwest|northeast|southwest|southeast)\s+)?([\w\d\s]+?)\s+(st|ave|rd|dr|blvd|ter|ct|pl|way|hwy|lane|court|place|terrace|avenue|street|road|drive|boulevard|highway)\b/gi;
  const out: string[] = [];
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = re.exec(decoded)) !== null) {
    const k = normAddr(m[0]);
    if (k && k.length >= 4 && !seen.has(k)) {
      seen.add(k);
      out.push(k);
    }
    if (out.length >= 3) break;
  }
  return out;
}

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log('\n🔬 Closings × SF × WP cross-reference audit (read-only)\n');

  const closings: Closing[] = JSON.parse(readFileSync('/tmp/closings.json', 'utf-8'));
  console.log(`Loaded ${closings.length} closings from /tmp/closings.json\n`);

  const { token, instance } = await sfAuth();
  const [sfAll, wpAll] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Address__c, Status__c, Listing_Type__c, Listing_Agent__r.Name, WP_Post_ID__c
         FROM Property__c`
    ),
    fetchAllWp(),
  ]);

  // ─── STATE NUMBERS ──────────────────────────────────────────────────
  const sfWithLink = sfAll.filter((r) => r.WP_Post_ID__c).length;
  const linkedWpIds = new Set(sfAll.map((r) => r.WP_Post_ID__c).filter(Boolean) as number[]);
  const wpBackedBySf = wpAll.filter((p) => linkedWpIds.has(p.id)).length;
  const wpOrphan = wpAll.length - wpBackedBySf;
  const wpPublish = wpAll.filter((p) => p.status === 'publish').length;
  const wpDraft = wpAll.filter((p) => p.status === 'draft').length;

  console.log('═'.repeat(78));
  console.log('CURRENT STATE');
  console.log('═'.repeat(78));
  console.log(`
  Salesforce
    Total Property__c records:          ${sfAll.length}
    With WP_Post_ID__c set (linked):    ${sfWithLink}
    Without WP link (unlinked):         ${sfAll.length - sfWithLink}

  WordPress
    Total property posts:               ${wpAll.length}
    ┃   Published:                      ${wpPublish}
    ┃   Draft:                          ${wpDraft}
    ┃   Other:                          ${wpAll.length - wpPublish - wpDraft}
    Backed by a SF record (linked):     ${wpBackedBySf}
    WP-only (no SF backing, orphan):    ${wpOrphan}
  `);

  // ─── BUILD MATCH INDEXES ────────────────────────────────────────────
  const sfByKey = new Map<string, SfProperty[]>();
  for (const r of sfAll) {
    const k = normAddr(r.Address__c);
    if (k && k.length >= 4) {
      const arr = sfByKey.get(k) || [];
      arr.push(r);
      sfByKey.set(k, arr);
    }
  }

  const wpByKey = new Map<string, WpPost[]>();
  for (const p of wpAll) {
    const keys = new Set<string>();
    const ak = normAddr(p.fave_property_address);
    if (ak && ak.length >= 4) keys.add(ak);
    for (const tk of extractTitleAddrs(p.title)) keys.add(tk);
    for (const k of keys) {
      const arr = wpByKey.get(k) || [];
      arr.push(p);
      wpByKey.set(k, arr);
    }
  }

  // ─── CATEGORIZE CLOSINGS ────────────────────────────────────────────
  type Match = {
    closing: Closing;
    matchedKeys: string[];
    sfMatches: SfProperty[];
    wpMatches: WpPost[];
    bucket: 'both' | 'sfOnly' | 'wpOnly' | 'none';
  };
  const matches: Match[] = [];
  for (const c of closings) {
    const addr = c['Property Address'];
    const variants = addressVariants(addr);
    if (variants.length === 0) {
      matches.push({ closing: c, matchedKeys: [], sfMatches: [], wpMatches: [], bucket: 'none' });
      continue;
    }

    // Try every variant against both indexes; collect dedup'd hits
    const sfHits = new Map<string, SfProperty>();
    const wpHits = new Map<number, WpPost>();
    const matchedKeys: string[] = [];
    for (const v of variants) {
      const sfArr = sfByKey.get(v) || [];
      const wpArr = wpByKey.get(v) || [];
      if (sfArr.length > 0 || wpArr.length > 0) matchedKeys.push(v);
      for (const sf of sfArr) sfHits.set(sf.Id, sf);
      for (const wp of wpArr) wpHits.set(wp.id, wp);
    }
    const sfMatches = [...sfHits.values()];
    const wpMatches = [...wpHits.values()];
    const bucket =
      sfMatches.length > 0 && wpMatches.length > 0
        ? 'both'
        : sfMatches.length > 0
        ? 'sfOnly'
        : wpMatches.length > 0
        ? 'wpOnly'
        : 'none';
    matches.push({ closing: c, matchedKeys, sfMatches, wpMatches, bucket });
  }

  const bothCount = matches.filter((m) => m.bucket === 'both').length;
  const sfOnlyCount = matches.filter((m) => m.bucket === 'sfOnly').length;
  const wpOnlyCount = matches.filter((m) => m.bucket === 'wpOnly').length;
  const noneCount = matches.filter((m) => m.bucket === 'none').length;

  // Also categorize by current SF status (already closed in SF or not)
  const bothAndSfStillActive = matches.filter(
    (m) =>
      m.bucket === 'both' &&
      m.sfMatches.some((sf) => (sf.Status__c || '').toLowerCase() === 'active')
  ).length;
  const bothAndSfClosed = matches.filter(
    (m) =>
      m.bucket === 'both' &&
      m.sfMatches.every((sf) => {
        const s = (sf.Status__c || '').toLowerCase();
        return s === 'closed won' || s === 'closed lost' || s === 'off market';
      })
  ).length;
  const sfOnlyStillActive = matches.filter(
    (m) =>
      m.bucket === 'sfOnly' &&
      m.sfMatches.some((sf) => (sf.Status__c || '').toLowerCase() === 'active')
  ).length;

  console.log('═'.repeat(78));
  console.log('CLOSING MATCH BREAKDOWN');
  console.log('═'.repeat(78));
  console.log(`
  Total closings:                                 ${closings.length}

  ✅ BOTH (SF + WP found):                         ${bothCount}
       ┣━ SF still marked Active (NEEDS UPDATE):  ${bothAndSfStillActive}
       ┗━ SF already closed:                      ${bothAndSfClosed}

  📋 SF only (WP post missing/deleted):            ${sfOnlyCount}
       ┗━ SF still marked Active (NEEDS UPDATE):  ${sfOnlyStillActive}

  🌐 WP only (no SF record — pre-SF era?):         ${wpOnlyCount}

  ❓ Neither (likely buyer-side):                  ${noneCount}
  `);

  // ─── DETAIL DUMPS ───────────────────────────────────────────────────
  function dumpClosing(m: Match) {
    const c = m.closing;
    const price = c['Closing Price'];
    const agent = c['Agents Involved'] || '—';
    const notes = c['Notes'] || '';
    console.log(`   "${c['Property Address']}"  ${typeof price === 'number' ? '$' + price.toLocaleString() : price}  /  ${agent}`);
    if (notes) console.log(`     Notes: ${trunc(notes, 80)}`);
    if (m.sfMatches.length > 0) {
      for (const sf of m.sfMatches) {
        console.log(`     SF: ${sf.Id}  Status=${sf.Status__c || '—'}  ${sf.Listing_Type__c || ''}  agent=${sf.Listing_Agent__r?.Name || '—'}  ${sf.WP_Post_ID__c ? '→ wp:' + sf.WP_Post_ID__c : '(no WP link)'}`);
      }
    }
    if (m.wpMatches.length > 0) {
      for (const wp of m.wpMatches) {
        console.log(`     WP: wp:${wp.id}  status=${wp.status}  "${trunc(wp.title.replace(/&#8211;/g, '–'), 55)}"`);
      }
    }
    console.log('');
  }

  console.log('═'.repeat(78));
  console.log(`BOTH MATCHED — SF still Active (${bothAndSfStillActive}) — these are the prime "mark sold" targets`);
  console.log('═'.repeat(78));
  for (const m of matches.filter(
    (m) =>
      m.bucket === 'both' &&
      m.sfMatches.some((sf) => (sf.Status__c || '').toLowerCase() === 'active')
  )) {
    dumpClosing(m);
  }

  console.log('═'.repeat(78));
  console.log(`SF ONLY — SF still Active (${sfOnlyStillActive}) — SF needs status update, no WP work`);
  console.log('═'.repeat(78));
  for (const m of matches.filter(
    (m) =>
      m.bucket === 'sfOnly' &&
      m.sfMatches.some((sf) => (sf.Status__c || '').toLowerCase() === 'active')
  )) {
    dumpClosing(m);
  }

  console.log('═'.repeat(78));
  console.log(`WP ONLY (${wpOnlyCount}) — closings with a WP post but no SF record`);
  console.log('═'.repeat(78));
  for (const m of matches.filter((m) => m.bucket === 'wpOnly')) {
    dumpClosing(m);
  }

  console.log('═'.repeat(78));
  console.log(`BOTH MATCHED — SF already closed (${bothAndSfClosed}) — both SF and WP already aligned, no action`);
  console.log('═'.repeat(78));
  console.log(`(${bothAndSfClosed} records — skipping detail)\n`);

  // ─── JSON OUTPUTS for downstream "mark sold" scripts ─────────────────
  // Strategy: ONE row per CLOSING. If a closing matches multiple SF records
  // (multi-unit building, ambiguous address), flag as "ambiguous" and don't
  // auto-act — those need human eyeballs. The auto-marker only touches
  // "confident" rows (exactly 1 active SF match per closing).
  const sfCandidateClosings = matches.filter((m) => {
    if (m.bucket !== 'both' && m.bucket !== 'sfOnly') return false;
    const notes = (m.closing.Notes || '').toLowerCase();
    if (notes.includes('on the buyer side') || notes.includes('buyer-side')) return false;
    return m.sfMatches.some(
      (sf) => (sf.Status__c || '').toLowerCase() === 'active'
    );
  });

  // First pass: count how many closings target each SF record. If an SF
  // record has multiple closings against it, it's a multi-unit / multi-lease
  // building — don't auto-close (the property still has activity).
  const sfClosingCount = new Map<string, number>();
  for (const m of sfCandidateClosings) {
    const activeSfs = m.sfMatches.filter(
      (sf) => (sf.Status__c || '').toLowerCase() === 'active'
    );
    if (activeSfs.length === 1) {
      const id = activeSfs[0].Id;
      sfClosingCount.set(id, (sfClosingCount.get(id) || 0) + 1);
    }
  }

  const confident: any[] = [];
  const ambiguous: any[] = [];
  const seenConfidentSfIds = new Set<string>();
  for (const m of sfCandidateClosings) {
    const activeSfs = m.sfMatches.filter(
      (sf) => (sf.Status__c || '').toLowerCase() === 'active'
    );
    const closingMeta = {
      closingPrice: m.closing['Closing Price'],
      closingAgents: m.closing['Agents Involved'],
      closingAddress: m.closing['Property Address'],
      closingTimestamp: m.closing.Timestamp,
      closingNotes: m.closing.Notes,
    };
    if (activeSfs.length === 1) {
      const sf = activeSfs[0];
      const closingCountForSf = sfClosingCount.get(sf.Id) || 1;
      if (closingCountForSf > 1) {
        // Multi-closing → same SF record. Multi-unit lease building.
        // Don't auto-close; surface for human review.
        ambiguous.push({
          reason: `Multi-closing: ${closingCountForSf} closings target this single SF record (multi-unit lease building)`,
          candidateCount: 1,
          candidates: [
            {
              sfId: sf.Id,
              sfAddress: sf.Address__c,
              listingAgent: sf.Listing_Agent__r?.Name || null,
              listingType: sf.Listing_Type__c,
              wpId: sf.WP_Post_ID__c,
            },
          ],
          ...closingMeta,
        });
        continue;
      }
      // Truly single-match; safe to auto-flip.
      // Skip if we already emitted a row for this SF id (defensive)
      if (seenConfidentSfIds.has(sf.Id)) continue;
      seenConfidentSfIds.add(sf.Id);
      confident.push({
        sfId: sf.Id,
        sfAddress: sf.Address__c,
        currentStatus: sf.Status__c,
        targetStatus: 'Closed Won',
        listingAgent: sf.Listing_Agent__r?.Name || null,
        listingType: sf.Listing_Type__c,
        wpId: sf.WP_Post_ID__c,
        ...closingMeta,
      });
    } else {
      ambiguous.push({
        reason: `Address matches multiple SF records (${activeSfs.length})`,
        candidateCount: activeSfs.length,
        candidates: activeSfs.map((sf) => ({
          sfId: sf.Id,
          sfAddress: sf.Address__c,
          listingAgent: sf.Listing_Agent__r?.Name || null,
          listingType: sf.Listing_Type__c,
          wpId: sf.WP_Post_ID__c,
        })),
        ...closingMeta,
      });
    }
  }
  writeFileSync('/tmp/closings-mark-sf-sold-confident.json', JSON.stringify(confident, null, 2));
  writeFileSync('/tmp/closings-mark-sf-sold-ambiguous.json', JSON.stringify(ambiguous, null, 2));
  console.log(`\n📄 Wrote ${confident.length} CONFIDENT SF→Closed Won rows to /tmp/closings-mark-sf-sold-confident.json`);
  console.log(`📄 Wrote ${ambiguous.length} AMBIGUOUS closings (multi-match) to /tmp/closings-mark-sf-sold-ambiguous.json`);

  // WP-only sold: WP posts where closing matched but no SF backing.
  const wpOnlyConfident: any[] = [];
  const wpOnlyAmbiguous: any[] = [];
  for (const m of matches.filter((m) => m.bucket === 'wpOnly')) {
    const closingMeta = {
      closingPrice: m.closing['Closing Price'],
      closingAgents: m.closing['Agents Involved'],
      closingAddress: m.closing['Property Address'],
      closingTimestamp: m.closing.Timestamp,
      closingNotes: m.closing.Notes,
    };
    if (m.wpMatches.length === 1) {
      const wp = m.wpMatches[0];
      wpOnlyConfident.push({
        wpId: wp.id,
        wpStatus: wp.status,
        wpTitle: wp.title.replace(/&#8211;/g, '–'),
        wpAddress: wp.fave_property_address,
        ...closingMeta,
      });
    } else {
      wpOnlyAmbiguous.push({
        candidateCount: m.wpMatches.length,
        candidates: m.wpMatches.map((wp) => ({
          wpId: wp.id,
          wpStatus: wp.status,
          wpTitle: wp.title.replace(/&#8211;/g, '–'),
          wpAddress: wp.fave_property_address,
        })),
        ...closingMeta,
      });
    }
  }
  writeFileSync('/tmp/closings-mark-wp-sold-confident.json', JSON.stringify(wpOnlyConfident, null, 2));
  writeFileSync('/tmp/closings-mark-wp-sold-ambiguous.json', JSON.stringify(wpOnlyAmbiguous, null, 2));
  console.log(`📄 Wrote ${wpOnlyConfident.length} CONFIDENT WP-only sold rows to /tmp/closings-mark-wp-sold-confident.json`);
  console.log(`📄 Wrote ${wpOnlyAmbiguous.length} AMBIGUOUS WP-only sold rows to /tmp/closings-mark-wp-sold-ambiguous.json\n`);

  console.log('═'.repeat(78));
  console.log(`NEITHER (${noneCount}) — likely buyer-side or unknown property`);
  console.log('═'.repeat(78));
  for (const m of matches.filter((m) => m.bucket === 'none')) {
    const c = m.closing;
    const price = c['Closing Price'];
    const agent = c['Agents Involved'] || '—';
    const notes = c['Notes'] || '';
    console.log(`   "${c['Property Address'] || '(no address)'}"  ${typeof price === 'number' ? '$' + price.toLocaleString() : price}  /  ${agent}`);
    if (notes) console.log(`     Notes: ${trunc(notes, 80)}`);
    console.log('');
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
