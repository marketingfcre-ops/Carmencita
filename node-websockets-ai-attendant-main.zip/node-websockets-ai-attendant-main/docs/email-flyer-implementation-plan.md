# Email + Flyer Implementation Plan

Scope: enable email delivery from the AI receptionist with a PDF flyer
attachment (or signed download link), and make the "what we offer" logic
graceful — website > flyer > agent follow-up — so every caller gets the
richest deliverable a property supports.

This is a planning document. No code in this PR. Treat it as the menu of
choices, with my recommendation called out for each.

---

## 1. What's already in the codebase (free wins)

Findings from a code sweep on `main`:

| Piece | Where | State |
|---|---|---|
| Flyer HTML renderer | [src/integrations/flyer.ts](../src/integrations/flyer.ts) | Done. Pulls SF property data, renders HTML. PDF rendering is a TODO comment with two paths sketched (PDFShift SaaS vs Puppeteer local). |
| Flyer route | [src/handlers/flyer.ts](../src/handlers/flyer.ts) | `GET /api/flyer/:sfPropertyId` (HTML default, `?pdf=1` flag). Auth via `FLYER_SHARED_SECRET` header or query. |
| Campaign Monitor Smart Email | [src/campaign-monitor.ts](../src/campaign-monitor.ts) — `sendSmartEmail()` line ~327 | Implemented but never called. Template ID + merge data, no attachment support in the current wrapper. |
| Campaign Monitor subscriber import | same file — `addOrUpdateSubscriber()` | Implemented, not called. Pushes EmailAddress + Name + CustomFields. |
| Inbound SMS keyword router | [src/webhooks/sms.ts:31](../src/webhooks/sms.ts) | STOP / START / HELP / YES wired. **EMAIL keyword is detected in [src/sms-keywords.ts](../src/sms-keywords.ts) but no handler runs on it today** — currently just logged. |
| SMS consent store | [src/sms-consent.ts](../src/sms-consent.ts) | File-backed at `data/sms-consent.json`. Stores phone + status + pending property metadata. **No email field yet.** |
| `EMAIL_ENABLED` flag | [src/sms.ts:41](../src/sms.ts), [src/claude.ts:25](../src/claude.ts) | Already stubbed off by default. Gates SMS body "Reply with your email" line + AI prompt around email. |
| SF Property fields available | [src/salesforce.ts:225](../src/salesforce.ts) | `Public_URL__c`, `Photo_URL__c`, `Description__c`, agents, address, price, units, sqft, etc. No standalone `Flyer_URL__c` — flyers are generated from this data, not stored as files. |
| Lead.Email push to SF | [src/salesforce.ts:63](../src/salesforce.ts) — `LeadCreateData` | **Email field is missing from the type.** Phone is captured, email is not. Easy add. |
| MMS support | [src/sms.ts:48](../src/sms.ts) — `sendSms()` | None. SMS body only; no `MediaUrl`. |

**Implication:** the heavy lift is already 60% in place. The missing pieces
are: PDF generation backend, email capture state, SF lead email field,
the email-send call into CM, and the AI prompt logic.

---

## 2. The big design choices (pick one each)

### 2.1 Email provider: Campaign Monitor vs SendGrid vs SES

| Provider | Pros | Cons | Cost |
|---|---|---|---|
| **Campaign Monitor Smart Email** (recommended) | Already integrated; same provider as marketing lists — single source of truth for opt-out and subscriber state; transactional `sendSmartEmail()` already implemented; faustocommercial.com SPF/DKIM already configured for CM | Need to verify CM Smart Email supports attachments (likely doesn't; we'd use a signed download link instead); templates live in CM UI, not in our repo | Likely already included in current CM plan; verify with whoever manages the CM account |
| **SendGrid** | Industry standard for transactional; dynamic templates; attachments built in; great deliverability; inbound email parse if we ever need it | Net-new vendor; another DKIM/SPF record to configure on faustocommercial.com; another opt-out surface to keep in sync with CM | Free 100/day → $19.95/mo for 50k/mo |
| **AWS SES** | Cheapest at scale; full attachment support | Most setup; bounce / complaint handling is on you; templates have to be coded | $0.10 per 1k emails |

**Recommendation: Campaign Monitor**, because the integration is half-done,
the from-domain reputation is already established, and a single
opt-out / suppression list is operationally much cleaner than juggling
two providers. The "no attachment" limit pushes us toward the
**signed-download-link pattern** anyway, which is the better UX (see 2.2).

### 2.2 PDF delivery: attachment vs hosted link

| Approach | Pros | Cons |
|---|---|---|
| **Hosted signed link** (recommended) | Works on every provider; lets the recipient redownload from any device; gives us click tracking; emails stay tiny so spam filters are kinder; PDF can be regenerated lazily | Need a stable URL pattern + auth + light analytics |
| **PDF as attachment** | One-click open from the email client | Provider-dependent (CM may not support); 10 MB inbox limits in some corp systems; mobile clients sometimes hide attachments behind extra taps; no analytics |

**Recommendation: signed link.** The flyer route at
`/api/flyer/:sfPropertyId?pdf=1&secret=<...>` already exists; we just
need the PDF backend wired and a short-lived signed-token scheme so the
secret is per-recipient and time-bound.

### 2.3 PDF renderer: PDFShift vs Puppeteer

| Option | Pros | Cons | Cost |
|---|---|---|---|
| **PDFShift** (recommended for v1) | Zero infra; POST HTML, get PDF; ~1–2s render; doesn't bloat Railway memory | Per-render cost; vendor lock | ~$9/mo for 200 PDFs; $49/mo for 1,000; pay-as-you-go too |
| **Puppeteer** | Free; full control over rendering; supports custom fonts/CSS | ~150 MB install bloats the Docker image; needs more RAM (often forces a Railway plan bump); occasional headless Chromium crashes | Free, but Railway plan delta is real |
| **pdfkit / pdfmake** (JS lib) | No Chromium; lightweight | Can't render arbitrary CSS / web fonts / property photos cleanly. Real-estate flyers will look bad. | Free |

**Recommendation: PDFShift for v1**, swap to Puppeteer later if monthly
volume crosses ~1,500 PDFs. The flyer.ts skeleton already names PDFShift
as option A.

### 2.4 Email capture: inbound-SMS reply vs voice vs form

| Path | Reliability | UX |
|---|---|---|
| **Inbound SMS reply** (recommended) | High — typing an email is easy on a keyboard | Caller hangs up, gets an SMS "reply with your email for the flyer", replies, gets the flyer. Async, low friction. |
| Voice during call | Low — spelled-out emails are STT-hostile ("c-o-m"), confirmation eats time | Wastes phone time; high error rate |
| Web form | High | Adds a click; some callers won't bother |

**Recommendation: inbound SMS reply.** The `EMAIL` keyword is already
detected in `sms-keywords.ts`; we just need to wire the handler.

### 2.5 List storage: where the email lives

The captured email needs to update **three** places, in priority order:

1. **Salesforce `Lead.Email`** — single source of truth for the lead record. Always update.
2. **`sms-consent.json`** — short-term state ("we're waiting for this phone to reply with an email so we can flyer them on property X"). Cleared once the email arrives.
3. **Campaign Monitor subscriber list** — only if the caller explicitly opts in to ongoing marketing emails ("new listings", "price drops"). Receiving a one-off flyer is a transactional send and does NOT auto-subscribe them — that's the CAN-SPAM distinction.

**Important:** never sync the "they asked for one flyer" event as a CM
subscriber. That conflates transactional with marketing consent and is
the easiest way to land on a spam blocklist. Subscription only happens
when they say yes to ongoing emails.

---

## 3. Recommended architecture (end-to-end)

```
┌──────────────────────────────────────────────────────────────────┐
│                       PHONE CALL                                 │
│                                                                  │
│  Caller asks about property X                                    │
│  AI runs search_properties → result line ends with one of:       │
│    canText=yes              → SMS path                           │
│    canText=NO + canFlyer=yes → Email path                        │
│    canText=NO + canFlyer=NO  → Agent path                        │
│                                                                  │
│  Email path conversation:                                        │
│    AI: "This one doesn't have a web page yet, but I have a       │
│         flyer I can email you — what's the best email address?"  │
│    Option 1: caller speaks email (risky — STT mangles)           │
│    Option 2: AI: "Easiest is to text it to the same number       │
│         you called from — I'll send the flyer to your email      │
│         right after. Want me to do that?"                        │
└──────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────────┐
│              SMS HANDOFF (after call ends)                       │
│                                                                  │
│  Server sends:                                                   │
│    "Fausto Commercial: reply with your email and we'll send      │
│     you the [property] flyer. Reply STOP to opt out."            │
│                                                                  │
│  sms-consent records:                                            │
│    pendingEmailCapture: { propertyId, sfPropertyName }           │
└──────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────────┐
│             INBOUND SMS (caller texts email)                     │
│                                                                  │
│  /sms/incoming sees EMAIL keyword + valid email format           │
│  → store email, clear pendingEmailCapture                        │
│  → upsert SF Lead.Email                                          │
│  → request CM Smart Email send with merge data:                  │
│       { firstName, propertyName, flyerUrl }                      │
│    where flyerUrl = signed link to /api/flyer/:id?pdf=1&token=…  │
│  → SMS reply: "Sent! Check your inbox."                          │
└──────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────────┐
│             EMAIL ARRIVES (Campaign Monitor)                     │
│                                                                  │
│  Subject: "Your flyer for [property name]"                       │
│  Body: a short note + "View / download the flyer" CTA            │
│  CTA links to /api/flyer/:sfPropertyId?pdf=1&token=…             │
│    → PDFShift renders flyer HTML to PDF on demand                │
│    → server streams PDF back, content-type: application/pdf      │
│                                                                  │
│  Token is short-lived (7 days), signed with FLYER_SIGNING_SECRET │
└──────────────────────────────────────────────────────────────────┘
```

### Schema changes

**SF:**
- `Lead.Email` is already a stock field — just push to it. No new fields.
- (Optional, later) `Lead.Flyer_Delivered__c` checkbox + `Lead.Last_Flyer_Property__c` lookup, so a sales rep sees the lead got the flyer.

**Local state (`sms-consent.json`):**
- Extend `ConsentRecord` with `pendingEmailFor` ({ propertyId, propertyName, requestedAt }) and `email` (last known address) — both nullable.

**Env:**
- `EMAIL_ENABLED=true` (already exists)
- `CM_API_KEY` (already exists for any CM use)
- `CM_SMART_EMAIL_ID` — UUID for the "Property Flyer Delivery" template, created in CM UI
- `PDFSHIFT_API_KEY` — new
- `FLYER_SIGNING_SECRET` — new; HMAC for the per-recipient signed link

---

## 4. Implementation phases

### Phase 1 — Email capture pipeline (~1 day)

1. Extend `sms-consent.ts` `ConsentRecord`: add `pendingEmailFor` and `email` fields. Add `setPendingEmailCapture`, `clearPendingEmailCapture`, `setEmail` helpers.
2. Wire the `EMAIL` keyword in [src/webhooks/sms.ts](../src/webhooks/sms.ts): when an inbound message contains an email and there's a `pendingEmailFor`, capture it, upsert `Lead.Email`, kick off the email send.
3. Add `email?: string` to `LeadCreateData` and push to SF when present.
4. Send-time SMS reply "Sent — check your inbox!" so the caller knows it worked.

### Phase 2 — PDF backend + signed link (~1 day)

1. Sign up PDFShift, add `PDFSHIFT_API_KEY` to Railway.
2. Implement `pdfFromHtml(html: string): Promise<Buffer>` in flyer.ts (replaces the TODO).
3. Add `FLYER_SIGNING_SECRET` + a tiny HMAC helper. `?token=<hmac>` replaces the static `?secret=<sharedSecret>` for per-recipient links.
4. `GET /api/flyer/:id?pdf=1&token=…` validates the token (expiry, propertyId binding) before rendering.
5. Optional: stash the rendered PDF in object storage with a short TTL, so the second click doesn't re-render. Skip for v1.

### Phase 3 — Campaign Monitor template + send call (~½ day)

1. Marketing team creates a Smart Email template in CM UI: "Property Flyer Delivery". Merge tags: `firstName`, `propertyName`, `flyerUrl`, `agentName`.
2. Grab the Smart Email ID, set `CM_SMART_EMAIL_ID` env var.
3. New module: `sendPropertyFlyerEmail(email, property, signedLink)` — calls `sendSmartEmail()` with the merge data.

### Phase 4 — AI prompt logic (~½ day)

1. Add `canFlyer` flag on each search result, like the existing `canText`. Computed as: "do we have enough SF data to render a useful flyer?" — at minimum address + property type + price + at least one photo URL. Conservatively, `true` whenever SF has the property record at all.
2. Update `formatResultsForClaude` to surface `canText`/`canFlyer` per line: `| can: text+flyer` / `| can: flyer only` / `| can: agent only`.
3. Update the system prompt's conversation-flow section to handle the four states:
   - both → offer text (free win)
   - flyer only → offer email
   - neither → agent follow-up
4. Reuse the proactive-ask gating we added in PR #25 — extend it to the email path too.

### Phase 5 — Marketing opt-in (~½ day, optional)

Separately from the flyer send, ask: "want me to add you to our new-listing email list too?" If yes, `addOrUpdateSubscriber` to a CM marketing list. This is the **only** path that creates a CM subscriber.

### Phase 6 — MMS (later, optional)

Twilio MMS supports `MediaUrl` for photos. PDFs are unreliable across
US carriers — many strip them, some convert to broken images, iOS vs
Android handling diverges. **Don't MMS PDFs.** Do MMS property photos
when we want a richer SMS for `canText=yes` properties.

Effort: ~3 hours to add `MediaUrl` to `sendSms()`, pull `Photo_URL__c`,
and update the body to "photo + listing link." Coverage gain is small
since photo-less listings already work via plain SMS — defer.

**Total v1 effort (phases 1–4): ~3–4 focused days.** Marketing team time for the CM template is in parallel.

---

## 5. List hygiene, compliance, deliverability

### Distinguishing transactional from marketing
- **Transactional** (the flyer): user-requested, one-shot, exempt from CAN-SPAM's opt-in requirement. Still needs accurate from-name, no deceptive subject, physical address in footer.
- **Marketing** (new-listing newsletter): requires explicit opt-in, must include unsubscribe link, syncs with the CM suppression list automatically.
- Send these from **different CM lists / sender identities** so a marketing unsubscribe doesn't kill the transactional path.

### Domain authentication
- `faustocommercial.com` SPF / DKIM / DMARC should already be set up for CM (since CM sends marketing today). Confirm.
- Adding SendGrid later would mean a second DKIM key — another reason to stay on CM.

### Bounce + complaint handling
- CM exposes a webhook for bounces/complaints — wire it later to update `Lead.EmailBouncedReason__c`.
- If we see a hard bounce, mark the SF Lead and refuse future sends to that address.
- Suppression list lives in CM; respect it client-side as a defense-in-depth.

### Rate limits / abuse prevention
- One flyer send per phone-number-per-property-per-24h. Prevents accidental loops if a caller spam-replies their email.
- Email-format regex must be strict; reject obvious typos before hitting CM.

### Privacy
- The signed link should not leak the property ID in plaintext if the property is private/draft. Keep the link short, token-bound, 7-day expiry, single-property scope.

---

## 6. Open decisions before you start

1. **Confirm CM transactional pricing / attachment support.** If CM supports attachments cleanly and pricing is fine, attachments could replace signed links — but recommend sticking with signed links regardless (better UX + analytics).
2. **CM template content.** Marketing team owns the design — get a draft going Friday.
3. **PDFShift vs Puppeteer.** Default PDFShift; revisit if monthly PDF volume crosses ~1,500.
4. **Voice-capture of email yes/no.** I recommend no (STT spells emails badly). Stick to the inbound-SMS-reply pattern.
5. **MMS photo enhancement timing.** Defer past v1.
6. **Auto-subscribe-to-marketing flow.** Add a `subscribed_to_marketing` boolean to `sms-consent`, default false. Asked separately by the AI as an opt-in question after the flyer is queued.

---

## 7. Risks + things that could bite

- **Smart Email template lock-in.** Once content is live in CM, editing requires the marketing team — devs can't hot-swap. Set the template up so merge data does the heavy lifting (property name, photo URL, price as merge fields), not hardcoded.
- **PDFShift outages.** Add a fallback: if PDFShift fails twice, email the user a link to the HTML version of the flyer instead of the PDF. The HTML version already works today.
- **Email arrives before SMS reply confirmation.** If CM is fast and SMS is slow, the user gets the email before our "Sent — check your inbox!" SMS. Not a real problem, but order is non-deterministic — don't write copy that assumes one before the other.
- **Caller texts an email for the wrong property.** If they call about property A, hang up, then text the email an hour later, we send A. If they meant B, they get the wrong flyer. Add an SMS confirmation step: "Reply YES to send the [property] flyer to that address."
- **Spam folder for first send.** First-time recipient domains often filter. Set the from-name to "Fausto Commercial" and warm up gradually if volume is low.

---

## 8. Test plan (when you implement)

- [ ] Phase 1: trigger a fake inbound SMS with `EMAIL me@example.com` after seeding a `pendingEmailFor` — assert SF Lead is updated and CM send is queued.
- [ ] Phase 2: hit `/api/flyer/<active property id>?pdf=1&token=<valid>` — get a PDF; with an expired token, get 401.
- [ ] Phase 3: send a test CM Smart Email to yourself with merge data — confirm template renders, link works, PDF downloads.
- [ ] Phase 4: live call about property with publish URL → SMS arrives. Live call about property with draft URL → AI offers email, you SMS reply your address, email arrives with PDF link.
- [ ] Phase 5 (if shipped): test the marketing opt-in path separately. Confirm the marketing list and transactional path are independent.
