/**
 * Smoke test — Salesforce Property → WordPress sync.
 *
 * Calls handlePropertyChanged() directly (bypassing the HTTP webhook layer)
 * to verify the integration end-to-end with a real SF Property and a real WP draft.
 *
 * Run: tsx --env-file .env.local scripts/smoke-sf-to-wp.ts <sfPropertyId>
 *
 * What it does:
 *   1. Initializes the SF client (OAuth)
 *   2. Fetches the Property__c record
 *   3. Runs the handler (creates WP draft, writes back WP_Post_ID__c + Public_URL__c)
 *   4. Re-fetches the SF record to confirm write-back
 *   5. Fetches the WP post via /fausto/v1/push to confirm it exists
 *
 * Safe: drafts are not publicly visible. Easy to delete after.
 */

import { initSalesforce, fetchPropertyForSync } from '../../src/salesforce';
import { handlePropertyChanged } from '../../src/handlers/sf-property-changed';
import { getProperty } from '../../src/integrations/wordpress';

async function main() {
  const sfId = process.argv[2];
  if (!sfId) {
    console.error('Usage: tsx --env-file .env.local scripts/smoke-sf-to-wp.ts <sfPropertyId>');
    process.exit(1);
  }

  console.log(`\n🔬 Smoke test — sync SF Property ${sfId} to WordPress\n`);

  // ---- Step 1: Init SF ----
  console.log('1. Initializing Salesforce client...');
  await initSalesforce();

  // ---- Step 2: Verify SF record exists ----
  console.log('\n2. Fetching SF Property__c...');
  const before = await fetchPropertyForSync(sfId);
  if (!before) {
    console.error(`❌ Property__c ${sfId} not found`);
    process.exit(1);
  }
  console.log(`   Name:         ${before.name}`);
  console.log(`   Marketing:    ${before.marketingName || '(none)'}`);
  console.log(`   Address:      ${before.address || '(none)'}, ${before.city || '?'}`);
  console.log(`   Listing Type: ${before.listingType}`);
  console.log(`   Status:       ${before.status}`);
  console.log(`   Price:        ${before.price ?? '(none)'}`);
  console.log(`   WP Post ID:   ${before.wpPostId ?? '(none yet)'}`);
  console.log(`   Public URL:   ${before.publicUrl ?? '(none yet)'}`);

  if (before.wpPostId) {
    console.log(
      '\n⚠️  This Property already has WP_Post_ID__c set — handler will UPDATE the existing post, not create.'
    );
  }

  // ---- Step 3: Run handler ----
  console.log('\n3. Running handlePropertyChanged...');
  const result = await handlePropertyChanged({
    recordId: sfId,
    reason: before.wpPostId ? 'updated' : 'created',
  });
  console.log(`   Result:       ${JSON.stringify(result, null, 2)}`);

  if (!result.ok) {
    console.error('\n❌ Handler failed.');
    process.exit(1);
  }

  // ---- Step 4: Verify SF write-back ----
  console.log('\n4. Re-fetching SF to verify write-back...');
  const after = await fetchPropertyForSync(sfId);
  if (!after) {
    console.error('❌ Could not re-fetch');
    process.exit(1);
  }
  console.log(`   WP Post ID:   ${after.wpPostId ?? '(MISSING)'}`);
  console.log(`   Public URL:   ${after.publicUrl ?? '(MISSING)'}`);

  // ---- Step 5: Verify WP side ----
  if (after.wpPostId) {
    console.log('\n5. Fetching WP post to verify Houzez meta...');
    const wp = await getProperty(after.wpPostId);
    if (!wp) {
      console.error('❌ WP post not retrievable');
      process.exit(1);
    }
    console.log(`   WP Title:     ${wp.title}`);
    console.log(`   WP Status:    ${wp.status}`);
    console.log(`   Permalink:    ${wp.permalink}`);
    console.log('   Houzez meta:');
    for (const [k, v] of Object.entries(wp.meta || {})) {
      const vs = typeof v === 'string' ? v : JSON.stringify(v);
      console.log(`     ${k}: ${vs.slice(0, 60)}`);
    }
  }

  console.log('\n✅ Smoke test complete.\n');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Smoke test crashed:', err);
  process.exit(1);
});
