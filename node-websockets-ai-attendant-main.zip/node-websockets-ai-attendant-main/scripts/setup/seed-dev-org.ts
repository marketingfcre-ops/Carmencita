/**
 * Seed the Dev Edition org with fields + sample data for end-to-end testing.
 *
 * PREREQUISITE: the three custom OBJECTS must exist (created via Dev UI):
 *   - Group__c                    (Name = Text)
 *   - Lead_List_Assignment__c     (Name = Auto Number, format "LLA-{0000}")
 *   - Property__c                 (Name = Text)
 *
 * This script then adds:
 *   - Lead.Group__c lookup
 *   - Lead_List_Assignment__c fields (Lead, Group, Status, Approved_By, Approved_Date)
 *   - Property__c fields (Status, Listing_Type, Address etc, Public_URL, WP_Post_ID)
 *   - Sample data: 5 groups, 10 leads, 5 properties
 *
 * Idempotent. Safe to re-run.
 *
 * Run: tsx --env-file .env.local scripts/seed-dev-org.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

const log = (...args: unknown[]) => console.log(...args);
const skip = (msg: string) => console.log(`  ⊘ ${msg} (already exists)`);
const ok = (msg: string) => console.log(`  ✓ ${msg}`);

// Auto-generated permission set for the integration user (System Administrator)
// in the Dev org. We grant FLS on all newly-created fields here so the same
// user that creates fields can also query/write them.
const DEV_INTEGRATION_PERM_SET_ID = '0PSg5000005aOVaGAM';

async function main() {
  console.log('\n🌱 Seeding Dev org with Fausto schema\n');

  const sf = await sfClient('dev');
  log(`Connected to ${sf.instance}\n`);

  // -----------------------------------------------------------------------
  // PHASE 1 — Verify required custom objects exist (created in UI)
  // -----------------------------------------------------------------------
  log('Phase 1: verifying required custom objects exist');
  for (const obj of ['Group__c', 'Lead_List_Assignment__c', 'Property__c']) {
    if (!(await objectExists(sf, obj))) {
      console.error(
        `  ✗ ${obj} does not exist. Create the object shell in Dev UI first.`
      );
      console.error(
        `    Setup → Object Manager → Create → Custom Object → "${obj.replace('__c', '').replace(/_/g, ' ')}"`
      );
      process.exit(1);
    }
    ok(`${obj} exists`);
  }

  // -----------------------------------------------------------------------
  // PHASE 2 — Lead.Group__c lookup
  // -----------------------------------------------------------------------
  log('\nPhase 2: Lead.Group__c lookup field');
  await ensureField(sf, 'Lead', 'Group__c', {
    type: 'Lookup',
    label: 'Group',
    referenceTo: 'Group__c',
    relationshipName: 'Leads',
    relationshipLabel: 'Leads',
    deleteConstraint: 'SetNull',
  });

  // -----------------------------------------------------------------------
  // PHASE 3 — Lead_List_Assignment__c (junction)
  // -----------------------------------------------------------------------
  log('\nPhase 3: Lead_List_Assignment__c fields');

  await ensureField(sf, 'Lead_List_Assignment__c', 'Lead__c', {
    type: 'Lookup',
    label: 'Lead',
    referenceTo: 'Lead',
    relationshipName: 'List_Assignments',
    relationshipLabel: 'List Assignments',
    // SF disallows Cascade and Restrict for Lookups targeting Lead, AND
    // disallows SetNull on a required field. So we leave it not-required at
    // the field level and rely on app logic / a validation rule to enforce
    // presence. The orphan case (Lead deleted) is rare and audit-friendly.
    deleteConstraint: 'SetNull',
    required: false,
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Group__c', {
    type: 'Lookup',
    label: 'Group',
    referenceTo: 'Group__c',
    relationshipName: 'Lead_Assignments',
    relationshipLabel: 'Lead Assignments',
    deleteConstraint: 'Restrict',
    required: true,
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Status__c', {
    type: 'Picklist',
    label: 'Status',
    valueSet: {
      restricted: true,
      valueSetDefinition: {
        sorted: false,
        value: [
          { fullName: 'Pending', default: true, label: 'Pending' },
          { fullName: 'Approved', default: false, label: 'Approved' },
        ],
      },
    },
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Approved_By__c', {
    type: 'Lookup',
    label: 'Approved By',
    referenceTo: 'User',
    relationshipName: 'Approved_List_Assignments',
    deleteConstraint: 'SetNull',
  });

  await ensureField(sf, 'Lead_List_Assignment__c', 'Approved_Date__c', {
    type: 'DateTime',
    label: 'Approved Date',
  });

  // -----------------------------------------------------------------------
  // PHASE 4 — Property__c (mirror of prod, only essential fields)
  // -----------------------------------------------------------------------
  log('\nPhase 4: Property__c fields');

  // Picklist for Status — matches prod values exactly
  await ensureField(sf, 'Property__c', 'Status__c', {
    type: 'Picklist',
    label: 'Status',
    valueSet: {
      restricted: true,
      valueSetDefinition: {
        sorted: false,
        value: [
          { fullName: 'Draft/Pre-Market', default: false, label: 'Draft/Pre-Market' },
          { fullName: 'Active', default: true, label: 'Active' },
          { fullName: 'Pending', default: false, label: 'Pending' },
          { fullName: 'LOI Signed', default: false, label: 'LOI Signed' },
          { fullName: 'Contract Signed', default: false, label: 'Contract Signed' },
          { fullName: 'Closed Won', default: false, label: 'Closed Won' },
          { fullName: 'Closed Lost', default: false, label: 'Closed Lost' },
        ],
      },
    },
  });

  await ensureField(sf, 'Property__c', 'Listing_Type__c', {
    type: 'Picklist',
    label: 'Listing Type',
    valueSet: {
      restricted: true,
      valueSetDefinition: {
        sorted: false,
        value: [
          { fullName: 'For Sale', default: true, label: 'For Sale' },
          { fullName: 'For Lease', default: false, label: 'For Lease' },
        ],
      },
    },
  });

  await ensureField(sf, 'Property__c', 'Marketing_Name__c', {
    type: 'Text',
    label: 'Marketing Name',
    length: 255,
  });
  await ensureField(sf, 'Property__c', 'Address__c', {
    type: 'Text',
    label: 'Address',
    length: 255,
  });
  await ensureField(sf, 'Property__c', 'City__c', {
    type: 'Text',
    label: 'City',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'State__c', {
    type: 'Text',
    label: 'State',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'Zip_Code__c', {
    type: 'Text',
    label: 'Zip Code',
    length: 20,
  });
  await ensureField(sf, 'Property__c', 'County__c', {
    type: 'Text',
    label: 'County',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'Property_Type__c', {
    type: 'Text',
    label: 'Property Type',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'Price__c', {
    type: 'Currency',
    label: 'Price',
    precision: 16,
    scale: 2,
  });
  await ensureField(sf, 'Property__c', 'Building_Size_sqft__c', {
    type: 'Number',
    label: 'Building Size (sqft)',
    precision: 12,
    scale: 0,
  });
  await ensureField(sf, 'Property__c', 'Lot_Size_sqft__c', {
    type: 'Number',
    label: 'Lot Size (sqft)',
    precision: 12,
    scale: 0,
  });
  await ensureField(sf, 'Property__c', 'Description__c', {
    type: 'LongTextArea',
    label: 'Description',
    length: 32000,
    visibleLines: 5,
  });
  await ensureField(sf, 'Property__c', 'Units__c', {
    type: 'Text',
    label: 'Units',
    length: 40,
  });
  await ensureField(sf, 'Property__c', 'Year_Built__c', {
    type: 'Text',
    label: 'Year Built',
    length: 20,
  });
  await ensureField(sf, 'Property__c', 'Zoning__c', {
    type: 'Text',
    label: 'Zoning',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'Pricing__c', {
    type: 'Text',
    label: 'Pricing',
    length: 80,
  });
  await ensureField(sf, 'Property__c', 'Public_URL__c', {
    type: 'Url',
    label: 'Public URL',
  });
  await ensureField(sf, 'Property__c', 'WP_Post_ID__c', {
    type: 'Number',
    label: 'WP Post ID',
    precision: 18,
    scale: 0,
  });

  // -----------------------------------------------------------------------
  // PHASE 5 — sample data
  // -----------------------------------------------------------------------
  log('\nPhase 5: sample data');
  await sleep(2000); // let metadata settle

  // 5 groups
  const sampleGroups = [
    'LittleHavanaMF',
    'MiamiBeachRetail',
    'AllapattahWarehouse',
    'CoralGablesOffice',
    'DoralIndustrial',
  ];
  const groupIds: Record<string, string> = {};
  const existingGroups = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c LIMIT 200`
  );
  for (const g of existingGroups) groupIds[g.Name] = g.Id;
  for (const name of sampleGroups) {
    if (groupIds[name]) {
      skip(`Group ${name}`);
      continue;
    }
    const id = await sf.create('Group__c', { Name: name });
    groupIds[name] = id;
    ok(`Group ${name}`);
  }

  // 10 leads with various group assignments (some sharing a group, some unique)
  const leadAssignments = [
    { name: 'Carlos Garcia', email: 'carlos.g@example.com', group: 'LittleHavanaMF' },
    { name: 'Maria Lopez', email: 'mlopez@example.com', group: 'LittleHavanaMF' },
    { name: 'Tom Reed', email: 'treed@example.com', group: 'MiamiBeachRetail' },
    { name: 'Yanira Suarez', email: 'ysuarez@example.com', group: 'MiamiBeachRetail' },
    { name: 'Bob Industrial', email: 'bob.i@example.com', group: 'AllapattahWarehouse' },
    { name: 'Sara CG', email: 'sara@example.com', group: 'CoralGablesOffice' },
    { name: 'Diego D', email: 'diego.d@example.com', group: 'DoralIndustrial' },
    { name: 'Test Multi', email: 'multi@example.com', group: 'LittleHavanaMF' },
    { name: 'Empty Lead', email: 'empty@example.com', group: '' },
    { name: 'Null Lead', email: 'null@example.com', group: '' },
  ];
  for (const la of leadAssignments) {
    const [first, ...lastParts] = la.name.split(' ');
    const last = lastParts.join(' ') || 'Test';
    const existing = await sf.soql<{ Id: string }>(
      `SELECT Id FROM Lead WHERE Email = '${la.email.replace(/'/g, "\\'")}'  LIMIT 1`
    );
    if (existing.length) {
      skip(`Lead ${la.email}`);
      continue;
    }
    const fields: Record<string, unknown> = {
      FirstName: first,
      LastName: last,
      Email: la.email,
      Company: `${la.name} LLC`,
    };
    if (la.group && groupIds[la.group]) fields.Group__c = groupIds[la.group];
    await sf.create('Lead', fields);
    ok(`Lead ${la.email}${la.group ? ' → ' + la.group : ''}`);
  }

  // 5 properties
  const sampleProperties = [
    {
      name: 'PROP-001',
      Marketing_Name__c: '8-Unit MF in Little Havana',
      Address__c: '1234 SW 8th St',
      City__c: 'Miami',
      State__c: 'FL',
      Zip_Code__c: '33135',
      County__c: 'Miami-Dade',
      Property_Type__c: 'Multi-Family',
      Listing_Type__c: 'For Sale',
      Status__c: 'Active',
      Price__c: 1850000,
      Building_Size_sqft__c: 8500,
      Lot_Size_sqft__c: 5000,
      Description__c: 'Test multi-family listing for Dev sync.',
    },
    {
      name: 'PROP-002',
      Marketing_Name__c: 'Retail Strip in Miami Beach',
      Address__c: '789 Collins Ave',
      City__c: 'Miami Beach',
      State__c: 'FL',
      Zip_Code__c: '33139',
      County__c: 'Miami-Dade',
      Property_Type__c: 'Retail',
      Listing_Type__c: 'For Lease',
      Status__c: 'Active',
      Price__c: 35,
      Building_Size_sqft__c: 2400,
      Lot_Size_sqft__c: 0,
      Description__c: 'Test retail listing for Dev sync.',
    },
    {
      name: 'PROP-003',
      Marketing_Name__c: 'Allapattah Warehouse',
      Address__c: '4500 NW 17th Ave',
      City__c: 'Miami',
      State__c: 'FL',
      Zip_Code__c: '33142',
      County__c: 'Miami-Dade',
      Property_Type__c: 'Industrial',
      Listing_Type__c: 'For Sale',
      Status__c: 'Pending',
      Price__c: 4200000,
      Building_Size_sqft__c: 18000,
      Lot_Size_sqft__c: 22000,
      Description__c: 'Test industrial listing.',
    },
    {
      name: 'PROP-004',
      Marketing_Name__c: 'Closed Won Sample',
      Address__c: '111 Closed Way',
      City__c: 'Doral',
      State__c: 'FL',
      Zip_Code__c: '33172',
      County__c: 'Miami-Dade',
      Property_Type__c: 'Office',
      Listing_Type__c: 'For Sale',
      Status__c: 'Closed Won',
      Price__c: 2500000,
      Description__c: 'Should map to SOLD on WP.',
    },
    {
      name: 'PROP-005',
      Marketing_Name__c: 'Closed Lost Sample',
      Address__c: '222 Lost Way',
      City__c: 'Hialeah',
      State__c: 'FL',
      Zip_Code__c: '33012',
      County__c: 'Miami-Dade',
      Property_Type__c: 'Office',
      Listing_Type__c: 'For Sale',
      Status__c: 'Closed Lost',
      Price__c: 1500000,
      Description__c: 'Should unpublish on WP.',
    },
  ];
  for (const p of sampleProperties) {
    const existing = await sf.soql<{ Id: string }>(
      `SELECT Id FROM Property__c WHERE Name = '${p.name}' LIMIT 1`
    );
    if (existing.length) {
      skip(`Property ${p.name}`);
      continue;
    }
    const fields: Record<string, unknown> = { ...p };
    delete (fields as Record<string, unknown>).name;
    fields.Name = p.name;
    await sf.create('Property__c', fields);
    ok(`Property ${p.name}`);
  }

  console.log('\n✅ Seed complete. Dev org ready for testing.\n');
  process.exit(0);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function objectExists(sf: Awaited<ReturnType<typeof sfClient>>, name: string): Promise<boolean> {
  try {
    await sf.describe(name);
    return true;
  } catch {
    return false;
  }
}

async function fieldExists(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<boolean> {
  try {
    const d = await sf.describe(obj);
    return d.fields.some((f: { name: string }) => f.name === field);
  } catch {
    return false;
  }
}

async function ensureField(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string,
  metadata: Record<string, unknown>
): Promise<void> {
  // describe() respects FLS for the calling user, so a freshly-created field
  // without FLS won't show up in describe — but Salesforce still knows it
  // exists and rejects duplicate creation. We try to create; on duplicate, we
  // treat it as "already there, just ensure FLS" — making the script
  // self-healing across reruns.
  if (await fieldExists(sf, obj, field)) {
    skip(`${obj}.${field}`);
    await grantFls(sf, obj, field);
    return;
  }
  try {
    await sf.toolingCreate('CustomField', {
      FullName: `${obj}.${field}`,
      Metadata: metadata,
    });
    await sleep(700);
    await grantFls(sf, obj, field);
    ok(`${obj}.${field}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('DUPLICATE_DEVELOPER_NAME')) {
      // Field already exists (FLS was hiding it from describe). Just grant FLS.
      await grantFls(sf, obj, field);
      console.log(`  ⊘ ${obj}.${field} (existed without FLS — granted)`);
      return;
    }
    console.error(`  ✗ ${obj}.${field} — ${msg}`);
  }
}

/**
 * Grant Read+Edit FLS on the given field to the integration user's permission
 * set. Newly created custom fields don't auto-grant FLS even on System Admin
 * profile when created via Tooling API — without this, the same user who just
 * created the field can't read or write it.
 */
async function grantFls(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<void> {
  try {
    await sf.create('FieldPermissions', {
      ParentId: DEV_INTEGRATION_PERM_SET_ID,
      SobjectType: obj,
      Field: `${obj}.${field}`,
      PermissionsRead: true,
      PermissionsEdit: true,
    });
  } catch (err) {
    // Common: DUPLICATE_VALUE if FLS already granted — fine, ignore.
    const msg = err instanceof Error ? err.message : String(err);
    if (!msg.includes('DUPLICATE_VALUE') && !msg.includes('already exists')) {
      console.warn(`    (FLS for ${obj}.${field}: ${msg.slice(0, 100)})`);
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Seed crashed:', err);
  process.exit(1);
});
