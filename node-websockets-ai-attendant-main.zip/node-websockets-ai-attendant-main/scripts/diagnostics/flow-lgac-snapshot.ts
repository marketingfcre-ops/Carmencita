/**
 * Snapshot the live Lead_Group_Access_Check Flow (active version) via Tooling
 * API. Read-only. Writes to sf-deploy/flows/Lead_Group_Access_Check-LIVE.json
 * so we can diff against the existing -BACKUP.json (which is Obsolete).
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/flow-lgac-snapshot.ts
 */
import fs from 'node:fs';
import path from 'node:path';
import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // 1. All Flow versions of Lead_Group_Access_Check
  const versions: any[] = await sf.toolingQuery(
    `SELECT Id, DefinitionId, VersionNumber, Status, MasterLabel, ApiVersion,
            ProcessType, CreatedDate, LastModifiedDate, LastModifiedBy.Name
     FROM Flow
     WHERE Definition.DeveloperName = 'Lead_Group_Access_Check'
     ORDER BY VersionNumber DESC`
  );
  console.log(`Found ${versions.length} versions of Lead_Group_Access_Check:`);
  for (const v of versions) {
    console.log(
      `  v${String(v.VersionNumber).padStart(2)}  ${v.Status.padEnd(10)} ${v.Id}  ${v.LastModifiedDate}  ${v.LastModifiedBy?.Name || ''}`
    );
  }

  const active = versions.find((v) => v.Status === 'Active');
  if (!active) {
    console.log('\n⚠️  No Active version found.');
    return;
  }
  console.log(`\nActive version: v${active.VersionNumber} (${active.Id})\n`);

  // 2. Pull full metadata for the active version
  const meta: any = await sf.toolingQuery(
    `SELECT Id, Status, VersionNumber, Metadata
     FROM Flow WHERE Id = '${active.Id}'`
  );
  const fullMetadata = (meta[0] as any)?.Metadata;

  const outDir = path.resolve(__dirname, '..', '..', 'sf-deploy', 'flows');
  const outPath = path.join(outDir, 'Lead_Group_Access_Check-LIVE.json');
  const payload = {
    snapshotted_at: new Date().toISOString(),
    flow_version_id: active.Id,
    flow_version_number: active.VersionNumber,
    status: active.Status,
    last_modified_date: active.LastModifiedDate,
    last_modified_by: active.LastModifiedBy?.Name,
    Metadata: fullMetadata,
  };
  fs.writeFileSync(outPath, JSON.stringify(payload, null, 2));
  console.log(`\nWrote ${outPath}`);
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
