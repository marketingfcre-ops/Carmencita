/**
 * ElevenLabs Text-to-Speech (WebSocket Streaming).
 * Uses the ultra-low latency `eleven_flash_v2_5` model.
 * Streams Twilio-compatible ulaw 8000Hz audio chunks back instantly.
 */

import WebSocket from 'ws';

const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY!;

const VOICES = {
  en: 'zGjIP4SZlMnY9m93k97r', //Hope
  es: '86V9x9hrQds83qf7zaGn', //Marcela
};

// ElevenLabs language codes for Flash v2.5
const LANG_CODES: Record<string, string> = {
  en: 'en',
  es: 'es',
};

export interface TTSOptions {
  voice?: string;
  lang?: 'en' | 'es';
}

export class ElevenLabsStream {
  private ws: WebSocket;
  private isReady = false;
  private textQueue: string[] = [];
  private completed = false;
  private spokenChars: string[] = []; // Alignment tracking for barge-in context

  constructor(
    private onAudioChunk: (audioBase64: string) => void,
    private onComplete: () => void,
    private onError: (err: any) => void,
    options?: TTSOptions
  ) {
    const lang = options?.lang || 'en';
    const voiceId = options?.voice || VOICES[lang];
    const langCode = LANG_CODES[lang] || 'en';

    // Request Twilio-compatible ulaw 8000Hz audio from the Flash model
    // Include language_code for reliable non-English generation
    // sync_alignment=true enables character-level alignment data in each audio chunk,
    // used by barge-in logic to know exactly what text was spoken before interruption
    const wsUrl = `wss://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream-input?model_id=eleven_flash_v2_5&output_format=ulaw_8000&language_code=${langCode}&sync_alignment=true`;

    this.ws = new WebSocket(wsUrl, {
      headers: { 'xi-api-key': ELEVENLABS_API_KEY },
    });

    this.ws.on('open', () => {
      this.isReady = true;
      // Send BOS (Beginning of Stream) message to initialize the voice
      this.ws.send(
        JSON.stringify({
          text: ' ',
          voice_settings: { stability: 0.5, similarity_boost: 0.8 },
          generation_config: {
            chunk_length_schedule: [50], // Smaller chunks = lower latency
          },
          apply_text_normalization: 'on', // Auto-normalize numbers, addresses, abbreviations for TTS
        })
      );
      this.flushQueue();
    });

    this.ws.on('message', (data: WebSocket.Data) => {
      try {
        const response = JSON.parse(data.toString());
        if (response.audio) {
          this.onAudioChunk(response.audio);
        }
        // Track alignment data — tells us exactly which characters were spoken
        if (response.alignment?.chars) {
          this.spokenChars.push(...response.alignment.chars);
        }
        if (response.isFinal) {
          this.ws.close();
          this.complete();
        }
        if (response.error) {
          console.error(`ElevenLabs error:`, response.error);
        }
      } catch (err) {
        this.onError(err);
      }
    });

    this.ws.on('error', (err) => {
      this.onError(err);
      this.complete(); // Unlock on error so call doesn't hang
    });
  }

  private complete(): void {
    if (this.completed) return;
    this.completed = true;
    this.onComplete();
  }

  /**
   * Push text chunks (from Claude) into the WebSocket.
   */
  public pushText(text: string): void {
    if (!text.trim()) return;

    if (!this.isReady) {
      this.textQueue.push(text);
      return;
    }

    this.ws.send(JSON.stringify({ text: text + ' ' }));
  }

  /**
   * Send the EOS (End of Stream) message to tell ElevenLabs to finish up.
   */
  public finish(): void {
    if (!this.isReady) {
      this.textQueue.push(''); // Empty string signals end
      return;
    }
    this.ws.send(JSON.stringify({ text: '' }));
  }

  public abort(): void {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.close();
    }
  }

  private flushQueue(): void {
    while (this.textQueue.length > 0) {
      const text = this.textQueue.shift();
      this.ws.send(JSON.stringify({ text: text === '' ? '' : text + ' ' }));
    }
  }

  public async waitForCompletion(): Promise<void> {
    return new Promise((resolve) => {
      const check = () => {
        if (this.completed) resolve();
        else setTimeout(check, 50); // Small poll is better than one big guess
      };
      check();
    });
  }

  /**
   * Get the text that ElevenLabs has converted to audio so far.
   * Built from alignment data sent with each audio chunk.
   * Used by barge-in logic to know exactly what the caller heard.
   */
  public getSpokenText(): string {
    return this.spokenChars.join('');
  }
}

/**
 * Helper: Detect language from text to pick the right TTS voice.
 */
export function detectLanguage(text: string): 'en' | 'es' {
  if (!text || text.trim().length === 0) return 'en';
  if (/[¿¡]/.test(text)) return 'es';
  const spanishWords =
    /\b(hola|gracias|puede|propiedad|está|estoy|oficina|almacén|bodega|disponible|información|ayudar|también|precio|alquiler|venta|pies|cuadrados|cerca|usted|tiene|para|por|nuestro|nuestra|perfecto|claro|bueno|bien|llamar|visita|negocio|espacio|detalles|coordinar|señor|señora|bienvenid[oa]|excelente|momento|comercial|terreno|zona|metros|interesad[oa])\b/gi;
  const matches = text.match(spanishWords);
  const wordCount = text.split(/\s+/).length;
  if (matches && matches.length / wordCount > 0.1) return 'es';
  return 'en';
}
