# Call Logs + Recordings Dashboard — Design Notes

_Draft 2026-06-21. Internal scoping doc. No timeline committed to client yet._

## Purpose

A single place for Fausto's admins to review call quality: **listen to recordings,
read transcripts, see the AI summary, and see what lead the call produced** — behind
real authentication. Replaces the current weak-key `/admin` page.

## Users

- **Carlos Fausto Miranda** (cfm@ — System Administrator)
- **Nathalie Aguirre** (na@)
- Other Salesforce **System Administrators**

Agents are **out of scope** for v1 (they'd only see their own calls — defer).

## What exists today (starting point)

| Piece | State | Gap |
|---|---|---|
| `/admin` dashboard | Server-rendered HTML, Fastify (`src/admin.ts`) | Auth = shared query key `?key=…`. Reads from local FS. |
| Call recording | Dual-channel started per call (`src/server.ts:138`) | No `RecordingStatusCallback` → URLs never captured/stored. |
| Call logs / transcripts | JSON written to `/tmp/call-logs` (`src/call-logger.ts`) | **`/tmp` is wiped on every Railway redeploy — logs are lost today.** |
| AI summary | Generated in-call | Not durably stored. |

## Architecture

```
Twilio ──(RecordingStatusCallback webhook)──▶ /webhooks/twilio/recording
                                                  │ fetch mp3 (authed)
                                                  ▼
                                        Object storage (R2 / B2)
                                          - recordings/  (6-mo retention)
                                          - calls/        (logs+transcripts, indefinite)
                                                  ▲
Caller ▶ call pipeline ─ CallLogger ──(write durable, not /tmp)──┘

Admin browser ──(SF OAuth web-server flow)──▶ /admin  ── reads from storage,
                                              gated to System Administrator
                                              ── streams recordings via signed URLs
```

### Decisions

- **Frontend:** extend the existing server-rendered `/admin` (Fastify + template
  literals). A separate SPA is not worth the maintenance for a 2–3 person audience.
- **Auth:** Salesforce **OAuth 2.0 web-server flow** via a Connected App (allowed in
  PE). On callback, check the user's Profile = System Administrator; else 403.
  Retire `ADMIN_KEY`.
- **Storage:** Cloudflare **R2** (or Backblaze B2) — same account as backups.
  - `calls/<callSid>.json` — transcript + events + AI summary. **Indefinite.**
  - `recordings/<callSid>.mp3` — pulled from Twilio. **6-month retention** (auto-prune).
- **Recordings ingest:** add `RecordingStatusCallback` to the recording start in
  `src/server.ts`; handler fetches the completed mp3 (Basic auth) and PUTs to storage.
  Serve to the browser via short-lived signed URLs — never expose Twilio creds.
- **Logs persistence:** point `CallLogger` at storage instead of `/tmp` (or write
  both). This is the **prerequisite fix worth doing first** — we lose logs on every
  deploy today.

## Compliance

- **Recording disclosure** added to the greeting 2026-06-21 (FL is two-party consent).
  Do **not** surface recordings made before that change without confirming disclosure.
- **Retention:** recordings 6 months; transcripts indefinite (text, low risk).

## Phases & rough estimate (~8–12 working days)

1. **Persist logs off `/tmp`** → storage. ~2d. _(Stops active data loss; do first.)_
2. **Recording capture** webhook + storage + signed-URL playback. ~2d.
3. **Salesforce OAuth** login + admin gating. ~2–3d.
4. **Dashboard UI** — list / filter / detail (player + transcript + summary + lead). ~3–4d.
5. **Polish, deploy, test.** ~1d.

## Open decisions

- Transcript **search** needed, or per-call browsing enough? (search adds an index.)
- Recording retention — confirm 6 months.
- Connected App ownership — created under cfm@ admin.
- Do we link each call to the Salesforce Lead it created (deep link)?
