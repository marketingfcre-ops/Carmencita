/**
 * South Florida spatial knowledge base.
 *
 * Gives the search engine and Claude awareness of:
 * - Miami-Dade 2D grid system (Streets N-S axis + Avenues E-W axis)
 * - Neighborhood boundaries, directional proximity with distances
 * - Highway and road aliases
 * - Address parsing and neighborhood location
 */

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface GridBounds {
  streets: [number, number]; // [min, max] street number range (N-S axis)
  avenues: [number, number]; // [min, max] avenue number range (E-W axis)
  quadrant: 'NW' | 'NE' | 'SW' | 'SE' | 'any';
}

interface DirectionalNeighbor {
  name: string;
  miles: number;
}

interface AreaInfo {
  name: string;
  aliases: string[];
  mainRoads: string[];
  boundaries: {
    north: string;
    south: string;
    east: string;
    west: string;
  };
  proximity: {
    north: DirectionalNeighbor[];
    south: DirectionalNeighbor[];
    east: DirectionalNeighbor[];
    west: DirectionalNeighbor[];
  };
  gridBounds?: GridBounds;
  county: 'miami-dade' | 'broward' | 'palm-beach';
  description: string;
}

// ---------------------------------------------------------------------------
// Area data — key 19 areas with full directional proximity + boundaries
// ---------------------------------------------------------------------------

const AREAS: AreaInfo[] = [
  // ---- Miami-Dade: Downtown core ----
  {
    name: 'downtown',
    aliases: ['downtown miami', 'brickell', 'brickell ave', 'cbd'],
    mainRoads: ['Biscayne Blvd', 'Flagler St', 'Miami Ave', 'Brickell Ave', 'I-95'],
    boundaries: { north: 'NE 17th Ter', south: 'SW 26th Rd (Rickenbacker)', east: 'Biscayne Bay', west: 'I-95' },
    proximity: {
      north: [{ name: 'edgewater', miles: 1 }, { name: 'wynwood', miles: 2 }, { name: 'little haiti', miles: 4 }],
      south: [{ name: 'coconut grove', miles: 3 }, { name: 'coral gables', miles: 4 }, { name: 'south miami', miles: 7 }],
      east: [{ name: 'miami beach', miles: 4 }],
      west: [{ name: 'little havana', miles: 1 }, { name: 'allapattah', miles: 3 }, { name: 'miami airport', miles: 7 }],
    },
    gridBounds: { streets: [0, 17], avenues: [0, 4], quadrant: 'any' },
    county: 'miami-dade',
    description: 'Central business district and Brickell financial district, along Biscayne Bay',
  },
  // ---- Wynwood ----
  {
    name: 'wynwood',
    aliases: ['wynwood arts', 'wynwood norte', 'the wynwood'],
    mainRoads: ['NW 2nd Ave', 'NW 29th St', 'NW 5th Ave'],
    boundaries: { north: 'NW 36th St', south: 'NW 20th St', east: 'N Miami Ave', west: 'NW 7th Ave' },
    proximity: {
      north: [{ name: 'little haiti', miles: 1 }, { name: 'little river', miles: 3 }],
      south: [{ name: 'edgewater', miles: 1 }, { name: 'downtown', miles: 2 }, { name: 'brickell', miles: 4 }],
      east: [{ name: 'miami beach', miles: 4 }],
      west: [{ name: 'allapattah', miles: 1 }, { name: 'miami airport', miles: 5 }, { name: 'doral', miles: 10 }],
    },
    gridBounds: { streets: [20, 36], avenues: [0, 7], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'Arts and warehouse district north of downtown, west of Edgewater',
  },
  // ---- Little Havana ----
  {
    name: 'little havana',
    aliases: ['calle ocho', 'la pequeña habana'],
    mainRoads: ['SW 8th St', 'W Flagler St', 'SW 27th Ave', 'SW 12th Ave'],
    boundaries: { north: 'W Flagler St', south: 'SW 16th St', east: 'SW 4th Ave', west: 'SW 27th Ave' },
    proximity: {
      north: [{ name: 'allapattah', miles: 1 }, { name: 'wynwood', miles: 2 }],
      south: [{ name: 'coral way', miles: 1 }, { name: 'coral gables', miles: 3 }],
      east: [{ name: 'downtown', miles: 1 }, { name: 'brickell', miles: 2 }],
      west: [{ name: 'flagami', miles: 2 }, { name: 'sweetwater', miles: 6 }, { name: 'doral', miles: 9 }],
    },
    gridBounds: { streets: [0, 16], avenues: [4, 27], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'West of Brickell, east of Coral Gables, runs along SW 8th St (Calle Ocho) and Flagler',
  },
  // ---- Allapattah ----
  {
    name: 'allapattah',
    aliases: ['allapathah', 'alla parra', 'alapara'],
    mainRoads: ['NW 20th St', 'NW 22nd Ave', 'NW 36th St', 'NW 7th Ave'],
    boundaries: { north: 'NW 36th St', south: 'NW 7th St', east: 'NW 7th Ave', west: 'NW 27th Ave' },
    proximity: {
      north: [{ name: 'liberty city', miles: 2 }, { name: 'brownsville', miles: 3 }],
      south: [{ name: 'little havana', miles: 1 }, { name: 'downtown', miles: 2 }],
      east: [{ name: 'wynwood', miles: 1 }, { name: 'edgewater', miles: 2 }],
      west: [{ name: 'miami airport', miles: 3 }, { name: 'doral', miles: 7 }],
    },
    gridBounds: { streets: [7, 36], avenues: [7, 27], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'Mile west of Wynwood, east of the airport, main road is NW 22nd Ave',
  },
  // ---- Little Haiti / Little River ----
  {
    name: 'little haiti',
    aliases: ['little river', 'lemon city', 'little haiti little river'],
    mainRoads: ['NE 2nd Ave', 'NE 54th St', 'NW 7th Ave', 'NW 79th St'],
    boundaries: { north: 'NW 79th St', south: 'NW 36th St', east: 'NE 2nd Ave', west: 'NW 17th Ave' },
    proximity: {
      north: [{ name: 'north miami', miles: 3 }, { name: 'north miami beach', miles: 7 }],
      south: [{ name: 'wynwood', miles: 1 }, { name: 'downtown', miles: 3 }],
      east: [{ name: 'miami beach', miles: 5 }],
      west: [{ name: 'liberty city', miles: 1 }, { name: 'hialeah', miles: 5 }],
    },
    gridBounds: { streets: [36, 79], avenues: [0, 17], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'North of Wynwood, cultural hub along NE 2nd Ave, includes Little River area',
  },
  // ---- Flagami / Coral Way ----
  {
    name: 'flagami',
    aliases: ['coral way', 'coral way village'],
    mainRoads: ['W Flagler St', 'SW 8th St', 'Coral Way', 'SW 72nd Ave', 'SW 42nd Ave'],
    boundaries: { north: 'W Flagler St', south: 'SW 24th St (Coral Way)', east: 'SW 27th Ave', west: 'SW 72nd Ave' },
    proximity: {
      north: [{ name: 'miami airport', miles: 2 }, { name: 'hialeah', miles: 5 }],
      south: [{ name: 'coral gables', miles: 2 }, { name: 'south miami', miles: 5 }],
      east: [{ name: 'little havana', miles: 2 }, { name: 'downtown', miles: 4 }],
      west: [{ name: 'sweetwater', miles: 3 }, { name: 'doral', miles: 6 }],
    },
    gridBounds: { streets: [0, 24], avenues: [27, 72], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'Residential area west of Little Havana, south of airport, Coral Way runs through it',
  },
  // ---- Coral Gables ----
  {
    name: 'coral gables',
    aliases: ['the gables', 'coral cable', 'coral cables'],
    mainRoads: ['Ponce de Leon Blvd', 'Miracle Mile', 'Le Jeune Rd', 'US-1', 'Coral Way'],
    boundaries: { north: 'SW 22nd St / Coral Way', south: 'SW 72nd St (Sunset Dr)', east: 'Le Jeune Rd / SW 42nd Ave', west: 'Red Rd / SW 57th Ave' },
    proximity: {
      north: [{ name: 'little havana', miles: 2 }, { name: 'flagami', miles: 2 }],
      south: [{ name: 'south miami', miles: 2 }, { name: 'pinecrest', miles: 5 }],
      east: [{ name: 'brickell', miles: 3 }, { name: 'coconut grove', miles: 2 }],
      west: [{ name: 'sweetwater', miles: 4 }, { name: 'kendall', miles: 5 }],
    },
    gridBounds: { streets: [22, 72], avenues: [37, 57], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'Upscale city south-southwest of downtown, known for Miracle Mile',
  },
  // ---- Doral ----
  {
    name: 'doral',
    aliases: ['city of doral'],
    mainRoads: ['NW 36th St', 'NW 41st St', 'NW 87th Ave', 'NW 107th Ave', 'Dolphin Expy (836)'],
    boundaries: { north: 'NW 58th St', south: 'NW 25th St', east: 'NW 79th Ave', west: 'NW 117th Ave' },
    proximity: {
      north: [{ name: 'medley', miles: 3 }, { name: 'hialeah gardens', miles: 5 }],
      south: [{ name: 'sweetwater', miles: 3 }, { name: 'flagami', miles: 5 }],
      east: [{ name: 'miami airport', miles: 3 }, { name: 'allapattah', miles: 7 }, { name: 'wynwood', miles: 10 }],
      west: [{ name: 'everglades', miles: 10 }],
    },
    gridBounds: { streets: [25, 58], avenues: [79, 117], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'Major commercial/industrial hub west of airport, along Dolphin Expressway (836)',
  },
  // ---- Hialeah ----
  {
    name: 'hialeah',
    aliases: ['city of hialeah', 'east hialeah'],
    mainRoads: ['W 49th St', 'Palm Ave', 'E 8th Ave', 'Okeechobee Rd', 'Palmetto Expy (826)'],
    boundaries: { north: 'NW 138th St', south: 'NW 36th St', east: 'E 2nd Ave', west: 'W 68th Ave (Palmetto)' },
    proximity: {
      north: [{ name: 'hialeah gardens', miles: 3 }, { name: 'opalocka', miles: 3 }],
      south: [{ name: 'miami airport', miles: 3 }, { name: 'allapattah', miles: 5 }],
      east: [{ name: 'little haiti', miles: 5 }, { name: 'north miami', miles: 5 }],
      west: [{ name: 'doral', miles: 3 }, { name: 'medley', miles: 3 }],
    },
    gridBounds: { streets: [36, 138], avenues: [0, 68], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'Large city northwest of Miami, heavily Hispanic, major industrial and commercial presence',
  },
  // ---- Medley ----
  {
    name: 'medley',
    aliases: ['town of medley'],
    mainRoads: ['NW 74th St', 'Okeechobee Rd', 'NW 107th Ave', 'Palmetto Expy (826)'],
    boundaries: { north: 'NW 138th St', south: 'NW 58th St', east: 'Palmetto Expy (826)', west: 'NW 117th Ave' },
    proximity: {
      north: [{ name: 'hialeah gardens', miles: 2 }],
      south: [{ name: 'doral', miles: 3 }, { name: 'sweetwater', miles: 5 }],
      east: [{ name: 'hialeah', miles: 2 }],
      west: [{ name: 'everglades', miles: 8 }],
    },
    gridBounds: { streets: [58, 138], avenues: [87, 117], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'Industrial town northwest of Doral, warehouses and distribution centers',
  },
  // ---- Opalocka ----
  {
    name: 'opalocka',
    aliases: ['opa-locka', 'opa locka'],
    mainRoads: ['NW 27th Ave', 'Ali Baba Ave', 'NW 135th St', 'NW 151st St'],
    boundaries: { north: 'NW 167th St (County Line)', south: 'NW 119th St', east: 'NW 17th Ave', west: 'NW 47th Ave' },
    proximity: {
      north: [{ name: 'miami gardens', miles: 3 }],
      south: [{ name: 'hialeah', miles: 3 }, { name: 'liberty city', miles: 5 }],
      east: [{ name: 'north miami', miles: 4 }],
      west: [{ name: 'hialeah gardens', miles: 3 }, { name: 'medley', miles: 5 }],
    },
    gridBounds: { streets: [119, 167], avenues: [17, 47], quadrant: 'NW' },
    county: 'miami-dade',
    description: 'North of Hialeah, known for Moorish architecture, airport area',
  },
  // ---- North Miami / North Miami Beach ----
  {
    name: 'north miami',
    aliases: ['nomi', 'north miami beach', 'nmb'],
    mainRoads: ['NE 125th St', 'Biscayne Blvd', 'W Dixie Hwy', 'NE 163rd St', 'NE 167th St'],
    boundaries: { north: 'NE 203rd St (Broward border)', south: 'NE 87th St', east: 'Biscayne Bay', west: 'NW 27th Ave' },
    proximity: {
      north: [{ name: 'hallandale', miles: 3 }, { name: 'hollywood', miles: 5 }],
      south: [{ name: 'little haiti', miles: 3 }, { name: 'wynwood', miles: 6 }, { name: 'downtown', miles: 8 }],
      east: [{ name: 'miami beach', miles: 3 }],
      west: [{ name: 'opalocka', miles: 4 }, { name: 'hialeah', miles: 5 }],
    },
    gridBounds: { streets: [87, 203], avenues: [0, 27], quadrant: 'NE' },
    county: 'miami-dade',
    description: 'Northeast Miami-Dade along Biscayne Blvd corridor, includes NMB near Aventura',
  },
  // ---- Kendall / Pinecrest / South Miami ----
  {
    name: 'kendall',
    aliases: ['pinecrest', 'south miami', 'south miami heights', 'sunset'],
    mainRoads: ['US-1', 'Kendall Dr (SW 88th St)', 'SW 104th St', 'SW 137th Ave', 'Sunset Dr'],
    boundaries: { north: 'SW 56th St (Miller Dr)', south: 'SW 184th St', east: 'US-1', west: 'SW 157th Ave' },
    proximity: {
      north: [{ name: 'coral gables', miles: 3 }, { name: 'south miami', miles: 1 }],
      south: [{ name: 'palmetto bay', miles: 3 }, { name: 'cutler bay', miles: 7 }, { name: 'homestead', miles: 15 }],
      east: [{ name: 'pinecrest', miles: 2 }],
      west: [{ name: 'the hammocks', miles: 3 }],
    },
    gridBounds: { streets: [56, 184], avenues: [57, 157], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'Large suburban area in south-central Miami-Dade along US-1 and Kendall Drive',
  },
  // ---- Palmetto Bay / Cutler Bay ----
  {
    name: 'cutler bay',
    aliases: ['palmetto bay', 'cutler ridge'],
    mainRoads: ['US-1', 'Old Cutler Rd', 'SW 184th St', 'SW 200th St', 'SW 211th St'],
    boundaries: { north: 'SW 168th St', south: 'SW 232nd St', east: 'Biscayne Bay', west: 'SW 117th Ave' },
    proximity: {
      north: [{ name: 'pinecrest', miles: 2 }, { name: 'kendall', miles: 5 }, { name: 'coral gables', miles: 10 }],
      south: [{ name: 'homestead', miles: 5 }, { name: 'florida city', miles: 10 }],
      east: [{ name: 'biscayne bay', miles: 1 }],
      west: [{ name: 'the hammocks', miles: 5 }],
    },
    gridBounds: { streets: [168, 232], avenues: [0, 117], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'Far south Miami-Dade between Pinecrest and Homestead along US-1',
  },
  // ---- Homestead / Florida City ----
  {
    name: 'homestead',
    aliases: ['florida city', 'city of homestead', 'goulds'],
    mainRoads: ['US-1', 'Krome Ave', 'Campbell Dr', 'SW 288th St', 'SW 312th St', 'Palm Dr'],
    boundaries: { north: 'SW 232nd St', south: 'SW 344th St (Florida City)', east: 'US-1', west: 'Krome Ave' },
    proximity: {
      north: [{ name: 'cutler bay', miles: 5 }, { name: 'palmetto bay', miles: 8 }, { name: 'kendall', miles: 15 }],
      south: [{ name: 'florida keys', miles: 20 }],
      east: [{ name: 'biscayne bay', miles: 5 }],
      west: [{ name: 'everglades', miles: 5 }],
    },
    gridBounds: { streets: [232, 350], avenues: [0, 150], quadrant: 'SW' },
    county: 'miami-dade',
    description: 'Far south, agricultural area, last major cities before the Florida Keys',
  },
  // ---- Miami Beach ----
  {
    name: 'miami beach',
    aliases: ['the beach', 'south beach', 'sobe', 'mb', 'north beach', 'mid beach'],
    mainRoads: ['Collins Ave', 'Ocean Dr', 'Alton Rd', 'Indian Creek Dr'],
    boundaries: { north: '87th Ter', south: 'South Pointe', east: 'Atlantic Ocean', west: 'Biscayne Bay' },
    proximity: {
      north: [{ name: 'surfside', miles: 2 }, { name: 'bal harbour', miles: 3 }],
      south: [],
      east: [],
      west: [{ name: 'downtown', miles: 4 }, { name: 'wynwood', miles: 5 }, { name: 'north miami', miles: 5 }],
    },
    county: 'miami-dade',
    description: 'Barrier island city east of downtown across Biscayne Bay',
  },
  // ---- Broward: Fort Lauderdale ----
  {
    name: 'fort lauderdale',
    aliases: ['ft lauderdale', 'ftl', 'ft. lauderdale', 'lauderdale'],
    mainRoads: ['Broward Blvd', 'Sunrise Blvd', 'Federal Hwy', 'US-1', 'I-95', 'A1A'],
    boundaries: { north: 'Cypress Creek Rd', south: 'Davie Blvd / SW 2nd St', east: 'Atlantic Ocean', west: 'I-95' },
    proximity: {
      north: [{ name: 'pompano beach', miles: 5 }, { name: 'deerfield beach', miles: 10 }],
      south: [{ name: 'dania beach', miles: 3 }, { name: 'hollywood', miles: 5 }, { name: 'hallandale', miles: 8 }],
      east: [],
      west: [{ name: 'davie', miles: 5 }, { name: 'lauderhill', miles: 5 }],
    },
    county: 'broward',
    description: 'Broward County seat, major city north of Miami-Dade border',
  },
  // ---- Broward: Hollywood / Hallandale ----
  {
    name: 'hollywood',
    aliases: ['hollywood fl', 'hallandale', 'hallandale beach'],
    mainRoads: ['Hollywood Blvd', 'Hallandale Beach Blvd', 'US-1', 'I-95', 'Federal Hwy'],
    boundaries: { north: 'Sheridan St', south: 'Miami-Dade County line', east: 'Atlantic Ocean', west: 'I-75' },
    proximity: {
      north: [{ name: 'dania beach', miles: 2 }, { name: 'fort lauderdale', miles: 5 }],
      south: [{ name: 'north miami beach', miles: 3 }, { name: 'aventura', miles: 2 }],
      east: [],
      west: [{ name: 'miramar', miles: 3 }, { name: 'pembroke park', miles: 2 }, { name: 'davie', miles: 5 }],
    },
    county: 'broward',
    description: 'Southern Broward including Hallandale Beach, on the Miami-Dade border',
  },
  // ---- Broward: Pompano / Deerfield ----
  {
    name: 'pompano beach',
    aliases: ['pompano', 'deerfield beach', 'deerfield'],
    mainRoads: ['Atlantic Blvd', 'Copans Rd', 'Hillsboro Blvd', 'Federal Hwy', 'US-1', 'I-95'],
    boundaries: { north: 'Palm Beach County line', south: 'Cypress Creek Rd', east: 'Atlantic Ocean', west: 'Powerline Rd' },
    proximity: {
      north: [{ name: 'boca raton', miles: 5 }],
      south: [{ name: 'fort lauderdale', miles: 5 }],
      east: [],
      west: [{ name: 'coral springs', miles: 5 }, { name: 'coconut creek', miles: 3 }],
    },
    county: 'broward',
    description: 'Northern Broward along the coast, includes Deerfield Beach area',
  },
];

// ---------------------------------------------------------------------------
// Highway aliases — for query expansion
// ---------------------------------------------------------------------------

export const HIGHWAY_ALIASES: Record<string, string[]> = {
  'us-1': ['us 1', 'us1', 'dixie', 'dixie hwy', 'dixie highway', 's dixie hwy', 'south dixie highway', 'route 1', 'highway 1', 'just one', 'just 1'],
  'us1': ['us-1', 'us 1', 'dixie', 'dixie hwy', 'dixie highway', 's dixie hwy', 'south dixie highway', 'route 1', 'highway 1'],
  'dixie': ['us-1', 'us 1', 'dixie hwy', 'dixie highway', 's dixie hwy', 'south dixie highway'],
  '836': ['dolphin', 'dolphin expressway', 'dolphin expy'],
  'dolphin': ['836', 'dolphin expressway', 'dolphin expy'],
  '826': ['palmetto', 'palmetto expressway', 'palmetto expy'],
  'palmetto expressway': ['826', 'palmetto', 'palmetto expy'],
  '874': ['don shula', 'don shula expressway', 'don shula expy'],
  'turnpike': ['florida turnpike', 'sr-91', 'sr 91'],
  'i-95': ['95', 'i95', 'interstate 95'],
  '95': ['i-95', 'i95', 'interstate 95'],
  'biscayne': ['biscayne blvd', 'biscayne boulevard'],
  'federal': ['federal hwy', 'federal highway'],
  'a1a': ['a-1-a', 'ocean blvd'],
  'krome': ['krome ave', 'krome avenue'],
  'okeechobee': ['okeechobee rd', 'okeechobee road'],
};

// ---------------------------------------------------------------------------
// Build lookup index
// ---------------------------------------------------------------------------

const areaIndex = new Map<string, AreaInfo>();
for (const area of AREAS) {
  areaIndex.set(area.name, area);
  for (const alias of area.aliases) {
    areaIndex.set(alias.toLowerCase(), area);
  }
}

// ---------------------------------------------------------------------------
// Address parsing
// ---------------------------------------------------------------------------

interface ParsedAddress {
  streetNum: number | null;  // N-S axis (street number or derived from building number)
  aveNum: number | null;     // E-W axis (avenue number)
  quadrant: string | null;   // NW, NE, SW, SE
}

/**
 * Parse a Miami-Dade address to extract grid coordinates.
 *
 * Examples:
 *   "12101 NW 98th Ave" → streetNum=121, aveNum=98, quadrant=NW
 *   "7921 NW 44th Ct"   → streetNum=79, aveNum=44, quadrant=NW
 *   "997 NE 125th St"   → streetNum=125, aveNum=10, quadrant=NE
 *   "4831 W Flagler St"  → streetNum=0 (Flagler), aveNum=48, quadrant=SW
 */
export function parseAddressGrid(address: string): ParsedAddress {
  const addr = address.toUpperCase().trim();
  const result: ParsedAddress = { streetNum: null, aveNum: null, quadrant: null };

  // Extract quadrant
  const quadMatch = addr.match(/\b(NW|NE|SW|SE|NORTHWEST|NORTHEAST|SOUTHWEST|SOUTHEAST)\b/);
  if (quadMatch) {
    const q = quadMatch[1];
    result.quadrant = q.length === 2 ? q : q.startsWith('NORTH')
      ? (q.endsWith('WEST') ? 'NW' : 'NE')
      : (q.endsWith('WEST') ? 'SW' : 'SE');
  }

  // Detect if it's a street or avenue address
  const isStreet = /\b(STREET|ST|TERRACE|TER|PLACE|PL)\b/i.test(addr) && !/\bAVE/i.test(addr);
  const isAvenue = /\b(AVENUE|AVE|COURT|CT|DRIVE|DR|WAY|LANE|LN)\b/i.test(addr);

  // Extract the road number (e.g., "98th Ave" → 98, "125th St" → 125)
  const roadNumMatch = addr.match(/\b(\d{1,3})\s*(?:TH|ST|ND|RD)?\s*(?:STREET|ST|AVENUE|AVE|COURT|CT|DRIVE|DR|TERRACE|TER|PLACE|PL|WAY|LANE|LN|BLVD|BOULEVARD|ROAD|RD)\b/i);
  const roadNum = roadNumMatch ? parseInt(roadNumMatch[1], 10) : null;

  // Extract building number (first number in address)
  const buildingMatch = addr.match(/^(\d{1,6})\b/);
  const buildingNum = buildingMatch ? parseInt(buildingMatch[1], 10) : null;

  // Derive cross-street from building number: 12101 → 121st block → street ~121
  const crossStreet = buildingNum ? Math.floor(buildingNum / 100) : null;

  if (isAvenue && roadNum != null) {
    // Address is on an avenue → roadNum is the E-W position, building number gives N-S
    result.aveNum = roadNum;
    result.streetNum = crossStreet;
  } else if (isStreet && roadNum != null) {
    // Address is on a street → roadNum is the N-S position, building number gives E-W
    result.streetNum = roadNum;
    result.aveNum = crossStreet;
  } else if (roadNum != null) {
    // Ambiguous — use building number heuristic
    result.streetNum = crossStreet;
    result.aveNum = roadNum;
  }

  // Handle Flagler St (the zero line)
  if (/FLAGLER/i.test(addr)) {
    result.streetNum = 0;
    if (buildingNum) result.aveNum = Math.floor(buildingNum / 100);
  }

  // Handle Miami Ave (the zero line)
  if (/MIAMI\s+AVE/i.test(addr)) {
    result.aveNum = 0;
    if (buildingNum) result.streetNum = Math.floor(buildingNum / 100);
  }

  return result;
}

// ---------------------------------------------------------------------------
// Location functions
// ---------------------------------------------------------------------------

/**
 * Given grid coordinates, return neighborhoods that contain this position.
 */
export function locateAddress(streetNum: number | null, aveNum: number | null, quadrant: string | null): string[] {
  const matches: string[] = [];

  for (const area of AREAS) {
    if (!area.gridBounds) continue;
    const gb = area.gridBounds;

    // Check quadrant compatibility
    if (gb.quadrant !== 'any' && quadrant && gb.quadrant !== quadrant) continue;

    // Check street range (N-S axis)
    const streetOk = streetNum == null || (streetNum >= gb.streets[0] && streetNum <= gb.streets[1]);
    // Check avenue range (E-W axis)
    const aveOk = aveNum == null || (aveNum >= gb.avenues[0] && aveNum <= gb.avenues[1]);

    if (streetOk && aveOk) {
      matches.push(area.name);
    }
  }

  return [...new Set(matches)];
}

/**
 * Flat list of all directional neighbors (for search token injection).
 */
export function getNearbyAreas(areaName: string): string[] {
  const area = areaIndex.get(areaName.toLowerCase().trim());
  if (!area) return [];

  const all: string[] = [];
  for (const dir of ['north', 'south', 'east', 'west'] as const) {
    for (const n of area.proximity[dir]) {
      all.push(n.name);
    }
  }
  return [...new Set(all)];
}

/**
 * Human-readable directional proximity description for Claude.
 */
export function getProximityContext(areaName: string): string | null {
  const area = areaIndex.get(areaName.toLowerCase().trim());
  if (!area) return null;

  const parts: string[] = [`${area.name}: ${area.description}`];
  parts.push(`Boundaries: N=${area.boundaries.north}, S=${area.boundaries.south}, E=${area.boundaries.east}, W=${area.boundaries.west}`);

  for (const dir of ['north', 'south', 'east', 'west'] as const) {
    if (area.proximity[dir].length > 0) {
      const neighbors = area.proximity[dir].map((n) => `${n.name} (${n.miles}mi)`).join(', ');
      parts.push(`${dir}: ${neighbors}`);
    }
  }

  return parts.join('. ');
}

/**
 * Look up an area by name or alias.
 */
export function getAreaInfo(name: string): AreaInfo | null {
  return areaIndex.get(name.toLowerCase().trim()) || null;
}

/**
 * Get all known area names and aliases.
 */
export function getAllAreaNames(): string[] {
  return Array.from(areaIndex.keys());
}

/**
 * Expand highway aliases for a token.
 */
export function expandHighwayAliases(token: string): string[] {
  const key = token.toLowerCase().replace(/[\s-]+/g, '-');
  return HIGHWAY_ALIASES[key] || HIGHWAY_ALIASES[token.toLowerCase()] || [];
}

/**
 * Analyze a search query for geographic cues and return context for Claude.
 */
export function getGeographyContext(query: string): string | null {
  const lower = query.toLowerCase();
  const parts: string[] = [];

  // Check for street number references (e.g., "215th", "near 125th")
  const streetMatch = lower.match(/\b(\d{1,3})\s*(?:th|st|nd|rd)?\s*(?:street|st|ave|avenue|blvd|boulevard|road|rd)?\b/);
  if (streetMatch) {
    const num = parseInt(streetMatch[1], 10);
    if (num > 0) {
      const areas = locateAddress(num, null, null);
      if (areas.length > 0) {
        parts.push(`Street ${num} is in the ${areas.slice(0, 3).join(' / ')} area`);
      }
    }
  }

  // Check for known area names
  for (const area of AREAS) {
    const names = [area.name, ...area.aliases];
    for (const name of names) {
      if (name.length > 2 && lower.includes(name.toLowerCase())) {
        const nearby = getNearbyAreas(area.name);
        parts.push(`${area.name}: ${area.description}. Nearby areas: ${nearby.slice(0, 4).join(', ')}`);
        break;
      }
    }
  }

  // Check for highway references
  for (const [key, aliases] of Object.entries(HIGHWAY_ALIASES)) {
    if (key.length > 2 && lower.includes(key)) {
      parts.push(`"${key}" is also known as: ${aliases.slice(0, 3).join(', ')}`);
      break;
    }
  }

  return parts.length > 0 ? parts.join('. ') : null;
}
