# Agent → Group Assignments — Current State

_From Salesforce `User_Group_Access__c`. These are the groups each agent is allowed to edit once protection is on._

**51 agents · 699 assignments (active agents only).**

| Agent | # Groups | Groups |
|---|---:|---|
| Adam Hauptman | 10 | Broward Gas, BrowardMulti, Brownsville, FTLApts, HallandaleRetail, HollywoodRetail, NOBE, SouthBrowardApt, SouthBrowardInd, SouthBrowardRetail |
| Adir Bezalely | 4 | DaniaMulti, FTLApts, LakeWorthApt, PompanoMultiFam |
| Anne Mairura | 3 | MiamiBeachCom, MiamiBeachRetail, NNN Kodiak |
| Aria Fleming | 5 | JaxDwnTwnRet, JaxDwtwnSpring, NoEastFlaHotel, StAugustineOffice, WestSideJax |
| Ariel Levi | 3 | CoralSpringsMF, DeerfieldApts, SouthBrowardRetail |
| Armando Mercado | 2 | Doral Industrial, NorthMiaLand |
| Armando Sanchez-Bueno | 2 | AirWest, Doral Industrial |
| Arun Mohan | 5 | BrowardMulti, FTL MF East, HallandaleRetail, HollywoodRetail, PompanoMultiFam |
| Ashleen Cruz | 24 | BirdRoadCom, CoralGablesCom, CoralWay, DadeHotelMotel, Doral HG&M&MS Retail, Flagami, Flagami Apts, Flagami Com, LittleHavanaCom, NewFlagami, QUAILROOST, ShenandoahApts, SouthMiami, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, UniPrkSwtwtrSoDoral, US1-Grovecom, WarehousesSouth, Westchester, WestchesterCom, WestchesterRetail, WestchesterWRetail |
| Avigail Gayer | 1 | BrowardShopping |
| Ben Fernandez | 4 | Allapattah, SouthMiaInd, SOUThMiamiAlberto, SouthMiamiInd |
| Benjamin Kunzle | 2 | EastSide, JRLitHaitiWyn |
| Bobby Berrido | 47 | AirWest, BirdRoadCom, BirdroadRetail, Bobby, BobbyRetail, BrevardGas, Broward Gas, CID, Collier Gas, CoralGables, CoralGablesOffice, CoralWay, Dade County, Doral, Doral Industrial, EHia, Flagami Apts, Flagami Com, GablesMulti, GasStation, HendryGas, HiaGardens, HiaGardenWare, Hialeah Gardens, HillsboroughGas, Homestead, LeeGas, LittleHavanaApt, LittleRiver, Medley, MIMO, MonroeGas, NewFlagami, OrangeGas, PalmBeachGas, SouthBrowardRetail, SouthMiaInd, SouthMiami, StLucieGas, Unincorporated Dade, US1, WarehousesSouth, West Little River, WestchesterCom, WestchesterRetail, Wynwood, Wynwood Norte |
| Carlos A Temperan | 1 | Allapattah |
| Carlos Fausto Miranda | 70 | 71st Ind, Allapattah, Allapattah; BVM, AllapattahMF, Big Game MF, Big MF list, Big MultiBay, Bigmf, BirdRoadCom, Brownsville, CalleOcho, CFM Big MF, CID, CIN, CivApts, CivCen, CoralGables, CoralWay, DadeHotelMotel, Doral, Doral Industrial, Fausto, Flagami Apts, GablesMulti, GasStation, HiaGardens, Hialeah Industrial, HialeahApt, HialeahCom, HialeahRetail, HollywoodRetail, JRLitHaitiWyn, LibCityCom, LibCityMF, LittleHaiti, LittleHaitiCom, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleHavanaLand, LittleRiver, Medley, MF Bay, Miami Beach, MiamiBeachCom, Naranja, NMB Land, NMB Retail, NoMiamiRetail, NorthMiaLand, NorthMultiFamily, OpaLockaInd, Outer Land, Overtown, OvertownMultifamily, ResidentialSingleFamily, RoadsShehnSilverApts, SelfStorage, SouthBrowardComm, SouthBrowardRetail, SouthMiaInd, SouthMiami, SouthMiamiMF, SouthRetail, VicenteRolodex, WarehousesSouth, WestchesterCom, WestchesterRetail, WestFlagler |
| Carlos Miranda-Brassac | 18 | Airport, Allapattah, Allapattah; BVM, AllapattahMF, CivApts, EHia Industrial, Flagami Apts, FlagamiApts, HialeahApt, HialeahCom, HialeahRetail, LibCityCom, LittleHavana, LittleHavanaApt, LittleHavanaCom, RoadsShehnSilverApts, SouthBrowardRetail, WarehousesSouth |
| Christopher Canizares | 9 | Flagami Apts, FlagamiApts, GablesMulti, JRLitHaitiWyn, JRLitHaitiWynAPT, Miami Beach, WWNAPT, Wynwood, Wynwood Norte |
| Christopher Carbonell | 10 | CoralWay, Flagami Com, LittleHavana, LittleHavanaApt, LittleHavanaCom, Overtown, OvertownComm, OvertownMultifamily, Retail Leasing Leads, RoadsShehnSilverApts |
| Elior Levi | 21 | ALFs Broward Palm, Broward MF 33021, BrowardMulti, BrowardShopping, DaniaMulti, FTL MF East, FTLApts, Hallandale MultiFam, HallandaleRetail, Hollywood33020Resi, HollywoodApt33023_4, HollywoodRetail, NorthMiaApts, NorthMiaLand, PompanoMultiFam, SouthBroward33021, SouthBrowardApt, SouthBrowardApt33020, SouthBrowardApts, SouthBrowardRetail, W Fort Lauderdale MF |
| Eric Cruz | 7 | CoralWay, LiquorKing, MiamiOfficesSouth, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, US1-Grovecom |
| Erick Moretti | 3 | K2 Goulds, South Developers, South Miami Hotel |
| Ernesto Diaz | 25 | 27 Ave, Airport, Allapattah, Allapattah; BVM, AllapattahMF, BirdRoadCom, CalleOcho, CID, CID Condo, CIN, EHia Industrial, HiaGardens, Hialeah, Hialeah Gardens, HialeahApt, HialeahCom, HialeahRetail, Homestead, LibCityCom, LittleRiver, NewFlagami, OpaLockaInd, SouthMiaInd, SouthMiamiInd, WarehousesSouth |
| Giovanni Bertolotti | 27 | 71st Ind, Allapattah, BirdRoadCom, CID, City of Miami, DesignDist North, GasStation, GioHotList, Institutional, JRLitHaitiWyn, LibCityApt, LibCityCom, LibCityMF, LittleHaitiCorridor, NNN Kodiak, NorthMultiFamily, RoadsShehnSilverApts, SouthBrowardRetail, SouthMiami, SouthMiamiRetail, SouthRetail, SURDEVRET, Vacant Land, WarehousesSouth, WestchesterCom, WestchesterRetail, Wynwood Norte |
| Halain Suarez | 16 | AirWest, Doral Industrial, EHia, EHia Industrial, Fausto, FTL NE Ind, HiaGardens, HiaGardenWare, Hialeah Gardens, HialeahCom, HialeahRetail, LittleHavanaCom, Medley, OpaLockaInd, Pickle/Padel, SouthMiaInd |
| Ian Wilson | 2 | FTL NE Ind, FTLInd |
| Joshua Jimenez | 28 | 2421 nw 27 ave, AirWest, Allapattah, Allapattah Retail, Buyer broker, CalleOcho, CivCen, CoralGablesCom, DesignDist North, Flagami Apts, Flagami Com, HialeahCom, Joshua Jimenez, LiquorKing, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleHavanaCom, MiamiOfficesSouth, OaklandParkInd, Retail Broward, SouthMiaInd, SouthMiami, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, VicenteRolodex |
| Kodiak Fields | 17 | CarWashBuyers, Doral Industrial, EastSide, Edgewater, HallandaleRetail, HollywoodRetail, KodiakBuyer, Medley, Miami Beach, MiamiBeachCom, MiamiBeachRetail, NNN Kodiak, NoMiamiRetail, OaklandParkInd, SouthBrowardRetail, VicenteLitHaiti, VicenteRolodex |
| Lourdes Ramia | 10 | Flagami Apts, Flagami South, Little HavanaWest, LittleHavana, LittleHavanaApt, LittleHavanaCom, Overtown, RoadsShehnSilverApts, Shenandoah, WestLittleHavana |
| Lucia Villa | 13 | BirdRoadCom, CoralGablesCom, CoralWay, Flagami, Florida City, SOUThMiamiAlberto, SouthMiamiInd, SouthRetail, SW&WC, UniPrkSwtwtrSoDoral, US1-Grovecom, WestchesterRetail, WestchesterWRetail |
| Luna Graciana | 15 | City of Miami, CoralWay, DeerfieldBeach, Flagami Apts, Flagami Com, Flagami South, GroveRIN, Lighthouse MF, LittleHavanaApt, LittleHavanaCom, Overtown, OvertownMultifamily, RoadsShehnSilverApts, The Roads, Wynwood Norte |
| Marcel Perez | 2 | HialeahApt, HialeahApts |
| Marcos GodoyTorrent | 11 | BirdRoadCom, CoconutGrove, GroveRIN, HIA warehouse, HiaGardens, HiaGardensWare, HiaGardenWare, Hialeah, Hialeah Gardens, Medley, WarehousesSouth |
| Markos Bertolotti | 60 | Airport, Allapattah, Allapattah; BVM, AllapattahMF, BirdRoadCom, Biscayne Park, Biscayne Shores, Brownsville, CID, City of Miami, CivCen, CoralGables, CoralTerrace, CoralWay, Dade County, Dadeland North, DaniaIndustrial, Doral, Doral Industrial, Flagami Apts, GablesMulti, Hallandale, HiaGardens, Hialeah, Hialeah Gardens, HialeahRetail, Homestead, JRLitHaitiWyn, LibCityCom, LittleHaiti, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleRiver, Medley, Miami, Miami Beach, Miami Dade, Miami Gardens, NOBE, North Bay Village, North Miami, NorthMultiFamily, OaklandParkInd, Opa Locka, OpaLockaInd, Outer Land, RoadsShehnSilverApts, Shenandoah, SouthMiaInd, St. Petersburg, Sunrise, SunriseInd, Tamiami, The Roads, Unincorporated Dade, WarehousesSouth, West Little River, Wynwood, Wynwood Norte |
| Martina Smoláková | 28 | BirdRoadCom, BirdroadRetail, CoralGablesCom, CoralWay, Edgewater, EdgewaterOmniWyn, Hallandale MultiFam, JRLitHaitiWyn, Land Edge Midtown, LHT Land Robin, LibCityCom, LibertyCityCom, LittleHaitiCorridor, Miami Beach, MiamiOfficesSouth, MOBILE_HOMES, NEMiamiRetail, NMB Land, NoMiamiRetail, North Miami, NorthMiaLand, NorthMultiFamily, OvertownMultifamily, Project 130, SouthBrowardInd, SouthBrowardRetail, US1-Grovecom, Wynwood Norte |
| Mauricio Villasuso | 35 | Allapattah, AllapattahMF, Bigmf, CalleOcho, CID, CivApts, CoralWay, Flagami, Flagami Apts, Flagami Com, Flagami South, GablesMulti, GasStation, HiaGardens, HialeahApt, HialeahApts, HialeahCom, HialeahRetail, Home Project, JRLitHaitiWyn, Little HavanaWest, LittleHavana, LittleHavanaApt, LittleHavanaCom, LittleHavanaLand, NewFlagami, Overtown, OvertownComm, RoadsShehnSilverApts, Shenandoah, ShenandoahApts, SouthBrowardRetail, WarehousesSouth, WestLittleHavana, Wynwood |
| Michael Bell | 1 | JaxDwtwnSpring |
| Miguel Fuentes | 9 | Allapattah, AllapattahMF, CivApts, CivCen, Flagami Apts, Flagami Com, FlagamiApts, LibCityApt, OvertownMultifamily |
| Mitchell Lieberman | 1 | Hollywood33020Resi |
| Moises Figueroa | 7 | CoralWay, DadeHotelMotel, Doral Industrial, EHia, HialeahApt, HialeahCom, HialeahRetail |
| Nathalie Aguirre | 3 | HollywoodRetail, SouthBrowardInd, SURDEVRET |
| Nicholas Bazajou | 6 | Allapattah Retail, LittleHavana, LittleHavanaCom, OaklandParkInd, SOUThMiamiAlberto, SouthMiamiInd |
| Reinier Moya | 18 | Allapattah, Allapattah; BVM, Big Game MF, CID, CoralGables, CoralWay, Edgewater, Flagami Apts, HomesteadMultifamily, JRLitHaitiWyn, JRLitHaitiWynAPT, LittleHavanaApt, NewFlagami, RoadsShehnSilverApts, SouthBrowardRetail, SouthMiamiMF, WarehousesSouth, Wynwood Norte |
| Robin Perez | 41 | AllapattahMF, Big Game MF, Broward Gas, CoralGablesOffice, DesignDist, DesignDist North, Distressed, EastSide, Edgewater, Edgewater Land, Expired, GasStation, GroveRIN, HiaGardens, HiaGardensWare, HiaGardenWare, JRLitHaitiWyn, JRLitHaitiWynAPT, LHT Land Robin, LibCityCom, LibCityMF, LibertyCity, LittleHaiti, LittleHaitiCorridor, LittleHavana, LittleHavanaApt, LittleRiver, Miami Beach, MOBILE_HOMES, North Miami, NorthMultiFamily, Opa Locka, OvertownMultifamily, Pompano Beach, Project 130, Upper east side, VicenteLitHaiti, West Little River, WWNAPT, Wynwood, Wynwood Norte |
| Ryan Carney | 10 | Biscayne Park, FTLApts, GasStation, Hallandale MultiFam, NMB Land, NoMiamiRetail, NorthMiaApts, NorthMiaLand, NorthMultiFamily, W Fort Lauderdale MF |
| Ryan Gonzalez | 2 | Big Game MF, Bigmf |
| Swaraj Gaikwad | 1 | NoEastFlaHotel |
| Tony Saladrigas | 15 | BirdRoadCom, Miami Beach, MiamiBeachCom, MiamiBeachRetail, Name Brand Retailers, NEMiamiRetail, OaklandParkInd, OvertownComm, PlantationCom, Retail Leasing Leads, RoadsShehnSilverApts, SouthBrowardRetail, TS Buyers, US1-Grovecom, WarehousesSouth |
| Veronica Rueda | 4 | Doral HG&M&MS Retail, Doral Retail, Miami Gardens Retail, WestchesterWRetail |
| Vicente Rodriguez | 17 | Big Game MF, CID, Edgewater, Expired, GablesMulti, JRLitHaitiWyn, LibCityApt, LittleHaiti, LittleHaitiMF, LittleHavana, LittleHavanaApt, LittleRiver, Miami Beach, Upper east side, VicenteLitHaiti, VicenteRolodex, Wynwood Norte |
| Yuniel De Varona | 15 | AirWest, Allapattah, DesignDist North, Hialeah Industrial, HialeahCom, LittleRiver, Miami Dade, NorthMiaApts, NorthMiaWrhse, Opa Locka, OpaLockaInd, SouthBrowardRetail, SouthMiamiMF, Unincorporated Dade, WarehousesSouth |
| Zenovia Varela | 9 | DaniaInd, DaniaIndustrial, JRLitHaitiWyn, LittleHaitiCorridor, LittleHavana, LittleRiver, SouthBrowardInd, SouthBrowardRetail, VicenteLitHaiti |
