#!/usr/bin/env python3
"""
Generate 3 audit CSVs for Fausto Commercial Salesforce data cleanup.

1. audit_needs_website_page.csv — 57 properties on LoopNet but not on website
2. audit_needs_agent_confirmation.csv — 74 properties with neither URL nor LoopNet
3. audit_needs_loopnet.csv — 52 properties on website but missing LoopNet ID
"""

import csv
from pathlib import Path

INPUT = Path("/Users/jesusvasquez/Downloads/Property__c_updated.csv")
OUTPUT_DIR = Path("/Users/jesusvasquez/Downloads")


def main():
    with open(INPUT, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    active = [r for r in rows if r.get("Status__c") == "Active"]

    def has_url(r):
        return r.get("Public_URL__c", "").strip().startswith("http")

    def has_loopnet(r):
        return bool(r.get("Loopnet_ID__c", "").strip())

    # Categorize
    needs_website = [r for r in active if not has_url(r) and has_loopnet(r)]
    needs_confirmation = [r for r in active if not has_url(r) and not has_loopnet(r)]
    needs_loopnet = [r for r in active if has_url(r) and not has_loopnet(r)]

    # -----------------------------------------------------------------------
    # Report 1: Needs Website Page
    # -----------------------------------------------------------------------
    out1 = OUTPUT_DIR / "audit_needs_website_page.csv"
    fields1 = [
        "Address", "City", "State", "Listing_Type", "Property_Type",
        "Price", "LoopNet_ID", "LoopNet_URL", "Listing_Agent_ID",
        "Listing_Date", "SF_Record_ID",
    ]
    with open(out1, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields1)
        w.writeheader()
        for r in sorted(needs_website, key=lambda x: x.get("City__c", "")):
            ln_id = r.get("Loopnet_ID__c", "").strip()
            w.writerow({
                "Address": r.get("Address__c") or r.get("Name", ""),
                "City": r.get("City__c", ""),
                "State": r.get("State__c", ""),
                "Listing_Type": r.get("Listing_Type__c", ""),
                "Property_Type": r.get("Property_Type__c", ""),
                "Price": r.get("Price__c", ""),
                "LoopNet_ID": ln_id,
                "LoopNet_URL": f"https://www.loopnet.com/Listing/{ln_id}/" if ln_id else "",
                "Listing_Agent_ID": r.get("Listing_Agent__c", ""),
                "Listing_Date": (r.get("Listing_Date__c", "") or "")[:10],
                "SF_Record_ID": r["Id"],
            })
    print(f"✅ {out1.name}: {len(needs_website)} rows")

    # -----------------------------------------------------------------------
    # Report 2: Needs Agent Confirmation
    # -----------------------------------------------------------------------
    out2 = OUTPUT_DIR / "audit_needs_agent_confirmation.csv"
    fields2 = [
        "Address", "City", "State", "Listing_Type", "Property_Type",
        "Price", "Listing_Agent_ID", "Listing_Date",
        "SF_Record_ID", "Status_Confirmed", "Notes",
    ]
    # Sort by agent then address for easy grouping
    sorted_confirm = sorted(
        needs_confirmation,
        key=lambda x: (x.get("Listing_Agent__c", ""), x.get("Address__c") or x.get("Name", "")),
    )
    with open(out2, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields2)
        w.writeheader()
        for r in sorted_confirm:
            w.writerow({
                "Address": r.get("Address__c") or r.get("Name", ""),
                "City": r.get("City__c", ""),
                "State": r.get("State__c", ""),
                "Listing_Type": r.get("Listing_Type__c", ""),
                "Property_Type": r.get("Property_Type__c", ""),
                "Price": r.get("Price__c", ""),
                "Listing_Agent_ID": r.get("Listing_Agent__c", ""),
                "Listing_Date": (r.get("Listing_Date__c", "") or "")[:10],
                "SF_Record_ID": r["Id"],
                "Status_Confirmed": "",  # Agent fills this in: Active / Archive
                "Notes": "",  # Agent fills this in
            })
    print(f"✅ {out2.name}: {len(needs_confirmation)} rows")

    # -----------------------------------------------------------------------
    # Report 3: Needs LoopNet
    # -----------------------------------------------------------------------
    out3 = OUTPUT_DIR / "audit_needs_loopnet.csv"
    fields3 = [
        "Address", "City", "State", "Listing_Type", "Property_Type",
        "Price", "Website_URL", "Listing_Agent_ID",
        "Listing_Date", "SF_Record_ID",
    ]
    with open(out3, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields3)
        w.writeheader()
        for r in sorted(needs_loopnet, key=lambda x: x.get("City__c", "")):
            w.writerow({
                "Address": r.get("Address__c") or r.get("Name", ""),
                "City": r.get("City__c", ""),
                "State": r.get("State__c", ""),
                "Listing_Type": r.get("Listing_Type__c", ""),
                "Property_Type": r.get("Property_Type__c", ""),
                "Price": r.get("Price__c", ""),
                "Website_URL": r.get("Public_URL__c", ""),
                "Listing_Agent_ID": r.get("Listing_Agent__c", ""),
                "Listing_Date": (r.get("Listing_Date__c", "") or "")[:10],
                "SF_Record_ID": r["Id"],
            })
    print(f"✅ {out3.name}: {len(needs_loopnet)} rows")

    # Summary
    print(f"\n{'='*60}")
    print(f"284 Active Properties Audit Summary")
    print(f"{'='*60}")
    print(f"  ✅ Ready (has website URL):           {len([r for r in active if has_url(r)])}")
    print(f"  ⚠️  Needs website page (has LoopNet): {len(needs_website)}")
    print(f"  ⚠️  Needs LoopNet (has website):      {len(needs_loopnet)}")
    print(f"  🔴 Needs agent confirmation:          {len(needs_confirmation)}")
    print(f"{'='*60}")
    print(f"Files saved to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
