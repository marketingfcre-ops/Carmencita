/**
 * Negative-path test for the Group_Edit_Restriction validation rule.
 *
 * System.runAs() is restricted to @isTest methods — execute-anonymous can't
 * use it. So we deploy a tiny Apex test class to Dev (which allows custom
 * Apex, unlike Pro Edition), run it via the Tooling API, and verify the
 * assertion holds.
 *
 * Run: tsx --env-file .env.local scripts/test-validation-rule.ts
 */

import { sfClient, type SfClient } from '../../src/integrations/sf-client';

interface ApexClassRecord {
  Id: string;
  Name: string;
}

interface RunTestsResult {
  successes: { Name: string; MethodName: string }[];
  failures: { Name: string; MethodName: string; Message: string; StackTrace: string }[];
  numTestsRun: number;
  numFailures: number;
}

async function main() {
  console.log('\n🧪 Negative-path test (Apex @isTest class)\n');
  const sf = await sfClient('dev');

  // 1. Find a non-admin user we can runAs
  console.log('Step 1: find a non-admin user');
  const nonAdmins = await sf.soql<{ Id: string; Username: string; Profile: { Name: string } }>(
    `SELECT Id, Username, Profile.Name FROM User
     WHERE IsActive = true AND Profile.Name <> 'System Administrator'
     LIMIT 1`
  );
  if (nonAdmins.length === 0) {
    console.error('  ✗ No non-admin users exist. Create one (Setup → Users → New User → profile "Standard User").');
    process.exit(1);
  }
  const testUser = nonAdmins[0];
  console.log(`  ${testUser.Username} (${testUser.Profile.Name})`);

  // 2. Find a Lead with a Group__c set
  console.log('\nStep 2: find a cross-group test lead');
  const leads = await sf.soql<{ Id: string; Email: string; Group__c: string }>(
    `SELECT Id, Email, Group__c FROM Lead WHERE Group__c != null LIMIT 1`
  );
  if (leads.length === 0) {
    console.error('  ✗ No leads with Group__c. Run seed-dev-org.ts.');
    process.exit(1);
  }
  const targetLead = leads[0];
  console.log(`  ${targetLead.Email} (group=${targetLead.Group__c})`);

  // 3. Find a different group to assign to the test user
  console.log('\nStep 3: find a different group for the test user');
  const otherGroups = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c WHERE Id != '${targetLead.Group__c}' LIMIT 1`
  );
  if (otherGroups.length === 0) {
    console.error('  ✗ Need at least 2 distinct groups. Run seed-dev-org.ts.');
    process.exit(1);
  }
  const otherGroup = otherGroups[0];
  console.log(`  ${otherGroup.Name} (${otherGroup.Id})`);

  await sf.update('User', testUser.Id, { Group_ID__c: otherGroup.Id });
  console.log(`  ✓ Test user.Group_ID__c set`);

  // 4. Deploy or update the Apex test class
  console.log('\nStep 4: deploy/refresh Apex test class');
  const className = 'GroupEditValidationTest';
  const apexBody = `@isTest
public class ${className} {
    @isTest
    static void nonAdminCannotEditCrossGroupLead() {
        User u = [SELECT Id FROM User WHERE Id = '${testUser.Id}'];
        Boolean blocked = false;
        String errMsg = '';
        System.runAs(u) {
            try {
                Lead l = new Lead(Id='${targetLead.Id}', Description='ValidationRuleTest');
                update l;
            } catch (DmlException e) {
                blocked = true;
                errMsg = e.getMessage();
            }
        }
        System.assert(blocked, 'Validation rule should have blocked the edit. Error message captured: ' + errMsg);
    }
}`;

  // Check if the class exists
  const existing = await sf.toolingQuery<ApexClassRecord>(
    `SELECT Id, Name FROM ApexClass WHERE Name = '${className}'`
  );

  if (existing.length > 0) {
    // Update via Tooling API: PATCH ApexClass/{id} with new Body — but Apex
    // updates require MetadataContainer pattern. Simpler: delete + recreate.
    await sf.delete('ApexClass', existing[0].Id);
    console.log(`  ⊘ existing ${className} deleted`);
  }

  await sf.toolingCreate('ApexClass', { Body: apexBody });
  console.log(`  ✓ ${className} deployed`);

  // 5. Find the new class ID and run the test
  console.log('\nStep 5: run the test');
  await sleep(1000); // let the class compile
  const deployed = await sf.toolingQuery<ApexClassRecord>(
    `SELECT Id, Name FROM ApexClass WHERE Name = '${className}' LIMIT 1`
  );
  if (deployed.length === 0) {
    console.error(`  ✗ Class ${className} not found after deploy.`);
    process.exit(1);
  }

  // POST to /tooling/runTestsSynchronous
  const url = `${sf.instance}/services/data/v59.0/tooling/runTestsSynchronous`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${sf.token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      tests: [{ classId: deployed[0].Id }],
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    console.error(`  ✗ runTestsSynchronous failed: ${res.status} ${err}`);
    process.exit(1);
  }
  const result = (await res.json()) as RunTestsResult;

  console.log(`\n  Tests run: ${result.numTestsRun}, failures: ${result.numFailures}`);

  if (result.numFailures === 0 && result.numTestsRun > 0) {
    console.log('\n✅ TEST PASSED — validation rule blocked the cross-group edit.\n');
    console.log('   Non-admin users assigned to one group cannot edit leads from');
    console.log('   a different group. Admins still can. Rule is working.\n');
    process.exit(0);
  } else {
    for (const f of result.failures) {
      console.error(`  ✗ ${f.Name}.${f.MethodName}`);
      console.error(`     ${f.Message}`);
      console.error(`     ${f.StackTrace?.split('\n')[0] ?? ''}`);
    }
    process.exit(1);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
