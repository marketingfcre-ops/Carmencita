/**
 * Hidden-list (Email 1 / Elior) prep + edition-restriction confirmation. Read-only.
 *
 *   A. Resolve the 11 restricted groups → Group__c Id + live lead count.
 *   B. Resolve the named agents → User Id + active + profile.
 *   C. Confirm whether this org can do record-VIEW restriction at all
 *      (criteria-based sharing rules / restriction rules) — the edition gate.
 *
 *   npx tsx --env-file .env.local scripts/diagnostics/hidden-list-prep-and-edition.ts
 */
import { sfClient } from '../../src/integrations/sf-client';

// The 11 distinct groups from Fausto's Email 1, exactly as he typed them,
// with the agents who may view/edit (besides Fausto, Temperan, Nathalie).
const HIDDEN = [
  { raw: 'ALFs broward Palm', agents: ['Elior Levi'] },
  { raw: 'DaniaMulti', agents: ['Adir Bezalely', 'Elior Levi'] },
  { raw: 'SouthBrowardApts', agents: ['Elior Levi'] },
  { raw: 'hollywoodapt33023_4', agents: ['Mitchell Lieberman', 'Elior Levi'] },
  { raw: 'southbrowardapt33020', agents: ['Elior Levi'] },
  { raw: 'Hallandale MF', agents: ['Ryan Carney', 'Elior Levi'] },
  { raw: 'NorthMiaApts', agents: ['Ryan Carney', 'Elior Levi'] },
  { raw: 'PompanoMultiFam', agents: ['Elior Levi', 'Arun Mohan'] },
  { raw: 'browardmulti', agents: ['Arun Mohan', 'Elior Levi'] },
  { raw: 'w fort laderdale mf', agents: ['Ryan Carney', 'Elior Levi'] },
  { raw: 'FTLApts', agents: ['Adir Bezalely', 'Arun Mohan', 'Elior Levi'] },
];

// Known reconcile renames (raw email spelling → canonical Group__c Name).
const ALIASES: Record<string, string> = {
  'southbrowardapts': 'southbrowardapt',
  'hallandale mf': 'hallandale multifam',
  'w fort laderdale mf': 'w fort lauderdale mf',
};

const norm = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // ---- C (first, it's the gate): edition + view-restriction capability ----
  console.log('================ EDITION / VIEW-RESTRICTION GATE ================');
  const org: any[] = await sf.soql(`SELECT Name, OrganizationType FROM Organization`);
  console.log(`Org:     ${org[0]?.Name}  ·  ${org[0]?.OrganizationType}`);
  const lead: any[] = await sf.toolingQuery(
    `SELECT InternalSharingModel FROM EntityDefinition WHERE QualifiedApiName = 'Lead'`
  ).catch(() => []);
  console.log(`Lead OWD: ${lead[0]?.InternalSharingModel} (must be Private to hide anything)`);

  // Probe each feature object. "not supported" = feature not provisioned here.
  const probes = [
    ['Criteria-based sharing rules', 'LeadCriteriaBasedSharingRule'],
    ['Ownership-based sharing rules', 'LeadOwnerSharingRule'],
    ['Restriction Rules', 'RestrictionRule'],
  ] as const;
  for (const [label, obj] of probes) {
    try {
      const rows: any[] = await sf.toolingQuery(`SELECT Id FROM ${obj} LIMIT 5`);
      console.log(`  ${label.padEnd(32)} AVAILABLE (${rows.length} existing)`);
    } catch (e: any) {
      const msg = String(e.message || e);
      const notSupported = /not supported/i.test(msg);
      console.log(`  ${label.padEnd(32)} ${notSupported ? '❌ NOT PROVISIONED (object not supported)' : 'error: ' + msg.slice(0, 60)}`);
    }
  }
  // Can the Lead share object even take rule/manual rows?
  try {
    const d = await sf.describe('LeadShare');
    const rowCause = d.fields.find((f: any) => f.name === 'RowCause');
    const causes = (rowCause?.picklistValues || []).map((p: any) => p.value);
    console.log(`  LeadShare RowCause options: ${causes.length ? causes.join(', ') : '(none/limited)'}`);
  } catch (e: any) {
    console.log(`  LeadShare describe failed: ${String(e.message).slice(0, 60)}`);
  }

  // ---- A: resolve the 11 groups ----
  console.log('\n================ A. THE 11 RESTRICTED GROUPS ================');
  const groups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  const byNorm = new Map<string, { id: string; name: string }[]>();
  for (const g of groups) {
    const k = norm(g.Name);
    if (!byNorm.has(k)) byNorm.set(k, []);
    byNorm.get(k)!.push({ id: g.Id, name: g.Name });
  }
  // lead counts per Group__c
  const counts: any[] = await sf.soql(
    `SELECT Group__c gid, COUNT(Id) cnt FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const cntById = new Map<string, number>();
  for (const r of counts) cntById.set(r.gid, Number(r.cnt ?? r.expr0 ?? 0));

  for (const h of HIDDEN) {
    const target = ALIASES[h.raw.toLowerCase()] || h.raw;
    let matches = byNorm.get(norm(target)) || byNorm.get(norm(h.raw)) || [];
    if (!matches.length) {
      // last resort: substring contains
      const k = norm(h.raw);
      for (const [gk, arr] of byNorm) if (gk.includes(k) || k.includes(gk)) matches.push(...arr);
    }
    if (!matches.length) {
      console.log(`  ❓ "${h.raw}"  →  NO MATCH`);
      continue;
    }
    const total = matches.reduce((s, m) => s + (cntById.get(m.id) || 0), 0);
    const dup = matches.length > 1 ? `  ⚠️ ${matches.length} records` : '';
    console.log(`  ✓ "${h.raw}"  →  ${matches.map((m) => `${m.name} [${m.id}] (${cntById.get(m.id) || 0})`).join(' + ')}  = ${total} leads${dup}`);
  }

  // ---- B: resolve the agents ----
  console.log('\n================ B. AGENTS → SF USERS ================');
  const names = new Set<string>();
  for (const h of HIDDEN) for (const a of h.agents) names.add(a);
  // plus the always-allowed admins
  ['Carlos Fausto Miranda', 'Carlos A Temperan', 'Nathalie Aguirre'].forEach((n) => names.add(n));

  for (const n of [...names].sort()) {
    const last = n.split(' ').slice(-1)[0].replace(/'/g, "\\'");
    const first = n.split(' ')[0].replace(/'/g, "\\'");
    const users: any[] = await sf.soql(
      `SELECT Id, Name, IsActive, Profile.Name FROM User WHERE (Name = '${n.replace(/'/g, "\\'")}' OR (LastName = '${last}' AND FirstName LIKE '${first}%')) AND IsActive = true`
    ).catch(() => []);
    if (!users.length) console.log(`  ❓ ${n}  →  no active user found`);
    else for (const u of users) console.log(`  ✓ ${n.padEnd(22)} → ${u.Name} [${u.Id}] active=${u.IsActive} profile="${u.Profile?.Name}"`);
  }
}

main().catch((e) => { console.error('💀', e); process.exit(1); });
