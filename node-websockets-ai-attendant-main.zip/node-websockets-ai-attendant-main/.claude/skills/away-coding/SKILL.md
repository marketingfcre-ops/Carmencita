---
name: away-coding
description: Use when working a GitHub issue autonomously / unattended ("work issue #N", "pick up the next issue", "code this while I'm away"). Runs the full loop in an isolated worktree, verifies, and opens a PR — without deploying or writing to prod. The PR is the user's review gate.
---

# Autonomous "code while away" loop

The user is away. You work to a **PR and stop** — the PR is their review gate.
Never cross the hard boundary below.

## Hard boundary (NEVER do these unattended)
- ❌ No deploys: `railway` deploy/up/redeploy, `sf-deploy` (`deploy-apex-trigger.ts`),
  Cloudways. (Several are deny-listed in `.claude/settings.json`.)
- ❌ No prod data writes: SF DML, WP POST/PUT/DELETE, Campaign Monitor writes,
  running anything in `scripts/migrations/`. If a step needs a prod write, **stop
  and leave it for the user in the PR description** — do not attempt it.
- ❌ No push to `main` (branch protection enforces this server-side anyway).
- ✅ Allowed: code edits, local build/tests, read-only prod queries (SOQL SELECT,
  GETs, dry-run previews), pushing your feature branch, opening a PR.

## Loop (per issue)
1. **Read the issue:** `gh issue view <N>`. Restate the goal + acceptance criteria.
   If the issue is ambiguous or needs a prod write to complete, comment on the
   issue with the blocker and move on — don't guess.
2. **Branch (work in place):** create and check out a feature branch in the
   current working directory:
   ```bash
   git checkout -b issue-<N>-<short-slug>
   ```
   Work here. **Do NOT create a separate git worktree for a single issue** — a
   worktree lives outside the project directory and trips Claude Code's
   "path outside allowed working directories" gate, forcing a prompt on every
   file op. Never commit to `main`. When done, leave the branch checked out and
   report it (the user reviews via the PR).
3. **Implement** the change. Keep it scoped to the issue.
4. **Verify — required before any PR:**
   - `npm run build` (tsc must pass)
   - run relevant tests in `scripts/tests/` if present
   - if it can't be verified locally, say so explicitly in the PR.
   Do not open a PR on a red build.
5. **Open the PR:** `gh pr create --base main`, title from the issue, body with:
   summary, what you changed, how you verified, anything left for the user
   (especially any deferred prod write/deploy), and `Closes #<N>`.
6. **Write a handoff** (use the `handoff` skill) capturing state + next steps, so
   the next session can continue if needed.
7. **Report** the PR URL. Move to the next issue only if asked.

## Running several at once (parallel — advanced)
Only for *multiple* issues at the same time. Spawn one background worktree agent
per issue (`Agent` with `run_in_background: true`, `isolation: "worktree"`). Each
gets its own branch + PR; no collisions.

⚠️ **Prerequisite:** worktrees live outside the project dir, so they trip the
"path outside allowed working directories" gate unless the worktree root is added
to `permissions.additionalDirectories` in `.claude/settings.json`. Set that up
*before* relying on parallel runs, or you'll be approving every path op. For a
single issue, prefer the in-place branch in step 2 — no whitelisting needed.

## If you get stuck
Stalling is safe; guessing is not. If blocked (ambiguous spec, needs prod write,
failing build you can't fix), stop, document it on the issue/PR, and leave it for
the user. Never disable tests or loosen the boundary to "make it pass."
