/**
 * List all Campaign Monitor clients + lists in the account tied to CM_API_KEY.
 * Prints ListID + Name + subscriber counts so we can wire up imports.
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/cm-discover.ts
 */

import {
  listClients,
  listLists,
  getListStats,
  getListCustomFields,
} from '../../src/campaign-monitor';

async function main() {
  const apiKey = process.env.CM_API_KEY;
  if (!apiKey) {
    console.error('ERROR: CM_API_KEY not set in environment.');
    process.exit(1);
  }

  const clients = await listClients(apiKey);
  console.log(`Found ${clients.length} client(s):`);
  for (const c of clients) console.log(`  ${c.ClientID}  ${c.Name}`);

  for (const client of clients) {
    console.log(`\n=== Lists for ${client.Name} (${client.ClientID}) ===`);
    const lists = await listLists(apiKey, client.ClientID);
    // Sort by name so output is stable.
    lists.sort((a, b) => a.Name.localeCompare(b.Name));

    const rows: Array<{ id: string; name: string; active: number; unsub: number; bounced: number }> = [];
    for (const l of lists) {
      try {
        const s = await getListStats(apiKey, l.ListID);
        rows.push({
          id: l.ListID,
          name: l.Name,
          active: s.TotalActiveSubscribers,
          unsub: s.TotalUnsubscribes,
          bounced: s.TotalBounces,
        });
      } catch (err) {
        rows.push({ id: l.ListID, name: l.Name, active: -1, unsub: -1, bounced: -1 });
      }
    }

    const nameWidth = Math.max(20, ...rows.map((r) => r.name.length));
    console.log(
      `  ${'ListID'.padEnd(34)} ${'Name'.padEnd(nameWidth)} ${'Active'.padStart(8)} ${'Unsub'.padStart(7)} ${'Bounced'.padStart(8)}`
    );
    for (const r of rows) {
      console.log(
        `  ${r.id.padEnd(34)} ${r.name.padEnd(nameWidth)} ${String(r.active).padStart(8)} ${String(r.unsub).padStart(7)} ${String(r.bounced).padStart(8)}`
      );
    }

    // For Loopnet-prefixed lists, also dump custom fields (useful for planning re-categorization).
    const loopnetLists = rows.filter((r) => /loopnet/i.test(r.name));
    if (loopnetLists.length) {
      console.log(`\n  Custom fields on Loopnet lists:`);
      for (const r of loopnetLists) {
        try {
          const fields = await getListCustomFields(apiKey, r.id);
          const keys = fields.map((f) => `${f.FieldName}(${f.DataType})`).join(', ');
          console.log(`    ${r.name}: ${keys || '(none)'}`);
        } catch {
          // skip
        }
      }
    }
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
