/**
 * For each Active SF record that has NO WP_Post_ID__c, show its
 * CreatedDate + LastModifiedDate. Lets us understand WHY they're
 * unlinked — created post-April-sync vs missed by April sync.
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  City__c: string | null;
  Status__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  CreatedDate: string;
  LastModifiedDate: string;
}

async function main() {
  const auth = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await auth.json()) as any;

  const soql = `SELECT Id, Name, Address__c, City__c, Status__c,
                       Listing_Agent__r.Name, CreatedDate, LastModifiedDate
                  FROM Property__c
                 WHERE WP_Post_ID__c = NULL
                   AND Status__c = 'Active'`;
  const r = await fetch(
    `${instance_url}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`,
    { headers: { Authorization: `Bearer ${access_token}` } }
  );
  const data = (await r.json()) as { records: SfProperty[] };
  const records = data.records || [];

  console.log(`\n📅 ${records.length} Active SF records with no WP link\n`);

  // Sort by CreatedDate ascending so oldest is at the top
  records.sort((a, b) => a.CreatedDate.localeCompare(b.CreatedDate));

  // April-sync was sometime in April 2026; treat anything before May 1
  // as "should have been picked up by April sync"
  const APRIL_CUTOFF = '2026-05-01';

  let beforeApril = 0;
  let aprilSyncEra = 0;
  let afterApril = 0;

  console.log('CreatedDate    LastModified   Agent                 City                Address');
  console.log('─'.repeat(120));
  for (const sf of records) {
    const created = sf.CreatedDate.slice(0, 10);
    const modified = sf.LastModifiedDate.slice(0, 10);
    const agent = (sf.Listing_Agent__r?.Name || '—').padEnd(20);
    const city = (sf.City__c || '—').padEnd(18);
    const addr = (sf.Address__c || sf.Name || '—').replace(/\s+/g, ' ').slice(0, 50);
    const flag =
      created < '2026-04-01'
        ? '🟥 pre-April'
        : created < APRIL_CUTOFF
        ? '🟨 April'
        : '🟩 post-April';
    console.log(`${created}    ${modified}   ${agent}  ${city}  ${addr}  ${flag}`);
    if (created < '2026-04-01') beforeApril++;
    else if (created < APRIL_CUTOFF) aprilSyncEra++;
    else afterApril++;
  }

  console.log('─'.repeat(120));
  console.log(`\n🟥 Pre-April (created before 2026-04-01):  ${beforeApril}  ← April sync should have caught these`);
  console.log(`🟨 April (created during April 2026):       ${aprilSyncEra}  ← May or may not have been in the import window`);
  console.log(`🟩 Post-April (created on or after May 1):  ${afterApril}  ← legitimately new, never had a sync chance`);
  console.log('');

  process.exit(0);
}

main().catch((err) => { console.error('💀 Crashed:', err); process.exit(1); });
