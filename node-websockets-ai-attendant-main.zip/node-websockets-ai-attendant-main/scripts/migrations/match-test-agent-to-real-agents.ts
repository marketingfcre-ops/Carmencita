import { sfClient } from '../../src/integrations/sf-client';
async function main() {
  const sf = (await sfClient('prod')) as any;
  const id = '005Jw00001mIHELIA4';
  const url = `${sf.instanceUrl}/services/data/v59.0/sobjects/User/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ReceivesInfoEmails: true,
      EmailEncodingKey: 'ISO-8859-1',
    }),
  });
  console.log(`PATCH → ${res.status}`);
  console.log(await res.text() || '(empty)');
  // Verify
  const v: any[] = await sf.soql(
    `SELECT Name, ReceivesInfoEmails, EmailEncodingKey FROM User WHERE Id = '${id}'`
  );
  console.log(JSON.stringify(v[0], null, 2));
}
main().catch(e=>{console.error(e);process.exit(1);});
