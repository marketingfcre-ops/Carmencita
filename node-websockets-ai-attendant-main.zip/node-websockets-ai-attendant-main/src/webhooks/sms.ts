/**
 * Inbound SMS webhook — Twilio Messaging webhook for our number.
 *
 * Configure in Twilio console: Messaging > Services > Sender Pool > our number,
 * set "A message comes in" to POST {APP_URL}/sms/incoming.
 *
 * Twilio sends application/x-www-form-urlencoded with at least:
 *   From, To, Body, MessageSid, NumMedia, AccountSid
 *
 * We must respond with TwiML (200 OK) — we use an empty <Response/> because
 * all of our replies are sent via the REST API (which gives us delivery SIDs
 * and richer error info than TwiML <Message>).
 */

import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { classifyInboundSms, extractEmail } from '../sms-keywords';
import {
  deliverPendingPropertySms,
  deliverFlyerByEmail,
  sendHelpReply,
  sendStartReply,
  sendStopConfirmation,
} from '../sms';
import {
  setConfirmed,
  setOptedOut,
  setReSubscribed,
} from '../sms-consent';

const EMPTY_TWIML = `<?xml version="1.0" encoding="UTF-8"?>\n<Response/>`;

export async function registerSmsWebhookRoutes(app: FastifyInstance): Promise<void> {
  app.post('/sms/incoming', async (request: FastifyRequest, reply: FastifyReply) => {
    const body = request.body as Record<string, string>;
    const from = (body.From || '').trim();
    const text = (body.Body || '').trim();
    const sid = body.MessageSid || 'unknown';

    if (!from || !text) {
      reply.type('text/xml').send(EMPTY_TWIML);
      return;
    }

    const kind = classifyInboundSms(text);
    console.log(`📨 [${sid}] Inbound SMS from ${from} (${kind}): "${text}"`);

    try {
      switch (kind) {
        case 'STOP':
          setOptedOut(from);
          await sendStopConfirmation(from);
          break;
        case 'START':
          setReSubscribed(from);
          await sendStartReply(from);
          break;
        case 'HELP':
          await sendHelpReply(from);
          break;
        case 'YES':
          setConfirmed(from);
          await deliverPendingPropertySms(from);
          break;
        case 'EMAIL': {
          // Caller replied with an email — send the pending property's flyer.
          const email = extractEmail(text);
          if (email) {
            const sent = await deliverFlyerByEmail(from, email);
            console.log(`📧 [${sid}] email reply ${email} → flyer ${sent ? 'sent' : 'not sent (none pending / failed)'}`);
          }
          break;
        }
        case 'OTHER':
          // Free-form message after consent — no auto-reply, but log for review.
          console.log(`💬 [${sid}] Caller sent free-form message — no auto-reply`);
          break;
      }
    } catch (err) {
      console.error(`❌ [${sid}] Inbound SMS handling error:`, err);
    }

    reply.type('text/xml').send(EMPTY_TWIML);
  });
}
