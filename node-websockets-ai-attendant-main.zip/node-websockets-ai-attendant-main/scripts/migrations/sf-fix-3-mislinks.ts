/**
 * Fix the 3 confirmed SF→WP mislinks.
 *
 * Each of these SF records points at a WP post for a different building
 * (verified by exhaustive WP search — no WP post exists at any of these
 * 3 addresses). The mislinks predate the dedupe migration.
 *
 * Action: clear BOTH WP_Post_ID__c AND Public_URL__c.
 *   - WP_Post_ID__c → null  (drops the wrong reference)
 *   - Public_URL__c → null  (prevents the webhook's slug-match from
 *                            re-linking to the same wrong post)
 *
 * Side effect (intentional): each cleared SF record fires SF Flow → webhook
 *   → handler sees both null → tryBackfillWpPostId returns null (no slug,
 *   no address match) → createNewListing creates a FRESH WP draft and
 *   writes the new wpId + permalink back to SF.
 *
 * Net result: each SF record gets a brand-new WP draft, like April-import.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-fix-3-mislinks.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-fix-3-mislinks.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 200;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const TARGETS: { sfId: string; sfAddress: string; currentWp: number; wrongWpAddress: string }[] = [
  {
    sfId: 'a0RJw000008GimsMAC',
    sfAddress: '700 SW 16th Ave (Fort Lauderdale)',
    currentWp: 39894,
    wrongWpAddress: '700 East 1st Avenue (Hialeah)',
  },
  {
    sfId: 'a0RJw000008KCQDMA4',
    sfAddress: '1395 NW 22 ST (Miami)',
    currentWp: 19819,
    wrongWpAddress: '1395 SW 22nd Street',
  },
  {
    sfId: 'a0RJw000008c9AXMAY',
    sfAddress: '2811 SW 3rd Ave (Miami)',
    currentWp: 19778,
    wrongWpAddress: '2811 SW 3rd Street',
  },
];

async function sfAuth(): Promise<{ token: string; instance: string }> {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  return { token: access_token, instance: instance_url };
}

async function sfUpdate(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true };
  return { ok: false, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

// Same placeholder retry pattern as the cleanup migration
const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  {
    match: /Listing_Date__c|Listing Date/i,
    field: 'Listing_Date__c',
    value: new Date().toISOString().slice(0, 10),
  },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string; rounds: number }> {
  const MAX_ROUNDS = 5;
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < MAX_ROUNDS; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true, rounds: i + 1 };
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false, error: lastError, rounds: i + 1 };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false, error: lastError, rounds: i + 1 };
  }
  return { ok: false, error: `Exhausted retries. Last: ${lastError}`, rounds: MAX_ROUNDS };
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !SF_CLIENT_SECRET) {
    console.error('❌ Missing SF env vars.');
    process.exit(1);
  }

  console.log(`\n🔧 Fix 3 SF mislinks ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();

  console.log('── Plan ──\n');
  for (const t of TARGETS) {
    console.log(`SF ${t.sfId}`);
    console.log(`   Address:        ${t.sfAddress}`);
    console.log(`   Currently:      WP_Post_ID__c = ${t.currentWp}   (${t.wrongWpAddress})`);
    console.log(`   Action:         SET WP_Post_ID__c = null  AND  Public_URL__c = null`);
    console.log(`                   → webhook fires → createNewListing → fresh WP draft`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('→ Executing...\n');
  let ok = 0;
  let err = 0;
  for (const t of TARGETS) {
    const result = await sfUpdateWithRetry(token, instance, t.sfId, {
      WP_Post_ID__c: null,
      Public_URL__c: null,
    });
    if (result.ok) {
      console.log(`   ✓ ${t.sfId} → both fields cleared  (${result.rounds} round(s))`);
      ok++;
    } else {
      console.warn(`   ❌ ${t.sfId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Cleared:   ${ok}`);
  console.log(`Failures:  ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
