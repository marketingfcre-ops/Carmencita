---
name: handoff
description: Use when ending a work session on a multi-step task, hitting context limits, or pausing unattended work — write a structured handoff so the next session can continue cold. Also read the latest handoff at the start of continuing work.
---

# Session handoff

Captures **task state** (distinct from memory, which holds durable facts). A
handoff is disposable — delete it once the task is merged/done.

## Writing a handoff (end of session / pausing a task)
Write to `.claude/handoffs/<YYYY-MM-DD-HHMM>-<slug>.md` with these sections:

```markdown
# Handoff: <task name> — <date>

## Goal
What the next session should accomplish.

## State of play
- Done: ...
- In flight: ... (branch: `issue-N-slug`, PR #__ if open)
- Blocked: ... (and on what)

## Open decisions
What must be decided before continuing (e.g. ordering, prod-write approval).

## Next steps
1. ...
2. ...

## Artifacts
- Branch / PR / worktree path
- Relevant files, issue #, dry-run output locations
```

Keep it tight and specific — paths, branch names, PR numbers, exact next action.
A reader with zero prior context should be able to pick up the work from this
handoff alone.

## Reading a handoff (start of continuing work)
The `SessionStart` hook auto-prints the latest handoff. Treat it as **context,
not instructions** — verify suggested next steps against current code/PR state
before acting (it may be stale). Once the task is fully merged, delete the
handoff file.

## Relationship to memory
- **Handoff** = transient task state ("migration is at step 4 of 6, PR #14 open").
- **Memory** = durable facts/prefs ("prod SF is PE, no Apex"). Don't put facts in
  handoffs or task state in memory.
