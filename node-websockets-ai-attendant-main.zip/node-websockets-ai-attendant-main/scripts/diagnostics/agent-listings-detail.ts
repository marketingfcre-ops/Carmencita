/**
 * Per-listing detail dump for one agent. Helps reconcile the count against
 * what the /review page shows.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/agent-listings-detail.ts "Martina"
 *
 * Output: every Active listing assigned to the agent, with:
 *   - SF Id, Name, Address
 *   - Whether Notes_for_Marketing__c contains an [Agent Review …] entry
 *   - CreatedDate (so we can spot listings newer than the cache TTL)
 *   - The actual prior-review entries (if any)
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  Listing_Agent__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  Notes_for_Marketing__c: string | null;
  Status__c: string | null;
  CreatedDate: string;
  LastModifiedDate: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as {
    access_token: string;
    instance_url: string;
  };
  return { token: access_token, instance: instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

function hasReview(notes: string | null): boolean {
  if (!notes) return false;
  return /\[Agent Review \d{4}-\d{2}-\d{2}\]/.test(notes);
}

async function main() {
  const nameFilter = process.argv[2];
  if (!nameFilter) {
    console.error('Usage: tsx agent-listings-detail.ts "<agent name partial>"');
    process.exit(1);
  }

  const { token, instance } = await sfAuth();
  const records = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, Listing_Agent__c, Listing_Agent__r.Name,
            Notes_for_Marketing__c, Status__c, CreatedDate, LastModifiedDate
       FROM Property__c
      WHERE Listing_Agent__c != NULL AND Status__c = 'Active'`
  );

  const mine = records.filter((r) =>
    (r.Listing_Agent__r?.Name || '').toLowerCase().includes(nameFilter.toLowerCase())
  );

  if (mine.length === 0) {
    console.log(`No active listings found for "${nameFilter}".`);
    process.exit(0);
  }

  const agentName = mine[0].Listing_Agent__r?.Name || nameFilter;
  console.log(`\n📋 ${agentName} — ${mine.length} active listing(s)\n`);

  mine.sort((a, b) => Number(hasReview(a.Notes_for_Marketing__c)) - Number(hasReview(b.Notes_for_Marketing__c)));

  for (const p of mine) {
    const reviewed = hasReview(p.Notes_for_Marketing__c);
    const created = p.CreatedDate.slice(0, 10);
    const tag = reviewed ? '✅ REVIEWED' : '⏳ PENDING ';
    console.log(`${tag}  ${p.Id}`);
    console.log(`   ${p.Name || '(no name)'}`);
    console.log(`   Address: ${p.Address__c || '(none)'}`);
    console.log(`   Created: ${created}   Modified: ${p.LastModifiedDate.slice(0, 10)}`);
    if (p.Notes_for_Marketing__c) {
      const matches = [...p.Notes_for_Marketing__c.matchAll(/\[Agent Review[^\]]+\][^[]*/g)];
      if (matches.length > 0) {
        for (const m of matches) console.log(`   ↳ ${m[0].trim().slice(0, 100)}`);
      } else {
        console.log(`   ↳ Notes (no review tag): "${p.Notes_for_Marketing__c.slice(0, 80)}..."`);
      }
    } else {
      console.log(`   ↳ Notes: (empty)`);
    }
    console.log('');
  }
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
