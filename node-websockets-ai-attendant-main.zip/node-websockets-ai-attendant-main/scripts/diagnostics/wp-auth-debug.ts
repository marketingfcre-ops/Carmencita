/**
 * WP auth debug — when auth seems to silently fail (no error, but our
 * credentials are ignored), this script proves whether the Authorization
 * header is reaching WP at all.
 *
 * Trick: fetch the same post with auth vs anonymous. If the field set is
 * IDENTICAL, WP isn't seeing our header — usually a reverse-proxy or
 * security plugin (Wordfence) stripping it. If the auth call returns
 * extra fields (author, date, modified, fave_*), WP sees the header.
 *
 * Read-only.
 *
 * Run: tsx --env-file .env.local scripts/diagnostics/wp-auth-debug.ts
 */

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH = 'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

async function main() {
  console.log(`\nWP_USER=${WP_USER}  pwd_length=${WP_APP_PASSWORD.length}\n`);

  // Pick any published property to compare against
  const listRes = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=1&status=publish&_fields=id`);
  const list = await listRes.json() as any[];
  if (!Array.isArray(list) || list.length === 0) {
    console.log('Could not fetch a sample property to test against.');
    process.exit(1);
  }
  const id = list[0].id;
  console.log(`Testing against wp:${id}\n`);

  // 1. With auth
  const a = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties/${id}`, { headers: { Authorization: WP_AUTH } });
  const aj: any = await a.json();
  const aKeys = new Set(Object.keys(aj));

  // 2. Without auth
  const b = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/properties/${id}`);
  const bj: any = await b.json();
  const bKeys = new Set(Object.keys(bj));

  const onlyAuth = [...aKeys].filter(k => !bKeys.has(k));
  console.log(`With auth:      ${a.status}, ${aKeys.size} fields`);
  console.log(`Without auth:   ${b.status}, ${bKeys.size} fields`);
  console.log(`Auth-only keys: ${onlyAuth.length ? onlyAuth.join(', ') : '(NONE)'}`);

  if (onlyAuth.length === 0) {
    console.log('\n❌ Authorization header is being stripped/ignored before reaching WP.');
    console.log('   Likely a Wordfence / iThemes / Cloudflare rule. Anonymous and authed responses are identical.');
  } else {
    console.log('\n✓ Authorization header is reaching WP (authenticated context exposed extra fields).');
  }

  // /users/me — independent confirmation
  console.log('\n── /users/me?context=edit ──');
  const me = await fetch(`${WP_SITE_URL}/wp-json/wp/v2/users/me?context=edit`, { headers: { Authorization: WP_AUTH } });
  const mj: any = await me.json();
  if (me.status === 200) {
    console.log(`   ✓ ${me.status} — id=${mj.id} slug=${mj.slug} roles=${JSON.stringify(mj.roles)}`);
  } else {
    console.log(`   ❌ ${me.status}: ${JSON.stringify(mj).slice(0, 300)}`);
  }

  // /wp-json root — what authentication schemes WP advertises
  console.log('\n── /wp-json (root) ──');
  const root = await fetch(`${WP_SITE_URL}/wp-json/`);
  const rj: any = await root.json();
  console.log(`   authentication: ${JSON.stringify(rj?.authentication || {})}`);

  process.exit(0);
}

main().catch((err) => { console.error('💀', err); process.exit(1); });
