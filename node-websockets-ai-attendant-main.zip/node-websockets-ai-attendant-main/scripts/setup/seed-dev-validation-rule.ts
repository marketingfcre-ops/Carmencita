/**
 * Build the group-based-edit validation rule in the Dev org.
 *
 * v1 approach (PE-compatible, no Flow / no Apex):
 *   - Use User.Group_ID__c (Text, 18) — holds the Group__c record ID for this user
 *     (Salesforce doesn't allow Lookup relationships from User to custom objects,
 *     so we store the ID as text and compare as strings.)
 *   - Validation Rule on Lead blocks edits when:
 *       a) User is not a System Administrator
 *       b) Lead.Group__c is set
 *       c) User.Group_ID__c is set
 *       d) The two IDs don't match
 *
 * Limitations:
 *   - Each user has ONE primary group (single-group model — covers ~90% of cases)
 *   - Multi-group users (team leaders) need v2 (Flow + junction lookups)
 *   - Admins bypass the rule
 *
 * Idempotent: safe to re-run.
 *
 * Run: tsx --env-file .env.local scripts/seed-dev-validation-rule.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

const DEV_INTEGRATION_PERM_SET_ID = '0PSg5000005aOVaGAM';
const VALIDATION_RULE_NAME = 'Group_Edit_Restriction';

const ok = (msg: string) => console.log(`  ✓ ${msg}`);
const skip = (msg: string) => console.log(`  ⊘ ${msg}`);

async function main() {
  console.log('\n🛡️  Building group-based-edit validation rule (v1, Dev org)\n');

  const sf = await sfClient('dev');
  console.log(`Connected to ${sf.instance}\n`);

  // -------------------------------------------------------------------------
  // 1. Verify User.Group_ID__c text field exists (UI-created — Salesforce
  //    doesn't allow Lookup from User to custom objects)
  // -------------------------------------------------------------------------
  console.log('Step 1: verify User.Group_ID__c text field exists');
  if (!(await fieldExists(sf, 'User', 'Group_ID__c'))) {
    console.error('  ✗ User.Group_ID__c does not exist.');
    console.error('    Create a Text field (length 18) labeled "Group ID" on User.');
    process.exit(1);
  }
  ok('User.Group_ID__c exists');
  await grantFls(sf, 'User', 'Group_ID__c');
  ok('User.Group_ID__c FLS granted');

  // -------------------------------------------------------------------------
  // 2. Set integration user's Group_ID__c to LittleHavanaMF's ID for testing
  // -------------------------------------------------------------------------
  console.log('\nStep 2: assign integration user to LittleHavanaMF group');
  const groups = await sf.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c WHERE Name = 'LittleHavanaMF' LIMIT 1`
  );
  if (groups.length === 0) {
    console.error('  ✗ LittleHavanaMF group not found. Run seed-dev-org.ts first.');
    process.exit(1);
  }
  const groupId = groups[0].Id; // 18-char ID from SOQL

  const me = await sf.soql<{ Id: string; Username: string; Group_ID__c: string | null }>(
    `SELECT Id, Username, Group_ID__c FROM User WHERE Username LIKE 'hello%agentforce%' LIMIT 1`
  );
  if (me.length === 0) {
    console.error('  ✗ Integration user not found.');
    process.exit(1);
  }

  if (me[0].Group_ID__c === groupId) {
    skip(`User ${me[0].Username} already has Group_ID__c = LittleHavanaMF`);
  } else {
    await sf.update('User', me[0].Id, { Group_ID__c: groupId });
    ok(`User ${me[0].Username} → Group_ID__c = ${groupId} (LittleHavanaMF)`);
  }

  // -------------------------------------------------------------------------
  // 3. Create the validation rule
  // -------------------------------------------------------------------------
  console.log('\nStep 3: Lead validation rule "Group_Edit_Restriction"');

  // Check if it already exists via Tooling SOQL
  const existing = await sf.toolingQuery<{ Id: string; ValidationName: string }>(
    `SELECT Id, ValidationName FROM ValidationRule WHERE EntityDefinition.QualifiedApiName = 'Lead' AND ValidationName = '${VALIDATION_RULE_NAME}' LIMIT 1`
  );

  // Formula text — see top-of-file comments for what each clause does.
  // Group__c on Lead is a Lookup (returns 18-char ID in formulas).
  // $User.Group_ID__c is Text holding the same 18-char ID, populated by
  // Step 2 above (and by future user-management workflow).
  const formula = `AND(
  $Profile.Name <> 'System Administrator',
  NOT(ISBLANK(Group__c)),
  NOT(ISBLANK($User.Group_ID__c)),
  Group__c <> $User.Group_ID__c
)`;

  const errorMessage =
    'You can only edit leads assigned to your group. ' +
    'Contact an administrator if you need access to this lead.';

  if (existing.length > 0) {
    skip(`Validation rule already exists (${existing[0].Id})`);
  } else {
    try {
      const result = await sf.toolingCreate('ValidationRule', {
        FullName: `Lead.${VALIDATION_RULE_NAME}`,
        Metadata: {
          active: true,
          errorConditionFormula: formula,
          errorMessage,
          description:
            'Blocks non-admin users from editing leads assigned to a different group. v1 (single-group model).',
        },
      });
      ok(`Validation rule created: ${result.id}`);
    } catch (err) {
      console.error(
        `  ✗ Failed to create validation rule:\n     ${err instanceof Error ? err.message : err}`
      );
      process.exit(1);
    }
  }

  // -------------------------------------------------------------------------
  // 4. Smoke test (positive path — admin should be able to edit)
  // -------------------------------------------------------------------------
  console.log('\nStep 4: smoke test (admin can still edit)');
  const testLead = await sf.soql<{ Id: string; Email: string; Group__c: string | null }>(
    `SELECT Id, Email, Group__c FROM Lead WHERE Email = 'treed@example.com' LIMIT 1`
  );
  if (testLead.length === 0) {
    console.warn('  ⚠ Test lead not found — skipping smoke test');
  } else {
    const lead = testLead[0];
    // treed is on MiamiBeachRetail; admin user is on LittleHavanaMF.
    // If validation rule worked correctly, an *agent* couldn't edit this.
    // Admin SHOULD be able to. Try touching a harmless field.
    try {
      await sf.update('Lead', lead.Id, {
        Description:
          `Smoke test ${new Date().toISOString()} — admin edit through validation rule`,
      });
      ok(`Admin successfully edited cross-group lead ${lead.Email} (rule bypassed for admin)`);
    } catch (err) {
      console.error(
        `  ✗ Admin edit failed — validation rule may be too aggressive:\n     ${err instanceof Error ? err.message : err}`
      );
    }
  }

  console.log('\n✅ Validation rule deployed and smoke-tested.\n');
  console.log('Negative-path test (blocking) requires a non-admin user.');
  console.log('To run it manually:');
  console.log(
    '  1. Create a user in Dev SF UI with profile "Standard User" (Setup → Users → New User)'
  );
  console.log(
    '  2. Assign that user a different Group__c value (e.g., DoralIndustrial)'
  );
  console.log(
    '  3. Log in as them and try to edit a Lead in MiamiBeachRetail — should be blocked'
  );
  console.log(
    '  4. Edit a Lead in DoralIndustrial — should succeed\n'
  );

  process.exit(0);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function fieldExists(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<boolean> {
  try {
    const d = await sf.describe(obj);
    return d.fields.some((f: { name: string }) => f.name === field);
  } catch {
    return false;
  }
}

async function grantFls(
  sf: Awaited<ReturnType<typeof sfClient>>,
  obj: string,
  field: string
): Promise<void> {
  try {
    await sf.create('FieldPermissions', {
      ParentId: DEV_INTEGRATION_PERM_SET_ID,
      SobjectType: obj,
      Field: `${obj}.${field}`,
      PermissionsRead: true,
      PermissionsEdit: true,
    });
  } catch {
    // duplicate / already granted — fine
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
