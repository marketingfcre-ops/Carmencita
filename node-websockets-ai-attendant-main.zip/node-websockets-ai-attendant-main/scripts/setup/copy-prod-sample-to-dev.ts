/**
 * Copy a representative sample of production data into the Dev org so the
 * 2-week roundtable feels real to agents (their own leads, real groups, etc.).
 *
 * Dev Edition has a hard 5MB data storage limit, so we cherry-pick:
 *   - Top ~25 most-used Group__c records (deduped to canonical names)
 *   - ~100 Lead records with a representative spread across those groups
 *   - ~30 Property__c records covering the full status spectrum
 *
 * Idempotent: skips records that already exist (matched by Email for Leads,
 * by Name for Groups and Properties).
 *
 * Run: tsx --env-file .env.local scripts/copy-prod-sample-to-dev.ts [--dry-run]
 *
 * Required: SF_*, SF_DEV_* env vars. Existing Dev sample data (from
 * seed-dev-org.ts) coexists peacefully — different Names won't collide.
 */

import { sfClient } from '../../src/integrations/sf-client';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 100;

const TOP_GROUPS = 25;
const SAMPLE_LEADS = 100;
const SAMPLE_PROPS = 30;

const ok = (msg: string) => console.log(`  ✓ ${msg}`);
const skip = (msg: string) => console.log(`  ⊘ ${msg}`);

interface ProdGroup {
  Id: string;
  Name: string;
  cnt: number;
}

interface ProdLead {
  Id: string;
  FirstName: string | null;
  LastName: string;
  Email: string | null;
  Phone: string | null;
  Company: string | null;
  Status: string | null;
  LeadSource: string | null;
  Group__c: string | null;
  Lead_Intent__c: string | null;
}

interface ProdProperty {
  Id: string;
  Name: string;
  Marketing_Name__c: string | null;
  Address__c: string | null;
  City__c: string | null;
  State__c: string | null;
  Zip_Code__c: string | null;
  County__c: string | null;
  Property_Type__c: string | null;
  Listing_Type__c: string | null;
  Status__c: string | null;
  Price__c: number | null;
  Building_Size_sqft__c: number | null;
  Lot_Size_sqft__c: number | null;
  Description__c: string | null;
  Public_URL__c: string | null;
  WP_Post_ID__c: number | null;
}

async function main() {
  console.log(
    `\n📋 Copy prod sample → Dev${DRY_RUN ? ' (DRY RUN)' : ''}\n`
  );

  const prod = await sfClient('prod');
  const dev = await sfClient('dev');
  console.log(`Prod: ${prod.instance}`);
  console.log(`Dev:  ${dev.instance}\n`);

  // -------------------------------------------------------------------------
  // 1. Pick top groups in prod by lead count, deduplicate by name
  // -------------------------------------------------------------------------
  console.log(`Step 1: pick top ${TOP_GROUPS} groups (by lead count)`);
  // Two-step query: SOQL doesn't reliably allow aggregate + relationship in
  // GROUP BY, so we count by ID first, then resolve names.
  const groupCounts = await prod.soql<{ Group__c: string; cnt: number }>(
    `SELECT Group__c, COUNT(Id) cnt
     FROM Lead
     WHERE Group__c != null
     GROUP BY Group__c
     ORDER BY COUNT(Id) DESC
     LIMIT 200`
  );

  // Resolve names for the top group IDs
  const topIdsForLookup = groupCounts.slice(0, 100).map((g) => `'${g.Group__c}'`).join(',');
  const groupNames = await prod.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c WHERE Id IN (${topIdsForLookup})`
  );
  const idToName = new Map<string, string>();
  for (const g of groupNames) idToName.set(g.Id, g.Name);

  // Deduplicate by Name (keep highest-count group for each name)
  const byName = new Map<string, ProdGroup>();
  for (const g of groupCounts) {
    const name = idToName.get(g.Group__c)?.trim();
    if (!name || name.toLowerCase() === 'other') continue;
    const existing = byName.get(name);
    if (!existing || existing.cnt < g.cnt) {
      byName.set(name, { Id: g.Group__c, Name: name, cnt: g.cnt });
    }
  }
  const topGroups = Array.from(byName.values())
    .sort((a, b) => b.cnt - a.cnt)
    .slice(0, TOP_GROUPS);

  console.log(`  Selected ${topGroups.length} canonical groups:`);
  for (const g of topGroups.slice(0, 10)) {
    console.log(`    ${g.Name.padEnd(30)} (${g.cnt} prod leads)`);
  }
  if (topGroups.length > 10) console.log(`    ... and ${topGroups.length - 10} more`);

  // -------------------------------------------------------------------------
  // 2. Insert/match groups in Dev — keep the original prod ID → dev ID map
  // -------------------------------------------------------------------------
  console.log('\nStep 2: insert groups into Dev');
  const existingDevGroups = await dev.soql<{ Id: string; Name: string }>(
    `SELECT Id, Name FROM Group__c LIMIT 500`
  );
  const devGroupByName = new Map<string, string>();
  for (const g of existingDevGroups) devGroupByName.set(g.Name, g.Id);

  const prodToDevGroupId = new Map<string, string>();
  for (const g of topGroups) {
    let devId = devGroupByName.get(g.Name);
    if (devId) {
      skip(`Group ${g.Name}`);
    } else {
      if (DRY_RUN) {
        ok(`(would create) Group ${g.Name}`);
        devId = 'DRY_RUN_PLACEHOLDER';
      } else {
        devId = await dev.create('Group__c', { Name: g.Name });
        ok(`Group ${g.Name}`);
      }
    }
    prodToDevGroupId.set(g.Id, devId);
    await sleep(REQUEST_DELAY_MS);
  }

  // -------------------------------------------------------------------------
  // 3. Sample ~SAMPLE_LEADS leads spread across the top groups
  // -------------------------------------------------------------------------
  console.log(`\nStep 3: sample ~${SAMPLE_LEADS} leads from prod`);
  const leadsPerGroup = Math.max(2, Math.floor(SAMPLE_LEADS / topGroups.length));
  const sampledLeads: ProdLead[] = [];
  for (const g of topGroups) {
    const leads = await prod.soql<ProdLead>(
      `SELECT Id, FirstName, LastName, Email, Phone, Company, Status, LeadSource,
              Group__c, Lead_Intent__c
       FROM Lead
       WHERE Group__c = '${g.Id}' AND Email != null
       ORDER BY LastModifiedDate DESC
       LIMIT ${leadsPerGroup}`
    );
    sampledLeads.push(...leads);
    if (sampledLeads.length >= SAMPLE_LEADS) break;
  }
  console.log(`  Sampled ${sampledLeads.length} leads`);

  // -------------------------------------------------------------------------
  // 4. Insert leads into Dev
  // -------------------------------------------------------------------------
  console.log('\nStep 4: insert leads into Dev');
  const existingDevLeadEmails = await dev.soql<{ Email: string }>(
    `SELECT Email FROM Lead WHERE Email != null LIMIT 500`
  );
  const devEmailSet = new Set(existingDevLeadEmails.map((l) => l.Email));

  let leadsCreated = 0;
  let leadsSkipped = 0;
  for (let i = 0; i < sampledLeads.length; i++) {
    const lead = sampledLeads[i];
    if (!lead.Email) continue;
    if (devEmailSet.has(lead.Email)) {
      leadsSkipped++;
      continue;
    }

    const devGroupId = lead.Group__c ? prodToDevGroupId.get(lead.Group__c) : undefined;

    const fields: Record<string, unknown> = {
      LastName: lead.LastName,
      Email: lead.Email,
      Company: lead.Company || `${lead.LastName} (Sample)`,
    };
    if (lead.FirstName) fields.FirstName = lead.FirstName;
    if (lead.Phone) fields.Phone = lead.Phone;
    if (lead.Status) fields.Status = lead.Status;
    if (lead.LeadSource) fields.LeadSource = lead.LeadSource;
    if (devGroupId && devGroupId !== 'DRY_RUN_PLACEHOLDER') fields.Group__c = devGroupId;
    if (lead.Lead_Intent__c) fields.Lead_Intent__c = lead.Lead_Intent__c;

    if (DRY_RUN) {
      leadsCreated++;
      continue;
    }

    try {
      await dev.create('Lead', fields);
      leadsCreated++;
    } catch (err) {
      console.warn(
        `    ⚠ ${lead.Email}: ${err instanceof Error ? err.message.slice(0, 100) : err}`
      );
    }

    if ((i + 1) % 25 === 0) {
      console.log(`    [${i + 1}/${sampledLeads.length}] created=${leadsCreated} skipped=${leadsSkipped}`);
    }
    await sleep(REQUEST_DELAY_MS);
  }
  console.log(`  Total: created=${leadsCreated} skipped=${leadsSkipped}`);

  // -------------------------------------------------------------------------
  // 5. Sample properties — mix of statuses
  // -------------------------------------------------------------------------
  console.log(`\nStep 5: sample ~${SAMPLE_PROPS} properties`);
  const statuses = ['Active', 'Pending', 'LOI Signed', 'Closed Won', 'Closed Lost'];
  const propsPerStatus = Math.ceil(SAMPLE_PROPS / statuses.length);
  const sampledProps: ProdProperty[] = [];
  for (const status of statuses) {
    const props = await prod.soql<ProdProperty>(
      `SELECT Id, Name, Marketing_Name__c, Address__c, City__c, State__c,
              Zip_Code__c, County__c, Property_Type__c, Listing_Type__c, Status__c,
              Price__c, Building_Size_sqft__c, Lot_Size_sqft__c, Description__c,
              Public_URL__c, WP_Post_ID__c
       FROM Property__c
       WHERE Status__c = '${status}'
       ORDER BY LastModifiedDate DESC
       LIMIT ${propsPerStatus}`
    );
    sampledProps.push(...props);
  }
  console.log(`  Sampled ${sampledProps.length} properties`);

  // -------------------------------------------------------------------------
  // 6. Insert properties into Dev
  // -------------------------------------------------------------------------
  console.log('\nStep 6: insert properties into Dev');
  const existingDevPropNames = await dev.soql<{ Name: string }>(
    `SELECT Name FROM Property__c LIMIT 500`
  );
  const devPropNameSet = new Set(existingDevPropNames.map((p) => p.Name));

  let propsCreated = 0;
  let propsSkipped = 0;
  for (const prop of sampledProps) {
    if (devPropNameSet.has(prop.Name)) {
      propsSkipped++;
      continue;
    }

    const fields: Record<string, unknown> = { Name: prop.Name };
    for (const k of [
      'Marketing_Name__c',
      'Address__c',
      'City__c',
      'State__c',
      'Zip_Code__c',
      'County__c',
      'Property_Type__c',
      'Listing_Type__c',
      'Status__c',
      'Description__c',
      'Public_URL__c',
    ] as const) {
      if (prop[k]) fields[k] = prop[k];
    }
    if (prop.Price__c != null) fields.Price__c = prop.Price__c;
    if (prop.Building_Size_sqft__c != null) fields.Building_Size_sqft__c = prop.Building_Size_sqft__c;
    if (prop.Lot_Size_sqft__c != null) fields.Lot_Size_sqft__c = prop.Lot_Size_sqft__c;
    if (prop.WP_Post_ID__c != null) fields.WP_Post_ID__c = prop.WP_Post_ID__c;

    if (DRY_RUN) {
      propsCreated++;
      continue;
    }

    try {
      await dev.create('Property__c', fields);
      propsCreated++;
    } catch (err) {
      console.warn(
        `    ⚠ ${prop.Name}: ${err instanceof Error ? err.message.slice(0, 100) : err}`
      );
    }
    await sleep(REQUEST_DELAY_MS);
  }
  console.log(`  Total: created=${propsCreated} skipped=${propsSkipped}`);

  // -------------------------------------------------------------------------
  // Summary
  // -------------------------------------------------------------------------
  console.log('\n=== Summary ===');
  console.log(`Groups:     ${prodToDevGroupId.size} mapped`);
  console.log(`Leads:      created=${leadsCreated} skipped=${leadsSkipped}`);
  console.log(`Properties: created=${propsCreated} skipped=${propsSkipped}`);
  console.log(`\n✅ Dev org now has agent-realistic data.\n`);
  process.exit(0);
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
