/**
 * Deploy the LeadGroupAccessRestriction trigger + test class to SF via the
 * Metadata REST API (the only path that works for code changes in a
 * Production org — Tooling API direct creates are blocked there).
 *
 * Path:
 *   1. Zip sf-deploy/ (which already has package.xml + triggers/ + classes/)
 *   2. POST the zip as multipart/form-data to /metadata/deployRequest
 *   3. Poll the deploy until it completes
 *   4. Report test results + coverage
 *
 * Tests run automatically as part of the deploy (we request RunSpecifiedTests
 * with our one test class). The deploy fails if any test fails or coverage
 * drops below 75%.
 *
 * Idempotent. Default target is prod. Dry-run uses checkOnly=true (validate
 * without committing).
 *
 * Run:
 *   tsx --env-file .env.local scripts/setup/deploy-apex-trigger.ts [--target dev] [--dry-run]
 */

import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { sfClient, type SfTarget } from '../../src/integrations/sf-client';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const SF_DEPLOY_DIR = path.join(REPO_ROOT, 'sf-deploy');
const ZIP_PATH = path.join('/tmp', `sf-deploy-${Date.now()}.zip`);
const API_VERSION = '59.0';

interface SfHandle {
  instanceUrl: string;
  accessToken: string;
}

function parseArgs(argv: string[]) {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) { out[key] = next; i++; }
      else out[key] = true;
    }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const TARGET: SfTarget = args.target === 'dev' ? 'dev' : 'prod';
const DRY_RUN = args['dry-run'] === true;

async function main() {
  console.log(`\n🚀 Deploying Apex to ${TARGET} via Metadata REST API`);
  console.log(`   mode: ${DRY_RUN ? '🧪 CHECK-ONLY (validate, no commit)' : '🔥 DEPLOY'}\n`);

  const sf = (await sfClient(TARGET)) as unknown as SfHandle & Record<string, any>;
  console.log(`Connected to ${sf.instanceUrl}`);

  // Sanity check: junction objects must exist or the Apex won't compile
  for (const obj of ['Lead_List_Assignment__c', 'User_Group_Access__c']) {
    try { await (sf as any).describe(obj); }
    catch {
      console.error(`❌ ${obj} missing in ${TARGET}. Apex will not compile.`);
      process.exit(1);
    }
  }
  console.log('✓ Junction objects present\n');

  // 1. Build the zip
  console.log('Building deploy package...');
  if (fs.existsSync(ZIP_PATH)) fs.unlinkSync(ZIP_PATH);
  execSync(
    `cd "${SF_DEPLOY_DIR}" && zip -r "${ZIP_PATH}" package.xml triggers classes -x "*.DS_Store"`,
    { stdio: 'pipe' }
  );
  const zipBytes = fs.readFileSync(ZIP_PATH);
  console.log(`  ${ZIP_PATH} (${(zipBytes.length / 1024).toFixed(1)} KB)\n`);

  // 2. POST to Metadata REST deployRequest
  console.log('Submitting deploy...');
  const boundary = '----sfdeploy' + Date.now().toString(36);
  const deployOptions = {
    deployOptions: {
      allowMissingFiles: false,
      autoUpdatePackage: false,
      checkOnly: DRY_RUN,
      ignoreWarnings: false,
      performRetrieve: false,
      purgeOnDelete: false,
      rollbackOnError: true,
      runTests: ['LeadGroupAccessRestrictionTest'],
      singlePackage: true,
      testLevel: 'RunSpecifiedTests',
    },
  };
  const parts: Buffer[] = [];
  parts.push(Buffer.from(
    `--${boundary}\r\n` +
    `Content-Disposition: form-data; name="json"\r\n` +
    `Content-Type: application/json\r\n\r\n` +
    JSON.stringify(deployOptions) + `\r\n`
  ));
  parts.push(Buffer.from(
    `--${boundary}\r\n` +
    `Content-Disposition: form-data; name="file"; filename="package.zip"\r\n` +
    `Content-Type: application/zip\r\n\r\n`
  ));
  parts.push(zipBytes);
  parts.push(Buffer.from(`\r\n--${boundary}--\r\n`));
  const body = Buffer.concat(parts);

  const deployRes = await fetch(
    `${sf.instanceUrl}/services/data/v${API_VERSION}/metadata/deployRequest`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${sf.accessToken}`,
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
      },
      body,
    }
  );
  if (!deployRes.ok) {
    console.error(`❌ Submit failed: ${deployRes.status} ${await deployRes.text()}`);
    process.exit(1);
  }
  const submitted: any = await deployRes.json();
  const deployId = submitted.id;
  console.log(`  deploy id: ${deployId}\n`);

  // 3. Poll
  console.log('Polling...');
  const start = Date.now();
  let last: any = null;
  for (let i = 0; i < 120; i++) {
    await sleep(3000);
    const r = await fetch(
      `${sf.instanceUrl}/services/data/v${API_VERSION}/metadata/deployRequest/${deployId}?includeDetails=true`,
      { headers: { Authorization: `Bearer ${sf.accessToken}` } }
    );
    last = await r.json();
    const status = last.deployResult?.status;
    process.stdout.write(`  [${i + 1}] ${status} ${last.deployResult?.numberComponentsDeployed ?? 0}/${last.deployResult?.numberComponentsTotal ?? '?'} components, ${last.deployResult?.numberTestsCompleted ?? 0}/${last.deployResult?.numberTestsTotal ?? '?'} tests\n`);
    if (status === 'Succeeded' || status === 'Failed' || status === 'SucceededPartial' || status === 'Canceled') break;
  }

  // 4. Report
  console.log(`\n=== Result ===`);
  const dr = last.deployResult;
  console.log(`  status:       ${dr?.status}`);
  console.log(`  elapsed:      ${((Date.now() - start) / 1000).toFixed(1)}s`);
  console.log(`  components:   ${dr?.numberComponentsDeployed}/${dr?.numberComponentsTotal} deployed, ${dr?.numberComponentErrors} errors`);
  console.log(`  tests:        ${dr?.numberTestsCompleted}/${dr?.numberTestsTotal} ran, ${dr?.numberTestErrors} errors`);
  if (dr?.details?.componentFailures?.length) {
    console.log('\n❌ COMPONENT FAILURES:');
    for (const f of dr.details.componentFailures) {
      console.log(`  ${f.fullName}: ${f.problem}`);
    }
  }
  if (dr?.details?.runTestResult?.failures?.length) {
    console.log('\n❌ TEST FAILURES:');
    for (const f of dr.details.runTestResult.failures) {
      console.log(`  ${f.name}.${f.methodName}: ${f.message}`);
      if (f.stackTrace) console.log(`    ${f.stackTrace}`);
    }
  }
  if (dr?.details?.runTestResult?.codeCoverage?.length) {
    console.log('\n✅ Code coverage:');
    for (const c of dr.details.runTestResult.codeCoverage) {
      const pct = c.numLocations > 0
        ? Math.round((100 * (c.numLocations - c.numLocationsNotCovered)) / c.numLocations)
        : 0;
      console.log(`  ${c.name} (${c.type}): ${pct}% (${c.numLocations - c.numLocationsNotCovered}/${c.numLocations})`);
    }
  }

  fs.unlinkSync(ZIP_PATH);
  if (dr?.status !== 'Succeeded') process.exit(1);
  console.log(`\n${DRY_RUN ? '✅ Validation passed (no changes committed).' : '🎉 Deploy succeeded.'}`);
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error('💀 Deploy crashed:', err);
  process.exit(1);
});
