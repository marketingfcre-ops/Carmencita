/**
 * ClickUp — read-only client for the marketing report's deliverables board.
 *
 * Pulls tasks from the "Listings & Marketing" space and buckets them into the
 * three columns the report shows: Shipped / On Hold / Blocked.
 *
 * Auth: a personal API token (`pk_...`). Read-only (GETs only).
 * Env vars:
 *   CLICKUP_TOKEN     — personal API token (required to enable this section)
 *   CLICKUP_TEAM_ID   — workspace id (default 9017742247)
 *   CLICKUP_SPACE_ID  — "Listings & Marketing" space (default 90173460377)
 *
 * Scoping (why it's not just "all tasks in the space"):
 * The space also holds demo/sample lists (a 2022–23 "Real Estate Marketing"
 * list), onboarding ("Get Started with ClickUp"), scratch "Project 1/2/3"
 * lists, and the Friday-report template. Those are noise for a deliverables
 * board. We therefore only include tasks whose **folder** is one of the
 * numbered operational folders ("01 | …" … "08 | …"), and drop the Backburner/
 * Wishlist folder (08) since those aren't in-flight deliverables.
 *
 * Bucketing (the space's operational lists only use "to do" / "complete", so
 * the three columns come from folder + status, not a native status set):
 *   Shipped  — status is closed/done (e.g. "complete")
 *   Blocked  — open task in the "Pending & Blocked" folder (07)
 *   On Hold  — every other open task in the operational folders
 */

const CLICKUP_BASE = 'https://api.clickup.com/api/v2';

const CLICKUP_TOKEN = process.env.CLICKUP_TOKEN || '';
const CLICKUP_TEAM_ID = process.env.CLICKUP_TEAM_ID || '9017742247';
const CLICKUP_SPACE_ID = process.env.CLICKUP_SPACE_ID || '90173460377';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ClickupBucket = 'shipped' | 'onHold' | 'blocked' | 'handoff';

export interface ClickupTask {
  id: string;
  name: string;
  url: string;
  /** Human status label as shown in ClickUp (e.g. "to do", "complete"). */
  status: string;
  /** Whether the task is complete/closed. */
  done: boolean;
  /** Normalized priority label, or null. */
  priority: 'urgent' | 'high' | 'normal' | 'low' | null;
  /** Owning list name — used as the sub-tag line in the report. */
  listName: string;
  /** Owning folder name (e.g. "07 | Pending & Blocked"). */
  folderName: string;
  bucket: ClickupBucket;
}

export interface ClickupBoard {
  shipped: ClickupTask[];
  onHold: ClickupTask[];
  blocked: ClickupTask[];
  /** Folder "09 | Transition & Handoff" — rendered as its own section. */
  handoff: ClickupTask[];
  counts: { shipped: number; onHold: number; blocked: number; handoff: number };
}

// Raw shape from GET /team/{id}/task (only the fields we read).
interface RawTask {
  id: string;
  name: string;
  url?: string;
  status?: { status?: string; type?: string };
  priority?: { priority?: string } | null;
  date_closed?: string | null;
  list?: { id?: string; name?: string };
  folder?: { id?: string; name?: string };
  space?: { id?: string };
}

// ---------------------------------------------------------------------------
// Config guard
// ---------------------------------------------------------------------------

export function isClickupConfigured(): boolean {
  return CLICKUP_TOKEN.length > 0;
}

// ---------------------------------------------------------------------------
// Scoping + bucketing helpers
// ---------------------------------------------------------------------------

/** Numbered operational folders: "01 | Salesforce", … "08 | Backburner". */
function isOperationalFolder(name: string): boolean {
  return /^\s*\d{1,2}\s*\|/.test(name);
}

/** Backburner/Wishlist (folder 08) — not in-flight deliverables. */
function isBackburnerFolder(name: string): boolean {
  return /backburner|wishlist/i.test(name);
}

/** The "Pending & Blocked" folder (07) and its blocker lists. */
function isBlockedScope(folderName: string): boolean {
  return /blocked/i.test(folderName);
}

/** Folder "09 | Transition & Handoff" — shown as its own dashboard section. */
function isHandoffFolder(name: string): boolean {
  return /transition|handoff/i.test(name);
}

/** ClickUp closed/done status → shipped. */
function isShippedStatus(t: RawTask): boolean {
  const type = t.status?.type?.toLowerCase();
  if (type === 'closed' || type === 'done') return true;
  if (t.date_closed) return true;
  const name = t.status?.status?.toLowerCase() || '';
  return /^(complete|completed|done|shipped|live|approved)$/.test(name);
}

function normalizePriority(t: RawTask): ClickupTask['priority'] {
  const p = t.priority?.priority?.toLowerCase();
  if (p === 'urgent' || p === 'high' || p === 'normal' || p === 'low') return p;
  return null;
}

// ---------------------------------------------------------------------------
// Fetch
// ---------------------------------------------------------------------------

async function fetchSpaceTasks(): Promise<RawTask[]> {
  const all: RawTask[] = [];
  // "Get Filtered Team Tasks" paginates 100/page; last page returns < 100.
  for (let page = 0; page < 50; page++) {
    const params = new URLSearchParams({
      page: String(page),
      include_closed: 'true',
      subtasks: 'true',
    });
    params.append('space_ids[]', CLICKUP_SPACE_ID);

    const res = await fetch(`${CLICKUP_BASE}/team/${CLICKUP_TEAM_ID}/task?${params}`, {
      headers: { Authorization: CLICKUP_TOKEN },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) {
      throw new Error(`ClickUp tasks fetch failed: ${res.status} ${await res.text()}`);
    }
    const data = (await res.json()) as { tasks?: RawTask[]; last_page?: boolean };
    const batch = data.tasks ?? [];
    all.push(...batch);
    if (data.last_page || batch.length < 100) break;
  }
  return all;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Build the Shipped / On Hold / Blocked board from the operational folders.
 * Returns null when ClickUp is not configured (caller renders "pending").
 */
export async function getClickupBoard(): Promise<ClickupBoard | null> {
  if (!isClickupConfigured()) return null;

  const raw = await fetchSpaceTasks();

  const shipped: ClickupTask[] = [];
  const onHold: ClickupTask[] = [];
  const blocked: ClickupTask[] = [];
  const handoff: ClickupTask[] = [];

  for (const t of raw) {
    const folderName = t.folder?.name || '';
    // Only structured operational folders; skip demo/onboarding/template lists.
    if (!isOperationalFolder(folderName)) continue;
    // Backburner/wishlist is not a live deliverable.
    if (isBackburnerFolder(folderName)) continue;

    const task: ClickupTask = {
      id: t.id,
      name: t.name,
      url: t.url || `https://app.clickup.com/t/${t.id}`,
      status: t.status?.status || '',
      done: isShippedStatus(t),
      priority: normalizePriority(t),
      listName: t.list?.name || '',
      folderName,
      bucket: 'onHold',
    };

    // "09 | Transition & Handoff" is its own dashboard section, not a board column.
    if (isHandoffFolder(folderName)) {
      task.bucket = 'handoff';
      handoff.push(task);
    } else if (task.done) {
      task.bucket = 'shipped';
      shipped.push(task);
    } else if (isBlockedScope(folderName)) {
      task.bucket = 'blocked';
      blocked.push(task);
    } else {
      task.bucket = 'onHold';
      onHold.push(task);
    }
  }

  // Sort each column by priority (urgent → low), then name, for stable display.
  const rank: Record<string, number> = { urgent: 0, high: 1, normal: 2, low: 3 };
  const byPriority = (a: ClickupTask, b: ClickupTask) => {
    const ra = a.priority ? rank[a.priority] : 4;
    const rb = b.priority ? rank[b.priority] : 4;
    return ra - rb || a.name.localeCompare(b.name);
  };
  shipped.sort(byPriority);
  onHold.sort(byPriority);
  blocked.sort(byPriority);
  // Handoff is a checklist — keep the numbered/authored order (by name).
  handoff.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

  return {
    shipped,
    onHold,
    blocked,
    handoff,
    counts: {
      shipped: shipped.length,
      onHold: onHold.length,
      blocked: blocked.length,
      handoff: handoff.length,
    },
  };
}
