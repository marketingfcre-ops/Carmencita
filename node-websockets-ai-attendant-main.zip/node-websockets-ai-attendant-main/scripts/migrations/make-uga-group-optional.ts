/**
 * Make User_Group_Access__c.Group__c optional at the schema level so wildcard
 * rows can have Group__c = null. Tooling-API metadata PATCH on the CustomField.
 *
 *   npx tsx --env-file .env.local scripts/migrations/make-uga-group-optional.ts --dry-run
 *   npx tsx --env-file .env.local scripts/migrations/make-uga-group-optional.ts --apply
 *
 * Idempotent: re-runs report "already optional" and exit 0.
 */
import { sfClient, SfClient } from '../../src/integrations/sf-client';

const APPLY = process.argv.includes('--apply');
const DRY = !APPLY;

async function toolingGet<T = unknown>(sf: SfClient, sobject: string, id: string): Promise<T> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${sf.token}` } });
  if (!res.ok) throw new Error(`tooling GET ${sobject}/${id} → ${res.status}: ${await res.text()}`);
  return (await res.json()) as T;
}

async function toolingPatch(
  sf: SfClient,
  sobject: string,
  id: string,
  body: Record<string, unknown>
): Promise<void> {
  const url = `${sf.instance}/services/data/v59.0/tooling/sobjects/${sobject}/${id}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${sf.token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`tooling PATCH ${sobject}/${id} → ${res.status}: ${await res.text()}`);
}

async function main() {
  const sf = await sfClient('prod');
  console.log(`Connected to ${sf.instance}`);
  console.log(DRY ? 'DRY-RUN (no writes). Pass --apply to execute.\n' : 'APPLY mode — will PATCH.\n');

  // 1. Find the CustomField Id for User_Group_Access__c.Group__c
  const cfs: any[] = await sf.toolingQuery(
    `SELECT Id, DeveloperName, EntityDefinition.QualifiedApiName
     FROM CustomField
     WHERE EntityDefinition.QualifiedApiName = 'User_Group_Access__c'
       AND DeveloperName = 'Group'`
  );
  if (!cfs.length) {
    console.error('❌ CustomField for User_Group_Access__c.Group__c not found via Tooling.');
    process.exit(1);
  }
  const cfId = cfs[0].Id;
  console.log(`✓ CustomField Id: ${cfId}`);

  // 2. Fetch the full record (incl. Metadata)
  const full: any = await toolingGet(sf, 'CustomField', cfId);
  const meta = full.Metadata || {};
  console.log(`\nCurrent Metadata (relevant fields):`);
  console.log(`  type:        ${meta.type}`);
  console.log(`  required:    ${meta.required}`);
  console.log(`  referenceTo: ${meta.referenceTo}`);
  console.log(`  relationshipName: ${meta.relationshipName}`);

  if (meta.required === false) {
    console.log('\n✓ Already optional — nothing to do.');
    return;
  }

  // 3. Plan the PATCH
  const newMeta = { ...meta, required: false };
  console.log(`\nPlanned PATCH: Metadata.required: ${meta.required} → false`);

  if (DRY) {
    console.log('\nDry-run complete. Re-run with --apply to execute.');
    return;
  }

  // 4. Execute PATCH
  await toolingPatch(sf, 'CustomField', cfId, { Metadata: newMeta });
  console.log('✓ PATCH succeeded.');

  // 5. Verify
  const after: any = await toolingGet(sf, 'CustomField', cfId);
  console.log(`\nVerify: Metadata.required = ${after.Metadata?.required}`);
}

main().catch((e) => {
  console.error('💀', e);
  process.exit(1);
});
