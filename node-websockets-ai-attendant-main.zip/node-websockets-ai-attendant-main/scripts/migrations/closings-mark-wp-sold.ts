/**
 * Tag 5 WP-only sold posts with the "Sold" property_status taxonomy.
 *
 * Reads /tmp/closings-mark-wp-sold-confident.json (produced by
 * scripts/diagnostics/closings-vs-sf-wp-audit.ts).
 *
 * These are WP posts where the closing spreadsheet matched a WP listing
 * but no SF record exists (likely pre-SF marketing content). We update
 * the Houzez property_status taxonomy to "Sold" so they show with the
 * Sold badge on the site.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/closings-mark-wp-sold.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/closings-mark-wp-sold.ts
 */

import { readFileSync } from 'fs';
import { setPropertyListingStatus } from '../../src/integrations/wordpress';

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

interface ConfidentRow {
  wpId: number;
  wpStatus: string;
  wpTitle: string;
  wpAddress: string;
  closingPrice: number | string | null;
  closingAgents: string | null;
  closingAddress: string;
  closingTimestamp: string;
  closingNotes: string | null;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  const rows: ConfidentRow[] = JSON.parse(
    readFileSync('/tmp/closings-mark-wp-sold-confident.json', 'utf-8')
  );

  console.log(`\n🏷️  Tag ${rows.length} WP-only posts as Sold ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  console.log('── Plan ──\n');
  for (const row of rows) {
    const price = typeof row.closingPrice === 'number' ? '$' + row.closingPrice.toLocaleString() : row.closingPrice;
    console.log(`wp:${row.wpId}  status=${row.wpStatus}`);
    console.log(`   Title:    "${row.wpTitle.slice(0, 70)}"`);
    console.log(`   Address:  ${row.wpAddress}`);
    console.log(`   Closing:  ${price}  / agents: ${row.closingAgents}`);
    console.log(`   Action:   PATCH property_status = ['sold' term]`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('── Executing ──\n');
  let ok = 0;
  let err = 0;
  for (const row of rows) {
    const result = await setPropertyListingStatus(row.wpId, 'sold');
    if (result.ok) {
      console.log(`   ✓ wp:${row.wpId} → property_status: Sold`);
      ok++;
    } else {
      console.warn(`   ❌ wp:${row.wpId}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Tagged Sold:        ${ok}`);
  console.log(`Failures:           ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
