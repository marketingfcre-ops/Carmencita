/**
 * Repoint SF.WP_Post_ID__c for the 18 cycle-group records.
 *
 * Background: my reconcile-cycles script earlier today elected a new
 * canonical (the lowest-ID post in each cycle pair) and stripped its
 * [DUPLICATE] prefix — but it didn't update SF. So 18 SF records are still
 * pointing at the post the reconciler tagged as duplicate, instead of the
 * canonical we elected.
 *
 * For each [DUPLICATE]-tagged WP post that has an SF record linked to it:
 *   1. Parse the "see wp:N" reference from the title — that's the canonical
 *   2. PATCH SF.WP_Post_ID__c to that canonical id
 *
 * Safe to run NOW because the deployed sync handler fix prevents the
 * resulting webhook from auto-publishing the canonical draft.
 *
 * Run:
 *   tsx --env-file .env.local scripts/migrations/sf-relink-cycle-groups.ts --dry-run
 *   tsx --env-file .env.local scripts/migrations/sf-relink-cycle-groups.ts
 */

const DRY_RUN = process.argv.includes('--dry-run');
const REQUEST_DELAY_MS = 250;

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const WP_SITE_URL = process.env.WP_SITE_URL || 'https://faustocommercial.com';
const WP_USER = process.env.WP_USER || '';
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD || '';
const WP_AUTH =
  'Basic ' + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString('base64');

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  WP_Post_ID__c: number | null;
}

interface WpPost {
  id: number;
  status: string;
  title: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function sfUpdate(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(`${instance}/services/data/v59.0/sobjects/Property__c/${id}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(fields),
  });
  if (res.status === 204) return { ok: true };
  return { ok: false, error: `${res.status} ${(await res.text()).slice(0, 400)}` };
}

const FIELD_PLACEHOLDERS: Array<{ match: RegExp; field: string; value: unknown }> = [
  { match: /Photo_URL__c/i, field: 'Photo_URL__c', value: 'pending' },
  { match: /Listing_Date__c|Listing Date/i, field: 'Listing_Date__c', value: new Date().toISOString().slice(0, 10) },
  { match: /Zoning__c|Zoning/i, field: 'Zoning__c', value: 'TBD' },
  { match: /Year Built|Year_Built__c/i, field: 'Year_Built__c', value: 0 },
  { match: /Building Size|Building_Size_sqft__c/i, field: 'Building_Size_sqft__c', value: 0 },
  { match: /\bUnits\b|Units__c/i, field: 'Units__c', value: 0 },
  { match: /Lot Size|Lot_Size_sqft__c/i, field: 'Lot_Size_sqft__c', value: 0 },
];

async function sfUpdateWithRetry(
  token: string,
  instance: string,
  id: string,
  fields: Record<string, unknown>
): Promise<{ ok: boolean; error?: string }> {
  const accumulated: Record<string, unknown> = {};
  let lastError = '';
  for (let i = 0; i < 5; i++) {
    const result = await sfUpdate(token, instance, id, { ...fields, ...accumulated });
    if (result.ok) return { ok: true };
    lastError = result.error || '';
    const isValidation =
      lastError.includes('REQUIRED_FIELD_MISSING') ||
      lastError.includes('FIELD_CUSTOM_VALIDATION_EXCEPTION');
    if (!isValidation) return { ok: false, error: lastError };
    let added = false;
    for (const p of FIELD_PLACEHOLDERS) {
      if (p.match.test(lastError) && !(p.field in accumulated)) {
        accumulated[p.field] = p.value;
        added = true;
      }
    }
    if (!added) return { ok: false, error: lastError };
  }
  return { ok: false, error: lastError };
}

async function fetchAllWpPosts(): Promise<WpPost[]> {
  const out: WpPost[] = [];
  for (const status of ['publish', 'draft', 'private', 'pending']) {
    for (let page = 1; page <= 20; page++) {
      const url = `${WP_SITE_URL}/wp-json/wp/v2/properties?per_page=100&page=${page}&status=${status}&context=edit&_fields=id,status,title`;
      const res = await fetch(url, { headers: { Authorization: WP_AUTH } });
      if (!res.ok) break;
      const batch = (await res.json()) as any[];
      if (!Array.isArray(batch) || batch.length === 0) break;
      for (const p of batch) {
        out.push({
          id: p.id,
          status: p.status || '',
          title: (p.title?.rendered || p.title || '').toString(),
        });
      }
      if (batch.length < 100) break;
    }
  }
  return out;
}

function extractCanonicalRef(title: string): number | null {
  const decoded = title.replace(/&#8211;/g, '–').replace(/&amp;/g, '&');
  const m = decoded.match(/\[DUPLICATE[\s\S]*?see wp:(\d+)\]/i);
  return m ? parseInt(m[1], 10) : null;
}

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  if (!SF_CLIENT_ID || !WP_USER) {
    console.error('❌ Missing env vars.');
    process.exit(1);
  }

  console.log(`\n🔗 Repoint SF records linked to [DUPLICATE] posts ${DRY_RUN ? '(DRY RUN)' : ''}\n`);

  const { token, instance } = await sfAuth();
  const [sfRecords, wpPosts] = await Promise.all([
    sfQuery<SfProperty>(
      token,
      instance,
      `SELECT Id, Name, Address__c, WP_Post_ID__c
         FROM Property__c
        WHERE WP_Post_ID__c != NULL`
    ),
    fetchAllWpPosts(),
  ]);

  const wpById = new Map<number, WpPost>();
  for (const p of wpPosts) wpById.set(p.id, p);

  // Find SF records whose WP_Post_ID__c points at a [DUPLICATE]-tagged post
  const plan: { sf: SfProperty; currentWpId: number; canonicalId: number; currentTitle: string }[] = [];
  for (const sf of sfRecords) {
    if (!sf.WP_Post_ID__c) continue;
    const wp = wpById.get(sf.WP_Post_ID__c);
    if (!wp) continue;
    if (!/\[DUPLICATE/i.test(wp.title)) continue;
    const canonical = extractCanonicalRef(wp.title);
    if (!canonical) {
      console.warn(`   ⚠️  SF ${sf.Id} → wp:${wp.id} has [DUPLICATE] tag but no canonical ref in title — skipping`);
      continue;
    }
    if (!wpById.has(canonical)) {
      console.warn(`   ⚠️  SF ${sf.Id} → canonical wp:${canonical} doesn't exist — skipping`);
      continue;
    }
    plan.push({ sf, currentWpId: wp.id, canonicalId: canonical, currentTitle: wp.title });
  }

  console.log(`Found ${plan.length} SF records to repoint.\n`);
  console.log('── Plan ──\n');
  for (const p of plan) {
    console.log(`SF ${p.sf.Id}  ${p.sf.Address__c || p.sf.Name}`);
    console.log(`   FROM:  wp:${p.currentWpId}  ([DUPLICATE] post)`);
    console.log(`   TO:    wp:${p.canonicalId}  (canonical)`);
    console.log('');
  }

  if (DRY_RUN) {
    console.log('[DRY RUN] No changes made.\n');
    process.exit(0);
  }

  console.log('→ Executing...\n');
  let ok = 0;
  let err = 0;
  for (const p of plan) {
    const result = await sfUpdateWithRetry(token, instance, p.sf.Id, {
      WP_Post_ID__c: p.canonicalId,
    });
    if (result.ok) {
      console.log(`   ✓ ${p.sf.Id}: wp:${p.currentWpId} → wp:${p.canonicalId}`);
      ok++;
    } else {
      console.warn(`   ❌ ${p.sf.Id}: ${result.error}`);
      err++;
    }
    await sleep(REQUEST_DELAY_MS);
  }

  console.log('\n=== Summary ===');
  console.log(`Repointed:   ${ok}`);
  console.log(`Failures:    ${err}`);
  console.log('');
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
