/**
 * QA Test 5: Closed Won → "Sold" badge, Closed Lost → "Off Market" badge.
 * Both states keep the WP listing browsable (Zillow-style historical record).
 *
 * Run: tsx --env-file .env.local scripts/tests/test-closed-won-lost.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = await sfClient('dev');
  const prop = (await sf.soql<{ Id: string; Name: string; Status__c: string }>(
    `SELECT Id, Name, Status__c FROM Property__c ORDER BY LastModifiedDate DESC LIMIT 1`
  ))[0];

  console.log(`\n=== Test 5a: Closed Won → SOLD ===`);
  console.log(`Property: ${prop.Name} (${prop.Id})`);
  console.log(`Current status: ${prop.Status__c}`);
  await sf.update('Property__c', prop.Id, { Status__c: 'Closed Won' });
  console.log('✅ Set to Closed Won. Watch log for sync.');

  await new Promise((r) => setTimeout(r, 8000));

  console.log(`\n=== Test 5b: Closed Lost → OFF MARKET (still public) ===`);
  await sf.update('Property__c', prop.Id, { Status__c: 'Closed Lost' });
  console.log('✅ Set to Closed Lost. Watch log for sync.');

  await new Promise((r) => setTimeout(r, 8000));

  // Reset
  console.log(`\n=== Reset → Active ===`);
  await sf.update('Property__c', prop.Id, { Status__c: 'Active' });
  console.log('✅ Reset.');
}

main().catch((err) => {
  console.error('Crashed:', err);
  process.exit(1);
});
