# Group-Assignment Approval Process — Design + Setup

Goal: when an agent creates a new `Lead_List_Assignment__c` row (a Lead being
added to a Group), it lands as `Status__c = Pending`. An admin reviews it
and either approves (sets `Status__c = Approved`, stamps `Approved_By__c`
and `Approved_Date__c`) or rejects (deletes it). Agents shouldn't be able
to self-approve — that defeats the point.

This doc gives you two paths. **Path A** is the native Salesforce Approval
Process — more polish, native email/queue UX, mobile-friendly. **Path B**
is a list view + an auto-stamp Flow — simpler, ships in 15 minutes.

If you're not sure which one to use, start with **Path B** today. Move to
Path A only if the volume is high enough that the lightweight list view
gets unwieldy (>20 pending at a time, sustained).

---

## Path A — Native Approval Process (recommended for higher volume)

Approval Processes are supported in Professional Edition. They give you:

- a global "Items to Approve" panel for approvers
- automated email on submission
- automated email on approve/reject
- an audit trail visible on each record
- mobile + Salesforce-app approvals

### Configuration

**Setup → Quick Find → Approval Processes → Manage Approval Processes**

1. **Object**: `Lead Group Assignment`
2. **New Approval Process** → **Use Jump Start Wizard**
3. **Name**: `Lead List Assignment Approval`
4. **Unique Name**: `Lead_List_Assignment_Approval`
5. **Description**: `Approve agent-submitted Lead → Group assignments before they take effect.`
6. **Entry Criteria** (the rule that decides if a record needs approval):
   - `Status__c equals Pending`
7. **Approver assignment**: Auto-assign to **Nathalie Aguirre**.
   - (Backup approver — add as a "Queue" later if you want Carlos / Elizabeth as fallback. Skip for v1.)
8. **Email Template**: leave default for the wizard; tweak after.
9. **Initial Submitters**: who can submit for approval. Choose `Account for Agents` profile + `System Administrator`. The submission is automatic on record creation (see step 11), so this is mostly a safety gate.

**Click Save.** You'll land on the Approval Process detail page.

### Final approval / rejection actions

On the detail page:

10. **Final Approval Actions** → **Add New** → **Field Update**:
    - Field: `Status__c`
    - Value: `Approved`
    - Re-evaluate workflow rules: leave unchecked
11. **Add another Field Update** for `Approved_By__c`:
    - Field: `Approved_By__c`
    - Value: `$User.Id` (current user, the approver)
12. **Add another Field Update** for `Approved_Date__c`:
    - Field: `Approved_Date__c`
    - Value: `NOW()`
13. **Add a Field Update** under **Final Rejection Actions** for `Status__c`:
    - Field: `Status__c`
    - Value: `Rejected`
    - (Optional: also add a Send Email to notify the submitter.)

### Auto-submit on record create

By default the submitter has to click "Submit for Approval." We want every
new Pending record to auto-submit so agents don't have to know about the
process. Use a Record-Triggered Flow:

**Setup → Flows → New Flow → Record-Triggered Flow**

- **Object**: `Lead_List_Assignment__c`
- **Trigger**: A record is created
- **Run flow**: After save
- **Set entry conditions**: `Status__c Equals Pending`
- **Add an Action** → **Submit for Approval**:
  - Approval Process: `Lead_List_Assignment_Approval`
  - Record: `{!$Record}`

**Activate the flow.**

### Activate the approval process

Back on the approval-process detail page → **Activate**.

### What approvers see

Nathalie (and any other approver) will see:
- "Items to Approve" tile on her home page
- Email per submission ("Approval request: Lead Group Assignment — [Lead Name] → [Group Name]")
- One-click approve/reject from the email or the SF mobile app

### Edge cases

- **Agent edits an Approved record back to Pending**: the approval process re-fires (since entry criteria is Status = Pending). Probably fine. Lock the field down on the agent profile if it's a concern.
- **Bulk creates**: the auto-submit Flow runs in bulk. Approvers get one email per record. Mass approval is one-by-one in v1 — tolerable up to ~20/day.

---

## Path B — List view + auto-stamp Flow (recommended to ship today)

If you want to skip Approval Processes for now and just give Nathalie a
simple queue, this is 15 minutes of work.

### Step 1 — The "Pending Lead List Assignments" list view

Setup → App Launcher → search **Lead Group Assignments** → click the tab.

1. List view dropdown (top right of the table) → **New**
2. **Name**: `Pending Approvals`
3. **Visibility**: All users can see this list view
4. **Filters**:
   - `Status equals Pending`
5. **Save**.
6. Edit the list view's displayed fields → add: `Lead`, `Group`, `Created Date`, `Created By`, `Status`.

Nathalie opens that view → ticks the rows she wants → **Edit** → set `Status` to `Approved` → Save. Approves in batches.

### Step 2 — Auto-stamp Flow

When `Status__c` is set to `Approved`, populate `Approved_By__c` and
`Approved_Date__c` automatically so we don't depend on the approver to
do it manually.

Setup → Flows → New Flow → Record-Triggered Flow

- **Object**: `Lead_List_Assignment__c`
- **Trigger**: Record updated
- **Set entry conditions**:
  - `Status__c` Equals `Approved`
  - **AND** `Approved_By__c` Is Null `True` (only stamp once)
- **Run flow**: Before save the record
- **Add an action** → **Update Triggering Record**:
  - `Approved_By__c` = `{!$User.Id}`
  - `Approved_Date__c` = `{!$Flow.CurrentDateTime}`
- **Save → Activate.**

### What this gets you

- A queue Nathalie can sort + filter
- Bulk approve via list-view inline edit
- Approved_By / Approved_Date automatically populated
- No emails on submission — agents tell Nathalie out-of-band when there's a batch to look at

### What it doesn't give you

- No native "approve / reject" UX in the SF mobile app
- No automatic email notifications
- No first-class audit trail (you'd query Field History instead)

For ~5–10 assignments a week, Path B is fine.

---

## Recommendation

Ship **Path B** today (15 min). If after 30 days the volume warrants it,
build **Path A** on top — they don't conflict if Path A's entry criteria
is `Status = Pending`, since Path B's manual-edits flip Status to Approved
directly (bypassing the Approval Process entry criteria).
