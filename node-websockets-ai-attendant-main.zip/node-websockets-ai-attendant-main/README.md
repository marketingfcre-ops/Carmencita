# Fausto — Commercial AI Phone Attendant ("Carmencita")

Low-latency real-time AI phone attendant for a commercial real-estate brokerage.
Callers speak naturally with an AI receptionist that answers questions about
listings, captures leads into Salesforce, and can text or email a listing/flyer
before the caller hangs up. Around that core sit a Salesforce lead-security
system, a Salesforce⇄WordPress listing sync, marketing-list automation, automated
off-site backups, and an admin dashboard.

It is not a chatbot on a phone line — it's a sub-2-second voice system with real
commercial-real-estate and Miami-geography intelligence and a production data
layer underneath.

## 📖 Start here — full documentation

The **complete technical handover** is in [`docs/handoff/`](docs/handoff/) — read
[`00-overview.md`](docs/handoff/00-overview.md) first. The same docs are served
in-app at **`/admin/docs`** (behind `ADMIN_KEY`) via
[`src/docs-bundle.ts`](src/docs-bundle.ts).

| # | Section | Covers |
|---|---|---|
| 00 | [Overview](docs/handoff/00-overview.md) | What the system is, architecture at a glance, cross-cutting gotchas |
| 01 | [Voice pipeline](docs/handoff/01-voice-pipeline.md) | Real-time STT→Claude→TTS, barge-in, turn-taking, tools, bilingual handling |
| 02 | [Search & geo intelligence](docs/handoff/02-intelligence-search-geo.md) | sqft↔acres, neighborhood/grid inference, proximity, fuzzy matching |
| 03 | [Salesforce security & sync](docs/handoff/03-salesforce-security-sync.md) | Lead-access model, groups, the access Flow, OAuth, SF→WP trigger |
| 04 | [SF automation, backups & ops](docs/handoff/04-sf-automation-backups-ops.md) | Server-side LLA reconcile + notify, R2 backups, the script library |
| 05 | [WordPress & marketing](docs/handoff/05-wordpress-marketing.md) | SF→WP listing sync, publish/unpublish, Campaign Monitor |
| 06 | [SMS, email & consent](docs/handoff/06-sms-email-consent.md) | A2P consent flow, SMS/email delivery, Resend |
| 07 | [Admin dashboard, architecture & env vars](docs/handoff/07-admin-framework-deploy.md) | Admin dash, framework structure, Railway deploy, **full env-var inventory** |

> **Section 08 (Handover & operations)** — accounts, transfer steps, and the
> ownership position — is intentionally **kept out of this repo** (internal /
> business; transferred separately). The in-app `/admin/docs` viewer also excludes it.

For the day-to-day working agreement (approval gates, read-only autonomy, deploy
rules) see [`CLAUDE.md`](CLAUDE.md). Ops runbooks are in
[`docs/`](docs/) (e.g. [`morning-runbook.md`](docs/morning-runbook.md),
[`nathalie-sf-runbook.md`](docs/nathalie-sf-runbook.md)).

## Architecture

```
Caller → Twilio <Connect><Stream> → WebSocket (/stream) → this server
                                       ├── Deepgram STT (streaming)   → transcript
                                       ├── Claude Haiku 4.5 (streaming) → text chunks
                                       ├── Sentence splitter           → complete sentences
                                       └── ElevenLabs TTS (mulaw)      → audio → back to Twilio
```

Text is streamed to TTS sentence-by-sentence, so the caller hears the first words
in ~1–1.5s instead of waiting for the full response.

**Stack:** Node + TypeScript · Fastify (HTTP + WebSocket, `@fastify/websocket`) ·
deployed on Railway.
**Voice:** Twilio Media Streams · Deepgram STT · Claude Haiku 4.5 · **ElevenLabs
TTS** (Flash v2.5, `src/tts.ts`).
**Data / integrations:** Salesforce (Professional Edition) · WordPress (Cloudways) ·
Campaign Monitor · Resend (email) · Cloudflare R2 (backups).

## Local development

```bash
npm install
npm run dev      # tsx watch, loads .env.local, port 3000
npm run ngrok    # exposes :3000 on the fixed ngrok domain
npm run build    # tsc → dist/
npm start        # node dist/server.js (prod-style)
npm run typecheck
```

- Fixed ngrok domain: `https://thymy-unjarring-brande.ngrok-free.dev`
- Secrets live in `.env.local` (gitignored). **Never print or commit them.**
- Full env-var inventory: [`docs/handoff/07-admin-framework-deploy.md`](docs/handoff/07-admin-framework-deploy.md).

## Endpoints

| Endpoint | Method | Purpose |
|---|---|---|
| `/voice/answer` | POST | Twilio webhook — returns TwiML with `<Connect><Stream>` |
| `/voice/status` | POST | Twilio call status callbacks |
| `/stream` | WS | WebSocket for Twilio Media Streams |
| `/health` | GET | Health check |
| `/debug` | GET | View leads and listings *(unauthenticated — lock down for prod)* |
| `/admin` | GET | Admin dashboard *(behind `ADMIN_KEY`)* |
| `/admin/docs` | GET | In-app system documentation viewer *(behind `ADMIN_KEY`)* |

## Deploy

- **Prod:** merge to `main` → Railway auto-deploys. No manual step.
- **Preview:** open a PR → Railway spins up a PR preview environment.
- **Salesforce:** prod is **Professional Edition — no custom Apex.** The Apex in
  `sf-deploy/` is **dev-org only**; prod lead-group access is enforced by a Flow.
  See [`CLAUDE.md`](CLAUDE.md) and section 03.

## ⚠️ Before running in production

These surfaced during the handover documentation (see §00 → "Cross-cutting findings"):

1. **Set a real `ADMIN_KEY`** — the default (`fausto2026`) is public, and `/debug`
   is unauthenticated.
2. **Two WordPress Code Snippets live outside this repo** (custom `/fausto/v1/...`
   endpoints) and are **not backed up** — the SF→WP sync depends on them (§05).
3. **Call logs are ephemeral** — stored in `/tmp/call-logs`, lost on every redeploy (§07).
4. **Feature-flag polarity varies** — `EMAIL_ENABLED`, `LLA_RECONCILE_ENABLED`,
   `LLA_NOTIFY_ENABLED` all default **OFF** (§04, §06, §07).

## Editing the docs

`docs/handoff/*.md` are the source of truth. The in-app `/admin/docs` viewer reads
from [`src/docs-bundle.ts`](src/docs-bundle.ts), a generated bundle of sections
00–07 (section 08 is intentionally excluded from the in-app copy). **After editing
the handoff markdown, regenerate the bundle:**

```bash
npx tsx scripts/setup/build-docs-bundle.ts          # regenerate src/docs-bundle.ts
npx tsx scripts/setup/build-docs-bundle.ts --check   # verify it's in sync (CI-friendly)
```
