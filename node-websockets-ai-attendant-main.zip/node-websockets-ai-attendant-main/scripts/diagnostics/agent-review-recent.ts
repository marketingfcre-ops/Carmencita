/**
 * Recent agent-review submission activity — pulls all [Agent Review YYYY-MM-DD]
 * markers out of Notes_for_Marketing__c and shows the most recent dates per agent.
 *
 * Run: npx tsx --env-file .env.local scripts/diagnostics/agent-review-recent.ts
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

interface SfProperty {
  Id: string;
  Listing_Agent__r: { Name: string } | null;
  Notes_for_Marketing__c: string | null;
  LastModifiedDate: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const { access_token, instance_url } = (await res.json()) as any;
  return { token: access_token, instance: instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL failed: ${res.status} ${await res.text()}`);
    const data = (await res.json()) as any;
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

async function main() {
  const { token, instance } = await sfAuth();
  const records = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Listing_Agent__r.Name, Notes_for_Marketing__c, LastModifiedDate
       FROM Property__c
      WHERE Listing_Agent__c != NULL AND Status__c = 'Active'`
  );

  // Per-marker rows: each "[Agent Review YYYY-MM-DD] Name: STATUS — notes"
  const re = /\[Agent Review (\d{4}-\d{2}-\d{2})\]\s*([^:]+):\s*([A-Z/ ]+?)(?:\s*—\s*(.*?))?(?=\[Agent Review|\s*$)/gs;
  type Row = { date: string; agent: string; status: string; sfId: string; lastMod: string };
  const rows: Row[] = [];
  for (const r of records) {
    const notes = r.Notes_for_Marketing__c || '';
    let m: RegExpExecArray | null;
    while ((m = re.exec(notes)) !== null) {
      rows.push({
        date: m[1],
        agent: m[2].trim(),
        status: m[3].trim(),
        sfId: r.Id,
        lastMod: r.LastModifiedDate,
      });
    }
  }

  // Most-recent marker date per agent
  const latestByAgent = new Map<string, { date: string; count: number }>();
  // Count of reviews submitted per (agent, date)
  const byAgentDate = new Map<string, number>();
  for (const row of rows) {
    const cur = latestByAgent.get(row.agent);
    if (!cur || row.date > cur.date) {
      latestByAgent.set(row.agent, { date: row.date, count: 1 });
    } else if (row.date === cur.date) {
      cur.count++;
    }
    const k = `${row.agent}\t${row.date}`;
    byAgentDate.set(k, (byAgentDate.get(k) || 0) + 1);
  }

  console.log(`\n📅 Latest agent-review marker date per agent (n=${rows.length} markers total)\n`);
  const sorted = [...latestByAgent.entries()].sort((a, b) =>
    b[1].date.localeCompare(a[1].date)
  );
  const nameW = Math.max(5, ...sorted.map(([n]) => n.length));
  const pad = (s: string, w: number) => s + ' '.repeat(Math.max(0, w - s.length));
  console.log(`${pad('AGENT', nameW)}   LATEST DATE   #ON THAT DAY`);
  console.log('─'.repeat(nameW + 30));
  for (const [name, info] of sorted) {
    console.log(`${pad(name, nameW)}   ${info.date}    ${info.count}`);
  }

  console.log(`\n📊 Submissions per day (all agents combined)\n`);
  const byDate = new Map<string, number>();
  for (const r of rows) byDate.set(r.date, (byDate.get(r.date) || 0) + 1);
  const dates = [...byDate.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  for (const [d, n] of dates) console.log(`  ${d}   ${n}`);

  console.log(`\n📊 Per-agent submissions per day\n`);
  const perAgentDay = [...byAgentDate.entries()]
    .map(([k, n]) => {
      const [a, d] = k.split('\t');
      return { agent: a, date: d, count: n };
    })
    .sort((a, b) => b.date.localeCompare(a.date) || a.agent.localeCompare(b.agent));
  for (const r of perAgentDay) {
    console.log(`  ${r.date}   ${pad(r.agent, nameW)}   ${r.count}`);
  }

  process.exit(0);
}

main().catch((err) => {
  console.error('💀', err);
  process.exit(1);
});
