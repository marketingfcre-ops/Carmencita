/**
 * POSITIVE-path test: when user.Group_ID__c MATCHES lead.Group__c, the
 * validation rule should NOT block.
 *
 * Run: tsx --env-file .env.local scripts/test-validation-rule-positive.ts
 */

import { sfClient, type SfClient } from '../../src/integrations/sf-client';

interface AnonymousResult {
  compiled: boolean;
  compileProblem: string | null;
  success: boolean;
  exceptionMessage: string | null;
}

interface RunTestsResult {
  successes: { Name: string; MethodName: string }[];
  failures: { Name: string; MethodName: string; Message: string; StackTrace: string }[];
  numTestsRun: number;
  numFailures: number;
}

async function main() {
  console.log('\n🧪 POSITIVE-path test: matching groups should ALLOW edit\n');
  const sf = await sfClient('dev');

  // Use test-agent-001 specifically (already set up in LittleHavanaMF)
  const users = await sf.soql<{ Id: string; Username: string; Group_ID__c: string }>(
    `SELECT Id, Username, Group_ID__c FROM User WHERE Username = 'test-agent-001@27colab.com.dev'`
  );
  if (users.length === 0) {
    console.error('test-agent-001 not found.');
    process.exit(1);
  }
  const testUser = users[0];
  console.log(`User: ${testUser.Username}`);
  console.log(`User.Group_ID__c: ${testUser.Group_ID__c}`);

  // Find a Lead in the SAME group
  const leads = await sf.soql<{ Id: string; Email: string; Group__c: string }>(
    `SELECT Id, Email, Group__c FROM Lead WHERE Group__c = '${testUser.Group_ID__c}' LIMIT 1`
  );
  if (leads.length === 0) {
    console.error(`No leads in group ${testUser.Group_ID__c}`);
    process.exit(1);
  }
  console.log(`Lead: ${leads[0].Email}`);
  console.log(`Lead.Group__c: ${leads[0].Group__c}`);
  console.log(`Match: ${leads[0].Group__c === testUser.Group_ID__c ? '✓' : '✗'}`);

  // Deploy a test class that tries to edit a same-group lead and asserts it succeeds
  const className = 'GroupEditValidationPositiveTest';
  const stamp = Date.now();
  const apexBody = `@isTest(seeAllData=true)
public class ${className} {
    @isTest
    static void sameGroupAllowsEdit() {
        User u = [SELECT Id, Group_ID__c FROM User WHERE Id = '${testUser.Id}'];
        Lead lead = [SELECT Id, Group__c FROM Lead WHERE Id = '${leads[0].Id}'];
        Boolean blocked = false;
        String errMsg = '';
        System.runAs(u) {
            try {
                Lead l = new Lead(Id='${leads[0].Id}', Description='PositiveTest_${stamp}');
                update l;
            } catch (DmlException e) {
                blocked = true;
                errMsg = e.getMessage();
            }
        }
        System.assert(!blocked, 'Validation rule WRONGLY blocked same-group edit. UserGroupID=[' + u.Group_ID__c + '] LeadGroupC=[' + lead.Group__c + '] err=' + errMsg);
    }
}`;

  // Delete existing class if any
  const existing = await sf.toolingQuery<{ Id: string }>(
    `SELECT Id FROM ApexClass WHERE Name = '${className}'`
  );
  if (existing.length > 0) await sf.delete('ApexClass', existing[0].Id);

  await sf.toolingCreate('ApexClass', { Body: apexBody });
  await new Promise((r) => setTimeout(r, 1000));

  const deployed = await sf.toolingQuery<{ Id: string }>(
    `SELECT Id FROM ApexClass WHERE Name = '${className}' LIMIT 1`
  );

  // Run the test
  const url = `${sf.instance}/services/data/v59.0/tooling/runTestsSynchronous`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${sf.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ tests: [{ classId: deployed[0].Id }] }),
  });
  const result = (await res.json()) as RunTestsResult;

  console.log(`\nTests run: ${result.numTestsRun}, failures: ${result.numFailures}`);
  if (result.numFailures === 0) {
    console.log('\n✅ TEST PASSED — same-group edits allowed.\n');
  } else {
    for (const f of result.failures) {
      console.error(`\n  ✗ ${f.Name}.${f.MethodName}`);
      console.error(`     ${f.Message}`);
      console.error(`     ${f.StackTrace?.split('\n').slice(0, 3).join('\n     ')}`);
    }
    console.error('\n❌ Validation rule is incorrectly blocking matching-group edits.\n');
  }
  process.exit(result.numFailures > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error('Crashed:', err);
  process.exit(1);
});
