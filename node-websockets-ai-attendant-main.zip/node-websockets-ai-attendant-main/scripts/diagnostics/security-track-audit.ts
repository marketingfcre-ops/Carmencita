/**
 * Pre-announcement audit. Sanity-checks the whole security track: Leads,
 * Group__c, Lead_List_Assignment__c, User_Group_Access__c, and the agent ↔
 * lead access graph. Read-only — never modifies prod.
 *
 * Run:
 *   tsx --env-file .env.local scripts/diagnostics/security-track-audit.ts
 */

import { sfClient } from '../../src/integrations/sf-client';

async function main() {
  const sf = (await sfClient('prod')) as any;
  console.log(`Connected to ${sf.instanceUrl}\n`);

  // ───────────────────────────────────────────────────────────
  // 1. Group__c canonicals
  // ───────────────────────────────────────────────────────────
  console.log('═══ 1. Group__c canonicals ═══');
  const allGroups: any[] = await sf.soql(`SELECT Id, Name FROM Group__c`);
  console.log(`  Total Group__c records: ${allGroups.length}`);

  // Duplicates by case-insensitive name?
  const byLower = new Map<string, any[]>();
  for (const g of allGroups) {
    const k = g.Name.toLowerCase();
    if (!byLower.has(k)) byLower.set(k, []);
    byLower.get(k)!.push(g);
  }
  const dupes = [...byLower.entries()].filter(([, arr]) => arr.length > 1);
  if (dupes.length === 0) console.log(`  ✓ No case-insensitive name duplicates`);
  else {
    console.log(`  ⚠ ${dupes.length} duplicate-by-lowercase name groups:`);
    for (const [k, arr] of dupes) console.log(`    "${k}" → ${arr.map((g) => `${g.Name}(${g.Id})`).join(', ')}`);
  }

  // Empty groups (0 leads AND 0 properties)?
  const leadCounts: any[] = await sf.soql(
    `SELECT Group__c, COUNT(Id) cnt FROM Lead WHERE Group__c != null GROUP BY Group__c`
  );
  const leadCountByGroup = new Map<string, number>(leadCounts.map((r) => [r.Group__c, r.cnt]));
  const propCounts: any[] = await sf.soql(
    `SELECT Group__c, COUNT(Id) cnt FROM Property__c WHERE Group__c != null GROUP BY Group__c`
  );
  const propCountByGroup = new Map<string, number>(propCounts.map((r) => [r.Group__c, r.cnt]));
  const emptyGroups = allGroups.filter(
    (g) => !leadCountByGroup.get(g.Id) && !propCountByGroup.get(g.Id)
  );
  console.log(`  Empty groups (0 leads + 0 properties): ${emptyGroups.length}`);
  if (emptyGroups.length > 0 && emptyGroups.length <= 30) {
    for (const g of emptyGroups) console.log(`    ⊘ "${g.Name}"`);
  }

  // ───────────────────────────────────────────────────────────
  // 2. Leads
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 2. Leads ═══');
  const leadStats: any[] = await sf.soql(
    `SELECT COUNT(Id) cnt, IsConverted FROM Lead GROUP BY IsConverted`
  );
  let totalLeads = 0;
  for (const r of leadStats) { totalLeads += r.cnt; console.log(`  IsConverted=${r.IsConverted}: ${r.cnt}`); }
  console.log(`  Total: ${totalLeads}`);

  const withGroup: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Lead WHERE Group__c != null`);
  const stillNullButOld: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Lead WHERE Group__c = null AND Group_old2__c != null`);
  const nullBoth: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Lead WHERE Group__c = null AND Group_old2__c = null`);
  console.log(`  Leads with Group__c set:                    ${withGroup[0].cnt}`);
  console.log(`  Leads with Group__c null + Group_old2 set:  ${stillNullButOld[0].cnt}  (expected ~53 — converted leads + niche text variants)`);
  console.log(`  Leads with both fields null:                ${nullBoth[0].cnt}`);

  // ───────────────────────────────────────────────────────────
  // 3. Lead_List_Assignment__c junctions
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 3. Lead_List_Assignment__c ═══');
  const totalJunctions: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Lead_List_Assignment__c`);
  console.log(`  Total junctions: ${totalJunctions[0].cnt}`);

  const byStatus: any[] = await sf.soql(`SELECT Status__c, COUNT(Id) cnt FROM Lead_List_Assignment__c GROUP BY Status__c`);
  for (const r of byStatus) console.log(`    Status=${r.Status__c}: ${r.cnt}`);

  // Leads with Group__c set but missing the equivalent (Lead__c, Group__c) junction
  const allLeadGroup: any[] = await sf.soql(`SELECT Id, Group__c FROM Lead WHERE Group__c != null`);
  const allJunctionKeys = new Set<string>();
  // We need to paginate or batch these — sf.soql() does that already
  const allJunc: any[] = await sf.soql(`SELECT Lead__c, Group__c FROM Lead_List_Assignment__c`);
  for (const j of allJunc) allJunctionKeys.add(`${j.Lead__c}|${j.Group__c}`);
  const missingJunctions = allLeadGroup.filter((l) => !allJunctionKeys.has(`${l.Id}|${l.Group__c}`));
  console.log(`  Leads with Group__c set but no matching junction: ${missingJunctions.length}`);

  // Duplicate junctions
  const juncCounts = new Map<string, number>();
  for (const j of allJunc) {
    const k = `${j.Lead__c}|${j.Group__c}`;
    juncCounts.set(k, (juncCounts.get(k) || 0) + 1);
  }
  const juncDupes = [...juncCounts.entries()].filter(([, n]) => n > 1);
  console.log(`  Duplicate (Lead, Group) junction pairs: ${juncDupes.length}`);

  // Leads with MORE than one junction (legitimate multi-group memberships)
  const byLead = new Map<string, number>();
  for (const j of allJunc) byLead.set(j.Lead__c, (byLead.get(j.Lead__c) || 0) + 1);
  const multiGroupLeads = [...byLead.entries()].filter(([, n]) => n > 1);
  console.log(`  Leads with >1 group membership (junction count): ${multiGroupLeads.length}`);
  if (multiGroupLeads.length > 0 && multiGroupLeads.length <= 10) {
    for (const [id, n] of multiGroupLeads) console.log(`    ${id}: ${n} groups`);
  }

  // ───────────────────────────────────────────────────────────
  // 4. User_Group_Access__c
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 4. User_Group_Access__c ═══');
  const totalAccess: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM User_Group_Access__c`);
  console.log(`  Total agent ↔ group rows: ${totalAccess[0].cnt}`);

  const accessByStatus: any[] = await sf.soql(`SELECT Status__c, COUNT(Id) cnt FROM User_Group_Access__c GROUP BY Status__c`);
  for (const r of accessByStatus) console.log(`    Status=${r.Status__c}: ${r.cnt}`);

  const allAccess: any[] = await sf.soql(`SELECT User__c, Group__c FROM User_Group_Access__c WHERE Status__c = 'Approved'`);
  const accessByUser = new Map<string, Set<string>>();
  for (const a of allAccess) {
    if (!accessByUser.has(a.User__c)) accessByUser.set(a.User__c, new Set());
    accessByUser.get(a.User__c)!.add(a.Group__c);
  }
  console.log(`  Distinct users with Approved access: ${accessByUser.size}`);

  // ───────────────────────────────────────────────────────────
  // 5. Agent access gap — the KEY check
  //    Leads where the owner does NOT have User_Group_Access to that lead's group.
  //    These would be BLOCKED by the validation flow when re-activated.
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 5. AGENT ACCESS GAP (validation flow blockers) ═══');
  console.log(`  For each Lead.Group__c set, check whether the Lead.OwnerId has an Approved User_Group_Access to that Group.`);

  // Pull leads + owners + groups, excluding converted (those are frozen) and Queue-owned leads
  const ownedLeads: any[] = await sf.soql(
    `SELECT Id, OwnerId, Group__c, Owner.Type FROM Lead WHERE Group__c != null AND IsConverted = false`
  );
  console.log(`  Active (non-converted) leads with Group__c set: ${ownedLeads.length}`);

  const gapByUser = new Map<string, { leadCount: number; userName: string; gapGroups: Map<string, number> }>();
  let queueOwnedSkipped = 0;
  let userOwnedTotal = 0;
  let gapLeadCount = 0;

  // Build a User lookup for owner names
  const userIds = [...new Set(ownedLeads.filter((l) => l.OwnerId?.startsWith('005')).map((l) => l.OwnerId))];
  const userIdsChunks: string[][] = [];
  for (let i = 0; i < userIds.length; i += 800) userIdsChunks.push(userIds.slice(i, i + 800).map((id) => `'${id}'`));
  const userNames = new Map<string, string>();
  for (const c of userIdsChunks) {
    const us: any[] = await sf.soql(`SELECT Id, Name FROM User WHERE Id IN (${c.join(',')})`);
    for (const u of us) userNames.set(u.Id, u.Name);
  }

  const groupNames = new Map<string, string>();
  for (const g of allGroups) groupNames.set(g.Id, g.Name);

  for (const l of ownedLeads) {
    if (!l.OwnerId?.startsWith('005')) { queueOwnedSkipped++; continue; }
    userOwnedTotal++;
    const userGroups = accessByUser.get(l.OwnerId);
    if (!userGroups || !userGroups.has(l.Group__c)) {
      gapLeadCount++;
      if (!gapByUser.has(l.OwnerId)) gapByUser.set(l.OwnerId, {
        leadCount: 0, userName: userNames.get(l.OwnerId) || l.OwnerId, gapGroups: new Map(),
      });
      const e = gapByUser.get(l.OwnerId)!;
      e.leadCount++;
      e.gapGroups.set(l.Group__c, (e.gapGroups.get(l.Group__c) || 0) + 1);
    }
  }

  console.log(`  Queue-owned leads (skipped — Queue doesn't need access): ${queueOwnedSkipped}`);
  console.log(`  User-owned leads checked: ${userOwnedTotal}`);
  console.log(`  ⚠ Leads where OWNER LACKS ACCESS to their lead's group: ${gapLeadCount}`);
  console.log(`  ⚠ Distinct owners with gaps: ${gapByUser.size}`);

  if (gapByUser.size > 0) {
    const sorted = [...gapByUser.entries()].sort((a, b) => b[1].leadCount - a[1].leadCount);
    console.log(`\n  Top owners by access-gap count:`);
    for (const [uid, info] of sorted.slice(0, 15)) {
      console.log(`    ${info.userName} (${uid}) — ${info.leadCount} leads across ${info.gapGroups.size} groups`);
      const topGroups = [...info.gapGroups.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
      for (const [gid, n] of topGroups) {
        console.log(`        ${n}× "${groupNames.get(gid) || gid}"`);
      }
    }
  }

  // ───────────────────────────────────────────────────────────
  // 6. Validation Flow status
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 6. Validation Flow status ═══');
  const flows: any[] = await sf.toolingQuery(
    `SELECT MasterLabel, ProcessType, Status FROM Flow WHERE ProcessType = 'AutoLaunchedFlow' AND Status = 'Active'`
  );
  let foundGroupCheck = false;
  for (const f of flows) {
    if (/group/i.test(f.MasterLabel) && /access|check/i.test(f.MasterLabel)) {
      foundGroupCheck = true;
      console.log(`  ⚠ ACTIVE: "${f.MasterLabel}"`);
    }
  }
  if (!foundGroupCheck) console.log(`  ✓ "Lead Group Access Check" flow is INACTIVE (good — re-activate after the announce/agent-comms)`);

  // ───────────────────────────────────────────────────────────
  // 7. Properties + Group__c
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 7. Properties using Group__c ═══');
  const propStats: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Property__c`);
  const propWithGroup: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Property__c WHERE Group__c != null`);
  console.log(`  Total properties: ${propStats[0].cnt}`);
  console.log(`  Properties with Group__c set: ${propWithGroup[0].cnt}`);

  // ───────────────────────────────────────────────────────────
  // 8. Group_old2 — should we plan to clear it?
  // ───────────────────────────────────────────────────────────
  console.log('\n═══ 8. Group_old2 field status ═══');
  const oldFieldSet: any[] = await sf.soql(`SELECT COUNT(Id) cnt FROM Lead WHERE Group_old2__c != null`);
  console.log(`  Leads still with Group_old2 populated: ${oldFieldSet[0].cnt}`);
  console.log(`  (We intentionally did NOT clear the legacy field — keeps the audit trail.)`);
}

main().catch((e) => { console.error(e); process.exit(1); });
