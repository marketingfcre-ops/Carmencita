/**
 * Investigate the agent-review count mismatch: my table vs what each agent
 * sees on their /review dashboard.
 *
 * For each agent, breaks down their listings by SF Status__c so we can see:
 *   - Active + has review entry  → dash shows ✅ reviewed
 *   - Active + no review entry   → dash shows ⏳ pending
 *   - NON-Active (any other)     → dash HIDES these
 *
 * Also compares against /debug on Railway to detect cache-lag records
 * (recently created/modified that haven't been picked up by the cache yet).
 *
 * Read-only.
 */

const SF_LOGIN_URL = process.env.SF_LOGIN_URL || '';
const SF_CLIENT_ID = process.env.SF_CLIENT_ID || '';
const SF_CLIENT_SECRET = process.env.SF_CLIENT_SECRET || '';

const APP_URL =
  process.env.APP_URL || 'https://node-websockets-ai-attendant-production.up.railway.app';

interface SfProperty {
  Id: string;
  Name: string;
  Address__c: string | null;
  Status__c: string | null;
  Listing_Agent__c: string | null;
  Listing_Agent__r: { Name: string } | null;
  Notes_for_Marketing__c: string | null;
  CreatedDate: string;
  LastModifiedDate: string;
}

async function sfAuth() {
  const res = await fetch(`${SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: SF_CLIENT_ID,
      client_secret: SF_CLIENT_SECRET,
    }).toString(),
  });
  const j = (await res.json()) as any;
  return { token: j.access_token, instance: j.instance_url };
}

async function sfQuery<T>(token: string, instance: string, soql: string): Promise<T[]> {
  let url: string | null = `${instance}/services/data/v59.0/query?q=${encodeURIComponent(soql)}`;
  const all: T[] = [];
  while (url) {
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`SOQL ${res.status} ${await res.text()}`);
    const data = (await res.json()) as { records?: T[]; nextRecordsUrl?: string };
    all.push(...(data.records || []));
    url = data.nextRecordsUrl ? `${instance}${data.nextRecordsUrl}` : null;
  }
  return all;
}

function hasReview(notes: string | null): boolean {
  if (!notes) return false;
  return /\[Agent Review \d{4}-\d{2}-\d{2}\]/.test(notes);
}

async function main() {
  if (!SF_CLIENT_ID) {
    console.error('❌ Missing SF env vars.');
    process.exit(1);
  }

  console.log('\n🔍 Agent review discrepancy investigation\n');

  // 1. Check the cache's lastRefresh
  console.log('── Step 1: Railway cache freshness ──');
  let cacheRefreshTime: string | null = null;
  try {
    const dbg = await fetch(`${APP_URL}/debug`);
    if (dbg.ok) {
      const data = (await dbg.json()) as any;
      cacheRefreshTime = data?.salesforce?.lastRefresh || null;
      console.log(`   Cached properties:    ${data?.salesforce?.properties}`);
      console.log(`   Cached agents:        ${data?.salesforce?.agents}`);
      console.log(`   Last cache refresh:   ${cacheRefreshTime}`);
      if (cacheRefreshTime) {
        const ageMin = (Date.now() - new Date(cacheRefreshTime).getTime()) / 60_000;
        console.log(`   Cache age:            ${ageMin.toFixed(1)} minutes`);
      }
    } else {
      console.log(`   ⚠️ /debug returned ${dbg.status}`);
    }
  } catch (err) {
    console.log(`   ⚠️ Could not reach /debug: ${err}`);
  }
  console.log('');

  // 2. Pull all SF property records with agent (any status)
  console.log('── Step 2: Live SF — break down by agent × status ──');
  const { token, instance } = await sfAuth();
  const all = await sfQuery<SfProperty>(
    token,
    instance,
    `SELECT Id, Name, Address__c, Status__c, Listing_Agent__c, Listing_Agent__r.Name,
            Notes_for_Marketing__c, CreatedDate, LastModifiedDate
       FROM Property__c
      WHERE Listing_Agent__c != NULL`
  );
  console.log(`   ${all.length} total agent-assigned property records in SF\n`);

  // Group by agent
  interface Bucket {
    name: string;
    activeReviewed: number;
    activePending: number;
    nonActiveByStatus: Map<string, number>;
    afterCacheRefresh: SfProperty[];
    activePendingRecords: SfProperty[];
  }
  const byAgent = new Map<string, Bucket>();
  const cacheTime = cacheRefreshTime ? new Date(cacheRefreshTime).getTime() : 0;

  for (const r of all) {
    const agentId = r.Listing_Agent__c!;
    const agentName = r.Listing_Agent__r?.Name || agentId;
    let b = byAgent.get(agentId);
    if (!b) {
      b = {
        name: agentName,
        activeReviewed: 0,
        activePending: 0,
        nonActiveByStatus: new Map(),
        afterCacheRefresh: [],
        activePendingRecords: [],
      };
      byAgent.set(agentId, b);
    }
    if ((r.Status__c || '').toLowerCase() === 'active') {
      if (hasReview(r.Notes_for_Marketing__c)) b.activeReviewed++;
      else {
        b.activePending++;
        b.activePendingRecords.push(r);
      }
    } else {
      const s = r.Status__c || '(none)';
      b.nonActiveByStatus.set(s, (b.nonActiveByStatus.get(s) || 0) + 1);
    }

    // Check if this record is newer than cache
    const lastMod = new Date(r.LastModifiedDate).getTime();
    if (cacheTime > 0 && lastMod > cacheTime) {
      b.afterCacheRefresh.push(r);
    }
  }

  // Sort by pending desc, then by total desc
  const rows = [...byAgent.values()]
    .map((b) => ({
      ...b,
      total: b.activeReviewed + b.activePending,
    }))
    .sort((a, b) => b.activePending - a.activePending || b.total - a.total);

  // Print compact table
  console.log('AGENT                  ACTIVE_REV  ACTIVE_PEND  NON-ACTIVE-SUMMARY                              MODIFIED_AFTER_CACHE');
  console.log('─'.repeat(140));
  for (const r of rows) {
    if (r.total === 0 && r.nonActiveByStatus.size === 0) continue;
    const nonActive =
      r.nonActiveByStatus.size === 0
        ? '—'
        : [...r.nonActiveByStatus.entries()].map(([s, n]) => `${s}=${n}`).join(', ');
    const newer = r.afterCacheRefresh.length;
    const newerFlag = newer > 0 ? `⚠️ ${newer} newer than cache` : '';
    console.log(
      `${r.name.padEnd(22)} ${String(r.activeReviewed).padStart(10)}  ${String(r.activePending).padStart(11)}  ${nonActive.padEnd(48)}  ${newerFlag}`
    );
  }
  console.log('');

  // 3. Focus on agents the user mentioned: Martina, Halain
  const focus = ['Martina Smoláková', 'Halain Suarez'];
  for (const name of focus) {
    const entry = rows.find((r) => r.name === name);
    if (!entry) continue;
    console.log(`── ${name} pending records detail ──`);
    for (const r of entry.activePendingRecords) {
      const newer = cacheTime > 0 && new Date(r.LastModifiedDate).getTime() > cacheTime;
      console.log(
        `   ${r.Id}  Status=${r.Status__c}  modified=${r.LastModifiedDate.slice(0, 19)}  ${newer ? '⚠️ NEWER THAN CACHE' : '✓ in cache window'}`
      );
      console.log(`     ${r.Address__c || r.Name}`);
    }
    console.log('');
  }

  // 4. Summary of explanations
  console.log('══════════════════════════════════════════════════════════════════════════════');
  console.log('INTERPRETATION');
  console.log('══════════════════════════════════════════════════════════════════════════════');
  console.log(`
  • ACTIVE_PEND column = what should show as "Pending" on the agent's dash
  • Compare to your table — if numbers don't match, see why:
    - If agent shows MODIFIED_AFTER_CACHE > 0 → cache is stale for them
    - If NON-ACTIVE-SUMMARY has values → those listings are mid-deal
      (Pending/Contract Signed/LOI Signed) — dash hides them by design
    - For the focus agents above, check the per-record detail to see
      whether the "pending" listings are recent enough to be missing
      from the cache
  `);
  process.exit(0);
}

main().catch((err) => {
  console.error('💀 Crashed:', err);
  process.exit(1);
});
