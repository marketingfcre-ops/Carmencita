/**
 * Audit General FCom List (or any CM list): categorize its subscribers into
 * the Loopnet-{AssetType}-for-{Intent} lists by cross-referencing against
 * Salesforce Leads + Property__c records.
 *
 * Match strategy per subscriber:
 *   1. If SF Lead.Listing__c is set → direct lookup (high confidence).
 *   2. Parse Lead.Property__c (or Company) text for an address →
 *      normalize → look up in Property__c address index. Intent comes from
 *      Property.Listing_Type__c.
 *   3. Fall back to keyword mapping on Lead.Group_old2__c (99% populated).
 *      Gets asset type only — no intent.
 *
 * Outputs a per-bucket preview CSV under data/cm_audit/ and a summary.
 * Does NOT write to CM (read-only audit for now).
 *
 * Run:
 *   npx tsx --env-file .env.local scripts/cm-audit.ts
 *   npx tsx --env-file .env.local scripts/cm-audit.ts --list "General FCom List"
 */

import { mkdirSync, writeFileSync } from 'fs';
import { join } from 'path';

import {
  listClients,
  listLists,
  getAllSubscribers,
  importSubscribersBatched,
  deleteSubscriber,
  CMSubscriber,
  CMSubscriberInput,
} from '../../src/campaign-monitor';

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
function parseArgs(): { listName: string; apply: boolean; removeFromSource: boolean } {
  const a = process.argv.slice(2);
  let listName = 'General FCom List';
  let apply = false;
  let removeFromSource = false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--list') listName = a[++i] || listName;
    else if (a[i] === '--apply') apply = true;
    else if (a[i] === '--remove-from-source') removeFromSource = true;
  }
  return { listName, apply, removeFromSource };
}

const OUTPUT_DIR = join(process.cwd(), 'data', 'cm_audit');

// ---------------------------------------------------------------------------
// SF helpers
// ---------------------------------------------------------------------------
async function sfAuth() {
  const params = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: (process.env.SF_CLIENT_ID || '').trim(),
    client_secret: (process.env.SF_CLIENT_SECRET || '').trim(),
  });
  const r = await fetch(`${process.env.SF_LOGIN_URL}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
  });
  if (!r.ok) throw new Error(`SF auth: ${r.status} ${await r.text()}`);
  return (await r.json()) as { access_token: string; instance_url: string };
}

async function soqlAll<T = any>(instance: string, token: string, q: string): Promise<T[]> {
  let url: string | null =
    `${instance}/services/data/v59.0/query?q=${encodeURIComponent(q)}`;
  const out: T[] = [];
  while (url) {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) throw new Error(`${r.status} ${await r.text()}`);
    const d = (await r.json()) as { records: T[]; done: boolean; nextRecordsUrl?: string };
    out.push(...d.records);
    url = d.nextRecordsUrl ? `${instance}${d.nextRecordsUrl}` : null;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Address normalization
// ---------------------------------------------------------------------------
const STREET_ABBR: Record<string, string> = {
  street: 'st',   str: 'st',
  avenue: 'ave',  av: 'ave',
  road: 'rd',
  boulevard: 'blvd', boulavard: 'blvd',
  drive: 'dr',
  court: 'ct',
  lane: 'ln',
  place: 'pl',
  parkway: 'pkwy',
  highway: 'hwy',
  terrace: 'ter',
  circle: 'cir',
  square: 'sq',
  way: 'way',
  trail: 'trl',
  north: 'n', south: 's', east: 'e', west: 'w',
  northeast: 'ne', northwest: 'nw', southeast: 'se', southwest: 'sw',
};

const STOPWORDS = new Set(['the', 'and', 'of']);

function normWord(w: string): string {
  const clean = w.toLowerCase().replace(/[^\w]/g, '');
  if (STOPWORDS.has(clean)) return '';
  if (STREET_ABBR[clean]) return STREET_ABBR[clean];
  // "29th" → "29"
  const ord = clean.match(/^(\d+)(st|nd|rd|th)$/);
  if (ord) return ord[1];
  return clean;
}

function normalizeAddress(s: string): string {
  if (!s) return '';
  return s
    .split(/[\s,.\-|]+/)
    .map(normWord)
    .filter(Boolean)
    .join(' ');
}

/** Extract street + city + zip from an address-like string. */
function splitAddressParts(s: string): { street: string; city: string; state: string; zip: string } {
  // Formats seen:
  //   "180 NE 29th St | Miami, FL 33137"
  //   "180 NE 29th St, Miami, FL 33137"
  //   "1151 WASHINGTON AVE"
  //   "PEMBROKE RD"
  let street = '', city = '', state = '', zip = '';
  const zipMatch = s.match(/\b(\d{5})(-\d{4})?\b/);
  if (zipMatch) zip = zipMatch[1];

  // Split on | first, then ,
  const parts = s.split(/[|]/).map((p) => p.trim()).filter(Boolean);
  if (parts.length >= 2) {
    street = parts[0];
    const rest = parts.slice(1).join(', ');
    const cityMatch = rest.match(/([^,]+?)\s*,\s*([A-Z]{2})/);
    if (cityMatch) { city = cityMatch[1]; state = cityMatch[2]; }
    else city = rest.replace(/\b\d{5}\b.*$/, '').trim();
  } else {
    const commaParts = s.split(',').map((p) => p.trim()).filter(Boolean);
    street = commaParts[0] || '';
    if (commaParts.length >= 2) {
      const m2 = commaParts.slice(1).join(', ').match(/([^,]+?)\s*,\s*([A-Z]{2})/);
      if (m2) { city = m2[1]; state = m2[2]; }
    }
  }
  return { street, city, state, zip };
}

// ---------------------------------------------------------------------------
// WordPress property fetch (public, no auth)
// ---------------------------------------------------------------------------
const WP_BASE = 'https://faustocommercial.com/wp-json/wp/v2';

// term ID → WP taxonomy name; we then map these to SF-style values.
async function wpFetchTerms(tax: string): Promise<Map<number, string>> {
  const map = new Map<number, string>();
  let page = 1;
  for (;;) {
    const r = await fetch(`${WP_BASE}/${tax}?per_page=100&page=${page}`);
    if (!r.ok) break;
    const terms = (await r.json()) as Array<{ id: number; name: string }>;
    if (!terms.length) break;
    for (const t of terms) map.set(t.id, t.name);
    const total = Number(r.headers.get('x-wp-totalpages') || 1);
    if (page >= total) break;
    page++;
  }
  return map;
}

// WP property_type term name → canonical SF-style asset type (lowercase)
function wpTypeToSf(name: string): string {
  const s = name.toLowerCase();
  if (s.includes('industrial')) return 'Industrial';
  if (s.includes('retail')) return 'Retail';
  if (s.includes('office') || s.includes('medical')) return 'Office';
  if (s.includes('multi')) return 'Multi-Family';
  if (s.includes('land')) return 'Land';
  if (s.includes('hotel') || s.includes('hospitality')) return 'Hospitality';
  return name;
}

interface WpPropertyRaw {
  id: number;
  title: { rendered: string };
  property_type: number[];
  property_status: number[];
  property_city: number[];
}

async function fetchWpProperties(): Promise<SFProp[]> {
  const [typeMap, statusMap, cityMap] = await Promise.all([
    wpFetchTerms('property_type'),
    wpFetchTerms('property_status'),
    wpFetchTerms('property_city'),
  ]);

  const out: SFProp[] = [];
  let page = 1;
  for (;;) {
    const url = `${WP_BASE}/properties?per_page=100&page=${page}&_fields=id,title,property_type,property_status,property_city`;
    const r = await fetch(url);
    if (!r.ok) break;
    const items = (await r.json()) as WpPropertyRaw[];
    if (!items.length) break;
    for (const it of items) {
      const title = (it.title?.rendered || '').replace(/&amp;/g, '&').trim();
      const types = (it.property_type || []).map((id) => typeMap.get(id) || '').filter(Boolean);
      const statuses = (it.property_status || []).map((id) => statusMap.get(id) || '').filter(Boolean);
      const city = (it.property_city || []).map((id) => cityMap.get(id) || '').filter(Boolean)[0] || '';
      out.push({
        id: `wp:${it.id}`,
        name: title,
        address: title,           // WP title IS the street address
        city,
        zipCode: '',
        propertyType: types.map(wpTypeToSf).join(';'),
        listingType: statuses.join(';'),   // e.g. "For Sale" / "For Lease"
        status: 'Active',
        source: 'wp',
      });
    }
    const total = Number(r.headers.get('x-wp-totalpages') || 1);
    if (page >= total) break;
    page++;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Property index (shared shape for SF + WP rows)
// ---------------------------------------------------------------------------
interface SFProp {
  id: string;            // "sf:<sfId>" or "wp:<wpId>"
  name: string;
  address: string;
  city: string;
  zipCode: string;
  propertyType: string;  // multi-select ; separated (SF format)
  listingType: string;   // For Sale / For Lease / Sold / etc.
  status: string;
  source: 'sf' | 'wp';
}

interface PropIndex {
  byStreetZip: Map<string, SFProp[]>;
  byStreetCity: Map<string, SFProp[]>;
  byStreet: Map<string, SFProp[]>;
  byId: Map<string, SFProp>;
}

function buildPropIndex(props: SFProp[]): PropIndex {
  const idx: PropIndex = {
    byStreetZip: new Map(),
    byStreetCity: new Map(),
    byStreet: new Map(),
    byId: new Map(),
  };
  const push = (m: Map<string, SFProp[]>, k: string, v: SFProp) => {
    if (!k) return;
    const arr = m.get(k);
    if (arr) arr.push(v); else m.set(k, [v]);
  };
  for (const p of props) {
    idx.byId.set(p.id, p);
    const street = normalizeAddress(p.address);
    const cityN = normalizeAddress(p.city);
    if (!street) continue;
    if (p.zipCode) push(idx.byStreetZip, `${street}|${p.zipCode}`, p);
    if (cityN)     push(idx.byStreetCity, `${street}|${cityN}`, p);
    push(idx.byStreet, street, p);
  }
  return idx;
}

function lookupProperty(text: string, idx: PropIndex): SFProp | null {
  if (!text) return null;
  const parts = splitAddressParts(text);
  const street = normalizeAddress(parts.street);
  if (!street) return null;
  const cityN = normalizeAddress(parts.city);

  // Tier 1: street + zip
  if (parts.zip) {
    const m = idx.byStreetZip.get(`${street}|${parts.zip}`);
    if (m && m.length === 1) return m[0];
    if (m && m.length > 1) return m[0]; // same street same zip → same property, just pick one
  }
  // Tier 2: street + city
  if (cityN) {
    const m = idx.byStreetCity.get(`${street}|${cityN}`);
    if (m && m.length === 1) return m[0];
  }
  // Tier 3: street alone (only if unambiguous)
  const m3 = idx.byStreet.get(street);
  if (m3 && m3.length === 1) return m3[0];

  return null;
}

// ---------------------------------------------------------------------------
// Group_old2__c keyword → asset type (heuristic)
// ---------------------------------------------------------------------------
function classifyGroup(g: string): string | null {
  if (!g) return null;
  const s = g.toLowerCase();
  // Order matters: check specific before generic substrings.
  if (/(hotel|hospitality)/.test(s)) return null; // no dedicated list
  if (/(med|healthcare|medical)/.test(s)) return 'medical office';
  if (/(apt|apts|multifam|multi-fam|resi\b|residential|mf\b|\bmulti)/.test(s)) return 'multi-family';
  if (/(ind|industrial|warehouse)/.test(s)) return 'industrial';
  if (/(retail|ret\b|shop|shopping)/.test(s)) return 'retail';
  if (/(land|vacant)/.test(s)) return 'land';
  if (/(office|\bcom\b|commercial)/.test(s)) return 'office';
  return null;
}

// ---------------------------------------------------------------------------
// Asset type from SF Property_Type__c multi-select
// ---------------------------------------------------------------------------
function classifyPropertyType(propType: string): string | null {
  if (!propType) return null;
  const types = propType.split(';').map((t) => t.trim().toLowerCase());
  if (types.includes('healthcare')) return 'medical office';
  if (types.includes('office')) return 'office';
  if (types.includes('multi-family')) return 'multi-family';
  if (types.includes('industrial')) return 'industrial';
  if (types.includes('retail')) return 'retail';
  if (types.includes('land development') || types.includes('land')) return 'land development';
  return null;
}

function normalizeIntent(listingType: string): 'sale' | 'lease' | null {
  const s = (listingType || '').toLowerCase();
  if (s.includes('sale')) return 'sale';
  if (s.includes('lease')) return 'lease';
  return null;
}

// Routing rules:
//   - Multi-Family, Land, Land Development: always Sale (never Lease per user).
//   - All other types: use known intent if we have it, otherwise default to Sale.
const SALE_ONLY_TYPES = new Set(['multi-family', 'land', 'land development']);

function chooseCmList(assetType: string, intent?: 'sale' | 'lease' | null): string | null {
  if (!assetType) return null;
  const effective: 'sale' | 'lease' =
    SALE_ONLY_TYPES.has(assetType) ? 'sale' : (intent || 'sale');
  const key = `${assetType}|${effective}`;
  const map: Record<string, string> = {
    'industrial|sale':        'Loopnet Industrial For Sale',
    'industrial|lease':       'Loopnet Industrial For Lease',
    'retail|sale':            'Loopnet Retail for Sale',
    'retail|lease':           'Loopnet Retail for Lease',
    'office|sale':            'Loopnet Office for Sale',
    'office|lease':           'Loopnet Office for Lease',
    'medical office|sale':    'Loopnet Medical Office for Sale',
    'medical office|lease':   'Loopnet Medical Office for Lease',
    'multi-family|sale':      'Loopnet Multi-Family for Sale',
    'land development|sale':  'Loopnet Land Development for Sale',
    'land|sale':              'Loopnet Land Development for Sale',  // merged
  };
  return map[key] || null;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
async function main() {
  const args = parseArgs();
  const apiKey = process.env.CM_API_KEY;
  if (!apiKey) { console.error('CM_API_KEY not set'); process.exit(1); }

  console.log(`Looking up CM list "${args.listName}"…`);
  const clients = await listClients(apiKey);
  const clientId = clients[0].ClientID;
  const lists = await listLists(apiKey, clientId);
  const target = lists.find((l) => l.Name.toLowerCase() === args.listName.toLowerCase());
  if (!target) { console.error(`List not found: ${args.listName}`); process.exit(1); }
  console.log(`  ListID: ${target.ListID}`);

  console.log('Fetching all active subscribers (this can take a minute)…');
  const subs = await getAllSubscribers(apiKey, target.ListID, 'active');
  const subEmails = new Set(subs.map((s) => s.EmailAddress.toLowerCase()));
  console.log(`  ${subs.length} active subscribers`);

  const sf = await sfAuth();
  const tok = sf.access_token, iurl = sf.instance_url;

  console.log('Fetching Property__c records (all statuses)…');
  const props = await soqlAll<any>(
    iurl, tok,
    `SELECT Id, Name, Address__c, City__c, Zip_Code__c,
            Property_Type__c, Listing_Type__c, Status__c
     FROM Property__c`
  );
  const propList: SFProp[] = props.map((p) => ({
    id: `sf:${p.Id}`, name: p.Name || '',
    address: p.Address__c || '', city: p.City__c || '', zipCode: p.Zip_Code__c || '',
    propertyType: p.Property_Type__c || '', listingType: p.Listing_Type__c || '',
    status: p.Status__c || '', source: 'sf',
  }));

  // Also pull published WordPress properties (no auth) and merge into the index.
  console.log('Fetching WordPress properties (public API)…');
  const wpProps = await fetchWpProperties();
  propList.push(...wpProps);
  console.log(`  ${wpProps.length} WP properties added (total index: ${propList.length})`);

  const idx = buildPropIndex(propList);

  console.log('Fetching SF Leads with email matching subscribers (chunked)…');
  const emails = [...subEmails];
  const CHUNK = 200;
  type SFLead = {
    Id: string; Email: string; Company: string;
    Property__c: string; Listing__c: string | null;
    Group_old2__c: string;
  };
  const leads: SFLead[] = [];
  for (let i = 0; i < emails.length; i += CHUNK) {
    const chunk = emails.slice(i, i + CHUNK);
    // SOQL IN clause on Email — sanitize quotes
    const inClause = chunk.map((e) => `'${e.replace(/'/g, "\\'")}'`).join(',');
    const soql =
      `SELECT Id, Email, Company, Property__c, Listing__c, Group_old2__c ` +
      `FROM Lead WHERE Email IN (${inClause})`;
    const rows = await soqlAll<SFLead>(iurl, tok, soql);
    leads.push(...rows);
    if ((i / CHUNK) % 10 === 0) {
      process.stdout.write(`\r  queried ${Math.min(i + CHUNK, emails.length)}/${emails.length}`);
    }
  }
  process.stdout.write(`\r  queried all ${emails.length} emails; matched ${leads.length} SF Leads\n`);

  // One email may have multiple Leads — pick the one with the most info (Listing__c > Property__c > Group_old2__c).
  const bestPerEmail = new Map<string, SFLead>();
  const leadScore = (l: SFLead) =>
    (l.Listing__c ? 100 : 0) + (l.Property__c ? 10 : 0) + (l.Group_old2__c ? 1 : 0);
  for (const l of leads) {
    const e = (l.Email || '').toLowerCase();
    if (!e) continue;
    const prev = bestPerEmail.get(e);
    if (!prev || leadScore(l) > leadScore(prev)) bestPerEmail.set(e, l);
  }

  // Classify each subscriber
  interface AuditRow {
    email: string;
    name: string;
    matched_lead_id: string;
    matched_source: 'listing_ref' | 'address_match' | 'group_keyword' | 'none';
    asset_type: string;
    intent: string;
    target_list: string;
    source_field: string;
    source_value: string;
    property_id: string;
    property_address: string;
  }

  const audit: AuditRow[] = [];
  const byTarget = new Map<string, AuditRow[]>();

  for (const sub of subs) {
    const email = sub.EmailAddress.toLowerCase();
    const name = sub.Name;
    const lead = bestPerEmail.get(email);
    const row: AuditRow = {
      email, name,
      matched_lead_id: lead?.Id || '',
      matched_source: 'none',
      asset_type: '', intent: '', target_list: '',
      source_field: '', source_value: '',
      property_id: '', property_address: '',
    };

    if (lead) {
      // Tier 1: direct reference
      if (lead.Listing__c) {
        const p = idx.byId.get(lead.Listing__c);
        if (p) {
          row.matched_source = 'listing_ref';
          row.source_field = 'Listing__c';
          row.source_value = p.address;
          row.property_id = p.id;
          row.property_address = `${p.address}, ${p.city}`;
          const at = classifyPropertyType(p.propertyType);
          const it = normalizeIntent(p.listingType);
          if (at) row.asset_type = at;
          if (it) row.intent = it;
        }
      }
      // Tier 2: address match from Property__c or Company
      if (row.matched_source === 'none') {
        for (const [field, value] of [
          ['Property__c', lead.Property__c],
          ['Company', lead.Company],
        ] as const) {
          if (!value) continue;
          const p = lookupProperty(value, idx);
          if (p) {
            row.matched_source = 'address_match';
            row.source_field = field;
            row.source_value = value;
            row.property_id = p.id;
            row.property_address = `${p.address}, ${p.city}`;
            const at = classifyPropertyType(p.propertyType);
            const it = normalizeIntent(p.listingType);
            if (at) row.asset_type = at;
            if (it) row.intent = it;
            break;
          }
        }
      }
      // Tier 3: keyword from Group_old2__c (asset type only)
      if (row.matched_source === 'none' && lead.Group_old2__c) {
        const at = classifyGroup(lead.Group_old2__c);
        if (at) {
          row.matched_source = 'group_keyword';
          row.source_field = 'Group_old2__c';
          row.source_value = lead.Group_old2__c;
          row.asset_type = at;
        }
      }
    }

    if (row.asset_type) {
      row.target_list = chooseCmList(row.asset_type, (row.intent || null) as any) || '';
    }

    audit.push(row);
    const bucket = row.target_list || (lead ? 'unclassified' : 'no_sf_lead');
    if (!byTarget.has(bucket)) byTarget.set(bucket, []);
    byTarget.get(bucket)!.push(row);
  }

  // Summary
  console.log('\nAudit summary:');
  const sorted = [...byTarget].sort((a, b) => b[1].length - a[1].length);
  for (const [bucket, rows] of sorted) {
    const bySource = rows.reduce((acc, r) => { acc[r.matched_source] = (acc[r.matched_source] || 0) + 1; return acc; }, {} as Record<string, number>);
    const srcLabel = Object.entries(bySource).map(([k, v]) => `${k}:${v}`).join(' ');
    console.log(`  ${bucket.padEnd(40)} ${String(rows.length).padStart(5)}   (${srcLabel})`);
  }

  // Write CSVs
  mkdirSync(OUTPUT_DIR, { recursive: true });
  const fields: (keyof AuditRow)[] = [
    'email', 'name', 'matched_lead_id', 'matched_source',
    'asset_type', 'intent', 'target_list',
    'source_field', 'source_value', 'property_id', 'property_address',
  ];
  const esc = (v: string) => `"${(v || '').replace(/"/g, '""')}"`;
  const writeCsv = (path: string, rows: AuditRow[]) => {
    const lines = [fields.join(',')];
    for (const r of rows) lines.push(fields.map((f) => esc(String(r[f] || ''))).join(','));
    writeFileSync(path, lines.join('\n'));
  };
  writeCsv(join(OUTPUT_DIR, 'audit_all.csv'), audit);
  for (const [bucket, rows] of byTarget) {
    const safe = bucket.replace(/[^\w.-]/g, '_');
    writeCsv(join(OUTPUT_DIR, `${safe}.csv`), rows);
  }
  console.log(`\nWrote ${audit.length} rows to ${OUTPUT_DIR}/`);

  // -------- Apply (actually push to CM) --------
  if (!args.apply) {
    console.log('\n(Dry-run: re-run with --apply to push to Campaign Monitor.)');
    if (args.removeFromSource) {
      console.log('Note: --remove-from-source is ignored without --apply.');
    }
    return;
  }

  // Resolve list IDs for every target_list we need.
  const listIdByName = new Map(lists.map((l) => [l.Name.toLowerCase(), l.ListID]));

  // Group audit rows by target_list (skip rows with no target).
  const byList = new Map<string, { email: string; name: string }[]>();
  for (const row of audit) {
    if (!row.target_list) continue;
    const arr = byList.get(row.target_list) || [];
    arr.push({ email: row.email, name: row.name || row.email });
    byList.set(row.target_list, arr);
  }

  const total = [...byList.values()].reduce((a, b) => a + b.length, 0);
  console.log(`\n--- APPLY --- pushing ${total} subscribers across ${byList.size} lists`);
  if (args.removeFromSource) {
    console.log(`    (and removing from "${args.listName}" after each successful copy)`);
  }

  const allMoved: string[] = []; // emails successfully placed somewhere
  for (const [listName, rows] of byList) {
    const listId = listIdByName.get(listName.toLowerCase());
    if (!listId) {
      console.error(`  SKIP: CM list not found by name: ${listName}`);
      continue;
    }
    const subs: CMSubscriberInput[] = rows.map((r) => ({
      EmailAddress: r.email,
      Name: r.name,
      ConsentToTrack: 'Unchanged' as const,
    }));
    try {
      const res = await importSubscribersBatched(apiKey, listId, subs);
      console.log(
        `  ${listName.padEnd(42)} new=${res.TotalNewSubscribers}  existing=${res.TotalExistingSubscribers}  failures=${res.FailureDetails.length}`
      );
      if (res.FailureDetails.length) {
        const safe = listName.replace(/[^\w.-]/g, '_');
        writeFileSync(
          join(OUTPUT_DIR, `failures_${safe}.json`),
          JSON.stringify(res.FailureDetails, null, 2)
        );
      }
      const failedEmails = new Set(res.FailureDetails.map((f) => f.EmailAddress.toLowerCase()));
      for (const r of rows) {
        if (!failedEmails.has(r.email)) allMoved.push(r.email);
      }
    } catch (e) {
      console.error(`  ERROR pushing to ${listName}:`, e);
    }
  }

  if (args.removeFromSource && allMoved.length) {
    console.log(`\nRemoving ${allMoved.length} emails from "${args.listName}"…`);
    let removed = 0;
    let failed = 0;
    for (const email of allMoved) {
      try {
        await deleteSubscriber(apiKey, target.ListID, email);
        removed++;
        if (removed % 200 === 0) {
          process.stdout.write(`\r  removed ${removed}/${allMoved.length}`);
        }
      } catch {
        failed++;
      }
    }
    process.stdout.write(`\r  removed ${removed}/${allMoved.length} (${failed} failed)\n`);
  }

  console.log('\nDone.');
}

main().catch((e) => { console.error(e); process.exit(1); });
